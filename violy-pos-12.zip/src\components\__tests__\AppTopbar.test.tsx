// @vitest-environment jsdom

import { cleanup, render, screen, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { AppTopbar } from '@/components/AppTopbar'

// The account menu navigates with `useRouter` rather than a `<Link>`, because
// it is a menu item and not an anchor. Outside a Next request there is no
// router mounted, so the bar cannot render at all without this.
vi.mock('next/navigation', () => ({
  useRouter: () => ({ push: vi.fn(), refresh: vi.fn() }),
  usePathname: () => '/counter',
}))

// Signing out is a Server Action; this suite is about the bar's layout.
vi.mock('@/server/auth', () => ({ signOut: vi.fn(async () => ({ ok: true })) }))

const notifications = {
  overdueAccounts: [
    {
      customerId: 7,
      name: 'Maria Santos',
      balanceCentavos: 125_00,
      dueAt: new Date('2026-08-01T00:00:00.000Z'),
    },
  ],
  overdueInstallments: [],
  dueToday: [],
  updatesAvailable: 0,
  lowStock: [{ id: 11, name: 'Hog Grower', unit: 'sako', stockQty: 2, lowStockThreshold: 3 }],
  total: 2,
}

/** Every group populated, to prove the bell counts and lists all three. */
const withInstallments = {
  ...notifications,
  overdueInstallments: [
    {
      customerId: 7,
      name: 'Maria Santos',
      planId: 3,
      count: 2,
      oldestDueAt: new Date('2026-06-15T00:00:00.000Z'),
      amountCentavos: 230_000,
    },
  ],
  total: 3,
}

describe('AppTopbar', () => {
  it('places the live notification count in the utility region', () => {
    render(<AppTopbar notifications={notifications} username={null} />)
    const utilities = screen.getByRole('region', { name: 'Header utilities' })
    expect(within(utilities).getByRole('button', { name: '2 notifications' })).toBeInTheDocument()
    expect(within(utilities).getByText('2')).toBeInTheDocument()
  })

  it('closes notifications on Escape and restores focus to the trigger', async () => {
    const user = userEvent.setup()
    render(<AppTopbar notifications={notifications} username={null} />)
    const trigger = screen.getByRole('button', { name: '2 notifications' })

    await user.click(trigger)
    expect(screen.getByRole('region', { name: 'Notifications' })).toBeInTheDocument()

    await user.keyboard('{Escape}')
    expect(screen.queryByRole('region', { name: 'Notifications' })).not.toBeInTheDocument()
    expect(trigger).toHaveFocus()
  })

  it('carries no primary navigation — that belongs to the rail', () => {
    render(<AppTopbar notifications={notifications} username={null} />)
    expect(
      screen.queryByRole('navigation', { name: 'Primary navigation' }),
    ).not.toBeInTheDocument()
  })

  it('lists missed instalments separately from overdue balances', async () => {
    const user = userEvent.setup()
    render(<AppTopbar notifications={withInstallments} username={null} />)
    await user.click(screen.getByRole('button', { name: '3 notifications' }))

    // Two distinct sections, not one merged list: a missed instalment on an
    // agreed schedule is a different conversation from a stale balance.
    const missed = screen.getByRole('region', { name: 'Notifications' })
    expect(within(missed).getByText('Missed instalments')).toBeInTheDocument()
    expect(within(missed).getByText('Overdue accounts')).toBeInTheDocument()
    expect(within(missed).getByText(/2 months behind/)).toBeInTheDocument()

    // It links to that plan's invoice, not merely to the customer.
    expect(
      within(missed).getByRole('link', { name: /2 months behind/ }),
    ).toHaveAttribute('href', '/book/7/plan/3')
  })

  it('counts every group in the badge', () => {
    render(<AppTopbar notifications={withInstallments} username={null} />)
    expect(screen.getByRole('button', { name: '3 notifications' })).toBeInTheDocument()
  })
})

describe('the unread badge', () => {
  beforeEach(() => {
    window.localStorage.clear()
  })

  it('shows the count until the panel has been opened', async () => {
    const user = userEvent.setup()
    const { rerender } = render(<AppTopbar notifications={notifications} username={null} />)
    const trigger = screen.getByRole('button', { name: '2 notifications' })

    expect(within(trigger).getByText('2')).toBeInTheDocument()

    await user.click(trigger)
    // Marked read on OPEN, not on close: opening the panel is the act of
    // looking, and anything cleverer leaves her tapping the bell twice
    // wondering why the red dot is still there.
    expect(within(trigger).queryByText('2')).not.toBeInTheDocument()

    // Still gone after closing, and still gone on a later page load with the
    // same notifications — this is the whole point.
    await user.click(trigger)
    rerender(<AppTopbar notifications={notifications} username={null} />)
    expect(within(trigger).queryByText('2')).not.toBeInTheDocument()
  })

  it('comes back when something new arrives', async () => {
    const user = userEvent.setup()
    render(<AppTopbar notifications={notifications} username={null} />)
    await user.click(screen.getByRole('button', { name: '2 notifications' }))

    cleanup()
    render(<AppTopbar notifications={withInstallments} username={null} />)
    const trigger = screen.getByRole('button', { name: '3 notifications' })
    expect(within(trigger).getByText('3')).toBeInTheDocument()
  })

  it('stays quiet when the same accounts are simply worth more', async () => {
    const user = userEvent.setup()
    render(<AppTopbar notifications={notifications} username={null} />)
    await user.click(screen.getByRole('button', { name: '2 notifications' }))

    cleanup()
    // Same customer, same product, larger balance. Already seen.
    const grown = {
      ...notifications,
      overdueAccounts: [{ ...notifications.overdueAccounts[0], balanceCentavos: 900_00 }],
    }
    render(<AppTopbar notifications={grown} username={null} />)
    const trigger = screen.getByRole('button', { name: '2 notifications' })
    expect(within(trigger).queryByText('2')).not.toBeInTheDocument()
  })

  it('shows no badge at all when there is nothing to report', () => {
    const empty = {
      overdueAccounts: [],
      overdueInstallments: [],
      dueToday: [],
      lowStock: [],
      updatesAvailable: 0,
      total: 0,
    }
    render(<AppTopbar notifications={empty} username={null} />)
    const trigger = screen.getByRole('button', { name: 'Notifications' })
    expect(within(trigger).queryByText('0')).not.toBeInTheDocument()
  })
})
