'use server'

import { Prisma } from '@prisma/client'
import type { LedgerEntry } from '@prisma/client'
import { prisma } from '@/lib/db'
import { balanceDelta, isLedgerEntryType, sumBalance } from '@/lib/ledger-balance'
import { reconcileCustomerDueAt } from '@/server/account-due'
import { ROUTES } from '@/lib/routes'
import { revalidateRoutes } from './revalidate'
import { confirmationGate } from './session'
import type {
  ActionResult,
  BatchPaymentRow,
  BatchPaymentResult,
  CustomerWithBalance,
  LedgerEntryType,
  LedgerLine,
} from '@/lib/types'
import { prismaErrorCode } from '@/lib/prisma-errors'

/** The one implementation of the balance arithmetic lives in
 * `@/lib/ledger-balance`, shared with due-date reconciliation so the list,
 * detail ledger, and reminder state cannot disagree. */

export async function getBalance(customerId: number): Promise<number> {
  const entries = await prisma.ledgerEntry.findMany({
    where: { customerId, isVoided: false },
    select: { id: true, type: true, amountCentavos: true, isVoided: true },
  })
  return sumBalance(entries)
}

/**
 * Every customer with their balance, largest owed first — that ordering is
 * the one she acts on. Zero balances sort last but stay visible: they are
 * still who she picks from tomorrow.
 *
 * Archived customers appear too. Archiving hides a name from the picker; it
 * must not hide money that is still owed.
 */
export async function listCustomerBalances(): Promise<CustomerWithBalance[]> {
  const customers = await prisma.customer.findMany({
    include: {
      entries: {
        select: { id: true, type: true, amountCentavos: true, isVoided: true, occurredAt: true },
      },
      sales: { select: { createdAt: true }, orderBy: { createdAt: 'desc' }, take: 1 },
    },
  })

  return customers
    .map((customer) => ({
      customerId: customer.id,
      name: customer.name,
      phone: customer.phone,
      notes: customer.notes,
      isArchived: customer.isArchived,
      lastOrderedAt: customer.sales[0]?.createdAt ?? null,
      lastPaymentAt: lastPaymentDate(customer.entries),
      dueAt: customer.dueAt,
      balanceCentavos: sumBalance(customer.entries),
    }))
    .sort((a, b) => b.balanceCentavos - a.balanceCentavos || a.name.localeCompare(b.name))
}

/**
 * The newest non-voided PAYMENT date, or null. Voided payments are excluded
 * deliberately: a payment that was voided did not happen, and treating it as
 * a payment would make an account look current when nothing was collected.
 *
 * Derived from the entries already loaded for the balance rather than a
 * second query — the list renders every customer, so a per-customer round
 * trip here would be an N+1.
 */
function lastPaymentDate(
  entries: readonly { type: string; isVoided: boolean; occurredAt: Date }[],
): Date | null {
  let latest: Date | null = null
  for (const entry of entries) {
    if (entry.type !== 'PAYMENT' || entry.isVoided) continue
    if (latest === null || entry.occurredAt > latest) latest = entry.occurredAt
  }
  return latest
}

export async function getTotalUtang(): Promise<number> {
  // Sum only positive per-customer balances. A credit held for one customer
  // must never cancel debt owed by another customer on the dashboard.
  const balances = await listCustomerBalances()
  return balances.reduce(
    (total, customer) => total + Math.max(0, customer.balanceCentavos),
    0,
  )
}

/**
 * One customer's ledger, oldest first, with the balance as it stood after
 * each row. Sorted by occurredAt — when it happened, not when it was typed.
 * Voided rows are returned so the ledger shows no gaps; they carry the
 * running balance forward unchanged.
 */
export async function getLedger(customerId: number): Promise<LedgerLine[]> {
  const entries = await prisma.ledgerEntry.findMany({
    where: { customerId },
    orderBy: [{ occurredAt: 'asc' }, { id: 'asc' }],
  })

  let running = 0
  return entries.map((entry) => {
    running += balanceDelta(entry)
    return {
      id: entry.id,
      type: entry.type as LedgerEntryType,
      amountCentavos: entry.amountCentavos,
      occurredAt: entry.occurredAt,
      note: entry.note,
      isVoided: entry.isVoided,
      saleId: entry.saleId,
      planId: entry.planId,
      runningBalanceCentavos: running,
    }
  })
}

/**
 * One payment, with the balance either side of it, for its printed receipt.
 *
 * The "before" figure is rebuilt from the entries that stood ahead of this one
 * in ledger order — occurredAt, then id — rather than snapshotted at write
 * time. A back-dated entry added later genuinely changes what the balance was
 * at this moment, and a receipt reprinted afterwards should say so.
 */
export async function getPaymentReceipt(entryId: number): Promise<{
  entry: LedgerLine
  customer: { id: number; name: string; phone: string | null }
  planId: number | null
  balanceBeforeCentavos: number
  balanceAfterCentavos: number
} | null> {
  if (!Number.isInteger(entryId) || entryId <= 0) return null

  const entry = await prisma.ledgerEntry.findUnique({
    where: { id: entryId },
    include: { customer: { select: { id: true, name: true, phone: true } } },
  })
  if (!entry || entry.type !== 'PAYMENT') return null

  const lines = await getLedger(entry.customerId)
  const index = lines.findIndex((line) => line.id === entry.id)
  if (index === -1) return null

  const line = lines[index]
  return {
    entry: line,
    customer: entry.customer,
    planId: entry.planId,
    balanceBeforeCentavos: index === 0 ? 0 : lines[index - 1].runningBalanceCentavos,
    balanceAfterCentavos: line.runningBalanceCentavos,
  }
}

function revalidateLedger(): void {
  // The notification bell lives in the root layout, so invalidate the shell
  // as well as the pages whose own data changed.
  revalidateRoutes([ROUTES.book, ROUTES.dashboard, ROUTES.history], { layout: true })
}

type EntryInput = {
  customerId: number
  amountCentavos: number
  occurredAt: Date
  note?: string
  /**
   * Which utang plan this payment settles. Null or omitted means the money
   * goes against the balance generally rather than against one borrowing —
   * a real choice she makes, not a missing value.
   */
  planId?: number | null
}

/**
 * The write boundary for every ledger entry. Validates `type` against
 * `LedgerEntryType` at runtime, not just at the type level — SQLite has no
 * enum, so this is the one place bad data can be refused before it reaches
 * a row. Callers today only ever pass the literal 'PAYMENT' or 'OPENING',
 * so the check is currently unreachable through the app's own writes; it
 * exists for whatever calls this next (a raw-SQL fix, a future caller).
 */
export async function createEntry(
  type: LedgerEntryType,
  input: EntryInput,
): Promise<ActionResult<{ entryId: number }>> {
  if (!isLedgerEntryType(type)) {
    return { ok: false, error: 'Unrecognised ledger entry type.' }
  }
  if (!Number.isInteger(input.amountCentavos) || input.amountCentavos <= 0) {
    return { ok: false, error: 'Amount must be more than zero.' }
  }

  const customer = await prisma.customer.findUnique({ where: { id: input.customerId } })
  if (!customer) return { ok: false, error: 'That customer no longer exists.' }

  // A payment may only be allocated to a live plan belonging to THIS customer.
  // Checked here rather than relying on the foreign key, which would happily
  // accept another customer's plan id and quietly credit the wrong account.
  const planId = input.planId ?? null
  if (planId !== null) {
    const plan = await prisma.utangPlan.findUnique({ where: { id: planId } })
    if (!plan || plan.customerId !== input.customerId) {
      return { ok: false, error: 'That utang record does not belong to this customer.' }
    }
    if (plan.isVoided) {
      return { ok: false, error: 'That utang has been voided. Record this against the account instead.' }
    }
  }

  let entry: { id: number }
  try {
    entry = await prisma.$transaction(async (tx) => {
      const created = await tx.ledgerEntry.create({
        data: {
          customerId: input.customerId,
          type,
          amountCentavos: input.amountCentavos,
          occurredAt: input.occurredAt,
          note: (input.note ?? '').trim(),
          planId,
        },
      })
      await reconcileCustomerDueAt(tx, input.customerId, input.occurredAt)
      return created
    })
  } catch (error) {
    if (
      prismaErrorCode(error) === 'P2003' ||
      (error instanceof Error && error.message === 'CUSTOMER_VANISHED')
    ) {
      return { ok: false, error: 'That customer no longer exists.' }
    }
    return { ok: false, error: 'Could not save the entry.' }
  }

  revalidateLedger()
  return { ok: true, data: { entryId: entry.id } }
}

export async function recordPayment(
  input: EntryInput,
): Promise<ActionResult<{ entryId: number }>> {
  return createEntry('PAYMENT', input)
}

/**
 * Records many payments in one pass, for transcribing a paper notebook.
 *
 * Deliberately NOT one transaction. Each row either becomes an entry or does
 * not, and the caller is told which failed and why — twenty rows deep, one
 * typo discarding the batch is how a person stops using a tool. There is no
 * half-written state to recover from because a row is a single entry.
 */
export async function recordPaymentBatch(
  rows: BatchPaymentRow[],
): Promise<ActionResult<BatchPaymentResult>> {
  if (rows.length === 0) return { ok: false, error: 'Nothing to save.' }

  let recorded = 0
  const failures: { index: number; error: string }[] = []

  for (const [index, row] of rows.entries()) {
    const result = await createEntry('PAYMENT', {
      customerId: row.customerId,
      amountCentavos: row.amountCentavos,
      occurredAt: row.occurredAt,
      note: row.note,
    })
    if (result.ok) recorded += 1
    else failures.push({ index, error: result.error })
  }

  revalidateLedger()
  return { ok: true, data: { recorded, failures } }
}

/** The one-time carry-over from the paper notebook. Refused only when a
 *  *live* OPENING entry already exists — a genuine second opening balance
 *  is always a mistake and belongs on the existing entry instead.
 *
 *  `OpeningBalanceDialog` calls this, from the "Starting utang" button on a
 *  customer's page. For a while nothing did: the New utang dialog had taken
 *  over the carry-over, and `createPlan` writes an OPENING entry itself when
 *  the customer has no live entries yet. That left the plainest case with no
 *  way in — a name carried across from the notebook, owing a figure, on no
 *  terms — and the shop noticed, because forty-six customers all started at
 *  zero. A plan is the wrong shape for it: no instalments, no interest, one
 *  number.
 *
 *  Deliberately narrower than "any entries": if she sets an opening
 *  balance wrong and voids it (voiding is the only undo the app has), she
 *  must be able to set it again. And a carry-over she remembers only after
 *  the customer already has a CHARGE from an order must still be enterable. */
export async function setOpeningBalance(
  input: EntryInput,
): Promise<ActionResult<{ entryId: number }>> {
  const existing = await prisma.ledgerEntry.count({
    where: { customerId: input.customerId, type: 'OPENING', isVoided: false },
  })
  if (existing > 0) {
    return { ok: false, error: 'This customer already has an opening balance. Edit that one instead.' }
  }
  return createEntry('OPENING', input)
}

/**
 * Which customers already have a carry-over, so the grid can leave them alone.
 *
 * Returned as ids rather than folded into `listCustomerBalances`: a balance is
 * what everything on the Book is about, and whether a *particular kind of entry*
 * exists is a question only the opening-balance grid asks.
 */
export async function listCustomersWithOpeningBalance(): Promise<number[]> {
  const rows = await prisma.ledgerEntry.findMany({
    where: { type: 'OPENING', isVoided: false },
    select: { customerId: true },
    distinct: ['customerId'],
  })
  return rows.map((row) => row.customerId)
}

/**
 * Carries a whole notebook across in one pass.
 *
 * `setOpeningBalance` has existed since the beginning and works perfectly — one
 * customer at a time, from a dialog on their own page. Forty-six of those is
 * the same wall that left every cost price at zero, and it produced the same
 * outcome: 0 of 46 customers had a starting figure, so the Book showed a shop
 * owed nothing by people who owed it plenty.
 *
 * Deliberately NOT one transaction, exactly like `recordPaymentBatch`: each row
 * either becomes an entry or does not, and the caller is told which failed and
 * why. Twenty rows deep, one refusal discarding the batch is how a person stops
 * using a tool. There is no half-written state to recover from, because a row is
 * a single entry.
 *
 * Per-row it calls `setOpeningBalance` rather than reimplementing it, so the
 * "already has one" guard cannot drift between the single and bulk paths — the
 * one rule that makes an opening balance safe to retry.
 */
export async function recordOpeningBalanceBatch(
  rows: BatchPaymentRow[],
): Promise<ActionResult<BatchPaymentResult>> {
  if (rows.length === 0) return { ok: false, error: 'Nothing to save.' }

  let recorded = 0
  const failures: { index: number; error: string }[] = []

  for (const [index, row] of rows.entries()) {
    const result = await setOpeningBalance({
      customerId: row.customerId,
      amountCentavos: row.amountCentavos,
      occurredAt: row.occurredAt,
      note: row.note,
      planId: null,
    })
    if (result.ok) recorded += 1
    else failures.push({ index, error: result.error })
  }

  revalidateLedger()
  return { ok: true, data: { recorded, failures } }
}

/** Snapshots the row as it was, then edits in place. She sees a clean
 *  ledger; the history exists for the day someone disputes it.
 *
 *  Re-reads the entry inside the transaction rather than trusting a copy
 *  read before the transaction opened, so the revision records the state
 *  actually being superseded, not a possibly-stale in-memory one. Returns
 *  null if the row vanished between the pre-check and the transaction. */
async function snapshot(tx: Prisma.TransactionClient, id: number): Promise<LedgerEntry | null> {
  const entry = await tx.ledgerEntry.findUnique({ where: { id } })
  if (!entry) return null

  await tx.ledgerEntryRevision.create({
    data: {
      ledgerEntryId: entry.id,
      type: entry.type,
      amountCentavos: entry.amountCentavos,
      occurredAt: entry.occurredAt,
      note: entry.note,
      isVoided: entry.isVoided,
    },
  })
  return entry
}

export async function updateEntry(
  id: number,
  patch: { amountCentavos: number; occurredAt: Date; note?: string },
): Promise<ActionResult> {
  // Guarded: this can hide money, so the person at the keyboard proves it is
  // still her. One confirmation covers a few minutes, so correcting three
  // entries in a row asks once.
  const gate = await confirmationGate()
  if (gate) return gate

  if (!Number.isInteger(patch.amountCentavos) || patch.amountCentavos <= 0) {
    return { ok: false, error: 'Amount must be more than zero.' }
  }

  const existing = await prisma.ledgerEntry.findUnique({ where: { id } })
  if (!existing) return { ok: false, error: 'That entry no longer exists.' }
  if (existing.saleId) {
    return { ok: false, error: 'Sale-linked charges must be corrected from the sale record.' }
  }
  // A plan's charge carries the principal-plus-interest total that the stored
  // schedule was built from. Editing it here would leave the entry and the
  // instalments disagreeing about the same debt, with the invoice printing one
  // figure and the balance showing another. Void the whole plan instead.
  if (existing.planId && existing.type !== 'PAYMENT') {
    return { ok: false, error: 'This charge belongs to an utang record. Void that record instead.' }
  }

  try {
    await prisma.$transaction(async (tx) => {
      const entry = await snapshot(tx, id)
      if (!entry) throw new Error('ENTRY_VANISHED')
      if (entry.saleId) throw new Error('SALE_LINKED_ENTRY')
      if (entry.planId && entry.type !== 'PAYMENT') throw new Error('PLAN_LINKED_ENTRY')
      await tx.ledgerEntry.update({
        where: { id },
        data: {
          amountCentavos: patch.amountCentavos,
          occurredAt: patch.occurredAt,
          note: (patch.note ?? '').trim(),
        },
      })
      await reconcileCustomerDueAt(tx, entry.customerId, patch.occurredAt)
    })
  } catch (error) {
    if (prismaErrorCode(error) === 'P2025' || (error instanceof Error && error.message === 'ENTRY_VANISHED')) {
      return { ok: false, error: 'That entry no longer exists.' }
    }
    if (error instanceof Error && error.message === 'SALE_LINKED_ENTRY') {
      return { ok: false, error: 'Sale-linked charges must be corrected from the sale record.' }
    }
    if (error instanceof Error && error.message === 'PLAN_LINKED_ENTRY') {
      return { ok: false, error: 'This charge belongs to an utang record. Void that record instead.' }
    }
    return { ok: false, error: 'Could not update the entry.' }
  }

  revalidateLedger()
  return { ok: true, data: undefined }
}

/** Voids rather than deletes. A deleted money row is a ledger that has
 *  stopped being evidence. */
export async function voidEntry(id: number): Promise<ActionResult> {
  // Guarded: this can hide money, so the person at the keyboard proves it is
  // still her. One confirmation covers a few minutes, so correcting three
  // entries in a row asks once.
  const gate = await confirmationGate()
  if (gate) return gate

  const existing = await prisma.ledgerEntry.findUnique({ where: { id } })
  if (!existing) return { ok: false, error: 'That entry no longer exists.' }
  if (existing.saleId) {
    return { ok: false, error: 'Sale-linked charges must be corrected from the sale record.' }
  }
  // A plan's charge carries the principal-plus-interest total that the stored
  // schedule was built from. Editing it here would leave the entry and the
  // instalments disagreeing about the same debt, with the invoice printing one
  // figure and the balance showing another. Void the whole plan instead.
  if (existing.planId && existing.type !== 'PAYMENT') {
    return { ok: false, error: 'This charge belongs to an utang record. Void that record instead.' }
  }
  if (existing.isVoided) return { ok: true, data: undefined }

  try {
    await prisma.$transaction(async (tx) => {
      const entry = await snapshot(tx, id)
      if (!entry) throw new Error('ENTRY_VANISHED')
      if (entry.saleId) throw new Error('SALE_LINKED_ENTRY')
      if (entry.planId && entry.type !== 'PAYMENT') throw new Error('PLAN_LINKED_ENTRY')
      await tx.ledgerEntry.update({ where: { id }, data: { isVoided: true } })
      await reconcileCustomerDueAt(tx, entry.customerId, new Date())
    })
  } catch (error) {
    if (prismaErrorCode(error) === 'P2025' || (error instanceof Error && error.message === 'ENTRY_VANISHED')) {
      return { ok: false, error: 'That entry no longer exists.' }
    }
    if (error instanceof Error && error.message === 'SALE_LINKED_ENTRY') {
      return { ok: false, error: 'Sale-linked charges must be corrected from the sale record.' }
    }
    if (error instanceof Error && error.message === 'PLAN_LINKED_ENTRY') {
      return { ok: false, error: 'This charge belongs to an utang record. Void that record instead.' }
    }
    return { ok: false, error: 'Could not void the entry.' }
  }

  revalidateLedger()
  return { ok: true, data: undefined }
}
