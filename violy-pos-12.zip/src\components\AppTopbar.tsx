'use client'

import { useState } from 'react'
import Link from 'next/link'
import { CommandPalette } from '@/components/CommandPalette'
import { AccountMenu } from '@/components/AccountMenu'
import { NotificationBell } from '@/components/NotificationBell'
import { Button } from '@/components/ui/Button'
import { Icon } from '@/components/ui/Icon'
import type { NotificationSummary } from '@/lib/types'

/**
 * Slim utility bar above `<main>`. Carries no primary navigation — that
 * lives entirely in `AppRail` now. The left slot holds the command-palette
 * (⌘K) trigger; the palette itself also answers the shortcut directly, so
 * this button and a bare keypress open the exact same dialog instance.
 */
export function AppTopbar({
  notifications,
  username,
}: {
  notifications: NotificationSummary
  /** Null when the shop has no login. The menu still reaches Settings. */
  username: string | null
}) {
  const [paletteOpen, setPaletteOpen] = useState(false)

  return (
    <header
      data-print="hide"
      className="flex h-16 shrink-0 items-center justify-between border-b border-line bg-surface px-4"
    >
      <div>
        <Button variant="secondary" onClick={() => setPaletteOpen(true)}>
          <Icon name="search" className="h-4 w-4" />
          Search ⌘K
        </Button>
        <CommandPalette open={paletteOpen} onOpenChange={setPaletteOpen} />
      </div>

      <div
        role="region"
        aria-label="Header utilities"
        className="flex shrink-0 items-center"
      >
        <NotificationBell notifications={notifications} />
        {/* Settings reaches the app from here rather than from the rail: the
            rail is the five workspaces she moves between all day, and store
            details are a utility touched once. It now sits under the account
            alongside signing out, which is where both are looked for. */}
        <AccountMenu username={username} />
      </div>
    </header>
  )
}
