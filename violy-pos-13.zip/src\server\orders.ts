'use server'

import { prisma } from '@/lib/db'
import { lineTotal } from '@/lib/money'
import {
  computeOrderTotals,
  customerDiscountsOf,
  mergeLineDiscounts,
  validateLineDiscount,
  isLineDiscountMode,
  type LineDiscountMode,
  validateOrderDiscount,
  type OrderDiscountInput,
} from '@/lib/discount'
import { startOfDay, addDays } from '@/lib/dates'
import {
  deliveryOrderTotal,
  validateDeliveryDetails,
  type DeliveryOrderDetails,
} from '@/lib/delivery-order'
import { sumBalance } from '@/lib/ledger-balance'
import { reconcileCustomerDueAt } from '@/server/account-due'
import type {
  ActionResult,
  DayOrder,
  OrderLineInput,
  OrderResult,
  ReceiptLine,
} from '@/lib/types'
import { ROUTES } from '@/lib/routes'
import { prismaErrorCode } from '@/lib/prisma-errors'
import { revalidateRoutes } from './revalidate'

class OrderError extends Error {}

export type CreateOrderInput = {
  customerId: number
  lines: OrderLineInput[]
  /** Cash handed over. The server stores only the portion retained as cash paid. */
  cashPaidCentavos: number | null
  /** The ad-hoc discount typed at the counter. Omitted means none. */
  orderDiscount?: OrderDiscountInput | null
  /**
   * How much of the customer's existing credit to put toward this order.
   *
   * Only ever REDUCES the cash she has to hand over. It posts no ledger entry
   * of its own: the charge this order already writes is `total - cash kept`,
   * and that moves a negative balance toward zero exactly as it moves a zero
   * balance upward. Adding a second posting would consume the credit twice.
   */
  creditAppliedCentavos?: number
  clientOrderKey?: string
  occurredAt?: Date
  /**
   * Where this order is going, when, and what the trip costs. Omitted is an
   * ordinary counter order, which is what every caller but the delivery screen
   * passes.
   *
   * Handled HERE rather than by a second action that creates a sale and then
   * attaches a delivery to it. A delivery order is one act — stock leaves, the
   * ledger is charged, and the load is booked — so it is one transaction. Two
   * writes could half-succeed, leaving a real charge against a customer with
   * nothing on record saying where the sacks went.
   */
  delivery?: DeliveryOrderDetails
}

function receiptLines(
  lines: readonly {
    productId: number
    quantity: number
    priceAtSale: number
    discountAtSale: number
    lineDiscountAtSale?: number
    product: { name: string; unit: string }
  }[],
): ReceiptLine[] {
  return lines.map((line) => ({
    productId: line.productId,
    name: line.product.name,
    unit: line.product.unit,
    quantity: line.quantity,
    priceAtSale: line.priceAtSale,
    discountAtSale: line.discountAtSale,
    // Less the whole-line discount as well, or a printed receipt
    // disagrees with the total the customer was read out.
    lineTotalCentavos:
      lineTotal(line.priceAtSale - line.discountAtSale, line.quantity) -
      (line.lineDiscountAtSale ?? 0),
  }))
}

async function existingOrderResult(clientOrderKey: string): Promise<OrderResult | null> {
  const sale = await prisma.sale.findUnique({
    where: { clientOrderKey },
    include: {
      items: { include: { product: { select: { name: true, unit: true } } } },
      ledgerEntry: { select: { amountCentavos: true, isVoided: true } },
    },
  })
  if (!sale) return null
  return {
    saleId: sale.id,
    createdAt: sale.createdAt.toISOString(),
    totalCentavos: sale.totalAmount,
    cashPaidCentavos: sale.cashPaidCentavos,
    cashTenderedCentavos: sale.cashTenderedCentavos ?? sale.cashPaidCentavos,
    changeCentavos: sale.changeCentavos,
    chargedCentavos:
      sale.ledgerEntry && !sale.ledgerEntry.isVoided ? sale.ledgerEntry.amountCentavos : 0,
    newBalanceCentavos: sale.customerBalanceAfterCentavos ?? 0,
    lines: receiptLines(sale.items),
  }
}

export async function createOrder(
  input: CreateOrderInput,
): Promise<ActionResult<OrderResult>> {
  if (input.lines.length === 0) {
    return { ok: false, error: 'No items yet. Add at least one.' }
  }
  for (const line of input.lines) {
    if (!Number.isFinite(line.quantity) || line.quantity <= 0) {
      return { ok: false, error: "Each line's quantity must be more than zero." }
    }
    const badDiscount = validateLineDiscount(line.discountPerUnitCentavos)
    if (badDiscount) return { ok: false, error: badDiscount }
    if (line.discountMode !== undefined && !isLineDiscountMode(line.discountMode)) {
      return { ok: false, error: 'Unrecognised line discount mode.' }
    }
  }
  if (
    input.cashPaidCentavos !== null &&
    (!Number.isInteger(input.cashPaidCentavos) || input.cashPaidCentavos < 0)
  ) {
    return { ok: false, error: 'Cash must be a non-negative whole number of centavos.' }
  }

  const creditRequested = input.creditAppliedCentavos ?? 0
  if (!Number.isInteger(creditRequested) || creditRequested < 0) {
    return { ok: false, error: 'Credit applied must be a whole number of centavos.' }
  }

  const discount = validateOrderDiscount(input.orderDiscount)
  if (!discount.ok) return { ok: false, error: discount.error }
  const orderDiscount = discount.value

  // The same check the delivery screen runs to decide whether Save is
  // enabled, so a disabled button and a refused save always agree about why.
  if (input.delivery) {
    const badDelivery = validateDeliveryDetails(input.delivery)
    if (badDelivery) return { ok: false, error: badDelivery }
  }
  const deliveryFeeCentavos = input.delivery?.feeCentavos ?? 0

  const clientOrderKey = input.clientOrderKey?.trim() || null
  if (clientOrderKey && (clientOrderKey.length < 8 || clientOrderKey.length > 128)) {
    return { ok: false, error: 'The checkout key is invalid. Start a fresh order and try again.' }
  }
  if (clientOrderKey) {
    const existing = await existingOrderResult(clientOrderKey)
    if (existing) return { ok: true, data: existing }
  }

  // Quantity AND the typed line discount, so two rows for one product become
  // one line without losing either.
  const merged = new Map<
    number,
    { quantity: number; discountPerUnitCentavos: number; discountMode: LineDiscountMode }
  >()
  for (const line of input.lines) {
    const existing = merged.get(line.productId)
    merged.set(line.productId, {
      quantity: (existing?.quantity ?? 0) + line.quantity,
      discountPerUnitCentavos: mergeLineDiscounts(
        existing?.discountPerUnitCentavos,
        line.discountPerUnitCentavos,
      ),
      // ONCE wins on a merge: a per-line figure applied per unit would
      // multiply rather than divide.
      discountMode:
        existing?.discountMode === 'ONCE' || line.discountMode === 'ONCE' ? 'ONCE' : 'EACH',
    })
  }

  const occurredAt = input.occurredAt ?? new Date()
  let result: OrderResult
  try {
    result = await prisma.$transaction(async (tx) => {
      const customer = await tx.customer.findUnique({
        where: { id: input.customerId },
        include: {
          discountCategories: { select: { id: true } },
          // Every standing rule, with its scopes. Loaded inside the same
          // transaction that prices the order, so a rule edited mid-checkout
          // cannot price half the lines one way and half the other.
          discountRules: {
            include: {
              categories: { select: { id: true, name: true } },
              products: { select: { id: true, name: true } },
            },
            orderBy: { id: 'asc' },
          },
          entries: {
            where: { isVoided: false },
            select: { id: true, type: true, amountCentavos: true, isVoided: true },
          },
        },
      })
      if (!customer) throw new OrderError('That customer no longer exists.')
      if (customer.isArchived) throw new OrderError(`${customer.name} is archived.`)

      const products = await tx.product.findMany({
        where: { id: { in: [...merged.keys()] } },
      })
      const byId = new Map(products.map((product) => [product.id, product]))

      // Availability is checked here; pricing is not. Everything about what a
      // line costs lives in `computeOrderTotals`, which the order screen's
      // live preview also calls — the figure she reads to the customer and
      // the figure that hits the books come out of one function.
      for (const productId of merged.keys()) {
        const product = byId.get(productId)
        if (!product) throw new OrderError('An item in this order no longer exists.')
        if (product.isArchived) throw new OrderError(`${product.name} is no longer available.`)
      }

      const totals = computeOrderTotals({
        lines: [...merged.entries()].map(([productId, row]) => {
          const product = byId.get(productId)!
          return {
            productId,
            quantity: row.quantity,
            priceCentavos: product.price,
            categoryId: product.categoryId,
            unit: product.unit,
            manualDiscountPerUnitCentavos: row.discountPerUnitCentavos,
            manualDiscountMode: row.discountMode,
          }
        }),
        customer: customerDiscountsOf(customer),
        order: orderDiscount,
      })

      const lines = totals.lines.map((line) => {
        const product = byId.get(line.productId)!
        return {
          productId: line.productId,
          quantity: line.quantity,
          priceAtSale: line.priceCentavos,
          costAtSale: product.costPrice,
          discountAtSale: line.discountPerUnitCentavos,
          lineDiscountAtSale: line.lineDiscountCentavos,
          product: { name: product.name, unit: product.unit },
        }
      })

      // The fee joins AFTER `computeOrderTotals` has finished, never before.
      // A customer's standing "10% off" is off feeds; folding the trip into
      // the priced order would quietly have their discount pay for the truck.
      // Everything below — cash kept, the charge, the balance after — works
      // off this one figure, so the fee is owed exactly as the sacks are.
      const totalAmount = deliveryOrderTotal(totals.totalCentavos, deliveryFeeCentavos)
      const previousBalance = sumBalance(customer.entries)

      // A negative balance is credit the shop holds for her. Read INSIDE the
      // transaction against her live entries, never from what the browser was
      // showing — a payment recorded on another screen a minute ago must not
      // be spent twice.
      const availableCredit = Math.max(0, -previousBalance)
      if (creditRequested > availableCredit) {
        throw new OrderError(
          availableCredit === 0
            ? 'This customer has no credit to use.'
            : 'That is more credit than this customer has.',
        )
      }
      // Capped at the order too: credit beyond the total would hand back cash
      // the shop never received.
      const creditApplied = Math.min(creditRequested, totalAmount)

      // What is left for her to cover once credit has done its part.
      const dueAfterCredit = totalAmount - creditApplied
      const cashTendered = input.cashPaidCentavos ?? dueAfterCredit
      const keptCentavos = Math.min(cashTendered, dueAfterCredit)
      const changeCentavos = Math.max(0, cashTendered - dueAfterCredit)

      // The single posting that does everything. `total - kept` is the charge
      // whether it is funded by credit, by utang, or by both: applying credit
      // simply means less cash was kept, so the charge is larger and eats into
      // the negative balance. No separate credit entry exists, and adding one
      // would consume the credit twice.
      const chargedCentavos = Math.max(0, totalAmount - keptCentavos)
      const newBalanceCentavos = previousBalance + chargedCentavos

      const sale = await tx.sale.create({
        data: {
          totalAmount,
          customerId: customer.id,
          cashPaidCentavos: keptCentavos,
          cashTenderedCentavos: cashTendered,
          changeCentavos,
          creditAppliedCentavos: creditApplied,
          customerBalanceAfterCentavos: newBalanceCentavos,
          // Snapshotted alongside the resulting peso figure, so a receipt
          // reprinted next year can still say "10% off" rather than leaving
          // the reader to reverse-engineer it from the total.
          customerDiscountCentavos: totals.customerDiscountCentavos,
          orderDiscountCentavos: totals.orderDiscountCentavos,
          orderDiscountKind: orderDiscount.kind,
          orderDiscountBps: orderDiscount.bps,
          orderDiscountMode: orderDiscount.mode,
          clientOrderKey,
          createdAt: occurredAt,
          // A null `deliverAt` is what says "ordinary counter order", so the
          // whole group is written only when there is a delivery. Trimmed
          // here rather than in the browser: what lands on the note is what
          // the server decided, not what a form happened to send.
          ...(input.delivery
            ? {
                deliverAt: input.delivery.deliverAt,
                deliverTo: input.delivery.deliverTo.trim(),
                deliverAddress: input.delivery.address.trim(),
                deliveryInstructions: input.delivery.instructions.trim(),
                deliveryFeeCentavos,
              }
            : {}),
          items: { create: lines.map(({ product, ...line }) => line) },
        },
      })

      for (const line of lines) {
        await tx.product.update({
          where: { id: line.productId },
          data: { stockQty: { decrement: line.quantity } },
        })
        await tx.stockMovement.create({
          data: {
            productId: line.productId,
            saleId: sale.id,
            type: 'SALE',
            quantity: -line.quantity,
            note: `Sale #${sale.id}`,
          },
        })
      }

      if (chargedCentavos > 0) {
        await tx.ledgerEntry.create({
          data: {
            customerId: customer.id,
            type: 'CHARGE',
            amountCentavos: chargedCentavos,
            occurredAt,
            saleId: sale.id,
          },
        })
        await reconcileCustomerDueAt(tx, customer.id, occurredAt)
      }

      return {
        saleId: sale.id,
        createdAt: sale.createdAt.toISOString(),
        totalCentavos: totalAmount,
        cashPaidCentavos: keptCentavos,
        cashTenderedCentavos: cashTendered,
        changeCentavos,
        chargedCentavos,
        newBalanceCentavos,
        lines: receiptLines(lines),
      }
    })
  } catch (error) {
    if (error instanceof OrderError) return { ok: false, error: error.message }
    if (clientOrderKey && prismaErrorCode(error) === 'P2002') {
      const existing = await existingOrderResult(clientOrderKey)
      if (existing) return { ok: true, data: existing }
    }
    return { ok: false, error: 'Could not save the order. Please try again.' }
  }

  revalidateRoutes(
    [ROUTES.counter, ROUTES.history, ROUTES.book, ROUTES.dashboard, ROUTES.stock],
    { layout: true },
  )
  return { ok: true, data: result }
}

/** One day's orders, newest first, shaped the way the notebook page reads. */
export async function listOrdersForDay(day: Date): Promise<DayOrder[]> {
  const from = startOfDay(day)
  const to = addDays(from, 1)

  const sales = await prisma.sale.findMany({
    where: { createdAt: { gte: from, lt: to } },
    include: {
      customer: { select: { id: true, name: true } },
      items: { include: { product: { select: { name: true, unit: true } } } },
      ledgerEntry: { select: { isVoided: true } },
    },
    orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
  })

  return sales.map((sale) => ({
    saleId: sale.id,
    customerId: sale.customer?.id ?? null,
    customerName: sale.customer?.name ?? null,
    totalCentavos: sale.totalAmount,
    cashPaidCentavos: sale.cashPaidCentavos,
    hasLiveCharge: sale.ledgerEntry !== null && !sale.ledgerEntry.isVoided,
    isVoided: sale.isVoided,
    createdAt: sale.createdAt,
    lines: sale.items.map((item) => ({
      name: item.product.name,
      unit: item.product.unit,
      quantity: item.quantity,
    })),
  }))
}
