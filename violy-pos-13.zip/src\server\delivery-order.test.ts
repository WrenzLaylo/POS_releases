import { describe, it, expect, beforeEach } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'
import { createOrder } from '@/server/orders'
import { getBalance } from '@/server/ledger'

beforeEach(resetDb)

async function makeProduct(overrides: Partial<{ price: number; stockQty: number }> = {}) {
  const category = await prisma.category.upsert({
    where: { name: 'Pig Feeds' },
    create: { name: 'Pig Feeds' },
    update: {},
  })
  return prisma.product.create({
    data: {
      categoryId: category.id,
      name: 'Hog Grower (sako)',
      unit: 'sako (50kg)',
      price: overrides.price ?? 201_000,
      costPrice: 180_000,
      stockQty: overrides.stockQty ?? 40,
      lowStockThreshold: 5,
    },
  })
}

async function makeCustomer(name = 'ADRIAN MAGPANTAY') {
  return prisma.customer.create({ data: { name } })
}

const DELIVER_AT = new Date(2026, 7, 22)

function delivery(overrides: Partial<Parameters<typeof createOrder>[0]['delivery']> = {}) {
  return {
    deliverAt: DELIVER_AT,
    deliverTo: 'Bagac',
    address: '',
    instructions: '',
    feeCentavos: 0,
    ...overrides,
  }
}

describe('createOrder with a delivery', () => {
  it('records the sale and where it is going, together', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer()

    const result = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 10 }],
      cashPaidCentavos: 0,
      delivery: delivery({
        address: '123 Purok 4, Barangay Ibaba, Bagac, Bataan',
        instructions: 'Leave with the caretaker.',
      }),
    })

    expect(result.ok).toBe(true)
    if (!result.ok) return

    const sale = await prisma.sale.findUniqueOrThrow({ where: { id: result.data.saleId } })
    expect(sale.deliverAt?.getTime()).toBe(DELIVER_AT.getTime())
    expect(sale.deliverTo).toBe('Bagac')
    expect(sale.deliverAddress).toBe('123 Purok 4, Barangay Ibaba, Bagac, Bataan')
    expect(sale.deliveryInstructions).toBe('Leave with the caretaker.')
    expect(sale.totalAmount).toBe(10 * 201_000)
  })

  // The sale is REAL at save time. This is the whole shape of the feature: it
  // is not a booking that becomes a sale later.
  it('moves stock and charges the ledger at save time', async () => {
    const product = await makeProduct({ stockQty: 40 })
    const customer = await makeCustomer()

    const result = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 10 }],
      cashPaidCentavos: 0,
      delivery: delivery(),
    })
    expect(result.ok).toBe(true)
    if (!result.ok) return

    const after = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
    expect(after.stockQty).toBe(30)

    const movements = await prisma.stockMovement.findMany({ where: { saleId: result.data.saleId } })
    expect(movements).toHaveLength(1)
    expect(movements[0].quantity).toBe(-10)
    expect(movements[0].type).toBe('SALE')

    expect(await getBalance(customer.id)).toBe(10 * 201_000)
  })

  it('adds the delivery fee to the total and to what is owed', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer()

    const result = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 10 }],
      cashPaidCentavos: 0,
      delivery: delivery({ feeCentavos: 30_000 }),
    })
    expect(result.ok).toBe(true)
    if (!result.ok) return

    const sale = await prisma.sale.findUniqueOrThrow({ where: { id: result.data.saleId } })
    expect(sale.deliveryFeeCentavos).toBe(30_000)
    expect(sale.totalAmount).toBe(10 * 201_000 + 30_000)
    expect(result.data.totalCentavos).toBe(10 * 201_000 + 30_000)
    expect(result.data.chargedCentavos).toBe(10 * 201_000 + 30_000)
    expect(await getBalance(customer.id)).toBe(10 * 201_000 + 30_000)
  })

  // The rule the fee's placement in the pipeline exists to protect: a standing
  // discount is off feeds, never off transport. Fold the fee in before pricing
  // and the customer's own discount starts paying for the truck.
  it('never lets a standing discount reach the fee', async () => {
    const product = await makeProduct()
    const customer = await prisma.customer.create({
      data: {
        name: 'DISCOUNTED',
        discountRules: {
          create: { kind: 'PERCENT', bps: 1000, basis: 'ORDER_TOTAL', scope: 'ALL' },
        },
      },
    })

    const result = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 10 }],
      cashPaidCentavos: 0,
      delivery: delivery({ feeCentavos: 30_000 }),
    })
    expect(result.ok).toBe(true)
    if (!result.ok) return

    const goodsAfterDiscount = 10 * 201_000 * 0.9
    const sale = await prisma.sale.findUniqueOrThrow({ where: { id: result.data.saleId } })
    // The fee arrives whole: 10% came off ₱20,100 and nothing came off ₱300.
    expect(sale.totalAmount).toBe(goodsAfterDiscount + 30_000)
    expect(sale.customerDiscountCentavos).toBe(10 * 201_000 * 0.1)
  })

  it('takes cash for the goods and the trip together', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer()

    const total = 10 * 201_000 + 30_000
    const result = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 10 }],
      cashPaidCentavos: total,
      delivery: delivery({ feeCentavos: 30_000 }),
    })
    expect(result.ok).toBe(true)
    if (!result.ok) return

    expect(result.data.cashPaidCentavos).toBe(total)
    expect(result.data.chargedCentavos).toBe(0)
    expect(await getBalance(customer.id)).toBe(0)
    const entries = await prisma.ledgerEntry.findMany({ where: { customerId: customer.id } })
    expect(entries).toHaveLength(0)
  })

  it('charges only the shortfall when she pays part of it', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer()

    const result = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 10 }],
      cashPaidCentavos: 1_000_000,
      delivery: delivery({ feeCentavos: 30_000 }),
    })
    expect(result.ok).toBe(true)
    if (!result.ok) return

    expect(result.data.chargedCentavos).toBe(10 * 201_000 + 30_000 - 1_000_000)
    expect(await getBalance(customer.id)).toBe(10 * 201_000 + 30_000 - 1_000_000)
  })

  it('refuses a delivery with nowhere to go, and writes nothing', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer()

    const result = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 10 }],
      cashPaidCentavos: 0,
      delivery: delivery({ deliverTo: '  ' }),
    })

    expect(result.ok).toBe(false)
    if (result.ok) return
    expect(result.error).toMatch(/where/)

    expect(await prisma.sale.count()).toBe(0)
    const after = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
    expect(after.stockQty).toBe(40)
    expect(await getBalance(customer.id)).toBe(0)
  })

  it('refuses a fee that is not a whole number of centavos', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer()

    const result = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 10 }],
      cashPaidCentavos: 0,
      delivery: delivery({ feeCentavos: 300.5 }),
    })

    expect(result.ok).toBe(false)
    expect(await prisma.sale.count()).toBe(0)
  })

  // Same guarantee the counter has. A delivery order raises a charge and moves
  // stock; a retry that wrote a second one would be the double-write this app
  // fears most.
  it('is idempotent on a retried save', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer()

    const input = {
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 10 }],
      cashPaidCentavos: 0,
      delivery: delivery({ feeCentavos: 30_000 }),
      clientOrderKey: 'deliver-abc12345',
    }

    const first = await createOrder(input)
    const second = await createOrder(input)

    expect(first.ok && second.ok).toBe(true)
    if (!first.ok || !second.ok) return
    expect(second.data.saleId).toBe(first.data.saleId)

    expect(await prisma.sale.count()).toBe(1)
    const after = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
    expect(after.stockQty).toBe(30)
    expect(await getBalance(customer.id)).toBe(10 * 201_000 + 30_000)
  })

  // Every sale in the shop's history predates this feature and must be
  // untouched by it.
  it('leaves an ordinary counter order with no delivery on it', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer()

    const result = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 2 }],
      cashPaidCentavos: null,
    })
    expect(result.ok).toBe(true)
    if (!result.ok) return

    const sale = await prisma.sale.findUniqueOrThrow({ where: { id: result.data.saleId } })
    expect(sale.deliverAt).toBeNull()
    expect(sale.deliverTo).toBe('')
    expect(sale.deliverAddress).toBe('')
    expect(sale.deliveryInstructions).toBe('')
    expect(sale.deliveryFeeCentavos).toBe(0)
    expect(sale.totalAmount).toBe(2 * 201_000)
  })

  it('still needs something to sell — a fee alone is not an order', async () => {
    const customer = await makeCustomer()

    const result = await createOrder({
      customerId: customer.id,
      lines: [],
      cashPaidCentavos: 0,
      delivery: delivery({ feeCentavos: 30_000 }),
    })

    expect(result.ok).toBe(false)
    expect(await prisma.sale.count()).toBe(0)
  })
})
