import { describe, expect, it } from 'vitest'
import { orphanedEngineFiles } from '../../scripts/prisma-temps.mjs'

/**
 * Prisma writes its 20 MB query engine to a temp name and renames it into
 * place. On Windows that rename fails with EPERM whenever something holds the
 * old engine open — a running app, a dev server — and `prisma generate` has
 * done exactly that repeatedly on this project. Each failure abandons the temp
 * copy. Seventeen of them had piled up: 343 MB, a quarter of the whole install,
 * doing nothing.
 *
 * The one file that must never be deleted is the engine itself.
 */
describe('orphanedEngineFiles', () => {
  const REAL = 'query_engine-windows.dll.node'

  it('finds an abandoned temp copy', () => {
    expect(orphanedEngineFiles([REAL, `${REAL}.tmp5040`])).toEqual([`${REAL}.tmp5040`])
  })

  it('finds all of them, which is the whole point', () => {
    const names = [REAL, `${REAL}.tmp5040`, `${REAL}.tmp33732`, `${REAL}.tmp32488`]
    expect(orphanedEngineFiles(names)).toHaveLength(3)
  })

  /** Deleting this is deleting the database driver. */
  it('never touches the real engine', () => {
    expect(orphanedEngineFiles([REAL])).toEqual([])
    expect(orphanedEngineFiles([REAL, `${REAL}.tmp1`])).not.toContain(REAL)
  })

  it('leaves the generated client and everything else alone', () => {
    expect(
      orphanedEngineFiles([
        'index.js',
        'index.d.ts',
        'schema.prisma',
        'package.json',
        'libquery_engine-debian.so.node',
      ]),
    ).toEqual([])
  })

  /**
   * The suffix is a process id, so digits are required. A file merely
   * containing the letters "tmp" is somebody else's and is left alone.
   */
  it('requires a numeric suffix rather than the word tmp', () => {
    expect(orphanedEngineFiles(['tmp.js', 'my.tmp', 'tmpfile.node', 'engine.tmp'])).toEqual([])
    expect(orphanedEngineFiles(['engine.tmp42'])).toEqual(['engine.tmp42'])
  })

  it('says nothing to sweep when there is nothing to sweep', () => {
    expect(orphanedEngineFiles([])).toEqual([])
  })
})
