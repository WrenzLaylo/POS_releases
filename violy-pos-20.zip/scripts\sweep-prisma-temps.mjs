#!/usr/bin/env node
/**
 * The sweep, as a command `install.cmd` can call.
 *
 * `update.mjs` imports the same function directly; a batch file cannot, so it
 * gets this. Silent when there is nothing to do, because most runs will have
 * nothing to do.
 */
import { sweepPrismaTemps } from './prisma-temps.mjs'

const { removed, bytes } = await sweepPrismaTemps(process.cwd())
if (removed > 0) {
  console.log(`      cleaned up ${removed} leftover file(s), ${Math.round(bytes / 1024 / 1024)} MB`)
}
