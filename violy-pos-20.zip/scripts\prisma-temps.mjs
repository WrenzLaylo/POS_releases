/**
 * Sweeps up the query engines a failed `prisma generate` leaves behind.
 *
 * Prisma writes its 20 MB engine to a temporary name and renames it into
 * place. On Windows that rename fails with EPERM whenever anything holds the
 * old engine open — the running till, a dev server, a build — and the temp
 * copy is simply abandoned. Nothing ever collects them.
 *
 * Seventeen had accumulated in this project: 343 MB, close to a quarter of the
 * whole installation, doing nothing at all. The shop laptop is worse off than
 * a developer's, because that is exactly the machine where `prisma generate`
 * runs while the app it is replacing is still shutting down.
 *
 * Run from `install.cmd` and from `update.mjs`, after the generate step, so
 * they cannot pile up again.
 */

import { readdir, rm, stat } from 'node:fs/promises'
import path from 'node:path'

/**
 * The abandoned ones, given a directory listing.
 *
 * A process id suffix is required rather than merely the letters "tmp": the
 * real engine is `query_engine-windows.dll.node` and losing it means losing the
 * database driver, so the match has to be narrow enough that no ordinary file
 * can be caught by it.
 */
export function orphanedEngineFiles(names) {
  return names.filter((name) => /\.tmp\d+$/.test(name))
}

/**
 * Deletes them, and reports how much was reclaimed.
 *
 * Failure is not an error worth stopping an install for — a temp file that
 * cannot be removed is the same nuisance it already was, and the app runs
 * either way.
 */
export async function sweepPrismaTemps(root) {
  const dir = path.join(root, 'node_modules', '.prisma', 'client')
  let names
  try {
    names = await readdir(dir)
  } catch {
    return { removed: 0, bytes: 0 }
  }

  let removed = 0
  let bytes = 0
  for (const name of orphanedEngineFiles(names)) {
    const file = path.join(dir, name)
    try {
      bytes += (await stat(file)).size
      await rm(file, { force: true })
      removed += 1
    } catch {
      // Still locked, or gone already. Neither is worth a word.
    }
  }
  return { removed, bytes }
}
