#!/usr/bin/env node
/**
 * Installs an update, then starts the app again.
 *
 * Runs in its OWN console window, detached from the server it is about to
 * stop. It cannot run inside the server process: on Windows the running app
 * holds locks on the files an update has to replace — `prisma generate` has
 * already failed in this project with EPERM because a dev server held the
 * Prisma query engine open, and `next build` cannot rewrite `.next` while it
 * is being served from.
 *
 * Order matters, and it is chosen so that the worst case is recoverable:
 *
 *   1. back up the database          — before anything else touches the disk
 *   2. ask what the newest build is  — and stop early if there is nothing new
 *   3. STOP the running app          — nothing else can replace locked files
 *   4. download, VERIFY, then unpack — nothing is overwritten until the zip
 *                                      has been checked against its hash
 *   5. install, migrate, build
 *   6. start the app again
 *
 * There is no git here. It used to fetch and fast-forward, which required git
 * installed on the shop laptop and a GitHub sign-in for a private repository —
 * two things to set up, and a credential that expires quietly a year later.
 *
 * If any step fails the window stays open with the reason, the backup already
 * exists, and the previous version is still on disk — a failed update leaves a
 * working shop, which matters more than a fast one.
 */

import { execSync, spawn } from 'node:child_process'
import { createWriteStream, existsSync, readFileSync, rmSync } from 'node:fs'
import { createHash, createPublicKey, verify } from 'node:crypto'
import { cp, mkdir, mkdtemp, readdir, readFile, rm, writeFile } from 'node:fs/promises'
import { PRUNABLE_DIRS, filesToPrune } from './update-prune.mjs'
import { sweepPrismaTemps } from './prisma-temps.mjs'
import { tmpdir } from 'node:os'
import { Readable } from 'node:stream'
import { pipeline } from 'node:stream/promises'
import path from 'node:path'
import readline from 'node:readline'

const ROOT = process.cwd()
const CHANNEL = JSON.parse(readFileSync(new URL('../release-channel.json', import.meta.url), 'utf8'))
const MANIFEST_URL = `${CHANNEL.baseUrl}/${CHANNEL.manifestFile}`
const PORT = process.env.PORT ?? '3000'
const NEWLINE = String.fromCharCode(10)

/**
 * The public key, read out of the module it ships in.
 *
 * Regexed from `src/lib/update-public-key.ts` rather than duplicated here,
 * because two copies of a trust anchor is one copy too many — and this script
 * runs under plain Node, before any TypeScript exists to import. Reading the
 * source file keeps a single definition that both the app and the updater use.
 *
 * If the file is missing or unreadable, verification cannot happen and the
 * update does not proceed. There is no "carry on unverified" path.
 */
function publicKeyPem() {
  const file = path.join(ROOT, 'src', 'lib', 'update-public-key.ts')
  const source = readFileSync(file, 'utf8')
  const match = source.match(/-----BEGIN PUBLIC KEY-----[\s\S]*?-----END PUBLIC KEY-----/)
  if (!match) throw new Error(`no public key found in ${file}`)
  return match[0]
}

/**
 * The canonical form that was signed.
 *
 * MUST match `canonicalManifest` in `src/lib/update-signature.ts` and the copy
 * in `scripts/release.mjs`. All three are asserted against each other by
 * `update-signature.test.ts`, because a separator that drifts in one of them
 * rejects every release and looks exactly like a wrong key.
 */
function canonicalManifest({ build, version, zipUrl, sha256 }) {
  return [
    `build:${build}`,
    `version:${version}`,
    `zipUrl:${zipUrl}`,
    `sha256:${String(sha256).toLowerCase()}`,
  ].join(NEWLINE)
}

/**
 * Whether this manifest was signed by us.
 *
 * Checked BEFORE the zip is fetched, not after. The checksum already proves a
 * download arrived intact; this proves it was ours to begin with, and there is
 * no reason to spend a shop's connection on a file that was never going to be
 * installed.
 *
 * Ed25519 verifies with a NULL algorithm — the curve carries its own hash.
 */
function manifestIsAuthentic(manifest) {
  try {
    return verify(
      null,
      Buffer.from(canonicalManifest(manifest), 'utf8'),
      createPublicKey(publicKeyPem()),
      Buffer.from(String(manifest.signature ?? ''), 'base64'),
    )
  } catch {
    return false
  }
}

/**
 * Reinstall even when the build number already matches.
 *
 * This is what `update-now.cmd` passes. The normal path stops at "already up
 * to date", which is right when the app is working and wrong when the app IS
 * the problem — a half-applied update, a file deleted by mistake, a build that
 * will not start. Forcing re-fetches the current release and lays it down
 * again, with the same backup first, the same signature check, and the same
 * put-the-old-one-back on failure as any other update.
 *
 * It never skips a check. It only stops the version comparison being a reason
 * to refuse.
 */
const FORCE = process.argv.includes('--force')

const say = (message) => console.log(message)
const step = (n, message) => console.log(`\n[${n}/7] ${message}`)

function sh(command, options = {}) {
  return execSync(command, { cwd: ROOT, stdio: 'inherit', ...options })
}

function shQuiet(command) {
  return execSync(command, { cwd: ROOT, encoding: 'utf8', windowsHide: true }).trim()
}

/**
 * Stops whatever is serving the app, by port rather than by remembered PID.
 *
 * A PID file goes stale the moment the app is started another way — a
 * double-clicked shortcut, a terminal, a reboot — and a stale PID either kills
 * nothing or, worse, kills whatever inherited that number. The port is the
 * thing that is actually true: if something is answering on it, that is the
 * app, and it has to stop before its files can be replaced.
 *
 * Failure here is not fatal. If nothing is listening, there was nothing to
 * close.
 */
function stopServer() {
  try {
    if (process.platform === 'win32') {
      const lines = execSync(`netstat -ano -p tcp | findstr LISTENING | findstr :${PORT}`, {
        encoding: 'utf8',
        windowsHide: true,
      })
      const pids = new Set(
        lines
          .split(NEWLINE)
          .map((line) => line.trim().split(/\s+/).pop())
          .filter((pid) => pid && /^\d+$/.test(pid) && pid !== '0'),
      )
      for (const pid of pids) {
        try {
          execSync(`taskkill /PID ${pid} /F /T`, { stdio: 'ignore', windowsHide: true })
        } catch {
          // Already gone between listing and killing.
        }
      }
    } else {
      execSync(`lsof -ti tcp:${PORT} | xargs -r kill -9`, { stdio: 'ignore' })
    }
  } catch {
    // Nothing was listening. Nothing to stop.
  }
}

async function waitForKey() {
  // Keeps the window open so a failure can actually be read. Without this the
  // console closes on exit and the person sees an app that simply never
  // returned.
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
  await new Promise((resolve) => rl.question('\nPress Enter to close this window. ', resolve))
  rl.close()
}

/**
 * A copy of the app's own files, taken before any are replaced.
 *
 * `null` until `snapshotApp()` runs, which is also how `fail()` knows which
 * side of the replacement it is on.
 */
let appSnapshot = null

/**
 * Everything an update replaces. The same list `scripts/release.mjs` packages,
 * because what the zip can overwrite is exactly what has to be recoverable.
 *
 * `node_modules` and `.next` are absent on purpose: they are derived, they are
 * enormous, and copying them would turn a two-second snapshot into a minute.
 * They are also the two things `npm install` and `next build` rebuild anyway.
 */
const APP_PATHS = [
  'src',
  'public',
  'prisma/schema.prisma',
  'prisma/migrations',
  'electron',
  'scripts',
  'package.json',
  'package-lock.json',
  'next.config.ts',
  'tsconfig.json',
  'postcss.config.mjs',
  'vitest.config.ts',
  'release-channel.json',
  'release.json',
  'install.cmd',
  'run-pos.vbs',
  'start-pos.cmd',
]

/**
 * Copies the current app aside so a failed update can be undone.
 *
 * Taken AFTER the download has been verified and BEFORE the first file is
 * replaced, which is the only window where it is both necessary and cheap.
 */
async function snapshotApp() {
  const dir = await mkdtemp(path.join(tmpdir(), 'violy-previous-'))
  for (const entry of APP_PATHS) {
    const from = path.join(ROOT, entry)
    if (!existsSync(from)) continue
    const to = path.join(dir, entry)
    await mkdir(path.dirname(to), { recursive: true })
    await cp(from, to, { recursive: true })
  }
  appSnapshot = dir
  return dir
}

/**
 * Puts the previous app files back.
 *
 * Does NOT touch the database, `.env`, `backups/` or `data/` — none of them
 * were ever copied aside, because none of them are ever replaced. Restoring is
 * only ever about code.
 */
async function restoreApp() {
  if (!appSnapshot) return false
  try {
    for (const entry of APP_PATHS) {
      const from = path.join(appSnapshot, entry)
      if (!existsSync(from)) continue
      await cp(from, path.join(ROOT, entry), { recursive: true, force: true })
    }
    return true
  } catch {
    return false
  }
}

/**
 * Stops with a message that is TRUE about what is on disk.
 *
 * It used to say "the app is still the version you had before" whatever had
 * happened, which is only right before the files are replaced. `applyFiles()`
 * runs at step 4 and three more steps follow it, so every failure from
 * unpacking onward was reassuring the shop about a version that had already
 * been overwritten — and telling her to "start the app again the way you
 * normally do" when what was on disk was half an update.
 */
async function fail(message, error) {
  const touched = appSnapshot !== null
  let restored = false
  if (touched) {
    say('\n  Putting the previous version back…')
    restored = await restoreApp()
  }

  say(`\n────────────────────────────────────────`)
  say(`UPDATE STOPPED: ${message}`)
  if (error) say(String(error.message ?? error).split('\n').slice(0, 6).join('\n'))
  say('')

  if (!touched) {
    say('Nothing was changed. The app is still the version you had before,')
    say('and a backup of your data was saved in the "backups" folder.')
    say('')
    say('Start the app again the way you normally do, and tell whoever')
    say('looks after this what the message above says.')
  } else if (restored) {
    say('The previous version has been put back, and your data was not')
    say('touched — a backup of it is in the "backups" folder either way.')
    say('')
    say('Start the app again the way you normally do. If it does not open,')
    say('run install.cmd once, then tell whoever looks after this what the')
    say('message above says.')
  } else {
    say('IMPORTANT: the update was stopped part-way and the previous version')
    say('could NOT be put back automatically.')
    say('')
    say('Your data is safe — it is never part of an update, and a backup is')
    say('in the "backups" folder. But the app itself may not start.')
    say('')
    say('Tell whoever looks after this app straight away, and show them this')
    say('message.')
  }

  say(`────────────────────────────────────────`)
  await waitForKey()
  process.exit(1)
}

/**
 * Which build this copy is. Absent means it was installed from source.
 */
async function readInstalled() {
  try {
    const raw = await readFile(path.join(ROOT, 'release.json'), 'utf8')
    const value = JSON.parse(raw)
    if (typeof value.build !== 'number' || !Number.isInteger(value.build)) return null
    return { build: value.build, version: String(value.version ?? value.build) }
  } catch {
    return null
  }
}

/**
 * Asks the public releases channel what the newest build is.
 *
 * `no-store` matters: this file changes, and the CDN in front of it would
 * otherwise hand back a cached copy for an hour after a release.
 */
async function fetchManifest() {
  // `?t=` busts the CDN cache. raw.githubusercontent.com holds a manifest for
  // five minutes, and `no-store` governs only this machine's own cache — so
  // without it an update run moments after a release installs the old build.
  const response = await fetch(`${MANIFEST_URL}?t=${Date.now()}`, {
    cache: 'no-store',
    signal: AbortSignal.timeout(20_000),
  })
  if (!response.ok) throw new Error(`update server returned ${response.status}`)

  const value = await response.json()
  if (typeof value.build !== 'number' || !Number.isInteger(value.build)) {
    throw new Error('the update server sent something this app could not read')
  }
  if (typeof value.zipUrl !== 'string' || !value.zipUrl.startsWith('https://')) {
    // HTTPS only. A plain-HTTP download is one anybody on the same network can
    // replace, and what it replaces is the application.
    throw new Error('the update server offered a download that is not https')
  }
  if (typeof value.sha256 !== 'string' || !/^[0-9a-f]{64}$/i.test(value.sha256)) {
    throw new Error('the update server offered a download with no checksum')
  }
  return {
    build: value.build,
    version: String(value.version ?? value.build),
    zipUrl: value.zipUrl,
    sha256: value.sha256.toLowerCase(),
    notes: Array.isArray(value.notes) ? value.notes.filter((n) => typeof n === 'string') : [],
    // Carried through, and this line is load-bearing. This function rebuilds
    // the manifest field by field rather than passing the parsed JSON on, and
    // the signature was not among them — so `manifestIsAuthentic` read
    // `undefined`, verified an empty signature, and refused EVERY genuine
    // release as forged. The check was written, shipped, and had never once
    // run against a real signed manifest, because no update has been installed
    // since signing was added.
    signature: typeof value.signature === 'string' ? value.signature : '',
  }
}

/**
 * Downloads the zip to a temporary folder and checks it against its hash.
 *
 * The hash is not ceremony. This writes over a working till, and a download
 * truncated by a dropped connection is a perfectly ordinary event on a shop's
 * internet — one that would otherwise unpack as a half-application.
 */
async function downloadAndVerify(manifest) {
  const staging = await mkdtemp(path.join(tmpdir(), 'violy-update-'))
  const zipPath = path.join(staging, 'update.zip')

  const response = await fetch(manifest.zipUrl, { signal: AbortSignal.timeout(180_000) })
  if (!response.ok) throw new Error(`download returned ${response.status}`)
  await pipeline(Readable.fromWeb(response.body), createWriteStream(zipPath))

  const actual = createHash('sha256').update(await readFile(zipPath)).digest('hex')
  if (actual !== manifest.sha256) {
    throw new Error(`the download did not match its checksum (expected ${manifest.sha256.slice(0, 12)}…, got ${actual.slice(0, 12)}…)`)
  }
  say(`  verified (${manifest.sha256.slice(0, 12)}…)`)

  // Expanded with PowerShell on Windows and `unzip` elsewhere, rather than
  // adding a zip library to a script that has to run before `npm install` has
  // had a chance to fix anything.
  const outDir = path.join(staging, 'app')
  if (process.platform === 'win32') {
    sh(
      `powershell -NoProfile -Command "Expand-Archive -LiteralPath '${zipPath}' -DestinationPath '${outDir}' -Force"`,
      { stdio: 'ignore' },
    )
  } else {
    sh(`unzip -q -o "${zipPath}" -d "${outDir}"`, { stdio: 'ignore' })
  }

  // Releases are packaged with everything at the top level, but a zip built
  // another way may wrap it in one folder. Unwrap that rather than writing a
  // nested copy over the install.
  const entries = await import('node:fs/promises').then((fs) => fs.readdir(outDir))
  if (entries.length === 1) {
    const inner = path.join(outDir, entries[0])
    const stat = await import('node:fs/promises').then((fs) => fs.stat(inner))
    if (stat.isDirectory() && !existsSync(path.join(outDir, 'package.json'))) return inner
  }
  return outDir
}

/**
 * Copies the new files over the install.
 *
 * What is NOT in the zip is the point: the database, `.env`, `backups/`,
 * `data/` and `node_modules/` are never packaged, so they cannot be
 * overwritten by an update. The shop's data survives because it was never in
 * the delivery, not because something remembered to skip it.
 */
async function applyFiles(sourceDir, manifest) {
  await cp(sourceDir, ROOT, { recursive: true, force: true })

  // Copying is not enough, and this is what that cost.
  //
  // An update overwrote what the new build ships and left everything else
  // alone — including files the new build had DELETED. Harmless until one of
  // them imports something deleted with it, and then `next build` fails on a
  // screen that no longer exists and the whole update rolls back. The shop's
  // laptop hit exactly that going 11 → 18: `discount-rules.ts` and
  // `DiscountEditor.tsx` survived `4d29eaa`, kept importing `isDiscountBasis`,
  // and produced six errors about a discount screen removed a week earlier.
  //
  // Only `src`, `electron` and `scripts` are pruned — see `PRUNABLE_DIRS` for
  // why that is a list and not "everything the zip lacks". The database, `.env`
  // and `backups/` are absent from the zip because they must never be shipped,
  // not because they are unwanted.
  const shipped = await listFilesUnder(sourceDir)
  const present = await listFilesUnder(ROOT, PRUNABLE_DIRS)
  const stale = filesToPrune(present, shipped)

  for (const relative of stale) {
    await rm(path.join(ROOT, relative), { force: true }).catch(() => {})
  }
  if (stale.length > 0) {
    say(`  removed ${stale.length} file(s) this version no longer uses`)
  }

  // Stamped last, so a copy that failed halfway does not claim to be the new
  // build and skip the update next time.
  await writeFile(
    path.join(ROOT, 'release.json'),
    JSON.stringify(
      { build: manifest.build, version: manifest.version, installedAt: new Date().toISOString() },
      null,
      2,
    ) + NEWLINE,
    'utf8',
  )

  await rm(path.dirname(sourceDir), { recursive: true, force: true }).catch(() => {})
}

/**
 * Every file under `root`, relative to it, as forward-slashed paths.
 *
 * `roots` narrows the walk to particular top-level directories — used when
 * listing what is on disk, so this never descends into `node_modules` or
 * `.next`, which between them hold tens of thousands of files nobody is asking
 * about and would turn a two-second step into a minute.
 */
async function listFilesUnder(root, roots = null) {
  const out = []
  const starts = roots ?? ['']

  async function walk(relative) {
    let entries
    try {
      entries = await readdir(path.join(root, relative), { withFileTypes: true })
    } catch {
      return
    }
    for (const entry of entries) {
      const next = relative === '' ? entry.name : `${relative}/${entry.name}`
      if (entry.isDirectory()) await walk(next)
      else if (entry.isFile()) out.push(next)
    }
  }

  for (const start of starts) await walk(start)
  return out
}

async function restartAndExit() {
  const launcher = path.join(ROOT, 'start-pos.cmd')
  const child = existsSync(launcher) && process.platform === 'win32'
    ? spawn('cmd.exe', ['/c', 'start', '""', launcher], { cwd: ROOT, detached: true, stdio: 'ignore' })
    : spawn('npm', ['start'], { cwd: ROOT, detached: true, stdio: 'ignore', shell: true })
  child.unref()
  say('\nThe app is starting. You can close this window.')
  await waitForKey()
}

async function main() {
  say('════════════════════════════════════════')
  say('  Violy Store — installing an update')
  say('════════════════════════════════════════')
  say('\nPlease do not close this window until it says it is finished.')

  // ── 1. back up first, always ───────────────────────────────────────────
  step(1, 'Saving a backup of your data…')
  try {
    sh('npm run backup')
  } catch (error) {
    // The one failure that stops everything: without a backup there is no way
    // back from a bad migration.
    await fail('could not save a backup of your data.', error)
  }

  // ── 2. what is installed, and what is published ────────────────────────
  //
  // No git anywhere in here any more. It used to run `git status`, `git fetch`
  // and `git merge --ff-only`, which meant the shop laptop needed git INSTALLED
  // and signed in to GitHub, because the source repository is private. Two
  // things to set up, and a credential that expires quietly months later,
  // leaving a till that stops receiving fixes with nothing on screen to say so.
  step(2, 'Checking for a new version…')

  const installed = await readInstalled()
  if (!installed) {
    await fail(
      'this copy was installed from source rather than from a release, so it cannot update itself. Pull and rebuild instead.',
    )
  }

  let manifest
  try {
    manifest = await fetchManifest()
  } catch (error) {
    await fail('could not reach the update server. Check the internet connection.', error)
  }

  if (manifest.build <= installed.build) {
    if (!FORCE) {
      say(`\n  Already up to date — you have build ${installed.build} (${installed.version}).`)
      say('\nNothing to install.')
      await restartAndExit()
      return
    }
    say(`\n  Build ${manifest.build} is already the installed version.`)
    say('  Reinstalling it anyway, because this was asked for directly.')
  }

  say(`  installed: build ${installed.build} (${installed.version})`)
  say(`  available: build ${manifest.build} (${manifest.version})`)

  // Before a single byte of the zip is fetched.
  if (!manifestIsAuthentic(manifest)) {
    await fail(
      [
        'this update could not be verified as authentic and was NOT installed.',
        '',
        'The update was signed with the wrong key, or not signed at all, or it',
        'was changed after it was published. Either way it is not something this',
        'app should install.',
        '',
        'Tell whoever looks after this app before trying again.',
      ].join(NEWLINE),
    )
  }
  say('  signature checked.')

  // ── 3. stop the running app ────────────────────────────────────────────
  //
  // This is the step that makes the rest possible. While the server runs it
  // holds `node_modules` and `.next` open, and on Windows that turns
  // `npm install` and `next build` into permission errors rather than
  // failures anyone can interpret.
  step(3, 'Closing the app…')
  stopServer()
  say('  closed.')

  // ── 4. download, verify, unpack ────────────────────────────────────────
  step(4, 'Downloading the update…')
  let staged
  try {
    staged = await downloadAndVerify(manifest)
  } catch (error) {
    await fail('could not download the update, or it arrived damaged.', error)
  }

  // Only now, with a VERIFIED copy on disk, is anything overwritten. Unpacking
  // a half-downloaded zip over a working till is the one failure this ordering
  // exists to prevent.
  say('  unpacking…')
  try {
    // Copied aside first: from here on, a failure has something to undo.
    await snapshotApp()
    await applyFiles(staged, manifest)
  } catch (error) {
    await fail('could not write the updated files.', error)
  }

  {
    // ── 5-7. dependencies, database, build ───────────────────────────────
    step(5, 'Installing the parts it needs…')
    try {
      sh('npm install')
    } catch (error) {
      await fail('could not install the updated parts.', error)
    }

    step(6, 'Updating the database…')
    try {
      // `migrate deploy`, never `migrate dev`: deploy applies existing
      // migrations and nothing else. `dev` can decide the database has drifted
      // and offer to RESET it, which on a shop laptop means deleting the
      // ledger.
      sh('npx prisma migrate deploy')
      sh('npx prisma generate')

      // `prisma generate` writes the 20 MB engine to a temp name and renames
      // it into place. On Windows that rename fails whenever anything still
      // holds the old engine — which on a shop laptop is most of the time, the
      // app having only just been asked to close. The temp copy is then
      // abandoned, and nothing has ever collected them: seventeen had piled up
      // in this project, 343 MB of nothing.
      const swept = await sweepPrismaTemps(ROOT)
      if (swept.removed > 0) {
        say(`  cleaned up ${swept.removed} leftover file(s), ${Math.round(swept.bytes / 1024 / 1024)} MB`)
      }
    } catch (error) {
      await fail('could not update the database. Your backup is safe.', error)
    }

    step(7, 'Preparing the app…')
    try {
      // Throw away the previous build first. Twice while building this, a
      // `next build` started moments after the server was killed died with
      // eighteen copies of "Can't resolve '@vercel/turbopack-next/internal/
      // font/google/font'" — a message that says nothing about the real
      // cause, which is a Turbopack cache left half-written by the process
      // that was serving from it. `rm -rf .next` fixed it both times.
      //
      // This updater does exactly that sequence: it stops the server by port
      // and then builds. Removing the folder costs a slower build once and
      // removes the chance of an update failing on a message nobody in this
      // shop could act on.
      rmSync('.next', { recursive: true, force: true })
      sh('npm run build')
    } catch (error) {
      await fail('could not prepare the updated app.', error)
    }
  }

  // Nothing left to undo. Dropped before the restart so a laptop that is
  // opened and closed all day does not collect a temp copy of the app each
  // time it updates.
  if (appSnapshot) {
    await rm(appSnapshot, { recursive: true, force: true }).catch(() => {})
    appSnapshot = null
  }

  // ── start again ────────────────────────────────────────────────────────
  say('\n════════════════════════════════════════')
  say(`  Updated to build ${manifest.build} (${manifest.version}). Starting the app…`)
  say('════════════════════════════════════════')

  await restartAndExit()
}

main().catch(async (error) => {
  await fail('something unexpected went wrong.', error)
})
