@echo off
REM ===========================================================================
REM  Violy Store POS — one-time setup
REM
REM  Run this once on the shop laptop. It installs what the app needs, prepares
REM  the database, builds the app, and puts an icon on the Desktop and in the
REM  Start menu so it opens like any other program.
REM
REM  Everything it does is repeatable: running it twice is harmless, and it
REM  never touches the database's contents — only its structure, and only
REM  forward.
REM ===========================================================================

setlocal
cd /d "%~dp0"

echo.
echo  ========================================
echo    Violy Store POS - setup
echo  ========================================
echo.
echo  This takes a few minutes. Please leave the window open.
echo.

REM --- Node is the one thing this cannot install for itself -----------------
where node >nul 2>&1
if errorlevel 1 (
  echo  [X] Node.js is not installed on this computer.
  echo.
  echo      Install it from https://nodejs.org  ^(the "LTS" version^),
  echo      then run this file again.
  echo.
  pause
  exit /b 1
)

REM --- .env is not in git, so a fresh clone has none ----------------------
REM  Without it DATABASE_URL is undefined and `prisma migrate deploy` stops
REM  with a validation error that names neither the file nor the fix. Verified
REM  by cloning this repository into an empty folder and running the step.
if not exist ".env" (
  echo  Creating .env from .env.example...
  copy /Y ".env.example" ".env" >nul
  if errorlevel 1 goto failed
)

echo  [1/6] Installing the parts the app needs...
call npm install
if errorlevel 1 goto failed

echo.
echo  [2/6] Preparing the database...
REM `migrate deploy` only applies migrations that already exist. `migrate dev`
REM is never used here: it can decide the database has drifted and offer to
REM RESET it, which on this laptop means deleting the ledger.
call npx prisma migrate deploy
if errorlevel 1 goto failed
call npx prisma generate
if errorlevel 1 goto failed

REM  A failed `prisma generate` abandons a 20 MB copy of the query engine, and
REM  nothing has ever collected them. Seventeen had accumulated in development
REM  — 343 MB. Not fatal if it fails; there is nothing here the app needs.
call node scripts/sweep-prisma-temps.mjs

echo.
echo  [3/6] Building the app...
call npm run build
if errorlevel 1 goto failed

echo.
echo  [4/6] Making the Desktop and Start menu icons...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\make-shortcuts.ps1"
if errorlevel 1 goto failed

echo.
echo  [5/6] Saving a first backup...
call npm run backup

echo.
echo  [6/6] Checking whether this copy has any data...
call npx tsx scripts/check-data.ts

echo.
echo  ========================================
echo    Setup finished.
echo  ========================================
echo.
echo  There is now a "Violy Store POS" icon on the Desktop.
echo  Double-click it to open the till.
echo.
echo  To make it open by itself when the computer turns on, use the
echo  menu inside the app:  Violy Store  ^>  Start when the computer turns on
echo.
pause
exit /b 0

:failed
echo.
echo  ========================================
echo    Setup did not finish.
echo  ========================================
echo.
echo  Nothing was broken. Read the red text above, or send a photo of this
echo  window to whoever looks after this app.
echo.
pause
exit /b 1
