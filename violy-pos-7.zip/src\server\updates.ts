'use server'

import { readFile } from 'node:fs/promises'
import path from 'node:path'
import { spawn } from 'node:child_process'
import type { ActionResult } from '@/lib/types'
import {
  INSTALLED_RELEASE_FILE,
  RELEASE_MANIFEST_URL,
  isNewer,
  parseInstalled,
  parseManifest,
  type UpdateStatus,
} from '@/lib/update-info'

/** The checkout or install this server is running from. */
const PROJECT_ROOT = process.cwd()

/** Long enough for a slow shop connection, short enough not to feel hung. */
const CHECK_TIMEOUT_MS = 8_000

/**
 * Which build this copy is.
 *
 * Absent on a developer's clone, which is the point: that copy is told there
 * is nothing to update rather than being offered a zip that would overwrite
 * uncommitted work.
 */
export async function installedRelease() {
  try {
    const raw = await readFile(path.join(PROJECT_ROOT, INSTALLED_RELEASE_FILE), 'utf8')
    return parseInstalled(JSON.parse(raw))
  } catch {
    return null
  }
}

/**
 * Asks the public releases channel what the newest build is.
 *
 * One small JSON file over plain HTTPS. No git, no GitHub account, nothing on
 * the laptop that can expire — which is exactly why this replaced `git fetch`.
 *
 * Every failure is a STATE to report, never an exception to throw at somebody
 * who pressed a button: the shop's connection is not guaranteed, and a check
 * that cannot reach the internet is an ordinary Tuesday rather than a fault.
 */
export async function checkForUpdates(): Promise<UpdateStatus> {
  const installed = await installedRelease()
  if (!installed) {
    return {
      kind: 'unknown',
      reason: 'This copy was installed from source, so it updates by rebuilding rather than downloading.',
    }
  }

  let manifest
  try {
    // The `?t=` is a cache-buster, and it is not superstition:
    // `raw.githubusercontent.com` sends `Cache-Control: max-age=300`, so for
    // five minutes after a release the CDN keeps returning the PREVIOUS
    // manifest. `cache: 'no-store'` does not help — that governs this
    // machine's own cache, not a CDN's. Measured: a freshly published build 2
    // still read as build 1, with a `Source-Age` of 261 seconds.
    const response = await fetch(`${RELEASE_MANIFEST_URL}?t=${Date.now()}`, {
      cache: 'no-store',
      signal: AbortSignal.timeout(CHECK_TIMEOUT_MS),
    })
    if (!response.ok) {
      return { kind: 'offline', reason: 'Could not reach the update server. Check the internet connection.' }
    }
    manifest = parseManifest(await response.json())
  } catch {
    return { kind: 'offline', reason: 'Could not reach the update server. Check the internet connection.' }
  }

  if (!manifest) {
    // Reached it and did not understand it. Deliberately NOT reported as
    // "up to date": something is wrong at the other end and saying nothing
    // would hide it.
    return { kind: 'offline', reason: 'The update server sent something this app could not read.' }
  }

  if (!isNewer(manifest, installed)) return { kind: 'up-to-date', installed }
  return { kind: 'available', installed, latest: manifest }
}

/**
 * Starts the updater and returns immediately.
 *
 * The updater runs DETACHED, in its own console window, and is the thing that
 * stops this server. It cannot run inside this process: replacing files that
 * the running server holds open fails on Windows — `prisma generate` in this
 * very project has failed with EPERM because the dev server held the query
 * engine — and `next build` cannot rewrite `.next` while it is being served
 * from.
 *
 * So the sequence is: this returns, the browser shows "closing to install",
 * the updater kills the server, does the work with nothing holding locks, and
 * starts the app again. The console window is deliberately visible: if a step
 * fails, the person can see that it failed and read why, instead of facing an
 * app that never came back.
 */
export async function startUpdate(): Promise<ActionResult<void>> {
  const installed = await installedRelease()
  if (!installed) {
    return {
      ok: false,
      error: 'This copy was installed from source. Update it by pulling and rebuilding instead.',
    }
  }

  try {
    const child = spawn(
      process.platform === 'win32' ? 'cmd.exe' : 'sh',
      process.platform === 'win32'
        ? ['/c', 'start', '"Violy Store update"', 'cmd', '/k', 'node', 'scripts/update.mjs']
        : ['-c', 'node scripts/update.mjs'],
      {
        cwd: PROJECT_ROOT,
        detached: true,
        stdio: 'ignore',
        windowsHide: false,
      },
    )
    // Unreferenced so this server can exit without waiting for it — which it
    // is about to be asked to do by the updater itself.
    child.unref()
    return { ok: true, data: undefined }
  } catch {
    return { ok: false, error: 'Could not start the updater.' }
  }
}

/** Where the updater lives, shown to anyone who would rather run it by hand. */
export async function updaterCommand(): Promise<string> {
  return `node ${path.join('scripts', 'update.mjs')}`
}
