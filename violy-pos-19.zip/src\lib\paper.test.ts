import { createRequire } from 'node:module'
import { readFileSync } from 'node:fs'
import { join } from 'node:path'
import { describe, expect, it } from 'vitest'

/**
 * The receipt roll is 58mm, and that number lives in three languages that
 * cannot import from one another: the print CSS, the injected `@page` rule in
 * a React component, and an Electron constant in inches.
 *
 * It was 80mm everywhere from the day it was written until 26 Aug 2026 — a
 * paper size the shop does not own. Every receipt was laid out roughly a third
 * wider than the paper it printed on, and nothing in the app could notice,
 * because nothing here compares one language's copy against another's. This
 * does. Same guard `health.test.ts` puts on the health check and
 * `startup.test.ts` puts on the counter route.
 */
const ROLL_MM = 58

const css = readFileSync(join(process.cwd(), 'src', 'app', 'globals.css'), 'utf8')
const shell = readFileSync(join(process.cwd(), 'src', 'components', 'DocumentShell.tsx'), 'utf8')
const pdfPage = createRequire(import.meta.url)(
  join(process.cwd(), 'electron', 'pdf-page.js'),
) as { ROLL_WIDTH: number; A4: { width: number; height: number } }

describe('the receipt roll is one width everywhere', () => {
  /** What the printer actually is. Change this and the three below must follow. */
  it('is 58mm', () => {
    expect(ROLL_MM).toBe(58)
  })

  it('the printed page box says so', () => {
    expect(shell).toContain(`@page { size: ${ROLL_MM}mm auto;`)
  })

  /**
   * Both the on-screen preview and the print override. The preview exists so
   * she sees the shape of the paper before spending it, which only helps if it
   * is the shape of the paper.
   */
  it('the stylesheet says so, on screen and on paper', () => {
    const widths = [...css.matchAll(/\.doc-sheet-roll\s*\{[^}]*max-width:\s*(\d+)mm/g)].map(
      (match) => Number(match[1]),
    )
    expect(widths.length).toBeGreaterThanOrEqual(2)
    expect(widths.every((mm) => mm === ROLL_MM)).toBe(true)
  })

  /** `printToPDF` measures in inches, so this one is converted rather than stated. */
  it('the PDF page is the same width in inches', () => {
    expect(pdfPage.ROLL_WIDTH).toBeCloseTo(ROLL_MM / 25.4, 6)
  })

  /**
   * The margins are not decoration. A 58mm head prints 48mm (384 dots at
   * 203dpi), so 5mm each side is what keeps the content inside the printable
   * area — 4mm would leave 50mm and clip at the edges.
   */
  it('leaves a printable column the thermal head can actually reach', () => {
    const margin = Number(shell.match(/@page \{ size: \d+mm auto; margin: (\d+)mm/)?.[1])
    expect(margin).toBe(5)
    expect(ROLL_MM - margin * 2).toBeLessThanOrEqual(48)
  })

  /** A4 is untouched by any of this and must stay itself. */
  it('leaves A4 alone', () => {
    expect(pdfPage.A4.width).toBeCloseTo(8.27, 2)
    expect(shell).toContain('@page { size: A4;')
  })
})

/**
 * `electron/main.js` used to carry its own copy of all three paper constants
 * beside the ones `pdf-page.js` exports, so the roll width was written twice
 * and changing the paper meant remembering both.
 */
describe('electron/main.js does not restate the paper sizes', () => {
  const main = readFileSync(join(process.cwd(), 'electron', 'main.js'), 'utf8')

  it('imports them instead', () => {
    expect(main).toContain("require('./pdf-page')")
  })

  it('declares no width of its own', () => {
    expect(main).not.toMatch(/const ROLL_WIDTH\s*=/)
    expect(main).not.toMatch(/const A4\s*=\s*\{/)
  })
})
