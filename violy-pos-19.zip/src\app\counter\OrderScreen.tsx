'use client'

import { useCallback, useEffect, useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import type {
  CustomerWithDiscount,
  OrderResult,
  ProductWithCategory,
  SaleResult,
} from '@/lib/types'
import { lineTotal, parsePesoInput } from '@/lib/money'
import {
  computeOrderTotals,
  hasOrderDiscount,
  MAX_BPS,
  type DiscountKind,
  type OrderDiscount,
  type LineDiscountMode,
} from '@/lib/discount'
import { createOrder } from '@/server/orders'
import { createSale } from '@/server/sales'
import { CatalogColumn } from './CatalogColumn'
import {
  OrderRail,
  type CustomerPaymentMode,
  type RailLine,
  type RailSelection,
} from './OrderRail'
import { OrderReceipt } from './OrderReceipt'
import { useSavedOrder } from './use-saved-order'
import { lineKey, parseLineKey } from '@/lib/per-kilo'

type Receipt =
  | { kind: 'walkin'; data: SaleResult }
  | { kind: 'customer'; customerName: string; data: OrderResult }

function newCheckoutKey(): string {
  return globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`
}

export function OrderScreen({
  products,
  customers,
  creditByCustomer,
}: {
  products: ProductWithCategory[]
  customers: CustomerWithDiscount[]
  /** Customer id to credit held, in centavos. Absent means none. */
  creditByCustomer: Record<number, number>
}) {
  const router = useRouter()
  const [selection, setSelection] = useState<RailSelection | null>(null)
  const [paymentMode, setPaymentMode] = useState<CustomerPaymentMode>('cash')
  // Opt-in, always. A credit is the customer's money; nothing spends it
  // without being asked to, and she may well want it kept for next time.
  const [useCredit, setUseCredit] = useState(false)
  /**
   * `lineKey(productId, soldPerKilo)` → quantity.
   *
   * Keyed on how the line is priced as well as what it is, because two sacks of
   * Broodsow and five kilos out of the open one are two lines. On a product id
   * alone they would merge into seven of something that does not exist.
   */
  const [quantities, setQuantities] = useState<Map<string, number>>(new Map())
  // productId → what she typed against that line, kept as raw text for the
  // same reason `discountAmount` is: "1," and "1.5" have to be typeable on the
  // way to a number, and a half-typed figure is not a zero.
  const [lineDiscounts, setLineDiscounts] = useState<Map<number, string>>(new Map())
  /**
   * What she has typed into a quantity box, per LINE, before it is a number.
   *
   * Keyed by `lineKey`, so four sacks and five kilos of the same feed keep
   * their own drafts. Held here rather than in the catalog or the rail because
   * the same figure has a box in both places — the product, to put it on the
   * order, and the rail line, to change it while she is looking at the total.
   * Two drafts would let those disagree about what she typed while agreeing
   * about the number, which nobody notices until the wrong figure is read out.
   *
   * Declared UP HERE with the other state, not beside the functions that use
   * it. `railLines` is computed during render and calls `quantityTextOf`, a
   * hoisted function declaration — so it runs happily and then reads a `const`
   * that has not been initialised yet. That is a blank counter reading "Cannot
   * access … before initialization", and only the browser catches it: tsc and
   * the production build are both perfectly happy.
   */
  const [quantityTexts, setQuantityTexts] = useState<Map<string, string>>(new Map())
  // Which line's discount editor is open. Held here rather than in the rail so
  // it survives the rail re-rendering as the total changes, and so saving or
  // removing the line can close it.
  const [editingDiscountFor, setEditingDiscountFor] = useState<number | null>(null)
  /** productId → whether her figure is per unit or for the whole line. */
  const [lineDiscountKinds, setLineDiscountKinds] = useState<Map<number, LineDiscountMode>>(
    new Map(),
  )
  const [cash, setCash] = useState('')
  const [discountAmount, setDiscountAmount] = useState('')
  const [discountKind, setDiscountKind] = useState<DiscountKind>('AMOUNT')
  const [search, setSearch] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [receipt, setReceipt] = useState<Receipt | null>(null)
  const [checkoutKey, setCheckoutKey] = useState(newCheckoutKey)
  const [pending, startTransition] = useTransition()
  const [resetKey, setResetKey] = useState(0)
  const { restored, ready, save: saveOrder, clear: clearSavedOrder } = useSavedOrder()

  // Restores once, after the first client pass. Guarded on `restored` being
  // non-null so it does not fight later edits, and it runs before any save
  // effect below can write the empty initial state back over it.
  useEffect(() => {
    if (!restored) return
    // `String(...)` because a draft written by an older build keyed its lines
    // by a bare product id, which JSON brings back as a number. `parseLineKey`
    // reads a bare id as a sack.
    setQuantities(new Map(restored.lines.map(([key, quantity]) => [String(key), quantity])))
    setLineDiscounts(new Map(restored.lineDiscounts ?? []))
    setSelection(
      restored.walkin
        ? { kind: 'walkin' }
        : restored.customerId !== null && restored.customerName !== null
          ? { kind: 'customer', id: restored.customerId, name: restored.customerName }
          : null,
    )
    setPaymentMode(restored.paymentMode as CustomerPaymentMode)
    setCash(restored.cash)
    setDiscountAmount(restored.discountAmount)
    setDiscountKind(restored.discountKind as DiscountKind)
  }, [restored])

  // Writes on every change, but only once the restore pass has run — without
  // `ready` the first render would persist an empty order over a saved one and
  // erase exactly what this exists to keep.
  useEffect(() => {
    if (!ready) return
    saveOrder({
      lines: [...quantities.entries()],
      lineDiscounts: [...lineDiscounts.entries()],
      customerId: selection?.kind === 'customer' ? selection.id : null,
      customerName: selection?.kind === 'customer' ? selection.name : null,
      walkin: selection?.kind === 'walkin',
      paymentMode,
      cash,
      discountAmount,
      discountKind,
    })
    // `saveOrder` is stable enough for this: it closes over nothing that
    // changes between renders.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    ready,
    quantities,
    lineDiscounts,
    selection,
    paymentMode,
    cash,
    discountAmount,
    discountKind,
  ])

  const dismissReceipt = useCallback(() => setReceipt(null), [])

  /**
   * A line's typed discount in centavos, or null while it is unparseable.
   *
   * Blank is zero, not an error — an empty box is the ordinary line. Anything
   * else that will not parse blocks the save rather than silently pricing at
   * zero, which is the same contract `discountAmount` has.
   */
  function parsedLineDiscount(productId: number): number | null {
    const raw = (lineDiscounts.get(productId) ?? '').trim()
    if (raw === '') return 0
    return parsePesoInput(raw)
  }

  const lines = [...quantities.entries()]
    .filter(([, quantity]) => quantity > 0)
    .flatMap(([key, quantity]) => {
      const parsed = parseLineKey(key)
      if (!parsed) return []
      return [
        {
          productId: parsed.productId,
          soldPerKilo: parsed.soldPerKilo,
          quantity,
          // A per-line discount belongs to the sack line. Loose feed is priced
          // by the kilo already, and a second per-unit figure on top of a
          // per-kilo price is a rate off a rate — the order discount is the
          // one that still applies to it.
          discountPerUnitCentavos: parsed.soldPerKilo
            ? 0
            : (parsedLineDiscount(parsed.productId) ?? 0),
          discountMode: parsed.soldPerKilo
            ? ('EACH' as LineDiscountMode)
            : (lineDiscountKinds.get(parsed.productId) ?? 'EACH'),
        },
      ]
    })

  // Every typed line discount has to parse before anything can be saved. A
  // line whose box holds "5o" would otherwise be sent as no discount at all,
  // and she would read one figure aloud while another hit the books.
  const lineDiscountsAreValid = lines.every(
    (line) => line.soldPerKilo || parsedLineDiscount(line.productId) !== null,
  )

  const selectedCustomer =
    selection?.kind === 'customer'
      ? (customers.find((customer) => customer.id === selection.id) ?? null)
      : null

  // A blank field is no discount, not a zero-value one. Anything unparseable
  // is a validation failure that blocks Save, exactly like the cash field —
  // never silently coerced to zero.
  const discountBlank = discountAmount.trim() === ''
  const parsedDiscount = discountBlank ? 0 : parsePesoInput(discountAmount)
  const discountIsValid = parsedDiscount !== null

  // `parsePesoInput` scales by 100, which is what both readings of this field
  // need: "50" is 5000 centavos and "10.5" is 1050 basis points — pesos and
  // percentages are both quoted to two decimal places, so one parse serves
  // both and the toggle only decides which field it lands in.
  const discountValue = parsedDiscount ?? 0
  const orderDiscount: OrderDiscount = {
    kind: discountKind,
    amountCentavos: discountKind === 'AMOUNT' ? discountValue : 0,
    bps: discountKind === 'PERCENT' ? Math.min(discountValue, MAX_BPS) : 0,
  }

  // The same `computeOrderTotals` the Server Action calls. This preview is
  // what she reads out to the customer, so it cannot be a second
  // implementation that agrees with the server most of the time.
  /** The price this line is actually sold at — by the sack, or by the kilo. */
  function priceOf(product: ProductWithCategory | undefined, soldPerKilo: boolean): number {
    if (!product) return 0
    return soldPerKilo ? (product.pricePerKiloCentavos ?? 0) : product.price
  }

  // Only lines whose product is on this page; kept as one array so the totals
  // below can be zipped back onto it by index.
  const pricedLines = lines.flatMap((line) => {
    const product = products.find((candidate) => candidate.id === line.productId)
    return product ? [{ ...line, product }] : []
  })

  const totals = computeOrderTotals({
    lines: pricedLines.map((line) => ({
      productId: line.productId,
      quantity: line.quantity,
      priceCentavos: priceOf(line.product, line.soldPerKilo),
      manualDiscountPerUnitCentavos: line.discountPerUnitCentavos,
      manualDiscountMode: line.discountMode,
    })),
    order: orderDiscount,
  })

  // By INDEX, not by product id. Two lines can now share a product — a sack
  // line and a kilo line — and a map keyed on the id would give both of them
  // whichever total was written last.
  const railLines: RailLine[] = pricedLines.map((line, index) => {
    const priced = totals.lines[index]
    const unitPrice = priceOf(line.product, line.soldPerKilo)
    return {
      productId: line.productId,
      soldPerKilo: line.soldPerKilo,
      quantityText: quantityTextOf(line.productId, line.soldPerKilo),
      // Null for kilos: loose feed takes nothing off stock, so it has no figure
      // to push below zero.
      stockAfter: line.soldPerKilo ? null : line.product.stockQty - line.quantity,
      name: line.product.name,
      quantity: line.quantity,
      totalCentavos: priced?.lineTotalCentavos ?? 0,
      // What it would come to at list price, so a discounted row can show
      // what it WAS as well as what it is.
      listTotalCentavos: lineTotal(unitPrice, line.quantity),
      // Raw text, so the rail's box shows exactly what she typed, and the
      // resolved figure, so it can say what actually came off.
      discountRaw: line.soldPerKilo ? '' : (lineDiscounts.get(line.productId) ?? ''),
      discountKind: line.soldPerKilo
        ? 'EACH'
        : (lineDiscountKinds.get(line.productId) ?? 'EACH'),
      lineDiscountCentavos: priced?.lineDiscountCentavos ?? 0,
      discountIsValid: line.soldPerKilo || parsedLineDiscount(line.productId) !== null,
      appliedDiscountPerUnitCentavos: priced?.discountPerUnitCentavos ?? 0,
    }
  })

  /**
   * Keeps only what can be part of a peso figure.
   *
   * Refused as she types rather than flagged afterwards. The box used to
   * accept "500zz", paint itself red and block the save — which is a
   * correction, not a guard, and it stops the sale at the worst moment. A
   * keypad cannot type a letter into a till drawer and neither should this.
   *
   * One decimal point only, and nothing before a leading dot is invented —
   * ".5" is left as she typed it for `parsePesoInput` to read.
   */
  function digitsOnly(raw: string): string {
    const kept = raw.replace(/[^0-9.]/g, '')
    const firstDot = kept.indexOf('.')
    if (firstDot === -1) return kept
    return kept.slice(0, firstDot + 1) + kept.slice(firstDot + 1).replace(/\./g, '')
  }

  function setQuantityText(productId: number, soldPerKilo: boolean, raw: string) {
    const cleaned = digitsOnly(raw)
    const key = lineKey(productId, soldPerKilo)
    setQuantityTexts((previous) => new Map(previous).set(key, cleaned))
    // `Number('2.')` is 2, which is right while she is still typing, and
    // `Number('')` is 0, which removes the line — what an empty quantity means
    // everywhere else here.
    setQuantity(productId, soldPerKilo, Number(cleaned) || 0)
  }

  /** The text a line's quantity box should show, whichever box is asking. */
  function quantityTextOf(productId: number, soldPerKilo: boolean): string {
    const key = lineKey(productId, soldPerKilo)
    const draft = quantityTexts.get(key)
    if (draft !== undefined) return draft
    const quantity = quantities.get(key) ?? 0
    return quantity > 0 ? String(quantity) : ''
  }

  function setLineDiscountKind(productId: number, mode: LineDiscountMode) {
    setLineDiscountKinds((previous) => {
      const next = new Map(previous)
      if (mode === 'EACH') next.delete(productId)
      else next.set(productId, mode)
      return next
    })
  }

  function setLineDiscount(productId: number, rawInput: string) {
    const raw = digitsOnly(rawInput)
    setLineDiscounts((previous) => {
      const next = new Map(previous)
      // An emptied box is removed rather than stored blank, so a draft does
      // not accumulate a key per product she once touched.
      if (raw.trim() === '') next.delete(productId)
      else next.set(productId, raw)
      return next
    })
  }

  const totalCentavos = totals.totalCentavos
  const discountCentavos = totals.totalDiscountCentavos

  const cashBlank = cash.trim() === ''
  const parsedCash = cashBlank ? 0 : parsePesoInput(cash)
  const cashIsValid = parsedCash !== null
  const cashCentavos = parsedCash ?? 0

  // What the shop is holding for this customer, and how much of it this
  // order can actually absorb — never more than the order is worth, or the
  // change would be cash the shop never received.
  const availableCreditCentavos =
    selection?.kind === 'customer' ? (creditByCustomer[selection.id] ?? 0) : 0
  const creditAppliedCentavos =
    useCredit && selection?.kind === 'customer'
      ? Math.min(availableCreditCentavos, totalCentavos)
      : 0

  // Everything below prices against what is left AFTER credit. Comparing
  // against the full total would ask her for cash the credit already covered,
  // and would compute the change against the wrong figure.
  const dueCentavos = Math.max(0, totalCentavos - creditAppliedCentavos)

  const exactCashMode =
    selection?.kind === 'walkin' ||
    (selection?.kind === 'customer' && paymentMode === 'cash')
  const displayedTenderCentavos = cashBlank && exactCashMode ? dueCentavos : cashCentavos
  const chargeCentavos =
    selection?.kind === 'customer' && paymentMode === 'credit'
      ? dueCentavos
      : Math.max(0, dueCentavos - displayedTenderCentavos)
  const changeCentavos = Math.max(0, displayedTenderCentavos - dueCentavos)
  const shortCentavos =
    exactCashMode && !cashBlank && cashIsValid
      ? Math.max(0, dueCentavos - cashCentavos)
      : 0

  function setQuantity(productId: number, soldPerKilo: boolean, quantity: number) {
    const key = lineKey(productId, soldPerKilo)
    setQuantities((previous) => {
      const next = new Map(previous)
      if (quantity <= 0) next.delete(key)
      else next.set(key, quantity)
      return next
    })
  }

  function resetAfterSave() {
    // The saved draft goes with the order it belonged to. Leaving it would
    // repopulate the counter with a sale that has already been rung up.
    clearSavedOrder()
    setSelection(null)
    setPaymentMode('cash')
    setQuantities(new Map())
    setLineDiscounts(new Map())
    setLineDiscountKinds(new Map())
    setEditingDiscountFor(null)
    setCash('')
    // The discount belongs to the order that just closed, not the next one.
    setDiscountAmount('')
    setDiscountKind('AMOUNT')
    setSearch('')
    setCheckoutKey(newCheckoutKey())
    setResetKey((value) => value + 1)
  }

  function save() {
    if (!selection) return
    setError(null)
    const key = checkoutKey

    startTransition(async () => {
      if (selection.kind === 'walkin') {
        const result = await createSale({
          items: lines,
          cashTenderedCentavos: cashBlank ? null : cashCentavos,
          orderDiscount,
          clientOrderKey: key,
        })
        if (!result.ok) {
          setError(result.error)
          return
        }
        setReceipt({ kind: 'walkin', data: result.data })
      } else {
        const tender =
          paymentMode === 'credit' ? 0 : cashBlank && paymentMode === 'cash' ? null : cashCentavos
        const result = await createOrder({
          customerId: selection.id,
          lines,
          cashPaidCentavos: tender,
          // The server re-reads her live balance and caps this itself; what is
          // sent is a request, not an authority.
          creditAppliedCentavos: creditAppliedCentavos || undefined,
          orderDiscount,
          clientOrderKey: key,
        })
        if (!result.ok) {
          setError(result.error)
          return
        }
        setReceipt({ kind: 'customer', customerName: selection.name, data: result.data })
      }

      resetAfterSave()
      router.refresh()
    })
  }

  const paymentIsValid = (() => {
    if (!selection) return false
    if (!cashIsValid) return false
    if (selection.kind === 'walkin') return cashBlank || cashCentavos >= totalCentavos
    if (paymentMode === 'credit') return true
    // Against `dueCentavos`, so a credit that covers the whole order leaves
    // nothing to collect and an empty cash box is still a complete payment.
    if (paymentMode === 'cash') return cashBlank || cashCentavos >= dueCentavos
    return !cashBlank && cashCentavos > 0 && cashCentavos < dueCentavos
  })()

  const canSave =
    selection !== null &&
    lines.length > 0 &&
    paymentIsValid &&
    discountIsValid &&
    lineDiscountsAreValid &&
    !pending

  return (
    // Side by side from `lg` (1024px), not `xl` (1280px). The rail carries the
    // running total, and below the old threshold it dropped BENEATH the catalog
    // — so on any laptop narrower than 1280 she was adding items with the total
    // scrolled off screen, which is the one thing a point of sale cannot do. It
    // narrows to 20rem before it gives up the row, rather than stacking.
    <div className="flex flex-col gap-6 lg:h-full lg:min-h-0 lg:flex-row">
      <div className="min-w-0 flex-1 lg:flex lg:min-h-0 lg:flex-col">
        <CatalogColumn
          products={products}
          quantities={quantities}
          onChange={setQuantity}
          kiloTextOf={(id) => quantityTextOf(id, true)}
          onKiloTextChange={(id, raw) => setQuantityText(id, true, raw)}
          search={search}
          onSearchChange={setSearch}
          resetKey={resetKey}
        />
      </div>

      {/* The rail scrolls on its own too. A twenty-line order used to run off
          the bottom with no way to reach the rest of it, now that the page
          itself no longer scrolls.

          320px up to `2xl`, and wider only above it. Measured rather than
          assumed: at 1366 — the shop laptop — 320px holds three product cards
          across and 384px drops it to two, so the shop laptop keeps exactly
          what it has. A 1920 monitor has room for both, and there the fixed
          320 was the reason the rail stayed cramped while the catalog took
          everything: a customer's name truncated to "Adrian Magpant…" beside
          hundreds of pixels of empty catalog. `2xl` is 1536, comfortably above
          1366. */}
      <div className="w-full shrink-0 lg:w-80 lg:overflow-y-auto 2xl:w-[26rem]">
        <div>
          {receipt ? (
            receipt.kind === 'walkin' ? (
              <OrderReceipt
                kind="walkin"
                saleId={receipt.data.saleId}
                createdAt={receipt.data.createdAt}
                lines={receipt.data.lines}
                totalCentavos={receipt.data.totalCentavos}
                cashPaidCentavos={receipt.data.cashPaidCentavos}
                cashTenderedCentavos={receipt.data.cashTenderedCentavos}
                changeCentavos={receipt.data.changeCentavos}
                onDismiss={dismissReceipt}
              />
            ) : (
              <OrderReceipt
                kind="customer"
                saleId={receipt.data.saleId}
                createdAt={receipt.data.createdAt}
                customerName={receipt.customerName}
                lines={receipt.data.lines}
                totalCentavos={receipt.data.totalCentavos}
                cashPaidCentavos={receipt.data.cashPaidCentavos}
                cashTenderedCentavos={receipt.data.cashTenderedCentavos}
                chargedCentavos={receipt.data.chargedCentavos}
                changeCentavos={receipt.data.changeCentavos}
                newBalanceCentavos={receipt.data.newBalanceCentavos}
                onDismiss={dismissReceipt}
              />
            )
          ) : (
            <OrderRail
              customers={customers}
              selection={selection}
              onSelectionChange={(next) => {
                setSelection(next)
                setPaymentMode('cash')
                setCash('')
                // Belongs to the customer who was selected, not to the order.
                setUseCredit(false)
              }}
              paymentMode={paymentMode}
              onPaymentModeChange={setPaymentMode}
              lines={railLines}
            onLineDiscountChange={setLineDiscount}
            editingDiscountFor={editingDiscountFor}
            onLineDiscountKindChange={setLineDiscountKind}
            onEditDiscountFor={setEditingDiscountFor}
              onQuantityTextChange={setQuantityText}
              onRemoveLine={(productId, soldPerKilo) => {
              // A removed line cannot leave its editor open over the row that
              // moves up into its place. Only a sack line has one.
              if (!soldPerKilo && editingDiscountFor === productId) setEditingDiscountFor(null)
              setQuantity(productId, soldPerKilo, 0)
            }}
              totalCentavos={totalCentavos}
              discountCentavos={discountCentavos}
              lineDiscountCentavos={totals.lineDiscountCentavos}
              orderDiscountCentavos={totals.orderDiscountCentavos}
              subtotalCentavos={totals.subtotalCentavos}
              discountAmount={discountAmount}
              onDiscountAmountChange={setDiscountAmount}
              discountKind={discountKind}
              onDiscountKindChange={setDiscountKind}
              discountIsValid={discountIsValid}
              availableCreditCentavos={availableCreditCentavos}
              creditAppliedCentavos={creditAppliedCentavos}
              useCredit={useCredit}
              onUseCreditChange={setUseCredit}
              dueCentavos={dueCentavos}
              cash={cash}
              onCashChange={setCash}
              cashIsValid={cashIsValid}
              chargeCentavos={chargeCentavos}
              changeCentavos={changeCentavos}
              shortCentavos={shortCentavos}
              onSave={save}
              canSave={canSave}
              pending={pending}
              error={error}
            />
          )}
        </div>
      </div>
    </div>
  )
}
