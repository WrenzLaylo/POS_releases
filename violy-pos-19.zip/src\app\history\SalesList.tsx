'use client'

import Link from 'next/link'
import { Fragment, useState } from 'react'
import { lineTotal } from '@/lib/money'
import { saleStatus } from '@/lib/money-display'
import { deliveryNote, sale as saleRoute } from '@/lib/routes'
import type { SaleWithItems } from '@/lib/types'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { Money } from '@/components/ui/Money'
import { EmptyState } from '@/components/ui/EmptyState'
import { unitSold } from '@/lib/per-kilo'

export function SalesList({ sales }: { sales: SaleWithItems[] }) {
  const [expanded, setExpanded] = useState<number | null>(null)

  if (sales.length === 0) {
    return <EmptyState>No sales match these filters.</EmptyState>
  }

  return (
    <div className="overflow-x-auto rounded-xl bg-surface">
      <table className="w-full min-w-[760px] text-sm">
        <thead className="bg-surface-sunk text-left text-xs uppercase tracking-wide text-ink-muted">
          <tr>
            <th className="px-4 py-3">Receipt</th>
            <th className="px-4 py-3">Date</th>
            <th className="px-4 py-3">Customer</th>
            <th className="px-4 py-3">Lines</th>
            <th className="px-4 py-3 text-right">Total</th>
            <th className="px-4 py-3 text-right">Payment</th>
            <th className="px-4 py-3" />
          </tr>
        </thead>
        <tbody className="divide-y divide-line">
          {sales.map((sale) => {
            const status = saleStatus({
              hasLiveCharge: sale.ledgerEntry !== null && !sale.ledgerEntry.isVoided,
              cashPaidCentavos: sale.cashPaidCentavos,
              totalCentavos: sale.totalAmount,
              isVoided: sale.isVoided,
            })
            const creditCentavos = Math.max(0, sale.totalAmount - sale.cashPaidCentavos)
            const displayedCreditCentavos =
              status === 'credit' || status === 'partial' ? creditCentavos : 0

            return (
              <Fragment key={sale.id}>
                <tr className={sale.isVoided ? 'opacity-60' : undefined}>
                  <td className="px-4 py-3 font-mono text-ink-muted">#{sale.id}</td>
                  <td className="px-4 py-3">
                    {sale.createdAt.toLocaleString('en-PH', {
                      dateStyle: 'medium',
                      timeStyle: 'short',
                    })}
                  </td>
                  {/* A second line rather than a seventh column. This table
                      is already `min-w-[760px]`, and 1024 has to keep fitting
                      — see docs/RESPONSIVE.md. The date and destination are
                      also more useful here than a bare "Delivery" chip would
                      be: they answer "which load was that" without opening
                      the row. */}
                  <td className="px-4 py-3 font-medium text-ink">
                    {sale.customer?.name ?? 'Walk-in'}
                    {sale.deliverAt && (
                      <span className="mt-0.5 block text-xs font-normal text-ink-muted">
                        Deliver{' '}
                        {sale.deliverAt.toLocaleDateString('en-PH', {
                          day: 'numeric',
                          month: 'short',
                        })}
                        {sale.deliverTo && `, ${sale.deliverTo}`}
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-ink-muted">{sale.items.length}</td>
                  <td className="px-4 py-3 text-right">
                    <Money centavos={sale.totalAmount} tone="neutral" className="font-semibold" />
                  </td>
                  <td className="px-4 py-3 text-right">
                    {status === 'cash' && <Badge tone="paid">Cash sale</Badge>}
                    {status === 'credit' && <Badge tone="owed">Full credit</Badge>}
                    {status === 'partial' && <Badge tone="owed">Partial</Badge>}
                    {status === 'charge-voided' && (
                      <Badge tone="neutral">Charge voided</Badge>
                    )}
                    {status === 'voided' && <Badge tone="muted">Voided</Badge>}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex justify-end gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => setExpanded(expanded === sale.id ? null : sale.id)}
                      >
                        {expanded === sale.id ? 'Hide' : 'View'}
                      </Button>
                      {sale.deliverAt && (
                        <Link
                          href={deliveryNote(sale.id)}
                          className="inline-flex h-8 items-center rounded-control px-3 text-sm font-medium text-ink-muted hover:bg-accent-soft hover:text-ink"
                        >
                          Note
                        </Link>
                      )}
                      <Link
                        href={saleRoute(sale.id)}
                        className="inline-flex h-8 items-center rounded-control px-3 text-sm font-medium text-accent hover:bg-accent-soft"
                      >
                        Open
                      </Link>
                    </div>
                  </td>
                </tr>
                {expanded === sale.id && (
                  <tr className="bg-surface-sunk">
                    <td colSpan={7} className="px-8 py-4">
                      <ul className="divide-y divide-line">
                        {sale.items.map((item) => {
                          const netPrice = item.priceAtSale - item.discountAtSale
                          return (
                            <li key={item.id} className="flex justify-between gap-4 py-2">
                              <span>
                                {item.product.name}
                                <span className="ml-2 text-ink-muted">
                                  {item.quantity} {unitSold(item.product.unit, item.soldPerKilo)} ×{' '}
                                  <Money centavos={netPrice} tone="neutral" />
                                </span>
                                {item.discountAtSale > 0 && (
                                  <span className="ml-2 text-ink-muted">
                                    (less <Money centavos={item.discountAtSale} tone="neutral" /> per unit)
                                  </span>
                                )}
                              </span>
                              <Money
                                centavos={lineTotal(netPrice, item.quantity)}
                                tone="neutral"
                                className="font-medium"
                              />
                            </li>
                          )
                        })}
                      </ul>

                      <div className="mt-4 grid gap-2 border-t border-line pt-4 sm:grid-cols-3">
                        <div>
                          <div className="text-xs uppercase tracking-wide text-ink-muted">Cash kept</div>
                          <Money centavos={sale.cashPaidCentavos} tone="in" scale="strong" />
                        </div>
                        <div>
                          <div className="text-xs uppercase tracking-wide text-ink-muted">Credit created</div>
                          <Money
                            centavos={displayedCreditCentavos}
                            tone={displayedCreditCentavos > 0 ? 'owed' : 'zero'}
                            scale="strong"
                          />
                        </div>
                        <div>
                          <div className="text-xs uppercase tracking-wide text-ink-muted">Change</div>
                          <Money centavos={sale.changeCentavos} tone="neutral" scale="strong" />
                        </div>
                      </div>

                      {sale.isVoided && sale.voidReason && (
                        <p className="mt-3 text-sm text-owed">Void reason: {sale.voidReason}</p>
                      )}
                    </td>
                  </tr>
                )}
              </Fragment>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}
