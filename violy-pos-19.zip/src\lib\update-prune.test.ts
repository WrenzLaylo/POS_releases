import { describe, expect, it } from 'vitest'
import { PRUNABLE_DIRS, filesToPrune } from '../../scripts/update-prune.mjs'

/**
 * The bug this exists for, in one sentence: an update COPIED the new build over
 * the old one and never removed anything, so a file deleted between the two
 * stayed on disk and kept importing exports that had gone with it.
 *
 * Violy's build 11 → 18 update died exactly there. `discount-rules.ts` and
 * `DiscountEditor.tsx` were removed in `4d29eaa`, along with the
 * `isDiscountBasis` and `isDiscountScope` exports they import — so `next build`
 * failed with six errors about a screen that no longer exists, and the whole
 * update rolled back.
 */
describe('filesToPrune', () => {
  it('removes a source file the new build no longer ships', () => {
    expect(
      filesToPrune(
        ['src/lib/discount.ts', 'src/server/discount-rules.ts'],
        ['src/lib/discount.ts'],
      ),
    ).toEqual(['src/server/discount-rules.ts'])
  })

  it('keeps everything the new build does ship', () => {
    const shipped = ['src/lib/discount.ts', 'electron/main.js', 'scripts/update.mjs']
    expect(filesToPrune(shipped, shipped)).toEqual([])
  })

  /**
   * The whole reason this is a list of directories rather than "everything not
   * in the zip". `prisma/dev.db` IS the shop's ledger and is deliberately never
   * packaged — pruning against the zip without this guard would delete it on
   * the first update, which is the worst thing this app could do.
   */
  it.each([
    'prisma/dev.db',
    'prisma/dev.db-journal',
    '.env',
    'backups/violy-pos-2026-08-28.db',
    'data/uploads/photo.jpg',
    'node_modules/next/package.json',
    '.next/static/chunk.js',
    'release.json',
  ])('never touches %s', (path) => {
    expect(filesToPrune([path], [])).toEqual([])
  })

  it('only considers the code directories', () => {
    expect(PRUNABLE_DIRS).toEqual(['src', 'electron', 'scripts'])
  })

  /** The zip lists paths with backslashes on Windows; disk walks give either. */
  it('compares regardless of slash direction', () => {
    expect(filesToPrune(['src\\server\\gone.ts'], ['src/server/kept.ts'])).toEqual([
      'src\\server\\gone.ts',
    ])
    expect(filesToPrune(['src/server/kept.ts'], ['src\\server\\kept.ts'])).toEqual([])
  })

  /**
   * A test file removed from the release is still a file that breaks `tsc` and
   * `next build` if it imports something that has gone.
   */
  it('prunes a stale test alongside stale source', () => {
    expect(
      filesToPrune(['src/server/discount-schema.test.ts'], ['src/server/sales.test.ts']),
    ).toEqual(['src/server/discount-schema.test.ts'])
  })

  it('prunes a stale file in electron, where splash.html was', () => {
    expect(filesToPrune(['electron/splash.html'], ['electron/boot.html'])).toEqual([
      'electron/splash.html',
    ])
  })
})
