'use client'

import { useEffect, useState, type ReactNode } from 'react'
import { usePathname } from 'next/navigation'
import { Button } from '@/components/ui/Button'
import { SegmentedControl } from '@/components/ui/SegmentedControl'
import { desktop } from '@/lib/desktop'
import { receiptPrinter } from '@/lib/counter-prefs'
import { cn } from '@/lib/cn'

const STORAGE_KEY = 'doc-paper'

const PAPER_OPTIONS = [
  { value: 'a4', label: 'A4' },
  { value: 'roll', label: '58mm' },
] as const

export type PaperSize = (typeof PAPER_OPTIONS)[number]['value']

function isPaperSize(value: string | null): value is PaperSize {
  return value === 'a4' || value === 'roll'
}

const PAGE_RULES: Record<PaperSize, string> = {
  a4: '@page { size: A4; margin: 12mm; }',
  // 58mm paper with 5mm margins leaves a 48mm column, which is the printable
  // width of a 58mm thermal head (384 dots at 203dpi). 4mm margins would leave
  // 50mm and clip at the edges. See `paper.test.ts` for the other three places
  // this number lives.
  roll: '@page { size: 58mm auto; margin: 5mm; }',
}

/**
 * The frame every printable document renders inside — sale receipt, payment
 * receipt, plan invoice, account statement. It owns the actions bar, the paper
 * size, and the sheet element, so a document itself is only its content and
 * all four print identically.
 *
 * `actions` holds whatever is specific to one document (Back, Void). Print is
 * always here, because every document has it — and so is Download PDF, on the
 * shop laptop, for the same reason.
 */
export function DocumentShell({
  fileName,
  actions,
  children,
}: {
  /**
   * What a downloaded copy is called, without the extension. The document's
   * own reference, so a folder of them sorts and reads as a filing cabinet
   * rather than `receipt (3).pdf`.
   */
  fileName: string
  actions?: ReactNode
  children: ReactNode
}) {
  const [paper, setPaper] = useState<PaperSize>('a4')

  const pathname = usePathname()
  const [saving, setSaving] = useState(false)
  const [printing, setPrinting] = useState(false)
  const [downloadError, setDownloadError] = useState<string | null>(null)
  const [printError, setPrintError] = useState<string | null>(null)

  /**
   * Saves this document as a PDF, without a print dialog, in both runtimes.
   *
   * The DESKTOP shell prints the very window she is looking at, in-process,
   * and drops the file in Downloads with an offer to open it. Nothing is
   * re-rendered and nothing is re-fetched.
   *
   * A BROWSER tab cannot write a file to a folder, so it asks the server,
   * which drives the same Chromium print pipeline headlessly (`/pdf` →
   * `electron/print-pdf.js`) and sends the result back as an attachment. Same
   * engine, same HTML, same `@media print` rules — so the two produce the same
   * document rather than two documents that merely look alike.
   *
   * The button is therefore offered everywhere. It used to be hidden outside
   * Electron, which meant the one person developing this app never saw the
   * feature that had been built for it.
   */
  /**
   * Puts this document on paper.
   *
   * In the desktop shell that is one press: `silent: true` against the printer
   * chosen once in Settings. The browser's dialog asks four questions for every
   * receipt — destination, paper, margins, Print — and three of them have the
   * same answer every time.
   *
   * A browser tab still opens the dialog, because a tab has no way to reach a
   * printer without one. That is a real difference and the only one left
   * between the two, so the button says which it is about to do.
   */
  async function print() {
    const bridge = desktop()
    if (!bridge) {
      window.print()
      return
    }

    setPrintError(null)
    setPrinting(true)
    try {
      const result = await bridge.printSilently({ deviceName: receiptPrinter(), paper })
      // Reported, never swallowed. A till that says nothing when the paper
      // does not come out teaches her to press Print twice.
      if (!result.ok) setPrintError(result.error)
    } catch {
      setPrintError('Could not reach the printer.')
    } finally {
      setPrinting(false)
    }
  }

  async function download() {
    setDownloadError(null)
    setSaving(true)
    try {
      const bridge = desktop()
      if (bridge) {
        await bridge.savePdf({ fileName, paper })
        return
      }

      const query = new URLSearchParams({ path: pathname, paper, name: fileName })
      const response = await fetch(`/pdf?${query.toString()}`)
      if (!response.ok) {
        setDownloadError(await response.text())
        return
      }
      const blob = await response.blob()
      const url = URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = `${fileName}.pdf`
      link.click()
      // Deferred: the click is asynchronous, and revoking on the next line can
      // pull the blob out from under a download that has not started.
      setTimeout(() => URL.revokeObjectURL(url), 30_000)
    } catch {
      setDownloadError('Could not build the PDF.')
    } finally {
      setSaving(false)
    }
  }

  // Read AFTER mount, never in the useState initialiser: the initialiser runs
  // on the server pass too, where localStorage does not exist. Same reason
  // `AppRail` reads its collapsed state in an effect.
  useEffect(() => {
    const stored = window.localStorage.getItem(STORAGE_KEY)
    if (isPaperSize(stored)) setPaper(stored)
  }, [])

  // `@page` takes no class selector — there is no way to write "A4 when this
  // element has class X". So the chosen rule is injected as its own <style>
  // and swapped on change. Appended to <head>, it lands after globals.css and
  // wins the cascade against the default rule there.
  useEffect(() => {
    const style = document.createElement('style')
    style.textContent = PAGE_RULES[paper]
    document.head.appendChild(style)
    return () => style.remove()
  }, [paper])

  function choose(next: PaperSize) {
    setPaper(next)
    window.localStorage.setItem(STORAGE_KEY, next)
  }

  return (
    <div className="doc-page mx-auto max-w-3xl p-6 lg:p-10">
      <div
        data-print="hide"
        className="mb-5 flex flex-wrap items-center justify-between gap-3"
      >
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="primary" onClick={print} disabled={printing}>
            {printing ? 'Printing…' : 'Print'}
          </Button>
          <Button variant="secondary" onClick={download} disabled={saving}>
            {saving ? 'Saving…' : 'Download PDF'}
          </Button>
          {actions}
        </div>
        {(downloadError || printError) && (
          <p className="w-full text-sm text-owed" role="alert">
            {downloadError ?? printError}
          </p>
        )}

        <div className="flex flex-col items-end gap-1">
          <SegmentedControl
            ariaLabel="Paper size"
            options={PAPER_OPTIONS}
            value={paper}
            onValueChange={(value) => {
              if (isPaperSize(value)) choose(value)
            }}
          />
          {/* The question this answers: "why is there no 58mm option?" The
              browser's paper list comes from the DESTINATION printer, and
              "Microsoft Print to PDF" only ever offers A4/Letter/Legal — so
              a 58mm document lands on Letter and spills to two sheets. The
              roll size appears once the receipt printer is the destination. */}
          {paper === 'roll' && (
            <p className="max-w-64 text-right text-xs text-ink-subtle">
              Pick your receipt printer under <span className="font-medium">Destination</span> —
              58mm shows up in its paper list. Print to PDF only offers A4, Letter and Legal.
            </p>
          )}
        </div>
      </div>

      {/* The sheet narrows on screen when the roll is selected, so the shape
          of the paper is visible before it is spent. */}
      <article
        className={cn(
          'doc-sheet rounded-card border border-line bg-surface-raised p-6 shadow-raised sm:p-8',
          paper === 'roll' && 'doc-sheet-roll',
        )}
      >
        {children}
      </article>
    </div>
  )
}
