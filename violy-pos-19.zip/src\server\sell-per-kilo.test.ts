import { beforeEach, describe, expect, it } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'
import { KILOS_PER_BAG } from '@/lib/per-kilo'
import { createSale, voidSale } from '@/server/sales'
import { createOrder } from '@/server/orders'
import { openBag } from '@/server/open-bag'

beforeEach(resetDb)

/** A 1,910.00 sack that cost 1,900.00, sold loose at 45.00 the kilo. */
async function makeFeed(pricePerKiloCentavos: number | null = 4_500) {
  const category = await prisma.category.upsert({
    where: { name: 'Pig Feeds' },
    create: { name: 'Pig Feeds' },
    update: {},
  })
  return prisma.product.create({
    data: {
      categoryId: category.id,
      name: 'Broodsow (Premium)',
      unit: 'bag (50kg)',
      price: 191_000,
      pricePerKiloCentavos,
      costPrice: 190_000,
      stockQty: 20,
      lowStockThreshold: 5,
    },
  })
}

async function makeCustomer() {
  return prisma.customer.create({ data: { name: 'Aling Nena' } })
}

const key = () => `kilo-test-${Math.random().toString(36).slice(2)}-${Date.now()}`

describe('selling loose feed by the kilo', () => {
  it('charges the per-kilo price, not the sack price divided by anything', async () => {
    const product = await makeFeed(4_500)
    const result = await createSale({
      items: [{ productId: product.id, quantity: 5, soldPerKilo: true }],
      cashTenderedCentavos: null,
      clientOrderKey: key(),
    })

    expect(result.ok).toBe(true)
    if (!result.ok) return
    // 5 kilos at 45.00, NOT 5/50ths of a 1,910.00 sack.
    expect(result.data.totalCentavos).toBe(22_500)
  })

  /**
   * The sack left the sealed count the moment it was opened. Taking a kilo off
   * as well would count the same sack twice, and what remains inside an open
   * sack is deliberately not tracked at all.
   */
  it('moves no stock and writes no movement', async () => {
    const product = await makeFeed()
    const before = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })

    await createSale({
      items: [{ productId: product.id, quantity: 5, soldPerKilo: true }],
      cashTenderedCentavos: null,
      clientOrderKey: key(),
    })

    const after = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
    expect(after.stockQty).toBe(before.stockQty)
    expect(await prisma.stockMovement.count({ where: { productId: product.id } })).toBe(0)
  })

  it('still takes a sack off stock when sold as a sack', async () => {
    const product = await makeFeed()
    await createSale({
      items: [{ productId: product.id, quantity: 2 }],
      cashTenderedCentavos: null,
      clientOrderKey: key(),
    })

    const after = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
    expect(after.stockQty).toBe(18)
    expect(await prisma.stockMovement.count({ where: { productId: product.id } })).toBe(1)
  })

  /**
   * The reason the merge key is composite. Merging these on `productId` alone
   * would make one line of 7 at whichever price won — seven sacks or seven
   * kilos, wrong either way and wrong in pesos.
   */
  it('keeps sacks and kilos of the same feed as two separate lines', async () => {
    const product = await makeFeed(4_500)
    const result = await createSale({
      items: [
        { productId: product.id, quantity: 2 },
        { productId: product.id, quantity: 5, soldPerKilo: true },
      ],
      cashTenderedCentavos: null,
      clientOrderKey: key(),
    })

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.lines).toHaveLength(2)
    // Two sacks at 1,910.00 plus five kilos at 45.00.
    expect(result.data.totalCentavos).toBe(382_000 + 22_500)

    // And only the sacks came off stock.
    const after = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
    expect(after.stockQty).toBe(18)
  })

  it('records a kilo line as kilos, so a receipt cannot print "5 bag"', async () => {
    const product = await makeFeed()
    const result = await createSale({
      items: [{ productId: product.id, quantity: 5, soldPerKilo: true }],
      cashTenderedCentavos: null,
      clientOrderKey: key(),
    })

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.lines[0].unit).toBe('kilo')

    const item = await prisma.saleItem.findFirstOrThrow({ where: { productId: product.id } })
    expect(item.soldPerKilo).toBe(true)
  })

  /** A kilo is a fiftieth of the sack it came out of. */
  it('costs a kilo at the sack cost over fifty, so profit is not fiction', async () => {
    const product = await makeFeed()
    await createSale({
      items: [{ productId: product.id, quantity: 5, soldPerKilo: true }],
      cashTenderedCentavos: null,
      clientOrderKey: key(),
    })

    const item = await prisma.saleItem.findFirstOrThrow({ where: { productId: product.id } })
    expect(item.costAtSale).toBe(190_000 / KILOS_PER_BAG)
  })

  /** Feed is scooped, not counted out. Half kilos are ordinary. */
  it('takes a fractional quantity', async () => {
    const product = await makeFeed(4_500)
    const result = await createSale({
      items: [{ productId: product.id, quantity: 2.5, soldPerKilo: true }],
      cashTenderedCentavos: null,
      clientOrderKey: key(),
    })

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.totalCentavos).toBe(11_250)
  })

  /**
   * Refused for want of a PRICE. Never for want of an open bag — whether a sack
   * is open is something she knows and the app is told afterwards, and refusing
   * would leave real feed sold with no record of it.
   */
  it('refuses when no price per kilo has been set', async () => {
    const product = await makeFeed(null)
    const result = await createSale({
      items: [{ productId: product.id, quantity: 5, soldPerKilo: true }],
      cashTenderedCentavos: null,
      clientOrderKey: key(),
    })

    expect(result.ok).toBe(false)
    expect(await prisma.saleItem.count()).toBe(0)
  })

  it('does not require a bag to be recorded open', async () => {
    const product = await makeFeed(4_500)
    const bags = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
    expect(bags.openBags).toBe(0)

    const result = await createSale({
      items: [{ productId: product.id, quantity: 5, soldPerKilo: true }],
      cashTenderedCentavos: null,
      clientOrderKey: key(),
    })
    expect(result.ok).toBe(true)
  })

  /**
   * The mirror of the sale. Restoring a kilo line would invent a sack that
   * never left — and unlike the sale side, where the error shows up as stock
   * running out early, this one silently inflates the count.
   */
  it('puts no stock back when a kilo line is voided', async () => {
    const product = await makeFeed()
    await openBag(product.id)
    const opened = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })

    const sale = await createSale({
      items: [{ productId: product.id, quantity: 5, soldPerKilo: true }],
      cashTenderedCentavos: null,
      clientOrderKey: key(),
    })
    expect(sale.ok).toBe(true)
    if (!sale.ok) return

    await voidSale(sale.data.saleId, 'Customer changed their mind')

    const after = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
    expect(after.stockQty).toBe(opened.stockQty)
  })

  it('works the same on a customer order, not just a walk-in', async () => {
    const product = await makeFeed(4_500)
    const customer = await makeCustomer()

    const result = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 5, soldPerKilo: true }],
      cashPaidCentavos: 0,
      clientOrderKey: key(),
    })

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.totalCentavos).toBe(22_500)

    const after = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
    expect(after.stockQty).toBe(20)
  })
})

/**
 * The unit on a line that has been SAVED and read back.
 *
 * The first version of this feature tested `result.data.lines[0].unit` on the
 * value `createSale` returns and stopped there. Every screen that shows a
 * stored sale — the receipt, the history detail, the delivery note, the day
 * list — reads the row back from the database and rendered `product.unit`
 * directly, so a five-kilo line printed "bag (50kg)" on the paper handed to the
 * customer. A green suite and a wrong receipt.
 */
describe('a saved kilo line reads back as kilos', () => {
  it('reports kilo when the sale is replayed by its order key', async () => {
    const product = await makeFeed(4_500)
    const orderKey = key()

    await createSale({
      items: [{ productId: product.id, quantity: 5, soldPerKilo: true }],
      cashTenderedCentavos: null,
      clientOrderKey: orderKey,
    })

    // The same key again returns the STORED sale rather than writing a second.
    const replay = await createSale({
      items: [{ productId: product.id, quantity: 5, soldPerKilo: true }],
      cashTenderedCentavos: null,
      clientOrderKey: orderKey,
    })

    expect(replay.ok).toBe(true)
    if (!replay.ok) return
    expect(replay.data.lines[0].unit).toBe('kilo')
    expect(await prisma.sale.count()).toBe(1)
  })

  it('still reports the sack unit for a sack line', async () => {
    const product = await makeFeed(4_500)
    const orderKey = key()
    await createSale({
      items: [{ productId: product.id, quantity: 2 }],
      cashTenderedCentavos: null,
      clientOrderKey: orderKey,
    })
    const replay = await createSale({
      items: [{ productId: product.id, quantity: 2 }],
      cashTenderedCentavos: null,
      clientOrderKey: orderKey,
    })
    expect(replay.ok).toBe(true)
    if (!replay.ok) return
    expect(replay.data.lines[0].unit).toBe('bag (50kg)')
  })
})
