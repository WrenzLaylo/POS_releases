/**
 * Which files an update must DELETE, not merely overwrite.
 *
 * `applyFiles` copied the new build over the old one and removed nothing, so a
 * file deleted between two releases stayed on disk for ever. That is harmless
 * right up until the deleted file imports something that went with it — and
 * then `next build` fails on a screen that no longer exists, the update rolls
 * back, and the shop stays on the old build with no way forward.
 *
 * It happened on the shop's laptop going 11 → 18: `discount-rules.ts` and
 * `DiscountEditor.tsx` were removed in `4d29eaa` along with the
 * `isDiscountBasis` and `isDiscountScope` exports they import. Six build errors
 * about a discount screen that had not existed for a week.
 *
 * Kept in its own module, imported by `update.mjs`, so the rule can be tested.
 * `update.mjs` itself runs as a script against a live shop and is not something
 * a test can drive.
 */

/**
 * The only directories an update may delete from.
 *
 * This is a list rather than "anything not in the zip" because of what lives
 * outside it. `prisma/dev.db` IS the ledger and is deliberately never packaged,
 * so pruning against the zip without this guard would delete the shop's data on
 * the first update — the worst thing this application could do. `.env`,
 * `backups/`, `data/`, `node_modules/` and `.next/` are all in the same
 * position: absent from the zip because they must never be shipped, not
 * because they are unwanted.
 *
 * So the rule is inverted: name the few directories the RELEASE owns outright,
 * and never touch anything else. Every file in `src`, `electron` and `scripts`
 * comes from the zip; nothing is written there at runtime.
 *
 * `prisma/` is deliberately NOT here. It holds migrations, which are additive
 * and never removed, and it holds the database.
 */
export const PRUNABLE_DIRS = ['src', 'electron', 'scripts']

/** Windows gives backslashes, the zip gives either. Compare on one form. */
function normalise(filePath) {
  return filePath.replace(/\\/g, '/')
}

function insidePrunableDir(filePath) {
  const normalised = normalise(filePath)
  return PRUNABLE_DIRS.some((dir) => normalised.startsWith(`${dir}/`))
}

/**
 * Files present on disk that the incoming build does not ship.
 *
 * Returns the paths exactly as they were given, so the caller can hand them
 * straight back to the filesystem.
 */
export function filesToPrune(onDisk, inZip) {
  const shipped = new Set(inZip.map(normalise))
  return onDisk.filter(
    (filePath) => insidePrunableDir(filePath) && !shipped.has(normalise(filePath)),
  )
}
