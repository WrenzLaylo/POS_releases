'use server'

import { Prisma } from '@prisma/client'
import { prisma } from '@/lib/db'
import { lineTotal } from '@/lib/money'
import {
  computeOrderTotals,
  mergeLineDiscounts,
  validateLineDiscount,
  isLineDiscountMode,
  type LineDiscountMode,
  validateOrderDiscount,
  type OrderDiscountInput,
} from '@/lib/discount'
import { addDays, parseDayKey } from '@/lib/dates'
import { PAGE_SIZE, pageCountOf, clampPage } from '@/lib/pagination'
import type {
  ActionResult,
  Paged,
  ReceiptLine,
  SaleResult,
  SalesFilters,
  SaleWithItems,
} from '@/lib/types'
import { ROUTES } from '@/lib/routes'
import { prismaErrorCode } from '@/lib/prisma-errors'
import { reconcileCustomerDueAt } from '@/server/account-due'
import { revalidateRoutes } from './revalidate'
import { kiloCostCentavos, lineKey, unitSold } from '@/lib/per-kilo'
import { confirmationGate } from './session'

export type CartInput = {
  productId: number
  quantity: number
  /**
   * Loose feed out of an open sack, priced by the kilo. `quantity` is then
   * kilos rather than sacks, and it may be fractional.
   */
  soldPerKilo?: boolean
  /** A discount typed at the counter against this line, in centavos. */
  discountPerUnitCentavos?: number
  /** 'EACH' | 'ONCE' — whether that figure is per unit or for the whole line. */
  discountMode?: string
}
export type CreateSaleInput = {
  items: CartInput[]
  /** null means exact cash against the authoritative server total. */
  cashTenderedCentavos: number | null
  /** The ad-hoc discount typed at the counter. Omitted means none. */
  orderDiscount?: OrderDiscountInput | null
  /** Generated once per checkout and reused if the request is retried. */
  clientOrderKey: string
}

/** Thrown inside a transaction to force a rollback and surface a safe message. */
class SaleError extends Error {}

function validClientOrderKey(value: string): boolean {
  return value.length >= 8 && value.length <= 128
}

function resultLines(
  lines: readonly {
    productId: number
    quantity: number
    soldPerKilo?: boolean
    priceAtSale: number
    discountAtSale: number
    lineDiscountAtSale?: number
    product: { name: string; unit: string }
  }[],
): ReceiptLine[] {
  return lines.map((line) => ({
    productId: line.productId,
    name: line.product.name,
    unit: unitSold(line.product.unit, line.soldPerKilo === true),
    quantity: line.quantity,
    priceAtSale: line.priceAtSale,
    discountAtSale: line.discountAtSale,
    // Less the whole-line discount as well, or a printed receipt
    // disagrees with the total the customer was read out.
    lineTotalCentavos:
      lineTotal(line.priceAtSale - line.discountAtSale, line.quantity) -
      (line.lineDiscountAtSale ?? 0),
  }))
}

async function existingSaleResult(clientOrderKey: string): Promise<SaleResult | null> {
  const sale = await prisma.sale.findUnique({
    where: { clientOrderKey },
    include: {
      items: { include: { product: { select: { name: true, unit: true } } } },
    },
  })
  if (!sale) return null
  return {
    saleId: sale.id,
    createdAt: sale.createdAt.toISOString(),
    totalCentavos: sale.totalAmount,
    cashPaidCentavos: sale.cashPaidCentavos,
    cashTenderedCentavos: sale.cashTenderedCentavos ?? sale.cashPaidCentavos,
    changeCentavos: sale.changeCentavos,
    lines: resultLines(sale.items),
  }
}

/**
 * Completes a walk-in sale. Prices, costs and the final total are always read
 * from the database. A blank cash field is represented as `null` and means
 * exact cash against that authoritative total; an explicit short tender is
 * refused instead of silently overstating the drawer.
 *
 * The array-only form remains accepted for older callers/tests and behaves as
 * exact cash without idempotency. New UI code always uses the object form.
 */
export async function createSale(
  input: CreateSaleInput | CartInput[],
): Promise<ActionResult<SaleResult>> {
  const legacy = Array.isArray(input)
  const items = legacy ? input : input.items
  const cashTenderedInput = legacy ? null : input.cashTenderedCentavos
  const clientOrderKey = legacy ? null : input.clientOrderKey.trim()

  if (items.length === 0) return { ok: false, error: 'Cart is empty.' }
  for (const item of items) {
    if (!Number.isFinite(item.quantity) || item.quantity <= 0) {
      return { ok: false, error: 'Every line needs a quantity greater than zero.' }
    }
    const badDiscount = validateLineDiscount(item.discountPerUnitCentavos)
    if (badDiscount) return { ok: false, error: badDiscount }
    if (item.discountMode !== undefined && !isLineDiscountMode(item.discountMode)) {
      return { ok: false, error: 'Unrecognised line discount mode.' }
    }
  }
  if (
    cashTenderedInput !== null &&
    (!Number.isInteger(cashTenderedInput) || cashTenderedInput < 0)
  ) {
    return { ok: false, error: 'Cash received must be a valid whole number of centavos.' }
  }
  if (clientOrderKey !== null && !validClientOrderKey(clientOrderKey)) {
    return { ok: false, error: 'The checkout key is invalid. Start a fresh order and try again.' }
  }

  // The legacy array form predates discounts entirely and never carries one.
  const discount = validateOrderDiscount(legacy ? null : input.orderDiscount)
  if (!discount.ok) return { ok: false, error: discount.error }
  const orderDiscount = discount.value


  if (clientOrderKey) {
    const existing = await existingSaleResult(clientOrderKey)
    if (existing) return { ok: true, data: existing }
  }

  // Quantity AND the typed line discount, so two rows for one product become
  // one line without losing either. Keyed on product AND how it was priced: two bags of Broodsow and five
  // kilos out of the open one is one order with TWO lines, and merging them
  // would add 2 and 5 into a line of 7 at whichever price won.
  const merged = new Map<
    string,
    {
      productId: number
      soldPerKilo: boolean
      quantity: number
      discountPerUnitCentavos: number
      discountMode: LineDiscountMode
    }
  >()
  for (const item of items) {
    const soldPerKilo = item.soldPerKilo === true
    const key = lineKey(item.productId, soldPerKilo)
    const existing = merged.get(key)
    merged.set(key, {
      productId: item.productId,
      soldPerKilo,
      quantity: (existing?.quantity ?? 0) + item.quantity,
      discountPerUnitCentavos: mergeLineDiscounts(
        existing?.discountPerUnitCentavos,
        item.discountPerUnitCentavos,
      ),
      // The counter cannot produce a duplicate; a caller assembling the
      // payload can. ONCE wins, because a per-line figure applied per unit
      // would multiply rather than divide.
      discountMode:
        existing?.discountMode === 'ONCE' || item.discountMode === 'ONCE' ? 'ONCE' : 'EACH',
    })
  }

  let result: SaleResult
  try {
    result = await prisma.$transaction(async (tx) => {
      // `entries` is held as an array rather than read back off the map,
      // because `computeOrderTotals` returns its lines in the order it was
      // given them and two of them can now share a `productId`. Zipping by
      // index is what keeps a kilo line from being priced as a sack below.
      const entries = [...merged.values()]

      const products = await tx.product.findMany({
        where: { id: { in: [...new Set(entries.map((entry) => entry.productId))] } },
      })
      const byId = new Map(products.map((product) => [product.id, product]))

      for (const entry of entries) {
        const product = byId.get(entry.productId)
        if (!product) throw new SaleError('A product in the cart no longer exists.')
        if (product.isArchived) throw new SaleError(`${product.name} is no longer available.`)
        // Refused only for want of a PRICE, never for want of an open bag.
        // Whether a sack is open is something she knows and the app is told
        // afterwards — the same reason `openBag` does not refuse to take stock
        // below zero. Refusing here would leave real feed sold and no record of
        // it, which is the worse of the two wrongs. A missing price is not a
        // judgement call: there is simply nothing to charge.
        if (entry.soldPerKilo && product.pricePerKiloCentavos === null) {
          throw new SaleError(`${product.name} has no price per kilo set.`)
        }
      }

      // Prices, and anything knocked off at the counter.
      const totals = computeOrderTotals({
        lines: entries.map((entry) => {
          const product = byId.get(entry.productId)!
          return {
            productId: entry.productId,
            quantity: entry.quantity,
            priceCentavos: entry.soldPerKilo
              ? product.pricePerKiloCentavos!
              : product.price,
            manualDiscountPerUnitCentavos: entry.discountPerUnitCentavos,
            manualDiscountMode: entry.discountMode,
          }
        }),
        order: orderDiscount,
      })

      const lines = totals.lines.map((line, index) => {
        const entry = entries[index]
        const product = byId.get(entry.productId)!
        return {
          productId: entry.productId,
          quantity: line.quantity,
          soldPerKilo: entry.soldPerKilo,
          priceAtSale: line.priceCentavos,
          // A kilo costs the shop a fiftieth of what the sack did. Derived
          // rather than typed — see `kiloCostCentavos`.
          costAtSale: entry.soldPerKilo
            ? kiloCostCentavos(product.costPrice)
            : product.costPrice,
          discountAtSale: line.discountPerUnitCentavos,
          lineDiscountAtSale: line.lineDiscountCentavos,
          product: { name: product.name, unit: unitSold(product.unit, entry.soldPerKilo) },
        }
      })

      const totalAmount = totals.totalCentavos
      const cashTenderedCentavos = cashTenderedInput ?? totalAmount
      if (cashTenderedCentavos < totalAmount) {
        throw new SaleError('Walk-in cash is short. Enter the full amount received before saving.')
      }
      const changeCentavos = cashTenderedCentavos - totalAmount

      const sale = await tx.sale.create({
        data: {
          totalAmount,
          cashPaidCentavos: totalAmount,
          cashTenderedCentavos,
          changeCentavos,
          orderDiscountCentavos: totals.orderDiscountCentavos,
          orderDiscountKind: orderDiscount.kind,
          orderDiscountBps: orderDiscount.bps,
          clientOrderKey,
          items: {
            create: lines.map(({ product, ...line }) => line),
          },
        },
      })

      for (const line of lines) {
        // Loose feed moves NO stock, and this is the whole accounting of it.
        // The sack left the sealed count the moment it was opened; taking a
        // kilo off as well would count the same sack twice. What is left inside
        // an open sack is deliberately not tracked — nobody can say how many
        // kilos remain without weighing it — so there is no figure here to
        // decrement and no movement to explain.
        if (line.soldPerKilo) continue

        await tx.product.update({
          where: { id: line.productId },
          data: { stockQty: { decrement: line.quantity } },
        })
        await tx.stockMovement.create({
          data: {
            productId: line.productId,
            saleId: sale.id,
            type: 'SALE',
            quantity: -line.quantity,
            note: `Sale #${sale.id}`,
          },
        })
      }

      return {
        saleId: sale.id,
        createdAt: sale.createdAt.toISOString(),
        totalCentavos: totalAmount,
        cashPaidCentavos: totalAmount,
        cashTenderedCentavos,
        changeCentavos,
        lines: resultLines(lines),
      }
    })
  } catch (error) {
    if (error instanceof SaleError) return { ok: false, error: error.message }
    if (clientOrderKey && prismaErrorCode(error) === 'P2002') {
      const existing = await existingSaleResult(clientOrderKey)
      if (existing) return { ok: true, data: existing }
    }
    return { ok: false, error: 'Could not complete the sale. Please try again.' }
  }

  revalidateRoutes([ROUTES.counter, ROUTES.history, ROUTES.dashboard, ROUTES.stock], {
    layout: true,
  })
  return { ok: true, data: result }
}

/** Permanent receipt/invoice data loaded from the saved database snapshot. */
export async function getSaleReceipt(saleId: number) {
  if (!Number.isInteger(saleId) || saleId <= 0) return null
  return prisma.sale.findUnique({
    where: { id: saleId },
    include: {
      customer: { select: { id: true, name: true, phone: true } },
      items: {
        include: { product: { select: { id: true, name: true, unit: true } } },
        orderBy: { id: 'asc' },
      },
      ledgerEntry: { select: { id: true, amountCentavos: true, isVoided: true } },
    },
  })
}

/**
 * Voids a complete sale atomically: stock is restored, its linked charge is
 * voided with a revision snapshot, and the sale remains visible for audit.
 */
export async function voidSale(
  saleId: number,
  reason: string,
): Promise<ActionResult<void>> {
  // Guarded: this can hide money, so the person at the keyboard proves it is
  // still her. One confirmation covers a few minutes, so correcting three
  // entries in a row asks once.
  const gate = await confirmationGate()
  if (gate) return gate

  if (!Number.isInteger(saleId) || saleId <= 0) {
    return { ok: false, error: 'Sale id is required.' }
  }
  const trimmedReason = reason.trim()
  if (trimmedReason.length < 3) {
    return { ok: false, error: 'Enter a brief reason for voiding this sale.' }
  }

  try {
    await prisma.$transaction(async (tx) => {
      const sale = await tx.sale.findUnique({
        where: { id: saleId },
        include: { items: true, ledgerEntry: true },
      })
      if (!sale) throw new SaleError('That sale no longer exists.')
      if (sale.isVoided) return

      for (const item of sale.items) {
        // The mirror of the sale: a kilo line took nothing off stock, so
        // voiding it must put nothing back. Restoring it would invent a sack
        // that never left — and unlike the sale side, where the error would
        // show up as stock running out early, this one silently inflates the
        // count and looks like a good day.
        if (item.soldPerKilo) continue

        await tx.product.update({
          where: { id: item.productId },
          data: { stockQty: { increment: item.quantity } },
        })
        await tx.stockMovement.create({
          data: {
            productId: item.productId,
            saleId: sale.id,
            type: 'VOID',
            quantity: item.quantity,
            note: trimmedReason,
          },
        })
      }

      if (sale.ledgerEntry && !sale.ledgerEntry.isVoided) {
        await tx.ledgerEntryRevision.create({
          data: {
            ledgerEntryId: sale.ledgerEntry.id,
            type: sale.ledgerEntry.type,
            amountCentavos: sale.ledgerEntry.amountCentavos,
            occurredAt: sale.ledgerEntry.occurredAt,
            note: sale.ledgerEntry.note,
            isVoided: sale.ledgerEntry.isVoided,
          },
        })
        await tx.ledgerEntry.update({
          where: { id: sale.ledgerEntry.id },
          data: { isVoided: true, note: `Sale voided: ${trimmedReason}` },
        })
      }

      await tx.sale.update({
        where: { id: sale.id },
        data: { isVoided: true, voidedAt: new Date(), voidReason: trimmedReason },
      })

      if (sale.customerId) await reconcileCustomerDueAt(tx, sale.customerId, new Date())
    })
  } catch (error) {
    if (error instanceof SaleError) return { ok: false, error: error.message }
    return { ok: false, error: 'Could not void the sale. Please try again.' }
  }

  revalidateRoutes(
    [ROUTES.counter, ROUTES.history, ROUTES.book, ROUTES.dashboard, ROUTES.stock],
    { layout: true },
  )
  return { ok: true, data: undefined }
}

export async function listSales(
  filters: SalesFilters = {},
  page = 1,
): Promise<Paged<SaleWithItems>> {
  const where: Prisma.SaleWhereInput = {}

  if (filters.from || filters.to) {
    where.createdAt = {}
    if (filters.from) {
      const from = parseDayKey(filters.from)
      if (from) where.createdAt.gte = from
    }
    if (filters.to) {
      const to = parseDayKey(filters.to)
      if (to) where.createdAt.lt = addDays(to, 1)
    }
  }

  if (filters.customerId === 'walkin') where.customerId = null
  else if (typeof filters.customerId === 'number') where.customerId = filters.customerId

  // "Which sales included anything from this brand?" — `some`, not `every`:
  // a sale of two Atlas sacks and one Pigrolac is an Atlas sale as well as a
  // Pigrolac one. `every` would answer a question nobody asks (sales made up
  // exclusively of one brand) and would also match every sale with no items
  // at all, which is how that mistake usually shows itself.
  if (filters.categoryId) {
    where.items = { some: { product: { categoryId: filters.categoryId } } }
  }

  // A separate axis from status, not another value of it: a delivery order is
  // paid for like any other sale, so "deliveries" and "full credit" are two
  // questions and both can be asked at once.
  if (filters.kind === 'delivery') where.deliverAt = { not: null }
  else if (filters.kind === 'counter') where.deliverAt = null

  if (filters.status === 'voided') {
    where.isVoided = true
  } else if (filters.status === 'cash') {
    where.isVoided = false
    where.ledgerEntry = null
  } else if (filters.status === 'credit') {
    where.isVoided = false
    where.cashPaidCentavos = 0
    where.ledgerEntry = { is: { isVoided: false } }
  } else if (filters.status === 'partial') {
    where.isVoided = false
    where.cashPaidCentavos = { gt: 0 }
    where.ledgerEntry = { is: { isVoided: false } }
  }

  const [total, sum] = await Promise.all([
    prisma.sale.count({ where }),
    prisma.sale.aggregate({ _sum: { totalAmount: true }, where }),
  ])
  const pageCount = pageCountOf(total)
  const current = clampPage(page, pageCount)

  const rows = await prisma.sale.findMany({
    where,
    include: {
      customer: { select: { id: true, name: true } },
      items: { include: { product: { select: { id: true, name: true, unit: true } } } },
      ledgerEntry: { select: { isVoided: true } },
    },
    orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
    skip: (current - 1) * PAGE_SIZE,
    take: PAGE_SIZE,
  })

  return {
    rows,
    total,
    page: current,
    pageCount,
    sumCentavos: sum._sum.totalAmount ?? 0,
  }
}
