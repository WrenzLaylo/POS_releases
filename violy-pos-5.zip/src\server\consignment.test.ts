import { beforeEach, describe, expect, it } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'
import {
  createDelivery,
  getDelivery,
  listDeliveries,
  payDelivery,
  listConsignmentsToSettle,
  reconcileDelivery,
  totalPayable,
  voidDelivery,
} from '@/server/deliveries'
import { createSale, voidSale } from '@/server/sales'
import { createSupplier } from '@/server/suppliers'
import type { DeliveryTerms } from '@/lib/delivery'

beforeEach(resetDb)

async function supplier(name = 'Bataan Farmers Center') {
  const result = await createSupplier({ name })
  if (!result.ok) throw new Error(result.error)
  return result.data.id
}

async function product(stockQty = 0) {
  const category = await prisma.category.upsert({
    where: { name: 'Pig Feeds' },
    create: { name: 'Pig Feeds' },
    update: {},
  })
  return prisma.product.create({
    data: {
      categoryId: category.id,
      name: 'Hog Grower',
      unit: 'bag (50kg)',
      price: 200_000,
      costPrice: 0,
      stockQty,
      lowStockThreshold: 5,
    },
  })
}

let keyCounter = 0

/** A consignment of one product, and the ids the estimate tests need. */
async function makeConsignment({ quantity, unitCost }: { quantity: number; unitCost: number }) {
  const supplierId = await supplier()
  const item = await product(quantity)
  const deliveryId = await receive(
    supplierId,
    [{ productId: item.id, quantity, unitCostCentavos: unitCost }],
    { terms: 'CONSIGNMENT' },
  )
  return { deliveryId, productId: item.id }
}

let saleKey = 0

/** A walk-in sale, which is what writes the SALE stock movement. */
async function sell(productId: number, quantity: number): Promise<number> {
  saleKey += 1
  const result = await createSale({
    items: [{ productId, quantity }],
    cashTenderedCentavos: null,
    clientOrderKey: `consignment-sale-${saleKey}`,
  })
  if (!result.ok) throw new Error(result.error)
  return result.data.saleId
}

async function receive(
  supplierId: number,
  lines: { productId: number; quantity: number; unitCostCentavos: number }[],
  overrides: Partial<{ terms: DeliveryTerms; amountPaidCentavos: number }> = {},
) {
  keyCounter += 1
  const result = await createDelivery({
    supplierId,
    terms: overrides.terms ?? 'OUTRIGHT',
    receivedAt: new Date(2026, 7, 17),
    reference: 'DR-1',
    note: '',
    lines,
    amountPaidCentavos: overrides.amountPaidCentavos ?? 0,
    clientKey: `consignment-test-${keyCounter}`,
  })
  if (!result.ok) throw new Error(result.error)
  return result.data.id
}

async function stockOf(productId: number): Promise<number> {
  const row = await prisma.product.findUnique({ where: { id: productId } })
  return row!.stockQty
}

describe('a consignment on the shelf', () => {
  it('is sellable immediately but owes nothing', async () => {
    // The defining difference from a purchase. Treating it as one would open a
    // debt that does not exist and overstate what the shop owes by the value
    // of every sack still unsold.
    const supplierId = await supplier()
    const sack = await product()
    const id = await receive(
      supplierId,
      [{ productId: sack.id, quantity: 50, unitCostCentavos: 180_000 }],
      { terms: 'CONSIGNMENT' },
    )

    expect(await stockOf(sack.id)).toBe(50)

    const detail = await getDelivery(id)
    expect(detail!.terms).toBe('CONSIGNMENT')
    expect(detail!.totalCostCentavos).toBe(50 * 180_000)
    expect(detail!.chargeableCentavos).toBe(0)
    expect(detail!.outstandingCentavos).toBe(0)
    expect(await totalPayable()).toBe(0)
  })

  it('cannot be paid before anything has been settled', async () => {
    const supplierId = await supplier()
    const sack = await product()
    const id = await receive(
      supplierId,
      [{ productId: sack.id, quantity: 50, unitCostCentavos: 180_000 }],
      { terms: 'CONSIGNMENT' },
    )

    const paid = await payDelivery(id, 100_000)
    expect(paid.ok).toBe(false)
    if (paid.ok) return
    expect(paid.error).toMatch(/nothing is owed/i)
  })

  it('stays out of the payables list while nothing has sold', async () => {
    const supplierId = await supplier()
    const sack = await product()
    await receive(supplierId, [{ productId: sack.id, quantity: 10, unitCostCentavos: 100_000 }], {
      terms: 'CONSIGNMENT',
    })
    await receive(supplierId, [{ productId: sack.id, quantity: 10, unitCostCentavos: 100_000 }])

    expect(await totalPayable()).toBe(1_000_000)
    expect((await listDeliveries({ unpaidOnly: true }, 1)).total).toBe(1)
  })
})

describe('settling a consignment', () => {
  it('owes for what sold, and takes back what did not', async () => {
    const supplierId = await supplier()
    const sack = await product()
    const id = await receive(
      supplierId,
      [{ productId: sack.id, quantity: 50, unitCostCentavos: 180_000 }],
      { terms: 'CONSIGNMENT' },
    )

    // The agent visits: 32 sold, 18 going back.
    expect(
      (await reconcileDelivery(id, [{ productId: sack.id, soldQuantity: 32, returnedQuantity: 18 }]))
        .ok,
    ).toBe(true)

    const detail = await getDelivery(id)
    expect(detail!.chargeableCentavos).toBe(32 * 180_000)
    expect(detail!.outstandingCentavos).toBe(32 * 180_000)
    expect(await totalPayable()).toBe(32 * 180_000)

    // ONLY the return moves stock. The 32 left the shelf when they were rung
    // up at the counter, and decrementing them again here would count the same
    // sacks twice.
    expect(await stockOf(sack.id)).toBe(50 - 18)

    const movements = await prisma.stockMovement.findMany({
      where: { productId: sack.id },
      orderBy: { id: 'asc' },
    })
    expect(movements.map((movement) => movement.type)).toEqual(['DELIVERY', 'RETURN'])
    expect(movements[1].quantity).toBe(-18)
  })

  it('accumulates across several visits', async () => {
    const supplierId = await supplier()
    const sack = await product()
    const id = await receive(
      supplierId,
      [{ productId: sack.id, quantity: 50, unitCostCentavos: 100_000 }],
      { terms: 'CONSIGNMENT' },
    )

    await reconcileDelivery(id, [{ productId: sack.id, soldQuantity: 20, returnedQuantity: 0 }])
    expect((await getDelivery(id))!.chargeableCentavos).toBe(20 * 100_000)

    await reconcileDelivery(id, [{ productId: sack.id, soldQuantity: 15, returnedQuantity: 0 }])
    expect((await getDelivery(id))!.chargeableCentavos).toBe(35 * 100_000)

    // Fifteen left, so twenty more is more than ever arrived.
    expect(
      (await reconcileDelivery(id, [{ productId: sack.id, soldQuantity: 20, returnedQuantity: 0 }]))
        .ok,
    ).toBe(false)

    const line = (await getDelivery(id))!.lines[0]
    expect(line.quantitySettled).toBe(35)
    expect(line.unaccountedQuantity).toBe(15)
  })

  it('can be paid once something is owed', async () => {
    const supplierId = await supplier()
    const sack = await product()
    const id = await receive(
      supplierId,
      [{ productId: sack.id, quantity: 10, unitCostCentavos: 100_000 }],
      { terms: 'CONSIGNMENT' },
    )

    await reconcileDelivery(id, [{ productId: sack.id, soldQuantity: 4, returnedQuantity: 0 }])
    expect((await payDelivery(id, 400_000)).ok).toBe(true)
    expect((await getDelivery(id))!.outstandingCentavos).toBe(0)
    expect((await payDelivery(id, 1)).ok).toBe(false)
  })

  it('refuses to settle a voided delivery', async () => {
    const supplierId = await supplier()
    const sack = await product()
    const id = await receive(
      supplierId,
      [{ productId: sack.id, quantity: 5, unitCostCentavos: 100_000 }],
      { terms: 'CONSIGNMENT' },
    )
    await voidDelivery(id, 'Duplicate paperwork')

    expect(
      (await reconcileDelivery(id, [{ productId: sack.id, soldQuantity: 1, returnedQuantity: 0 }]))
        .ok,
    ).toBe(false)
  })
})

describe('returning stock on an outright purchase', () => {
  it('takes it off the shelf and off the bill', async () => {
    // Torn sacks go back, and are not paid for.
    const supplierId = await supplier()
    const sack = await product()
    const id = await receive(supplierId, [
      { productId: sack.id, quantity: 20, unitCostCentavos: 100_000 },
    ])

    expect(
      (await reconcileDelivery(id, [{ productId: sack.id, soldQuantity: 0, returnedQuantity: 2 }]))
        .ok,
    ).toBe(true)

    expect((await getDelivery(id))!.chargeableCentavos).toBe(18 * 100_000)
    expect(await stockOf(sack.id)).toBe(18)
  })

  it('refuses to settle one as sold, because it is owed in full already', async () => {
    const supplierId = await supplier()
    const sack = await product()
    const id = await receive(supplierId, [
      { productId: sack.id, quantity: 20, unitCostCentavos: 100_000 },
    ])

    const wrong = await reconcileDelivery(id, [
      { productId: sack.id, soldQuantity: 5, returnedQuantity: 0 },
    ])
    expect(wrong.ok).toBe(false)
    if (wrong.ok) return
    expect(wrong.error).toMatch(/outright/i)
  })

  it('will not leave a delivery owing less than has already been paid', async () => {
    const supplierId = await supplier()
    const sack = await product()
    const id = await receive(
      supplierId,
      [{ productId: sack.id, quantity: 10, unitCostCentavos: 100_000 }],
      { amountPaidCentavos: 1_000_000 },
    )

    const impossible = await reconcileDelivery(id, [
      { productId: sack.id, soldQuantity: 0, returnedQuantity: 3 },
    ])
    expect(impossible.ok).toBe(false)
    if (impossible.ok) return
    expect(impossible.error).toMatch(/already been paid/i)
  })

  it('does not take the same sacks off twice when a part-returned delivery is voided', async () => {
    const supplierId = await supplier()
    const sack = await product()
    const id = await receive(supplierId, [
      { productId: sack.id, quantity: 20, unitCostCentavos: 100_000 },
    ])

    await reconcileDelivery(id, [{ productId: sack.id, soldQuantity: 0, returnedQuantity: 5 }])
    expect(await stockOf(sack.id)).toBe(15)

    // Voiding reverses only the 15 still notionally here, not all 20.
    expect((await voidDelivery(id, 'Never actually arrived')).ok).toBe(true)
    expect(await stockOf(sack.id)).toBe(0)
    expect(await totalPayable()).toBe(0)
  })
})

describe('what has probably sold since a consignment arrived', () => {
  it('counts sales of the product since it landed, and calls it approximate', async () => {
    // The whole point: "₱0.00 owed" is true and misleading while the shop has
    // been selling the supplier's stock for a fortnight.
    const { deliveryId, productId } = await makeConsignment({ quantity: 50, unitCost: 190_000 })

    await sell(productId, 5)

    const [row] = await listConsignmentsToSettle()
    expect(row.id).toBe(deliveryId)
    expect(row.lines[0].estimatedSoldQuantity).toBe(5)
    expect(row.estimatedOwedCentavos).toBe(5 * 190_000)
    // Still nothing actually OWED — that only moves when she settles.
    expect(row.outstandingCentavos).toBe(0)
  })

  it('nets out a voided sale rather than billing for it', async () => {
    // `voidSale` writes a positive VOID movement against the negative SALE
    // one. Counting only SALE rows would charge the supplier for a sale that
    // was cancelled.
    const { productId } = await makeConsignment({ quantity: 50, unitCost: 190_000 })
    const saleId = await sell(productId, 5)
    await voidSale(saleId, 'Wrong customer')

    const [row] = await listConsignmentsToSettle()
    expect(row.lines[0].estimatedSoldQuantity).toBe(0)
    expect(row.estimatedOwedCentavos).toBe(0)
  })

  it('never estimates more than the consignment ever held', async () => {
    // Stock of the same product from another source would otherwise inflate
    // this past the number of sacks that actually arrived.
    const { productId } = await makeConsignment({ quantity: 5, unitCost: 190_000 })
    await sell(productId, 5)
    await sell(productId, 5)

    const [row] = await listConsignmentsToSettle()
    expect(row.lines[0].estimatedSoldQuantity).toBe(5)
  })

  it('ignores sales made before it arrived', async () => {
    const { productId } = await makeConsignment({ quantity: 50, unitCost: 190_000 })
    // Backdate a movement to before the delivery landed.
    await prisma.stockMovement.create({
      data: {
        productId,
        type: 'SALE',
        quantity: -9,
        createdAt: new Date('2020-01-01T00:00:00.000Z'),
      },
    })

    const [row] = await listConsignmentsToSettle()
    expect(row.lines[0].estimatedSoldQuantity).toBe(0)
  })
})
