/**
 * Every route in the app, in one place. Nothing anywhere else writes a route
 * string literal — screens link through these, and Server Actions revalidate
 * through them via `revalidateRoutes`. A rename therefore updates every call
 * site at once and fails `tsc` if one is missed.
 */
export const ROUTES = {
  counter: '/counter',
  history: '/history',
  book: '/book',
  stock: '/stock',
  deliveries: '/deliveries',
  dashboard: '/dashboard',
  settings: '/settings',
} as const

export type AppRoute = (typeof ROUTES)[keyof typeof ROUTES]

/** A single customer's passbook. */
export function bookEntry(customerId: number): string {
  return `${ROUTES.book}/${customerId}`
}

/** The bulk payment entry grid. */
export const BOOK_BULK = `${ROUTES.book}/bulk`

/** A completed sale: what was bought and how it was paid for. */
export function sale(saleId: number): string {
  return `${ROUTES.history}/${saleId}`
}

/** A permanent printable receipt/invoice for a completed sale. */
export function saleReceipt(saleId: number): string {
  return `${ROUTES.history}/${saleId}/receipt`
}

/**
 * The three utang documents, all nested under the customer they belong to.
 *
 * Nested rather than flat (`/book/plan/[id]`) on purpose: a static `plan`
 * segment would sit alongside `[id]` and win the match for `/book/plan`,
 * which reads as a customer named "plan". Keeping them under the customer
 * also means every document URL carries the account it concerns.
 */
export function planInvoice(customerId: number, planId: number): string {
  return `${bookEntry(customerId)}/plan/${planId}`
}

export function paymentReceipt(customerId: number, entryId: number): string {
  return `${bookEntry(customerId)}/payment/${entryId}`
}

export function accountStatement(customerId: number): string {
  return `${bookEntry(customerId)}/statement`
}

/** Recording a delivery. A page, not a dialog — the number of lines it has
 *  to hold is unbounded. */
export const NEW_DELIVERY = `${ROUTES.deliveries}/new`

/** One customer's standing discount, which outgrew the edit dialog. */
export function customerDiscount(customerId: number): string {
  return `${bookEntry(customerId)}/discount`
}

/** Walking the shelves and typing what is actually on them. */
export const STOCK_COUNT = `${ROUTES.stock}/count`

/** One consignment: what arrived, at what cost, and what is still owed. */
export function delivery(deliveryId: number): string {
  return `${ROUTES.deliveries}/${deliveryId}`
}
