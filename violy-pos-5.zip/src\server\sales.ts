'use server'

import { Prisma } from '@prisma/client'
import { prisma } from '@/lib/db'
import { lineTotal } from '@/lib/money'
import {
  computeOrderTotals,
  mergeLineDiscounts,
  validateLineDiscount,
  isOrderDiscountMode,
  validateOrderDiscount,
  type OrderDiscountInput,
} from '@/lib/discount'
import { addDays, parseDayKey } from '@/lib/dates'
import { PAGE_SIZE, pageCountOf, clampPage } from '@/lib/pagination'
import type {
  ActionResult,
  Paged,
  ReceiptLine,
  SaleResult,
  SalesFilters,
  SaleWithItems,
} from '@/lib/types'
import { ROUTES } from '@/lib/routes'
import { prismaErrorCode } from '@/lib/prisma-errors'
import { reconcileCustomerDueAt } from '@/server/account-due'
import { revalidateRoutes } from './revalidate'

export type CartInput = {
  productId: number
  quantity: number
  /** A discount typed at the counter against this line, per unit, in centavos. */
  discountPerUnitCentavos?: number
}
export type CreateSaleInput = {
  items: CartInput[]
  /** null means exact cash against the authoritative server total. */
  cashTenderedCentavos: number | null
  /** The ad-hoc discount typed at the counter. Omitted means none. */
  orderDiscount?: OrderDiscountInput | null
  /** 'REPLACE' | 'STACK' — how a typed line discount meets a standing rate. */
  lineDiscountMode?: string
  /** Generated once per checkout and reused if the request is retried. */
  clientOrderKey: string
}

/** Thrown inside a transaction to force a rollback and surface a safe message. */
class SaleError extends Error {}

function validClientOrderKey(value: string): boolean {
  return value.length >= 8 && value.length <= 128
}

function resultLines(
  lines: readonly {
    productId: number
    quantity: number
    priceAtSale: number
    discountAtSale: number
    product: { name: string; unit: string }
  }[],
): ReceiptLine[] {
  return lines.map((line) => ({
    productId: line.productId,
    name: line.product.name,
    unit: line.product.unit,
    quantity: line.quantity,
    priceAtSale: line.priceAtSale,
    discountAtSale: line.discountAtSale,
    lineTotalCentavos: lineTotal(line.priceAtSale - line.discountAtSale, line.quantity),
  }))
}

async function existingSaleResult(clientOrderKey: string): Promise<SaleResult | null> {
  const sale = await prisma.sale.findUnique({
    where: { clientOrderKey },
    include: {
      items: { include: { product: { select: { name: true, unit: true } } } },
    },
  })
  if (!sale) return null
  return {
    saleId: sale.id,
    createdAt: sale.createdAt.toISOString(),
    totalCentavos: sale.totalAmount,
    cashPaidCentavos: sale.cashPaidCentavos,
    cashTenderedCentavos: sale.cashTenderedCentavos ?? sale.cashPaidCentavos,
    changeCentavos: sale.changeCentavos,
    lines: resultLines(sale.items),
  }
}

/**
 * Completes a walk-in sale. Prices, costs and the final total are always read
 * from the database. A blank cash field is represented as `null` and means
 * exact cash against that authoritative total; an explicit short tender is
 * refused instead of silently overstating the drawer.
 *
 * The array-only form remains accepted for older callers/tests and behaves as
 * exact cash without idempotency. New UI code always uses the object form.
 */
export async function createSale(
  input: CreateSaleInput | CartInput[],
): Promise<ActionResult<SaleResult>> {
  const legacy = Array.isArray(input)
  const items = legacy ? input : input.items
  const cashTenderedInput = legacy ? null : input.cashTenderedCentavos
  const clientOrderKey = legacy ? null : input.clientOrderKey.trim()

  if (items.length === 0) return { ok: false, error: 'Cart is empty.' }
  for (const item of items) {
    if (!Number.isFinite(item.quantity) || item.quantity <= 0) {
      return { ok: false, error: 'Every line needs a quantity greater than zero.' }
    }
    const badDiscount = validateLineDiscount(item.discountPerUnitCentavos)
    if (badDiscount) return { ok: false, error: badDiscount }
  }
  if (
    cashTenderedInput !== null &&
    (!Number.isInteger(cashTenderedInput) || cashTenderedInput < 0)
  ) {
    return { ok: false, error: 'Cash received must be a valid whole number of centavos.' }
  }
  if (clientOrderKey !== null && !validClientOrderKey(clientOrderKey)) {
    return { ok: false, error: 'The checkout key is invalid. Start a fresh order and try again.' }
  }

  // The legacy array form predates discounts entirely and never carries one.
  const discount = validateOrderDiscount(legacy ? null : input.orderDiscount)
  if (!discount.ok) return { ok: false, error: discount.error }
  const orderDiscount = discount.value

  // How a typed LINE discount meets the customer's standing rate. Validated
  // rather than trusted, like every other union crossing this boundary, and
  // defaulted to REPLACE so a caller that never heard of it prices exactly as
  // it did before.
  const rawLineMode = legacy ? undefined : input.lineDiscountMode
  if (rawLineMode !== undefined && !isOrderDiscountMode(rawLineMode)) {
    return { ok: false, error: 'Unrecognised line discount mode.' }
  }
  const lineMode = rawLineMode ?? 'REPLACE'

  if (clientOrderKey) {
    const existing = await existingSaleResult(clientOrderKey)
    if (existing) return { ok: true, data: existing }
  }

  // Quantity AND the typed line discount, so two rows for one product become
  // one line without losing either.
  const merged = new Map<number, { quantity: number; discountPerUnitCentavos: number }>()
  for (const item of items) {
    const existing = merged.get(item.productId)
    merged.set(item.productId, {
      quantity: (existing?.quantity ?? 0) + item.quantity,
      discountPerUnitCentavos: mergeLineDiscounts(
        existing?.discountPerUnitCentavos,
        item.discountPerUnitCentavos,
      ),
    })
  }

  let result: SaleResult
  try {
    result = await prisma.$transaction(async (tx) => {
      const products = await tx.product.findMany({
        where: { id: { in: [...merged.keys()] } },
      })
      const byId = new Map(products.map((product) => [product.id, product]))

      for (const productId of merged.keys()) {
        const product = byId.get(productId)
        if (!product) throw new SaleError('A product in the cart no longer exists.')
        if (product.isArchived) throw new SaleError(`${product.name} is no longer available.`)
      }

      // A walk-in has no customer and therefore no standing discount, but the
      // counter can still knock something off this one sale.
      const totals = computeOrderTotals({
        lines: [...merged.entries()].map(([productId, row]) => {
          const product = byId.get(productId)!
          return {
            productId,
            quantity: row.quantity,
            priceCentavos: product.price,
            categoryId: product.categoryId,
            unit: product.unit,
            manualDiscountPerUnitCentavos: row.discountPerUnitCentavos,
          }
        }),
        customer: null,
        lineMode,
        order: orderDiscount,
      })

      const lines = totals.lines.map((line) => {
        const product = byId.get(line.productId)!
        return {
          productId: line.productId,
          quantity: line.quantity,
          priceAtSale: line.priceCentavos,
          costAtSale: product.costPrice,
          discountAtSale: line.discountPerUnitCentavos,
          product: { name: product.name, unit: product.unit },
        }
      })

      const totalAmount = totals.totalCentavos
      const cashTenderedCentavos = cashTenderedInput ?? totalAmount
      if (cashTenderedCentavos < totalAmount) {
        throw new SaleError('Walk-in cash is short. Enter the full amount received before saving.')
      }
      const changeCentavos = cashTenderedCentavos - totalAmount

      const sale = await tx.sale.create({
        data: {
          totalAmount,
          cashPaidCentavos: totalAmount,
          cashTenderedCentavos,
          changeCentavos,
          orderDiscountCentavos: totals.orderDiscountCentavos,
          orderDiscountKind: orderDiscount.kind,
          orderDiscountBps: orderDiscount.bps,
          orderDiscountMode: orderDiscount.mode,
          clientOrderKey,
          items: {
            create: lines.map(({ product, ...line }) => line),
          },
        },
      })

      for (const line of lines) {
        await tx.product.update({
          where: { id: line.productId },
          data: { stockQty: { decrement: line.quantity } },
        })
        await tx.stockMovement.create({
          data: {
            productId: line.productId,
            saleId: sale.id,
            type: 'SALE',
            quantity: -line.quantity,
            note: `Sale #${sale.id}`,
          },
        })
      }

      return {
        saleId: sale.id,
        createdAt: sale.createdAt.toISOString(),
        totalCentavos: totalAmount,
        cashPaidCentavos: totalAmount,
        cashTenderedCentavos,
        changeCentavos,
        lines: resultLines(lines),
      }
    })
  } catch (error) {
    if (error instanceof SaleError) return { ok: false, error: error.message }
    if (clientOrderKey && prismaErrorCode(error) === 'P2002') {
      const existing = await existingSaleResult(clientOrderKey)
      if (existing) return { ok: true, data: existing }
    }
    return { ok: false, error: 'Could not complete the sale. Please try again.' }
  }

  revalidateRoutes([ROUTES.counter, ROUTES.history, ROUTES.dashboard, ROUTES.stock], {
    layout: true,
  })
  return { ok: true, data: result }
}

/** Permanent receipt/invoice data loaded from the saved database snapshot. */
export async function getSaleReceipt(saleId: number) {
  if (!Number.isInteger(saleId) || saleId <= 0) return null
  return prisma.sale.findUnique({
    where: { id: saleId },
    include: {
      customer: { select: { id: true, name: true, phone: true } },
      items: {
        include: { product: { select: { id: true, name: true, unit: true } } },
        orderBy: { id: 'asc' },
      },
      ledgerEntry: { select: { id: true, amountCentavos: true, isVoided: true } },
    },
  })
}

/**
 * Voids a complete sale atomically: stock is restored, its linked charge is
 * voided with a revision snapshot, and the sale remains visible for audit.
 */
export async function voidSale(
  saleId: number,
  reason: string,
): Promise<ActionResult<void>> {
  if (!Number.isInteger(saleId) || saleId <= 0) {
    return { ok: false, error: 'Sale id is required.' }
  }
  const trimmedReason = reason.trim()
  if (trimmedReason.length < 3) {
    return { ok: false, error: 'Enter a brief reason for voiding this sale.' }
  }

  try {
    await prisma.$transaction(async (tx) => {
      const sale = await tx.sale.findUnique({
        where: { id: saleId },
        include: { items: true, ledgerEntry: true },
      })
      if (!sale) throw new SaleError('That sale no longer exists.')
      if (sale.isVoided) return

      for (const item of sale.items) {
        await tx.product.update({
          where: { id: item.productId },
          data: { stockQty: { increment: item.quantity } },
        })
        await tx.stockMovement.create({
          data: {
            productId: item.productId,
            saleId: sale.id,
            type: 'VOID',
            quantity: item.quantity,
            note: trimmedReason,
          },
        })
      }

      if (sale.ledgerEntry && !sale.ledgerEntry.isVoided) {
        await tx.ledgerEntryRevision.create({
          data: {
            ledgerEntryId: sale.ledgerEntry.id,
            type: sale.ledgerEntry.type,
            amountCentavos: sale.ledgerEntry.amountCentavos,
            occurredAt: sale.ledgerEntry.occurredAt,
            note: sale.ledgerEntry.note,
            isVoided: sale.ledgerEntry.isVoided,
          },
        })
        await tx.ledgerEntry.update({
          where: { id: sale.ledgerEntry.id },
          data: { isVoided: true, note: `Sale voided: ${trimmedReason}` },
        })
      }

      await tx.sale.update({
        where: { id: sale.id },
        data: { isVoided: true, voidedAt: new Date(), voidReason: trimmedReason },
      })

      if (sale.customerId) await reconcileCustomerDueAt(tx, sale.customerId, new Date())
    })
  } catch (error) {
    if (error instanceof SaleError) return { ok: false, error: error.message }
    return { ok: false, error: 'Could not void the sale. Please try again.' }
  }

  revalidateRoutes(
    [ROUTES.counter, ROUTES.history, ROUTES.book, ROUTES.dashboard, ROUTES.stock],
    { layout: true },
  )
  return { ok: true, data: undefined }
}

export async function listSales(
  filters: SalesFilters = {},
  page = 1,
): Promise<Paged<SaleWithItems>> {
  const where: Prisma.SaleWhereInput = {}

  if (filters.from || filters.to) {
    where.createdAt = {}
    if (filters.from) {
      const from = parseDayKey(filters.from)
      if (from) where.createdAt.gte = from
    }
    if (filters.to) {
      const to = parseDayKey(filters.to)
      if (to) where.createdAt.lt = addDays(to, 1)
    }
  }

  if (filters.customerId === 'walkin') where.customerId = null
  else if (typeof filters.customerId === 'number') where.customerId = filters.customerId

  // "Which sales included anything from this brand?" — `some`, not `every`:
  // a sale of two Atlas sacks and one Pigrolac is an Atlas sale as well as a
  // Pigrolac one. `every` would answer a question nobody asks (sales made up
  // exclusively of one brand) and would also match every sale with no items
  // at all, which is how that mistake usually shows itself.
  if (filters.categoryId) {
    where.items = { some: { product: { categoryId: filters.categoryId } } }
  }

  if (filters.status === 'voided') {
    where.isVoided = true
  } else if (filters.status === 'cash') {
    where.isVoided = false
    where.ledgerEntry = null
  } else if (filters.status === 'credit') {
    where.isVoided = false
    where.cashPaidCentavos = 0
    where.ledgerEntry = { is: { isVoided: false } }
  } else if (filters.status === 'partial') {
    where.isVoided = false
    where.cashPaidCentavos = { gt: 0 }
    where.ledgerEntry = { is: { isVoided: false } }
  }

  const [total, sum] = await Promise.all([
    prisma.sale.count({ where }),
    prisma.sale.aggregate({ _sum: { totalAmount: true }, where }),
  ])
  const pageCount = pageCountOf(total)
  const current = clampPage(page, pageCount)

  const rows = await prisma.sale.findMany({
    where,
    include: {
      customer: { select: { id: true, name: true } },
      items: { include: { product: { select: { id: true, name: true, unit: true } } } },
      ledgerEntry: { select: { isVoided: true } },
    },
    orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
    skip: (current - 1) * PAGE_SIZE,
    take: PAGE_SIZE,
  })

  return {
    rows,
    total,
    page: current,
    pageCount,
    sumCentavos: sum._sum.totalAmount ?? 0,
  }
}
