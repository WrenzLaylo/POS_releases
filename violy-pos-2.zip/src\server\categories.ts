'use server'

import { prisma } from '@/lib/db'
import type { ActionResult } from '@/lib/types'
import { ROUTES } from '@/lib/routes'
import { revalidateRoutes } from './revalidate'

export type CategoryRow = {
  id: number
  name: string
  sortOrder: number
  /** How many products sit in it — what decides whether it can be removed. */
  productCount: number
}

/**
 * The category already on file under this name, if there is one.
 *
 * Same rule and same reason as products, customers and suppliers: `@@unique`
 * on the column is not enough, because SQLite compares TEXT case-sensitively
 * unless declared `COLLATE NOCASE`, so "Atlas" and "atlas" would both be
 * allowed and then split one brand's products across two chips on the counter.
 */
async function findByName(
  name: string,
  excludeId?: number,
): Promise<{ id: number; name: string } | null> {
  const needle = name.trim().toLowerCase()
  if (!needle) return null

  const candidates = await prisma.category.findMany({
    where: { name: { contains: needle } },
    select: { id: true, name: true },
  })
  return (
    candidates.find((row) => row.name.trim().toLowerCase() === needle && row.id !== excludeId) ??
    null
  )
}

function parseName(raw: string): string | { error: string } {
  const name = raw.trim()
  if (!name) return { error: 'Category name is required.' }
  if (name.length > 60) return { error: 'That name is too long.' }
  return name
}

export async function listCategoriesWithCounts(): Promise<CategoryRow[]> {
  const rows = await prisma.category.findMany({
    select: { id: true, name: true, sortOrder: true, _count: { select: { products: true } } },
    orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
  })
  return rows.map((row) => ({
    id: row.id,
    name: row.name,
    sortOrder: row.sortOrder,
    productCount: row._count.products,
  }))
}

/**
 * Adds a category.
 *
 * New ones sort to the END rather than into the middle. `sortOrder` drives the
 * chip strip on the counter, and quietly reordering a strip she has learned the
 * shape of is worse than a new chip appearing predictably at the far right.
 */
export async function createCategory(rawName: string): Promise<ActionResult<{ id: number }>> {
  const name = parseName(rawName)
  if (typeof name !== 'string') return { ok: false, error: name.error }

  const clash = await findByName(name)
  if (clash) return { ok: false, error: `${clash.name} is already a category.` }

  let id: number
  try {
    const last = await prisma.category.findFirst({
      orderBy: { sortOrder: 'desc' },
      select: { sortOrder: true },
    })
    const created = await prisma.category.create({
      data: { name, sortOrder: (last?.sortOrder ?? 0) + 1 },
    })
    id = created.id
  } catch {
    return { ok: false, error: 'Could not save that category.' }
  }

  revalidateRoutes([ROUTES.stock, ROUTES.counter, ROUTES.book], { layout: true })
  return { ok: true, data: { id } }
}

/**
 * Renames a category.
 *
 * Renaming is safe where deleting is not: every product keeps pointing at the
 * same row, so the whole catalogue follows the new name at once. This is the
 * answer to "Chicken should really be Gamefowl".
 */
export async function renameCategory(id: number, rawName: string): Promise<ActionResult> {
  if (!Number.isInteger(id) || id <= 0) return { ok: false, error: 'Category id is required.' }

  const name = parseName(rawName)
  if (typeof name !== 'string') return { ok: false, error: name.error }

  const existing = await prisma.category.findUnique({ where: { id } })
  if (!existing) return { ok: false, error: 'Category not found.' }

  // Excluding itself, or saving a category without changing its name would
  // report it as a duplicate of itself.
  const clash = await findByName(name, id)
  if (clash) return { ok: false, error: `${clash.name} is already a category.` }

  try {
    await prisma.category.update({ where: { id }, data: { name } })
  } catch {
    return { ok: false, error: 'Could not rename that category.' }
  }

  revalidateRoutes([ROUTES.stock, ROUTES.counter, ROUTES.book], { layout: true })
  return { ok: true, data: undefined }
}

/**
 * Removes a category, but only an empty one.
 *
 * There is no archive flag here, unlike products and customers, and no need
 * for one: a category holds no history of its own. What it does hold is
 * products, and `Product.categoryId` is required — so deleting a category with
 * anything in it would either orphan those rows or take the catalogue with it.
 *
 * Refused with a count rather than silently reassigning to some "Other"
 * bucket, because which category a sack belongs to is a decision for the shop,
 * not for a delete button.
 */
export async function deleteCategory(id: number): Promise<ActionResult> {
  if (!Number.isInteger(id) || id <= 0) return { ok: false, error: 'Category id is required.' }

  const existing = await prisma.category.findUnique({
    where: { id },
    select: { id: true, name: true, _count: { select: { products: true } } },
  })
  if (!existing) return { ok: false, error: 'Category not found.' }

  if (existing._count.products > 0) {
    const n = existing._count.products
    return {
      ok: false,
      error: `${existing.name} still has ${n} product${n === 1 ? '' : 's'} in it. Move them to another category first, or rename this one.`,
    }
  }

  try {
    // Customers may reference it as a discount scope. Disconnected first, or
    // the delete fails on a relation nobody thinks about when they press the
    // button — a discount scoped to an empty category is inert anyway.
    await prisma.category.update({ where: { id }, data: { discountedFor: { set: [] } } })
    await prisma.category.delete({ where: { id } })
  } catch {
    return { ok: false, error: 'Could not remove that category.' }
  }

  revalidateRoutes([ROUTES.stock, ROUTES.counter, ROUTES.book], { layout: true })
  return { ok: true, data: undefined }
}
