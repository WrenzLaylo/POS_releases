/**
 * Puts a backup back, in place of the current database.
 *
 * The way the shop's data moves to another computer, and the way it comes back
 * after something goes wrong. Both are the same operation: replace the live
 * database with a known-good copy.
 *
 *   npm run restore -- backups/violy-pos-2026-08-17_09-30-19-482.db
 *
 * Deliberately careful, because this is the one command in the project that
 * destroys data on purpose:
 *
 *   · The file is OPENED and checked before anything is replaced. A truncated
 *     copy, a file that is not a database, or one missing the tables this app
 *     needs is refused — restoring rubbish over a working till would turn a
 *     recoverable problem into a total loss.
 *   · Whatever is currently in place is backed up FIRST, into `backups/`,
 *     under its own timestamp. Restoring the wrong file is then undoable.
 *   · It says what is in the file before replacing anything, so an accidental
 *     restore of last month's copy is visible rather than silent.
 */

import { copyFile, mkdir, stat } from 'node:fs/promises'
import path from 'node:path'
import { createBackup, databaseFile } from '@/lib/backup-run'

/** Tables this app cannot run without. A file lacking them is not our backup. */
const REQUIRED_TABLES = ['Product', 'Customer', 'Sale', 'LedgerEntry']

type Summary = { products: number; customers: number; sales: number; entries: number }

/**
 * Opens the candidate read-only and reads it.
 *
 * Uses `node:sqlite` rather than Prisma on purpose: Prisma would connect to
 * whatever `DATABASE_URL` points at, which is the file being replaced, not the
 * one being inspected.
 */
async function inspect(file: string): Promise<Summary> {
  const { DatabaseSync } = await import('node:sqlite')
  const db = new DatabaseSync(file, { readOnly: true })
  try {
    const names = new Set(
      db
        .prepare("SELECT name FROM sqlite_master WHERE type = 'table'")
        .all()
        .map((row) => String((row as { name: unknown }).name)),
    )
    const missing = REQUIRED_TABLES.filter((table) => !names.has(table))
    if (missing.length > 0) {
      throw new Error(`that file is missing the ${missing.join(', ')} table(s)`)
    }

    const count = (table: string) =>
      Number((db.prepare(`SELECT COUNT(*) AS c FROM "${table}"`).get() as { c: number }).c)

    return {
      products: count('Product'),
      customers: count('Customer'),
      sales: count('Sale'),
      entries: count('LedgerEntry'),
    }
  } finally {
    db.close()
  }
}

async function main(): Promise<void> {
  const source = process.argv[2]
  if (!source) {
    console.error('Which backup? Usage:')
    console.error('  npm run restore -- backups/violy-pos-YYYY-MM-DD_HH-MM-SS-mmm.db')
    process.exit(1)
  }

  const from = path.resolve(source)
  await stat(from)

  const summary = await inspect(from)
  console.log(`\nThat file holds:`)
  console.log(`  ${summary.products} products`)
  console.log(`  ${summary.customers} customers`)
  console.log(`  ${summary.sales} sales`)
  console.log(`  ${summary.entries} ledger entries`)

  const target = databaseFile()

  // Only if there is something to lose. On a fresh install there is not, and
  // an empty "safety" backup is noise.
  let existing = false
  try {
    await stat(target)
    existing = true
  } catch {
    existing = false
  }

  if (existing) {
    const safety = await createBackup()
    if (safety.kind === 'created') {
      console.log(`\nCurrent database saved first as ${safety.name}`)
    }
  }

  await mkdir(path.dirname(target), { recursive: true })
  await copyFile(from, target)

  console.log(`\nRestored into ${target}`)
  console.log('Open the app to check it, then carry on.\n')
}

main().catch((error: unknown) => {
  console.error(`\nRestore FAILED: ${error instanceof Error ? error.message : String(error)}`)
  console.error('Nothing was replaced.\n')
  process.exit(1)
})
