'use client'

import { useEffect, useState } from 'react'

const STORAGE_KEY = 'counter-order'

/** What survives leaving the Counter and coming back. */
export type SavedOrder = {
  /** productId → quantity. */
  lines: [number, number][]
  customerId: number | null
  customerName: string | null
  walkin: boolean
  paymentMode: string
  cash: string
  discountAmount: string
  discountKind: string
  discountMode: string
}

/**
 * Keeps a half-built order alive across navigation.
 *
 * Tapping Book to check what somebody owes, then coming back to a cleared
 * counter, means re-tallying a physical pile of sacks from memory. The order
 * lives in `sessionStorage` rather than `localStorage` on purpose: it should
 * outlast a tab switch, not a closed browser. An order from three days ago
 * reappearing at the counter is worse than no order at all, because it looks
 * like today's.
 *
 * Read AFTER mount, never in a `useState` initialiser — the initialiser also
 * runs on the server pass, where `sessionStorage` does not exist. This is the
 * same rule `AppRail` follows for its collapsed state.
 */
export function useSavedOrder(): {
  restored: SavedOrder | null
  ready: boolean
  save: (order: SavedOrder) => void
  clear: () => void
} {
  const [restored, setRestored] = useState<SavedOrder | null>(null)
  const [ready, setReady] = useState(false)

  useEffect(() => {
    try {
      const raw = window.sessionStorage.getItem(STORAGE_KEY)
      if (raw) setRestored(JSON.parse(raw) as SavedOrder)
    } catch {
      // Malformed or unreadable storage is not worth an error at the counter.
      // The worst case is starting from an empty order, which is where every
      // sale starts anyway.
    }
    setReady(true)
  }, [])

  function save(order: SavedOrder) {
    try {
      // An order with nothing in it is not worth keeping, and writing one
      // would resurrect an empty draft over a genuinely cleared counter.
      if (order.lines.length === 0) window.sessionStorage.removeItem(STORAGE_KEY)
      else window.sessionStorage.setItem(STORAGE_KEY, JSON.stringify(order))
    } catch {
      // Storage can be full or blocked; the sale itself does not depend on it.
    }
  }

  function clear() {
    try {
      window.sessionStorage.removeItem(STORAGE_KEY)
    } catch {
      // Same: nothing here is load-bearing for money.
    }
  }

  return { restored, ready, save, clear }
}
