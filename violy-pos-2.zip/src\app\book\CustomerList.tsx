'use client'

import { useMemo, useState, useTransition } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import type { CategoryCheapest, CustomerWithBalance, CustomerWithDiscount } from '@/lib/types'
import { getCustomer, archiveCustomer, restoreCustomer } from '@/server/customers'
import { PageHeader } from '@/components/ui/PageHeader'
import { Money } from '@/components/ui/Money'
import { Badge } from '@/components/ui/Badge'
import { EmptyState } from '@/components/ui/EmptyState'
import { FilterChips } from '@/components/ui/FilterChips'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { FormError } from '@/components/ui/FormError'
import { Tabs } from '@/components/ui/Tabs'
import { SortableHeader } from '@/components/ui/SortableHeader'
import { compareValues, nextSort, type SortState } from '@/lib/sorting'
import { PAGE_SIZE } from '@/lib/pagination'
import { TapeCell, TapeRow } from '@/components/ui/Tape'
import { dayKey, parseDayKey } from '@/lib/dates'
import { ROUTES, bookEntry } from '@/lib/routes'
import { CustomerForm } from './CustomerForm'
import { BulkPaymentGrid } from './bulk/BulkPaymentGrid'

type CustomerSortKey = 'name' | 'balance' | 'lastPaid'

const BOOK_TABS = [
  { value: 'list', label: 'Customers' },
  { value: 'bulk', label: 'Bulk payments' },
] as const

const BALANCE_FILTERS = [
  { value: '', label: 'Everyone' },
  { value: 'owing', label: 'Owing' },
  { value: 'settled', label: 'Settled' },
  { value: 'credit', label: 'In credit' },
] as const

const DUE_FILTERS = [
  { value: '', label: 'Any date' },
  { value: 'overdue', label: 'Overdue' },
  { value: 'today', label: 'Due today' },
  { value: 'none', label: 'No due date' },
] as const

/**
 * Owing, settled, or in credit.
 *
 * Three states rather than "has a balance / does not", because the sign
 * carries the meaning: a negative balance is money the shop is holding for
 * somebody, and lumping it in with debt would put a customer who has overpaid
 * on the list of people to chase.
 */
function matchesBalance(row: CustomerWithBalance, filter: string): boolean {
  if (filter === 'owing') return row.balanceCentavos > 0
  if (filter === 'settled') return row.balanceCentavos === 0
  if (filter === 'credit') return row.balanceCentavos < 0
  return true
}

/**
 * Overdue, due today, or no date set.
 *
 * Compared as day KEYS, never as timestamps: a due date stored at midnight is
 * "before now" from one minute past midnight onwards, so a `dueAt < new Date()`
 * test reports everything due today as already overdue. `todayKey` arrives as
 * a prop computed on the server for the same reason the last-payment column
 * takes one — so this agrees between the server render and the hydration pass.
 *
 * Settled accounts are never overdue whatever their date says. A due date is
 * left behind on a customer who has since paid in full, and listing them among
 * the people to chase is how a collection round wastes a morning.
 */
function matchesDue(row: CustomerWithBalance, filter: string, todayKey: string): boolean {
  if (filter === '') return true
  if (filter === 'none') return row.dueAt === null

  if (row.dueAt === null || row.balanceCentavos <= 0) return false
  const due = dayKey(row.dueAt)
  return filter === 'today' ? due === todayKey : due < todayKey
}

function shortDate(date: Date): string {
  return new Intl.DateTimeFormat('en-PH', { month: 'short', day: 'numeric' }).format(date)
}

/**
 * "Days since last payment" is the collection-risk signal this column was
 * specified with — not days since the last order. A customer can order
 * today and still be three months behind on paying, so `lastOrderedAt`
 * cannot answer this; `lastPaymentAt` is the newest non-voided PAYMENT date.
 * A customer who has never paid renders an em dash, never "0 days" and
 * never a blank cell, because never having paid is a distinct fact from
 * having paid today.
 *
 * Pure date-key arithmetic — no `new Date()` here. `todayKey` comes down as
 * a prop computed server-side, so this stays identical between the server
 * render and the client hydration pass.
 */
function lastPaymentLabel(lastPaymentAt: Date | null, todayKey: string): string {
  if (!lastPaymentAt) return '—'
  const paidKey = dayKey(lastPaymentAt)
  if (paidKey === todayKey) return 'Today'

  const today = parseDayKey(todayKey)
  const paid = parseDayKey(paidKey)
  if (!today || !paid) return shortDate(lastPaymentAt)

  const days = Math.round((today.getTime() - paid.getTime()) / 86_400_000)
  return `${days}d ago`
}

export function CustomerList({
  rows,
  totalCentavos,
  categories,
  customers,
  units,
  todayKey,
  tab,
}: {
  rows: CustomerWithBalance[]
  totalCentavos: number
  categories: CategoryCheapest[]
  /** Unarchived customers, for the New/Edit customer form. */
  customers: CustomerWithDiscount[]
  /** Unit kinds the catalog sells in, for scoping a per-unit discount. */
  units: string[]
  todayKey: string
  tab: 'list' | 'bulk'
}) {
  const router = useRouter()
  const [filter, setFilter] = useState('')
  const [balanceFilter, setBalanceFilter] = useState('')
  const [dueFilter, setDueFilter] = useState('')
  const [formOpen, setFormOpen] = useState(false)
  const [editing, setEditing] = useState<CustomerWithDiscount | null>(null)
  const [confirmingId, setConfirmingId] = useState<number | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [pending, startTransition] = useTransition()

  const [sort, setSort] = useState<SortState<CustomerSortKey>>({
    key: 'balance',
    direction: 'desc',
  })
  const [page, setPage] = useState(1)

  // Filtered, then sorted, then paged — in that order. Sorting before
  // filtering would order rows that are about to be thrown away, and paging
  // before either would page the wrong set entirely.
  //
  // All three happen in the browser here, unlike the stock table. This list is
  // already fully in memory (the total-utang figure above needs every row), so
  // a round trip per click would buy nothing.
  const needle = filter.trim().toLowerCase()
  const matched = useMemo(() => {
    const byName = needle ? rows.filter((row) => row.name.toLowerCase().includes(needle)) : rows
    return byName.filter(
      (row) => matchesBalance(row, balanceFilter) && matchesDue(row, dueFilter, todayKey),
    )
  }, [rows, needle, balanceFilter, dueFilter, todayKey])

  // Counted against everything the name search left, NOT against the rows the
  // other facet already narrowed. A count that changes as you use the chip it
  // is attached to cannot be trusted — tap "Overdue", watch "Owing 12" become
  // "Owing 4", and the number is no longer answering "how many owe me".
  const facetBase = useMemo(
    () => (needle ? rows.filter((row) => row.name.toLowerCase().includes(needle)) : rows),
    [rows, needle],
  )

  const balanceOptions = useMemo(
    () =>
      BALANCE_FILTERS.map((option) => ({
        ...option,
        count: facetBase.filter((row) => matchesBalance(row, option.value)).length,
      })),
    [facetBase],
  )

  const dueOptions = useMemo(
    () =>
      DUE_FILTERS.map((option) => ({
        ...option,
        count: facetBase.filter((row) => matchesDue(row, option.value, todayKey)).length,
      })),
    [facetBase, todayKey],
  )

  const sorted = useMemo(() => {
    const copy = [...matched]
    copy.sort((a, b) => {
      const result =
        sort.key === 'name'
          ? compareValues(a.name, b.name, sort.direction)
          : sort.key === 'balance'
            ? compareValues(a.balanceCentavos, b.balanceCentavos, sort.direction)
            : compareValues(a.lastPaymentAt, b.lastPaymentAt, sort.direction)
      // Name is the tiebreaker on every other column, so two customers with
      // the same balance keep a stable, predictable order between renders.
      return result !== 0 || sort.key === 'name' ? result : a.name.localeCompare(b.name)
    })
    return copy
  }, [matched, sort])

  const pageCount = Math.max(1, Math.ceil(sorted.length / PAGE_SIZE))
  const currentPage = Math.min(page, pageCount)
  const visible = sorted.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE)

  function applySort(key: CustomerSortKey, descendingFirst = false) {
    setSort((current) => nextSort(current, key, descendingFirst))
    // Back to page 1: staying on page 3 of a freshly reordered list shows rows
    // that have nothing to do with the column just clicked.
    setPage(1)
  }

  async function handleEdit(customerId: number) {
    setError(null)
    const customer = await getCustomer(customerId)
    if (!customer) {
      setError('Customer not found.')
      return
    }
    setEditing(customer)
    setFormOpen(true)
  }

  // No confirmation step, unlike archiving: restoring puts a record back and
  // takes nothing away, so the destructive-confirm pattern would be noise.
  function handleRestore(customerId: number) {
    setError(null)
    startTransition(async () => {
      const result = await restoreCustomer(customerId)
      if (!result.ok) {
        setError(result.error)
        return
      }
      router.refresh()
    })
  }

  function handleArchive(customerId: number) {
    setError(null)
    startTransition(async () => {
      const result = await archiveCustomer(customerId)
      if (!result.ok) {
        setError(result.error)
        return
      }
      setConfirmingId(null)
      router.refresh()
    })
  }

  return (
    <PageHeader title="Book">
      {/* Leads the page regardless of which tab is showing. Always the
          full-store total from the server, never recomputed from `visible`
          or scoped to a tab — a name filter or a tab switch must not move
          this figure. */}
      <div className="mb-6 rounded-card border border-line-strong bg-surface-raised px-5 py-4 shadow-panel">
        <TapeRow>
          <TapeCell>
            <span className="text-xs font-semibold uppercase tracking-[0.14em] text-ink-muted">
              Total utang
            </span>
          </TapeCell>
          <TapeCell align="end">
            <Money centavos={totalCentavos} tone="owed" scale="hero" />
          </TapeCell>
        </TapeRow>
      </div>

      {/* `tab` comes from the `?tab=` search param via page.tsx, not local
          state — this is what keeps the URL shareable and the browser back
          button working. Selecting a tab is a real navigation
          (`router.push`), not a client-only toggle. */}
      <Tabs
        ariaLabel="Book view"
        tabs={BOOK_TABS}
        value={tab}
        onValueChange={(value) =>
          router.push(value === 'bulk' ? `${ROUTES.book}?tab=bulk` : ROUTES.book)
        }
        className="mb-6"
      />

      {error && <FormError className="mb-4">{error}</FormError>}

      {tab === 'bulk' ? (
        // `rows`, not `customers`: the grid is now a list of who owes what, so
        // it needs balances rather than discount settings.
        <BulkPaymentGrid customers={rows} todayKey={todayKey} />
      ) : (
        <>
          {/* Facets above the search box, not beside it. This list had a name
              search and nothing else, which answers "where is Marilou" but not
              "who do I collect from today" — the question the Book actually
              gets opened for. The counts are the useful part: she can see
              there are nine overdue accounts without filtering to them. */}
          <div className="mb-4 flex flex-wrap gap-x-8 gap-y-4">
            <FilterChips
              label="Balance"
              ariaLabel="Filter by balance"
              options={balanceOptions}
              value={balanceFilter}
              onChange={(value) => {
                setBalanceFilter(value)
                setPage(1)
              }}
            />
            <FilterChips
              label="Due"
              ariaLabel="Filter by due date"
              options={dueOptions}
              value={dueFilter}
              onChange={(value) => {
                setDueFilter(value)
                setPage(1)
              }}
            />
          </div>

          <div className="mb-4 flex flex-wrap items-center justify-between gap-4">
            <Input
              type="search"
              value={filter}
              onChange={(e) => {
                setFilter(e.target.value)
                setPage(1)
              }}
              placeholder="Filter names"
              className="w-64"
            />
            <Button
              variant="primary"
              onClick={() => {
                setEditing(null)
                setFormOpen(true)
              }}
            >
              New customer
            </Button>
          </div>

          {visible.length === 0 ? (
            <EmptyState>
              {rows.length === 0
                ? 'No customers yet.'
                : 'No customers match these filters.'}
            </EmptyState>
          ) : (
            <div className="overflow-x-auto rounded-card border border-line bg-surface">
              <table className="w-full text-sm">
                <thead className="bg-surface-sunk text-left text-xs uppercase tracking-wide text-ink-muted">
                  <tr>
                    <SortableHeader
                      label="Name"
                      active={sort.key === 'name'}
                      direction={sort.direction}
                      onSort={() => applySort('name')}
                    />
                    {/* Largest owed first on a first click — that is the order
                        she works down, and the default this list already
                        arrived in. */}
                    <SortableHeader
                      label="Balance"
                      align="end"
                      active={sort.key === 'balance'}
                      direction={sort.direction}
                      onSort={() => applySort('balance', true)}
                    />
                    <SortableHeader
                      label="Last paid"
                      active={sort.key === 'lastPaid'}
                      direction={sort.direction}
                      onSort={() => applySort('lastPaid')}
                    />
                    <th className="px-4 py-3" />
                  </tr>
                </thead>
                <tbody className="divide-y divide-line">
                  {visible.map((row) => (
                    <tr key={row.customerId} className="transition-colors duration-150 hover:bg-surface-sunk">
                      <td className="px-4 py-3">
                        {/* Accent and underlined, not bold ink. Every other
                            name in this column is also bold, so weight alone
                            never signalled that this one was a link — the
                            only affordance was hovering over it and noticing
                            the cursor. */}
                        <Link
                          href={bookEntry(row.customerId)}
                          className="font-semibold text-accent underline decoration-accent/40 underline-offset-4 transition-colors duration-150 hover:text-accent-strong hover:decoration-accent-strong focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                        >
                          {row.name}
                        </Link>
                        {row.isArchived && (
                          <Badge tone="muted" className="ml-2">
                            archived
                          </Badge>
                        )}
                        {row.balanceCentavos > 0 && row.dueAt && (
                          <Badge
                            tone={dayKey(row.dueAt) < todayKey ? 'owed' : 'warn'}
                            className="ml-2"
                          >
                            {dayKey(row.dueAt) < todayKey ? 'Overdue' : 'Due'} {shortDate(row.dueAt)}
                          </Badge>
                        )}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <Money centavos={row.balanceCentavos} scale="strong" tone="balance" />
                      </td>
                      <td className="px-4 py-3 text-xs text-ink-subtle">
                        {lastPaymentLabel(row.lastPaymentAt, todayKey)}
                      </td>
                      <td className="px-4 py-3 text-right">
                        {confirmingId === row.customerId ? (
                          <span className="flex flex-wrap items-center justify-end gap-3">
                            <span className="text-sm text-ink">
                              Archive <span className="font-semibold">{row.name}</span>?
                            </span>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleArchive(row.customerId)}
                              disabled={pending}
                            >
                              Yes, archive it
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => setConfirmingId(null)}
                              disabled={pending}
                            >
                              Cancel
                            </Button>
                          </span>
                        ) : (
                          <span className="flex justify-end gap-2">
                            <Button size="sm" variant="ghost" onClick={() => handleEdit(row.customerId)}>
                              Edit
                            </Button>
                            {row.isArchived ? (
                              // Archiving hides a customer from the order picker
                              // and the bulk payment grid while their utang
                              // stays on this page. Without a way back, one
                              // mis-click needs a database edit to undo —
                              // re-creating them is blocked by the unique-name
                              // check.
                              <Button
                                size="sm"
                                variant="secondary"
                                onClick={() => handleRestore(row.customerId)}
                                disabled={pending}
                              >
                                Restore
                              </Button>
                            ) : (
                              <Button
                                size="sm"
                                variant="danger"
                                onClick={() => setConfirmingId(row.customerId)}
                              >
                                Archive
                              </Button>
                            )}
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {pageCount > 1 && (
            <nav className="mt-4 flex items-center justify-between gap-4">
              <Button
                variant="secondary"
                onClick={() => setPage(currentPage - 1)}
                disabled={currentPage <= 1}
              >
                Previous
              </Button>
              <span className="text-sm text-ink-muted">
                Page {currentPage} of {pageCount} · {sorted.length} customer
                {sorted.length === 1 ? '' : 's'}
              </span>
              <Button
                variant="secondary"
                onClick={() => setPage(currentPage + 1)}
                disabled={currentPage >= pageCount}
              >
                Next
              </Button>
            </nav>
          )}
        </>
      )}

      {/* Conditionally mounted, not held open via a prop: each open is a
          fresh mount, so the form's internal fields always start from the
          current `editing` customer instead of carrying over whatever was
          typed the last time it was open. */}
      {formOpen && (
        <CustomerForm
          categories={categories}
          units={units}
          customer={editing}
          onClose={() => setFormOpen(false)}
        />
      )}
    </PageHeader>
  )
}
