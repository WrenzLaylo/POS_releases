# Installing on the shop laptop

Rehearsed on a clean clone before being written down: every step below was run
against an empty folder, and the two that used to fail silently now do not.

Budget about 20 minutes, most of it waiting for downloads.

---

## Before you start

**One** thing must be on the laptop first, and it is quick.

### Node.js

Download the **LTS** version from <https://nodejs.org> and install it with the
default options.

`install.cmd` checks for this and stops with a plain message if it is missing,
so if you forget, nothing breaks.

> **Git is not needed.** It used to be — the app updated itself with
> `git pull`, which meant installing git AND signing in to GitHub, because the
> source repository is private. That was two things to set up and a credential
> that expires quietly a year later, leaving a till that stops receiving fixes
> with nothing on screen to say so. Updates now download a zip over plain
> HTTPS from a public releases channel. Nothing to install, nothing to sign in
> to, nothing to expire.

---

## Step 1 — Get the app

Download the newest release zip:

<https://github.com/WrenzLaylo/POS-releases> → `violy-pos-<number>.zip`

Extract it to `Documents\POS`. That is all — no git, no account.

> The zip deliberately contains no database, no `.env` and no backups. The
> shop's data is never in a release, which is why an update can never overwrite
> it. Step 3 brings the data across.

## Step 2 — Run the setup

```
cd %USERPROFILE%\Documents\POS
install.cmd
```

Or just double-click `install.cmd` in the folder.

It installs the dependencies, prepares the database, builds the app, creates
the Desktop and Start-menu icons, takes a first backup, and finishes by telling
you whether this copy has any data in it. It is safe to run twice.

Give it time — this is the slow step, and most of it is downloading
dependencies.

## Step 3 — Carry the shop's data across

**The setup finishes with an empty till.** That is correct and expected: the
database is never in git, because it holds the customers and the money. The
last line of the setup will say so.

On the **old** computer:

```
npm run backup
```

Copy the newest file from its `backups\` folder onto a USB stick. The names
sort by date, so the newest is the last one.

On the **new** laptop:

```
npm run restore -- C:\path\to\violy-pos-2026-08-17_10-26-59-170.db
```

It prints what is in the file before replacing anything — check the customer
and product counts look right — and it saves whatever was already there first,
so restoring the wrong file can be undone. A file that is not one of our
backups is refused without touching the database.

## Step 4 — Open it

Double-click **Violy Store POS** on the Desktop.

To have it start by itself when the laptop turns on:
**Violy Store → Start when the computer turns on** in the app's own menu.

---

## Afterwards

Nothing here is urgent, but nothing here is optional either.

- **Take a backup off the laptop now and then.** Backups run by themselves
  every six hours, but they live on the same machine. That survives a mistake;
  it does not survive a theft or a flood. `Violy Store → Open backups folder`,
  then copy to a USB stick.
- **Fill in the store profile** — Settings → registered name, address, TIN,
  registration number. These print on the receipts and invoices, and they are
  blank until somebody types them.
- **Count the stock in and enter cost prices.** Until then every product reads
  as out of stock and the counter asks for confirmation on every line. Either
  record a delivery (which sets cost from what was paid) or use
  Settings → Export → Products, fill in the spreadsheet, and import it back.

## If something goes wrong

The setup stops at the first failure and says which step it was. Nothing is
half-applied: the database is only ever migrated forward, never reset.

- **"Node.js is not installed"** — do the prerequisite above, then run
  `install.cmd` again.
- **The app opens but the catalogue is empty** — step 3 has not been done yet.
- **"Could not check for updates"** — the laptop cannot reach the internet, or
  the releases channel is down. Harmless: it retries, and the till works
  offline regardless.
- **"Updates are not available on this copy"** — this copy was installed from
  source rather than from a release zip. Only release installs update
  themselves; a source checkout is updated by pulling and rebuilding.
- **Anything else** — send a photo of the window. The setup leaves the error
  on screen rather than closing.

---

## Publishing an update (for whoever maintains this)

On the development machine:

```
npm run release -- "What changed, in one sentence"
```

That builds the app, packages it, and writes two files to `release-out/`:

```
violy-pos-<build>.zip     the app, with none of the shop's data in it
latest.json               build number, notes, download URL, SHA-256
```

Copy both into the **public** releases repository and push — **the zip first,
`latest.json` last**. A manifest naming a zip nobody has uploaded yet sends
every laptop to a 404.

The build number rises on its own, and only a strictly HIGHER build is offered
as an update, so republishing an older one cannot roll a till backwards.

The shop laptop checks on launch and hourly, downloads the zip, **verifies it
against the SHA-256 before writing anything**, backs up the database, stops the
app, unpacks, migrates, rebuilds and restarts.
