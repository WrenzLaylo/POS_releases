'use client'

import { useState, useTransition } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import type { LedgerLine } from '@/lib/types'
import { parsePesoInput, toPesos } from '@/lib/money'
import { dayKey } from '@/lib/dates'
import { updateEntry, voidEntry } from '@/server/ledger'
import { Button } from '@/components/ui/Button'
import { FormError } from '@/components/ui/FormError'
import { DatePicker } from '@/components/ui/DatePicker'
import { Input } from '@/components/ui/Input'
import { Money } from '@/components/ui/Money'
import { EmptyState } from '@/components/ui/EmptyState'
import { TapeCell, TapeRow } from '@/components/ui/Tape'
import { cn } from '@/lib/cn'
import { paymentReceipt, saleReceipt } from '@/lib/routes'

const LABELS: Record<LedgerLine['type'], string> = {
  OPENING: 'Opening balance',
  CHARGE: 'Order',
  PAYMENT: 'Payment',
}

/**
 * Fixed rem widths, not content-sized. Every `TapeRow` is its own
 * independent CSS grid (they are separate elements, not rows of one shared
 * table), so the only way Charge/Payment/Balance line up down the page is
 * for every row's amount block to be exactly the same width regardless of
 * how many digits it holds or what else is going on in that row.
 */
const AMOUNT_COLS = 'grid grid-cols-[5rem_5rem_6rem] gap-4'
const HEADER_LABEL = 'font-sans text-xs font-semibold uppercase tracking-wide text-ink-subtle'

function LedgerRow({ line, customerId }: { line: LedgerLine; customerId: number }) {
  const router = useRouter()
  const [editing, setEditing] = useState(false)
  const [confirming, setConfirming] = useState(false)
  const [amount, setAmount] = useState(String(toPesos(line.amountCentavos)))
  const [date, setDate] = useState(dayKey(line.occurredAt))
  const [note, setNote] = useState(line.note)
  const [error, setError] = useState<string | null>(null)
  const [pending, startTransition] = useTransition()

  function save() {
    setError(null)
    // Same rule as every other money field: null is a validation failure,
    // never a zero. Editing an entry down to ₱0.00 by typo would silently
    // rewrite a real charge or payment.
    const amountCentavos = parsePesoInput(amount)
    if (amountCentavos === null) {
      setError('Enter an amount like 50 or 1,000')
      return
    }
    if (amountCentavos <= 0) {
      setError('Amount must be more than zero.')
      return
    }
    startTransition(async () => {
      const result = await updateEntry(line.id, {
        amountCentavos,
        occurredAt: new Date(`${date}T00:00:00`),
        note,
      })
      if (!result.ok) {
        setError(result.error)
        return
      }
      setEditing(false)
      router.refresh()
    })
  }

  function cancel() {
    setError(null)
    startTransition(async () => {
      const result = await voidEntry(line.id)
      if (!result.ok) {
        setError(result.error)
        setConfirming(false)
        return
      }
      router.refresh()
    })
  }

  if (editing) {
    return (
      <div className="flex flex-wrap items-end gap-3 border-b border-line py-3 last:border-b-0">
        <DatePicker
          value={date}
          onChange={setDate}
          aria-label="Entry date"
          className="w-48"
        />
        <Input
          inputMode="decimal"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          className="w-32 tabular-nums"
        />
        <Input
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Note"
          className="min-w-40 flex-1"
        />
        <Button variant="primary" size="sm" onClick={save} disabled={pending}>
          Save
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => {
            setEditing(false)
            setError(null)
          }}
        >
          Cancel
        </Button>
        {error && <FormError className="w-full">{error}</FormError>}
      </div>
    )
  }

  const voided = line.isVoided
  const saleLinked = line.saleId !== null
  // A plan's charge carries the total its stored schedule was built from, so
  // it is corrected by voiding the whole record, never edited here. The server
  // refuses it either way; this keeps the buttons from being offered at all.
  const planCharge = line.planId !== null && line.type !== 'PAYMENT'

  return (
    <TapeRow>
      <TapeCell>
        <div className="flex min-w-0 items-baseline gap-3">
          <span className={cn('shrink-0 text-ink-muted', voided && 'line-through')}>
            {line.occurredAt.toLocaleDateString('en-PH')}
          </span>
          <span className={cn('shrink-0 font-medium text-ink', voided && 'text-ink-subtle line-through')}>
            {LABELS[line.type]}
          </span>
          {line.note && (
            <span className={cn('min-w-0 flex-1 truncate text-ink-muted', voided && 'line-through')}>
              {line.note}
            </span>
          )}
        </div>
      </TapeCell>

      <TapeCell align="end">
        {/* Charge and Payment are mutually exclusive per line — an entry is
            one or the other, never both — so each column shows either a
            toned figure or a muted placeholder, never a blank cell that
            could be misread as "not loaded yet." */}
        <div className={AMOUNT_COLS}>
          <span>
            {line.type !== 'PAYMENT' ? (
              <Money centavos={line.amountCentavos} tone={voided ? 'zero' : 'owed'} />
            ) : (
              <span className="text-ink-subtle">—</span>
            )}
          </span>
          <span>
            {line.type === 'PAYMENT' ? (
              <Money centavos={line.amountCentavos} tone={voided ? 'zero' : 'in'} />
            ) : (
              <span className="text-ink-subtle">—</span>
            )}
          </span>
          <span>
            <Money centavos={line.runningBalanceCentavos} tone={voided ? 'zero' : 'balance'} />
          </span>
        </div>

        {!voided && (
          <div className="mt-1">
            {saleLinked ? (
              <div className="flex justify-end">
                <Link
                  href={saleReceipt(line.saleId!)}
                  className="inline-flex h-8 items-center rounded-control px-3 text-sm font-medium text-accent hover:bg-accent-soft"
                >
                  Open sale #{line.saleId}
                </Link>
              </div>
            ) : planCharge ? (
              <div className="flex justify-end">
                <span className="inline-flex h-8 items-center px-3 text-xs text-ink-subtle">
                  From an utang record above
                </span>
              </div>
            ) : confirming ? (
              <span className="flex flex-wrap items-center justify-end gap-2">
                <span className="text-xs font-medium text-ink">Void?</span>
                <Button variant="destructive" size="sm" onClick={cancel} disabled={pending}>
                  Yes, void it
                </Button>
                <Button variant="ghost" size="sm" onClick={() => setConfirming(false)} disabled={pending}>
                  No
                </Button>
              </span>
            ) : (
              <span className="flex justify-end gap-2">
                {/* Only a payment gets a receipt: it is the only entry type
                    that records cash actually changing hands. */}
                {line.type === 'PAYMENT' && (
                  <Link
                    href={paymentReceipt(customerId, line.id)}
                    className="inline-flex h-8 items-center rounded-control px-3 text-sm font-medium text-accent hover:bg-accent-soft"
                  >
                    Receipt
                  </Link>
                )}
                <Button variant="ghost" size="sm" onClick={() => setEditing(true)}>
                  Edit
                </Button>
                <Button variant="danger" size="sm" onClick={() => setConfirming(true)} disabled={pending}>
                  Void
                </Button>
              </span>
            )}
          </div>
        )}

        {error && <FormError className="mt-1 text-right">{error}</FormError>}
      </TapeCell>
    </TapeRow>
  )
}

/**
 * The ledger, rebuilt as genuine accounting tape: date, description, charge,
 * payment, and running balance in aligned mono columns, hairlines between
 * rows, no card chrome. This is the screen the tape motif exists for.
 */
export function LedgerView({ lines, customerId }: { lines: LedgerLine[]; customerId: number }) {
  return (
    <div>
      <h2 className="mb-3 text-base font-semibold">Ledger</h2>

      {lines.length === 0 ? (
        <EmptyState>No entries yet.</EmptyState>
      ) : (
        <div>
          <TapeRow>
            <TapeCell>
              <span className={HEADER_LABEL}>Date / description</span>
            </TapeCell>
            <TapeCell align="end">
              <div className={AMOUNT_COLS}>
                <span className={HEADER_LABEL}>Charge</span>
                <span className={HEADER_LABEL}>Payment</span>
                <span className={HEADER_LABEL}>Balance</span>
              </div>
            </TapeCell>
          </TapeRow>
          {lines.map((line) => (
            <LedgerRow key={line.id} line={line} customerId={customerId} />
          ))}
        </div>
      )}
    </div>
  )
}
