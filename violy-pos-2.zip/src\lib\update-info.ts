/**
 * Shapes shared between the update check and the screen that shows it.
 *
 * In `lib/`, not beside the server functions, for the reason recorded in
 * `lib/export-tables.ts`: a `'use server'` module may export only async
 * functions, and a constant exported from one arrives in a client component as
 * a function rather than the value.
 *
 * ── Why this is no longer git ──────────────────────────────────────────
 *
 * Updates used to be `git fetch` and `git merge --ff-only`. That required git
 * installed on the shop laptop AND a GitHub sign-in, because the source
 * repository is private — two things to install, and a credential that can
 * quietly expire months later, leaving a till that stops receiving fixes with
 * nothing on screen to say so.
 *
 * Now the laptop reads ONE small JSON file over plain HTTPS from a public
 * releases channel and downloads a zip when there is a newer build. No git, no
 * account, nothing to expire. The source repository stays private; only built
 * releases are public.
 */

import channel from '../../release-channel.json'

/**
 * Where the shop laptop looks for new builds. Public, and read-only.
 *
 * Built from `release-channel.json` rather than written here, because the same
 * URL is needed by the desktop shell, the updater and the release packager —
 * and four copies of one string is how a channel ends up half-moved.
 */
export const RELEASE_MANIFEST_URL = `${channel.baseUrl}/${channel.manifestFile}`

/**
 * The file an installed copy carries to say which build it is.
 *
 * Written into the zip when a release is packaged. A copy WITHOUT it was
 * installed from source rather than from a release — a developer's clone — and
 * is deliberately told there is nothing to update, rather than being offered a
 * zip that would overwrite uncommitted work.
 */
export const INSTALLED_RELEASE_FILE = 'release.json'

/**
 * What a release is, on both ends.
 *
 * `build` is the thing compared: a plain incrementing integer, because every
 * clever version scheme has an ordering edge case and this one has none.
 * `version` is for reading — a date is what somebody means by "which version
 * is this".
 */
export type ReleaseManifest = {
  build: number
  version: string
  /** ISO date the release was published. */
  publishedAt: string
  /** Plain sentences describing what changed, newest first. */
  notes: string[]
  /** Absolute HTTPS URL of the zip. */
  zipUrl: string
  /** Hex SHA-256 of the zip, checked after download. */
  sha256: string
}

export type InstalledRelease = {
  build: number
  version: string
  installedAt: string
}

export type UpdateStatus =
  | { kind: 'up-to-date'; installed: InstalledRelease }
  | { kind: 'available'; installed: InstalledRelease; latest: ReleaseManifest }
  /** Not installed from a release, so there is nothing to compare against. */
  | { kind: 'unknown'; reason: string }
  | { kind: 'offline'; reason: string }

/**
 * Reads a manifest that arrived over the network, refusing anything malformed.
 *
 * Everything here crossed the internet, so nothing is assumed. A manifest with
 * a missing `sha256` or a non-HTTPS `zipUrl` is refused rather than
 * half-trusted: this file decides what code gets written over a working till.
 */
export function parseManifest(raw: unknown): ReleaseManifest | null {
  if (typeof raw !== 'object' || raw === null) return null
  const value = raw as Record<string, unknown>

  const build = value.build
  if (typeof build !== 'number' || !Number.isInteger(build) || build < 1) return null

  const version = typeof value.version === 'string' ? value.version.trim() : ''
  if (version === '') return null

  const zipUrl = typeof value.zipUrl === 'string' ? value.zipUrl.trim() : ''
  // HTTPS only. A plain-HTTP download is one that anybody on the same network
  // can replace, and what it replaces is the application.
  if (!zipUrl.startsWith('https://')) return null

  const sha256 = typeof value.sha256 === 'string' ? value.sha256.trim().toLowerCase() : ''
  if (!/^[0-9a-f]{64}$/.test(sha256)) return null

  const notes = Array.isArray(value.notes)
    ? value.notes.filter((note): note is string => typeof note === 'string')
    : []

  const publishedAt = typeof value.publishedAt === 'string' ? value.publishedAt : ''

  return { build, version, publishedAt, notes, zipUrl, sha256 }
}

/** Reads the `release.json` an installed copy carries. */
export function parseInstalled(raw: unknown): InstalledRelease | null {
  if (typeof raw !== 'object' || raw === null) return null
  const value = raw as Record<string, unknown>

  const build = value.build
  if (typeof build !== 'number' || !Number.isInteger(build) || build < 1) return null

  return {
    build,
    version: typeof value.version === 'string' ? value.version : String(build),
    installedAt: typeof value.installedAt === 'string' ? value.installedAt : '',
  }
}

/**
 * Whether the published build is newer than the installed one.
 *
 * Strictly greater, never merely "different". A manifest that has gone
 * BACKWARDS — a bad release pulled and replaced with an older one — must not be
 * offered as an update: applying it would roll the till back, and the next
 * check would offer it again, forever.
 */
export function isNewer(latest: ReleaseManifest, installed: InstalledRelease): boolean {
  return latest.build > installed.build
}

/**
 * Plain wording for a shopkeeper, not a developer.
 *
 * The person using this reads "you are up to date" or "there is a new
 * version". Build numbers and hashes belong in the detail, not the headline.
 */
export function updateHeadline(status: UpdateStatus): string {
  switch (status.kind) {
    case 'up-to-date':
      return 'You have the latest version.'
    case 'available':
      return 'There is a new version ready to install.'
    case 'offline':
      return 'Could not check for updates.'
    case 'unknown':
      return 'Updates are not available on this copy.'
  }
}
