'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { parsePesoInput } from '@/lib/money'
import { dayKey } from '@/lib/dates'
import { recordPayment } from '@/server/ledger'
import type { UtangPlanView } from '@/lib/types'
import { Button } from '@/components/ui/Button'
import { Dialog } from '@/components/ui/Dialog'
import { Field } from '@/components/ui/Field'
import { FormError } from '@/components/ui/FormError'
import { DatePicker } from '@/components/ui/DatePicker'
import { Input } from '@/components/ui/Input'
import { Money } from '@/components/ui/Money'
import { Select } from '@/components/ui/Select'

/** The sentinel for "against the account, not one record". */
const ACCOUNT = 'account'

export function PaymentDialog({
  customerId,
  plans,
  todayKey,
  balanceCentavos,
  onClose,
}: {
  customerId: number
  /** Live plans only — a voided record cannot take a payment. */
  plans: UtangPlanView[]
  /** Computed on the server so this cannot differ between the two passes. */
  todayKey: string
  /** What is owed right now. */
  balanceCentavos: number
  onClose: () => void
}) {
  const router = useRouter()
  const [amount, setAmount] = useState('')
  const [date, setDate] = useState(todayKey)
  const [note, setNote] = useState('')
  const [target, setTarget] = useState<string>(
    // Defaults to the oldest unsettled record, which is the one a payment is
    // usually for. Defaulting to "the account" instead would quietly leave
    // every record looking unpaid.
    () => {
      const open = plans.filter((plan) => plan.outstandingCentavos > 0)
      const oldest = open[open.length - 1]
      return oldest ? String(oldest.id) : ACCOUNT
    },
  )
  const [error, setError] = useState<string | null>(null)
  const [confirmingOverpay, setConfirmingOverpay] = useState(false)
  const [pending, startTransition] = useTransition()

  const selected = plans.find((plan) => String(plan.id) === target) ?? null
  const parsed = parsePesoInput(amount)

  // Paying more than is owed is not an error — a customer really can hand over
  // extra, and the account carries the credit. It is just almost always a
  // typo or the wrong customer, so it has to be said out loud before it is
  // booked rather than discovered later as a mystery credit.
  const owedCentavos = Math.max(0, balanceCentavos)
  const overpays = parsed !== null && parsed > 0 && parsed > owedCentavos
  const excessCentavos = overpays ? parsed - owedCentavos : 0

  // Re-arming on every change is the point: adjust the amount after
  // confirming and the question is asked again about the new figure.
  function amendAmount(value: string) {
    setAmount(value)
    setConfirmingOverpay(false)
  }

  function save() {
    setError(null)
    // Null, never 0, for anything unparseable — a payment must not be booked
    // as ₱0.00 because of a stray character.
    if (parsed === null) {
      setError('Enter an amount like 50 or 1,000')
      return
    }
    if (parsed <= 0) {
      setError('Amount must be more than zero.')
      return
    }
    if (overpays && !confirmingOverpay) {
      setConfirmingOverpay(true)
      return
    }

    startTransition(async () => {
      const result = await recordPayment({
        customerId,
        amountCentavos: parsed,
        // Local midnight, not UTC — the ledger sorts by her calendar.
        occurredAt: new Date(`${date}T00:00:00`),
        note,
        planId: target === ACCOUNT ? null : Number(target),
      })
      if (!result.ok) {
        setError(result.error)
        return
      }
      router.refresh()
      onClose()
    })
  }

  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title="Record a payment"
      footer={
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose} disabled={pending}>
            Cancel
          </Button>
          <Button
            variant={confirmingOverpay ? 'destructive' : 'success'}
            onClick={save}
            disabled={pending}
          >
            {pending
              ? 'Saving…'
              : confirmingOverpay
                ? 'Yes, record it anyway'
                : 'Save payment'}
          </Button>
        </div>
      }
    >
      <div className="grid gap-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Amount">
            <Input
              inputMode="decimal"
              value={amount}
              onChange={(event) => amendAmount(event.target.value)}
              placeholder="0.00"
              className="w-full tabular-nums"
              autoFocus
            />
          </Field>

          <Field label="Date">
            <DatePicker
              value={date}
              onChange={setDate}
              aria-label="Date received"
              className="w-full"
            />
          </Field>
        </div>

        {plans.length > 0 && (
          <>
            <Field label="Put this towards">
              <Select
                aria-label="Which utang this payment settles"
                value={target}
                onChange={(event) => setTarget(event.target.value)}
                className="w-full"
              >
                {plans.map((plan) => (
                  <option key={plan.id} value={String(plan.id)}>
                    {plan.startedAt.toLocaleDateString('en-PH', {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric',
                    })}
                    {' — '}
                    {plan.termsLabel}
                  </option>
                ))}
                <option value={ACCOUNT}>Account — no specific record</option>
              </Select>
            </Field>

            {selected ? (
              <p className="-mt-2 text-xs text-ink-subtle">
                Outstanding on this record:{' '}
                <Money centavos={selected.outstandingCentavos} tone="owed" />
                {selected.nextDue && (
                  <>
                    {' · next instalment '}
                    <Money centavos={selected.nextDue.amountCentavos} />
                    {' due '}
                    {selected.nextDue.dueAt.toLocaleDateString('en-PH', {
                      month: 'short',
                      day: 'numeric',
                    })}
                  </>
                )}
              </p>
            ) : (
              <p className="-mt-2 text-xs text-ink-subtle">
                Reduces the balance without settling any one record.
              </p>
            )}
          </>
        )}

        <Field label="Note (optional)">
          <Input
            value={note}
            onChange={(event) => setNote(event.target.value)}
            className="w-full"
          />
        </Field>

        {overpays && (
          <div
            role="alert"
            className="rounded-control border border-warn/40 bg-warn/10 p-3 text-sm text-warn"
          >
            <div className="font-semibold">
              {owedCentavos === 0
                ? 'This account owes nothing.'
                : 'This is more than the account owes.'}
            </div>
            <div className="mt-1">
              {owedCentavos === 0 ? (
                <>
                  Saving <Money centavos={parsed ?? 0} /> leaves the account{' '}
                  <Money centavos={excessCentavos} /> in credit.
                </>
              ) : (
                <>
                  Only <Money centavos={owedCentavos} /> is outstanding, so{' '}
                  <Money centavos={excessCentavos} /> becomes credit on the account.
                </>
              )}
            </div>
            {confirmingOverpay && (
              <div className="mt-2 font-semibold">
                Press Save payment again to record it anyway.
              </div>
            )}
          </div>
        )}

        {error && <FormError>{error}</FormError>}
      </div>
    </Dialog>
  )
}
