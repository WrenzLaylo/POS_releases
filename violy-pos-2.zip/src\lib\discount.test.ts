import { describe, expect, it } from 'vitest'
import {
  computeOrderTotals,
  hasOrderDiscount,
  percentOf,
  type CustomerDiscount,
  type OrderDiscount,
} from './discount'

const FEEDS = 1
const MEDICINE = 2

/** A ₱1,000 sack of feeds, quantity 1, unless a test says otherwise. */
function line(overrides: Partial<Parameters<typeof computeOrderTotals>[0]['lines'][number]> = {}) {
  return {
    productId: 1,
    quantity: 1,
    priceCentavos: 100_000,
    categoryId: FEEDS,
    unit: 'bag (50kg)',
    ...overrides,
  }
}

function customer(overrides: Partial<CustomerDiscount> = {}): CustomerDiscount {
  return {
    kind: 'AMOUNT',
    amountCentavos: 0,
    bps: 0,
    basis: 'PER_UNIT',
    // Empty: every existing case in this file was written before discounts
    // could name a unit, and must keep pricing the same way.
    unit: '',
    categoryIds: new Set([FEEDS]),
    ...overrides,
  }
}

function order(overrides: Partial<OrderDiscount> = {}): OrderDiscount {
  return { kind: 'AMOUNT', amountCentavos: 0, bps: 0, mode: 'STACK', ...overrides }
}

describe('percentOf', () => {
  it('converts basis points to centavos', () => {
    expect(percentOf(100_000, 500)).toBe(5_000) // 5% of ₱1,000 is ₱50
    expect(percentOf(145_000, 500)).toBe(7_250) // 5% of ₱1,450 is ₱72.50
    expect(percentOf(100_000, 10_000)).toBe(100_000) // 100% is the whole thing
    expect(percentOf(100_000, 0)).toBe(0)
  })

  it('rounds to whole centavos rather than carrying a fraction', () => {
    // 3.33% of ₱10.00 is 3.33 centavos, which does not exist.
    expect(percentOf(1_000, 333)).toBe(33)
    expect(Number.isInteger(percentOf(99_999, 777))).toBe(true)
  })
})

describe('hasOrderDiscount', () => {
  it('reads the field its kind actually uses', () => {
    // A leftover bps on an AMOUNT discount is not a discount, and vice versa.
    expect(hasOrderDiscount(order({ kind: 'AMOUNT', amountCentavos: 0, bps: 500 }))).toBe(false)
    expect(hasOrderDiscount(order({ kind: 'PERCENT', bps: 0, amountCentavos: 5_000 }))).toBe(false)
    expect(hasOrderDiscount(order({ kind: 'AMOUNT', amountCentavos: 5_000 }))).toBe(true)
    expect(hasOrderDiscount(order({ kind: 'PERCENT', bps: 500 }))).toBe(true)
    expect(hasOrderDiscount(null)).toBe(false)
  })
})

describe('no discount', () => {
  it('leaves the total as the plain subtotal', () => {
    const totals = computeOrderTotals({ lines: [line({ quantity: 3 })] })
    expect(totals.subtotalCentavos).toBe(300_000)
    expect(totals.totalCentavos).toBe(300_000)
    expect(totals.totalDiscountCentavos).toBe(0)
  })
})

describe('customer discount, per unit', () => {
  it('takes a peso amount off each unit in a covered category', () => {
    const totals = computeOrderTotals({
      lines: [line({ quantity: 3 })],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 5_000 }),
    })
    expect(totals.lines[0].discountPerUnitCentavos).toBe(5_000)
    expect(totals.totalCentavos).toBe(285_000) // 3 × ₱950
    expect(totals.lineDiscountCentavos).toBe(15_000)
  })

  it('takes a percentage off each unit in a covered category', () => {
    const totals = computeOrderTotals({
      lines: [line({ priceCentavos: 145_000, quantity: 2 })],
      customer: customer({ kind: 'PERCENT', bps: 500 }),
    })
    expect(totals.lines[0].discountPerUnitCentavos).toBe(7_250) // 5% of ₱1,450
    expect(totals.totalCentavos).toBe(275_500) // 2 × ₱1,377.50
  })

  it('leaves categories outside the discount alone', () => {
    const totals = computeOrderTotals({
      lines: [line({ categoryId: MEDICINE })],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 5_000 }),
    })
    expect(totals.lines[0].discountPerUnitCentavos).toBe(0)
    expect(totals.totalCentavos).toBe(100_000)
  })

  it('applies to nothing when the discount has no categories', () => {
    const totals = computeOrderTotals({
      lines: [line()],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 5_000, categoryIds: new Set() }),
    })
    expect(totals.totalCentavos).toBe(100_000)
  })

  it('makes a line free rather than negative when the discount exceeds the price', () => {
    const totals = computeOrderTotals({
      lines: [line({ priceCentavos: 3_000, quantity: 4 })],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 5_000 }),
    })
    expect(totals.lines[0].discountPerUnitCentavos).toBe(3_000)
    expect(totals.totalCentavos).toBe(0)
  })
})

describe('customer discount, whole order', () => {
  it('takes a percentage off the order and ignores category scoping', () => {
    const totals = computeOrderTotals({
      lines: [line(), line({ productId: 2, categoryId: MEDICINE })],
      customer: customer({ kind: 'PERCENT', bps: 1_000, basis: 'ORDER_TOTAL' }),
    })
    // Both lines count, including the one outside the discounted category.
    expect(totals.customerDiscountCentavos).toBe(20_000)
    expect(totals.lineDiscountCentavos).toBe(0)
    expect(totals.totalCentavos).toBe(180_000)
  })

  it('never takes off more than the order is worth', () => {
    const totals = computeOrderTotals({
      lines: [line({ priceCentavos: 5_000 })],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 900_000, basis: 'ORDER_TOTAL' }),
    })
    expect(totals.customerDiscountCentavos).toBe(5_000)
    expect(totals.totalCentavos).toBe(0)
  })
})

describe('ad-hoc counter discount', () => {
  it('stacks on top of a per-unit customer discount', () => {
    const totals = computeOrderTotals({
      lines: [line()],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 10_000 }),
      order: order({ kind: 'AMOUNT', amountCentavos: 5_000 }),
    })
    expect(totals.lineDiscountCentavos).toBe(10_000)
    expect(totals.orderDiscountCentavos).toBe(5_000)
    expect(totals.totalCentavos).toBe(85_000)
  })

  it('takes its percentage against the already-discounted figure', () => {
    const totals = computeOrderTotals({
      lines: [line()],
      customer: customer({ kind: 'PERCENT', bps: 1_000 }),
      order: order({ kind: 'PERCENT', bps: 1_000 }),
    })
    // 10% off ₱1,000 leaves ₱900; the counter's 10% is ₱90, not ₱100.
    expect(totals.orderDiscountCentavos).toBe(9_000)
    expect(totals.totalCentavos).toBe(81_000)
  })

  it('replaces the standing discount when the mode says so', () => {
    const totals = computeOrderTotals({
      lines: [line()],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 10_000 }),
      order: order({ kind: 'AMOUNT', amountCentavos: 5_000, mode: 'REPLACE' }),
    })
    expect(totals.lineDiscountCentavos).toBe(0)
    expect(totals.orderDiscountCentavos).toBe(5_000)
    expect(totals.totalCentavos).toBe(95_000)
  })

  it('keeps the standing discount when REPLACE is set but nothing was entered', () => {
    // Leaving the toggle on "instead of" with an empty amount must not
    // silently strip a customer of the discount they are owed.
    const totals = computeOrderTotals({
      lines: [line()],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 10_000 }),
      order: order({ mode: 'REPLACE', amountCentavos: 0 }),
    })
    expect(totals.lineDiscountCentavos).toBe(10_000)
    expect(totals.totalCentavos).toBe(90_000)
  })

  it('never drives the total below zero', () => {
    const totals = computeOrderTotals({
      lines: [line({ priceCentavos: 5_000 })],
      order: order({ kind: 'AMOUNT', amountCentavos: 900_000 }),
    })
    expect(totals.orderDiscountCentavos).toBe(5_000)
    expect(totals.totalCentavos).toBe(0)
  })

  it('applies to a walk-in with no customer at all', () => {
    const totals = computeOrderTotals({
      lines: [line()],
      customer: null,
      order: order({ kind: 'PERCENT', bps: 1_000 }),
    })
    expect(totals.totalCentavos).toBe(90_000)
  })
})

describe('invariants', () => {
  const kinds = ['AMOUNT', 'PERCENT'] as const
  const bases = ['PER_UNIT', 'ORDER_TOTAL'] as const
  const modes = ['STACK', 'REPLACE'] as const

  it('always reports a total of subtotal minus every discount, and never a negative', () => {
    for (const customerKind of kinds) {
      for (const basis of bases) {
        for (const orderKind of kinds) {
          for (const mode of modes) {
            for (const quantity of [1, 2.5, 7]) {
              const totals = computeOrderTotals({
                lines: [
                  line({ quantity, priceCentavos: 145_000 }),
                  line({ productId: 2, quantity, priceCentavos: 3_300, categoryId: MEDICINE }),
                ],
                customer: customer({
                  kind: customerKind,
                  basis,
                  amountCentavos: 7_000,
                  bps: 1_250,
                }),
                order: order({ kind: orderKind, mode, amountCentavos: 9_900, bps: 750 }),
              })

              const label = `${customerKind}/${basis} + ${orderKind}/${mode} × ${quantity}`
              expect(totals.totalCentavos, label).toBeGreaterThanOrEqual(0)
              expect(
                totals.subtotalCentavos - totals.totalDiscountCentavos,
                label,
              ).toBe(totals.totalCentavos)
              expect(Number.isInteger(totals.totalCentavos), label).toBe(true)
            }
          }
        }
      }
    }
  })
})

describe('a per-unit discount scoped to a unit', () => {
  it('applies to the named unit and skips the others', () => {
    const customer = { kind: 'AMOUNT' as const, amountCentavos: 2_000, bps: 0, basis: 'PER_UNIT' as const, unit: 'bag', categoryIds: new Set([FEEDS]) }

    const totals = computeOrderTotals({
      lines: [
        line({ productId: 1, quantity: 1, priceCentavos: 205_000, unit: 'bag (50kg)' }),
        line({ productId: 2, quantity: 1, priceCentavos: 11_000, unit: 'kilo' }),
      ],
      customer,
    })

    // ₱20 off the sack, nothing off the kilo pack.
    expect(totals.lines[0].discountPerUnitCentavos).toBe(2_000)
    expect(totals.lines[1].discountPerUnitCentavos).toBe(0)
    expect(totals.totalCentavos).toBe(205_000 - 2_000 + 11_000)
  })

  it('treats every bag size as a bag', () => {
    const customer = { kind: 'AMOUNT' as const, amountCentavos: 2_000, bps: 0, basis: 'PER_UNIT' as const, unit: 'bag', categoryIds: new Set([FEEDS]) }

    const totals = computeOrderTotals({
      lines: [
        line({ productId: 1, unit: 'bag (50kg)' }),
        line({ productId: 2, unit: 'bag (25kg)' }),
        line({ productId: 3, unit: 'bag' }),
      ],
      customer,
    })

    for (const discounted of totals.lines) {
      expect(discounted.discountPerUnitCentavos).toBe(2_000)
    }
  })

  it('still requires the category, so a unit does not widen the scope', () => {
    const customer = { kind: 'AMOUNT' as const, amountCentavos: 2_000, bps: 0, basis: 'PER_UNIT' as const, unit: 'bag', categoryIds: new Set([FEEDS]) }

    const totals = computeOrderTotals({
      lines: [line({ categoryId: 999, unit: 'bag (50kg)' })],
      customer,
    })
    expect(totals.lines[0].discountPerUnitCentavos).toBe(0)
  })

  it('with no unit named, prices exactly as it did before units existed', () => {
    const customer = { kind: 'AMOUNT' as const, amountCentavos: 2_000, bps: 0, basis: 'PER_UNIT' as const, unit: '', categoryIds: new Set([FEEDS]) }

    const totals = computeOrderTotals({
      lines: [line({ productId: 1, unit: 'bag (50kg)' }), line({ productId: 2, unit: 'kilo' })],
      customer,
    })
    expect(totals.lines.map((l) => l.discountPerUnitCentavos)).toEqual([2_000, 2_000])
  })

  it('is ignored entirely by a whole-order discount', () => {
    // ORDER_TOTAL has no per-line scope at all, so naming a unit must not
    // start narrowing one.
    const customer = { kind: 'AMOUNT' as const, amountCentavos: 5_000, bps: 0, basis: 'ORDER_TOTAL' as const, unit: 'bag', categoryIds: new Set([FEEDS]) }

    const totals = computeOrderTotals({
      lines: [line({ priceCentavos: 100_000, unit: 'kilo' })],
      customer,
    })
    expect(totals.totalCentavos).toBe(95_000)
  })
})
