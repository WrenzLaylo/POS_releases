/**
 * Which tables can be exported, and how they are described in the UI.
 *
 * In its own module rather than beside `exportTableCsv`, because
 * `src/server/export-data.ts` carries `'use server'` and such a file may
 * export ONLY async functions. Next wraps every export of a `'use server'`
 * module as a server-action reference, so a `const` array arrives in a client
 * component as a FUNCTION — which fails at runtime with "g.map is not a
 * function" and not at build time.
 *
 * This is the second time that trap has bitten in this codebase; the first was
 * `PRODUCT_SORT_KEYS`, which at least failed loudly during page-data
 * collection. Non-function exports belong in `lib/`.
 */

export type ExportTable = 'products' | 'customers' | 'sales' | 'ledger'

export const EXPORT_TABLES: readonly { value: ExportTable; label: string; note: string }[] = [
  { value: 'products', label: 'Products', note: 'Name, category, unit, prices, stock' },
  { value: 'customers', label: 'Customers', note: 'Names, contact, discount, balance' },
  { value: 'sales', label: 'Sales', note: 'Every sale with its totals and payment' },
  { value: 'ledger', label: 'Ledger entries', note: 'Every charge and payment on the book' },
]
