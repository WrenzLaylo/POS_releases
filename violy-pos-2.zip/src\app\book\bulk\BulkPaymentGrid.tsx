'use client'

import { useMemo, useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import type { BatchPaymentRow, CustomerWithBalance } from '@/lib/types'
import { formatPeso, parsePesoInput, toPesos } from '@/lib/money'
import { recordPaymentBatch } from '@/server/ledger'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { EmptyState } from '@/components/ui/EmptyState'
import { Field } from '@/components/ui/Field'
import { DatePicker } from '@/components/ui/DatePicker'
import { Input } from '@/components/ui/Input'
import { Money } from '@/components/ui/Money'
import { FormError } from '@/components/ui/FormError'
import { cn } from '@/lib/cn'

/**
 * Recording a round of collections in one pass.
 *
 * The old version was a blank grid: pick a customer from a dropdown, type an
 * amount, repeat. Two things were wrong with that. The dropdown was clipped to
 * a few pixels, because `Select` renders an absolutely-positioned popup and the
 * grid wrapped it in `overflow-x-auto` — setting one overflow axis makes the
 * other `auto`, so the popup got its own scrollbar inside a 40px window. And
 * the shape was backwards: it asked her to remember who paid, when the useful
 * question is the opposite — here is everyone who owes, mark off the ones who
 * paid.
 *
 * So the customers ARE the rows. No dropdown to clip, no customer to pick
 * wrongly, the balance visible beside every amount, and a running total of
 * what is about to be recorded.
 */
export function BulkPaymentGrid({
  customers,
  todayKey,
}: {
  /** Everyone on the book, with what they owe. */
  customers: CustomerWithBalance[]
  /** Computed on the server, so the two render passes cannot disagree. */
  todayKey: string
}) {
  const router = useRouter()
  const [date, setDate] = useState(todayKey)
  const [note, setNote] = useState('')
  const [filter, setFilter] = useState('')
  const [showSettled, setShowSettled] = useState(false)
  /** customerId → what she typed. Absent means this row is not being paid. */
  const [amounts, setAmounts] = useState<Map<number, string>>(new Map())
  const [errors, setErrors] = useState<Map<number, string>>(new Map())
  const [topError, setTopError] = useState<string | null>(null)
  const [summary, setSummary] = useState<{ recorded: number; failed: number } | null>(null)
  const [pending, startTransition] = useTransition()

  // Owing first and largest first — the order she works down a collection
  // round. Archived names stay out; a settled customer only appears when
  // asked for, since paying one is the exception.
  const visible = useMemo(() => {
    const needle = filter.trim().toLowerCase()
    return customers
      .filter((customer) => !customer.isArchived)
      .filter((customer) => showSettled || customer.balanceCentavos > 0)
      .filter((customer) => needle === '' || customer.name.toLowerCase().includes(needle))
      .sort(
        (a, b) => b.balanceCentavos - a.balanceCentavos || a.name.localeCompare(b.name),
      )
  }, [customers, filter, showSettled])

  // Every row that currently holds a parseable, positive amount.
  const entered = useMemo(() => {
    const rows: { customer: CustomerWithBalance; centavos: number }[] = []
    for (const customer of customers) {
      const raw = amounts.get(customer.customerId)
      if (raw === undefined || raw.trim() === '') continue
      const centavos = parsePesoInput(raw)
      if (centavos === null || centavos <= 0) continue
      rows.push({ customer, centavos })
    }
    return rows
  }, [amounts, customers])

  const totalCentavos = entered.reduce((total, row) => total + row.centavos, 0)

  function setAmount(customerId: number, value: string) {
    setSummary(null)
    setTopError(null)
    setErrors((current) => {
      if (!current.has(customerId)) return current
      const next = new Map(current)
      next.delete(customerId)
      return next
    })
    setAmounts((current) => {
      const next = new Map(current)
      if (value === '') next.delete(customerId)
      else next.set(customerId, value)
      return next
    })
  }

  function save() {
    setTopError(null)
    setSummary(null)

    // Anything typed that could not be read is a mistake to point at, never a
    // row to silently skip: skipping it would report "3 payments recorded"
    // while she believed she had entered four.
    const unreadable = new Map<number, string>()
    for (const [customerId, raw] of amounts) {
      if (raw.trim() === '') continue
      const centavos = parsePesoInput(raw)
      if (centavos === null) unreadable.set(customerId, 'Enter an amount like 50 or 1,000')
      else if (centavos <= 0) unreadable.set(customerId, 'Amount must be more than zero.')
    }
    if (unreadable.size > 0) {
      setErrors(unreadable)
      return
    }
    if (entered.length === 0) {
      setTopError('Nothing entered yet. Type an amount beside anyone who paid.')
      return
    }

    // The array order IS what `failures[].index` refers to, so it is captured
    // here and used to pin each failure back to the right customer.
    const sending = entered.map(({ customer, centavos }) => ({
      customerId: customer.customerId,
      row: {
        customerId: customer.customerId,
        amountCentavos: centavos,
        // Local midnight, not UTC — the ledger sorts by her calendar.
        occurredAt: new Date(`${date}T00:00:00`),
        note: note.trim() || undefined,
      } satisfies BatchPaymentRow,
    }))

    startTransition(async () => {
      const result = await recordPaymentBatch(sending.map((s) => s.row))
      if (!result.ok) {
        setTopError(result.error)
        return
      }

      const failed = new Map<number, string>()
      for (const failure of result.data.failures) {
        failed.set(sending[failure.index].customerId, failure.error)
      }

      // Successful rows are cleared; failed ones keep what was typed so it can
      // be corrected rather than re-entered from memory.
      setAmounts((current) => {
        const next = new Map<number, string>()
        for (const [customerId, raw] of current) {
          if (failed.has(customerId)) next.set(customerId, raw)
        }
        return next
      })
      setErrors(failed)
      setSummary({ recorded: result.data.recorded, failed: result.data.failures.length })
      router.refresh()
    })
  }

  const owing = customers.filter((c) => !c.isArchived && c.balanceCentavos > 0).length

  return (
    <Card>
      <div className="mb-4 flex flex-wrap items-end justify-between gap-4">
        <div className="flex flex-wrap items-end gap-3">
          <Field label="Date received">
            <DatePicker
              value={date}
              onChange={setDate}
              disabled={pending}
              aria-label="Date received"
              className="w-48"
            />
          </Field>
          <Field label="Note for all of these (optional)">
            <Input
              value={note}
              onChange={(event) => setNote(event.target.value)}
              placeholder="e.g. Saturday collection"
              disabled={pending}
              className="w-56"
            />
          </Field>
          <Field label="Find a name">
            <Input
              type="search"
              value={filter}
              onChange={(event) => setFilter(event.target.value)}
              placeholder="Filter names"
              className="w-48"
            />
          </Field>
        </div>

        {/* The running total. Neutral until it is actually saved — this is
            money about to be recorded, not money received. */}
        <div className="text-right">
          <div className="text-xs font-semibold uppercase tracking-wide text-ink-muted">
            About to record
          </div>
          <Money centavos={totalCentavos} scale="strong" />
          <div className="text-xs text-ink-subtle">
            {entered.length} payment{entered.length === 1 ? '' : 's'}
          </div>
        </div>
      </div>

      {topError && <FormError className="mb-3">{topError}</FormError>}

      {visible.length === 0 ? (
        <EmptyState>
          {owing === 0
            ? 'Nobody owes anything right now.'
            : 'No names match that filter.'}
        </EmptyState>
      ) : (
        <div className="overflow-hidden rounded-card border border-line">
          <table className="w-full text-sm">
            <thead className="bg-surface-sunk text-left text-xs uppercase tracking-wide text-ink-muted">
              <tr>
                <th className="px-4 py-3 font-medium">Name</th>
                <th className="px-4 py-3 text-right font-medium">Owes</th>
                <th className="px-4 py-3 text-right font-medium">Paying now</th>
                <th className="px-4 py-3 font-medium" />
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {visible.map((customer) => {
                const raw = amounts.get(customer.customerId) ?? ''
                const error = errors.get(customer.customerId)
                const centavos = raw.trim() === '' ? null : parsePesoInput(raw)
                const owes = Math.max(0, customer.balanceCentavos)
                const overpays = centavos !== null && centavos > owes

                return (
                  <tr
                    key={customer.customerId}
                    className={cn(raw.trim() !== '' && 'bg-accent-soft/40')}
                  >
                    <td className="px-4 py-2 font-medium text-ink">{customer.name}</td>
                    <td className="px-4 py-2 text-right">
                      <Money centavos={customer.balanceCentavos} tone="balance" />
                    </td>
                    <td className="px-4 py-2 text-right">
                      <Input
                        inputMode="decimal"
                        value={raw}
                        onChange={(event) => setAmount(customer.customerId, event.target.value)}
                        placeholder="—"
                        aria-label={`Amount paid by ${customer.name}`}
                        aria-invalid={error ? true : undefined}
                        disabled={pending}
                        className="w-32 text-right tabular-nums"
                      />
                    </td>
                    <td className="px-4 py-2">
                      <div className="flex min-h-8 flex-wrap items-center gap-2">
                        {owes > 0 && (
                          <Button
                            size="sm"
                            variant="ghost"
                            disabled={pending}
                            onClick={() =>
                              setAmount(customer.customerId, String(toPesos(owes)))
                            }
                          >
                            Pay all
                          </Button>
                        )}
                        {raw.trim() !== '' && (
                          <Button
                            size="sm"
                            variant="ghost"
                            disabled={pending}
                            onClick={() => setAmount(customer.customerId, '')}
                          >
                            Clear
                          </Button>
                        )}
                        {/* Not blocked, just said out loud — a customer can
                            genuinely hand over more, and the account carries
                            the credit. */}
                        {overpays && !error && (
                          <span className="text-xs text-warn">
                            {formatPeso(centavos - owes)} more than owed
                          </span>
                        )}
                        {error && <span className="text-xs text-owed">{error}</span>}
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}

      <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
        <label className="flex items-center gap-2 text-sm text-ink-muted">
          <input
            type="checkbox"
            checked={showSettled}
            onChange={(event) => setShowSettled(event.target.checked)}
          />
          Show customers who owe nothing
        </label>

        <div className="flex flex-wrap items-center gap-3">
          {summary && (
            <p className="text-sm">
              {summary.recorded > 0 && (
                // `text-accent`, not `money-in`: a save-confirmation count is
                // not a money figure.
                <span className="font-medium text-accent">
                  {summary.recorded} payment{summary.recorded === 1 ? '' : 's'} recorded.
                </span>
              )}
              {summary.failed > 0 && (
                <span className="ml-1 font-medium text-owed">
                  {summary.failed} not saved.
                </span>
              )}
            </p>
          )}
          <Button
            variant="success"
            size="wide"
            onClick={save}
            disabled={pending || entered.length === 0}
          >
            {pending
              ? 'Saving…'
              : entered.length === 0
                ? 'Save payments'
                : `Save ${entered.length} payment${entered.length === 1 ? '' : 's'} · ${formatPeso(totalCentavos)}`}
          </Button>
        </div>
      </div>
    </Card>
  )
}
