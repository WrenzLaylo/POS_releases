'use client'

import type { CustomerWithDiscount } from '@/lib/types'
import type { DiscountKind, OrderDiscountMode } from '@/lib/discount'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { EmptyState } from '@/components/ui/EmptyState'
import { Field } from '@/components/ui/Field'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'
import { Money } from '@/components/ui/Money'
import { SegmentedControl } from '@/components/ui/SegmentedControl'
import { TapeCell, TapeRow } from '@/components/ui/Tape'
import { CustomerCombobox } from './CustomerCombobox'

export type RailSelection = { kind: 'customer'; id: number; name: string } | { kind: 'walkin' }
export type CustomerPaymentMode = 'cash' | 'partial' | 'credit'

export type RailLine = {
  productId: number
  name: string
  quantity: number
  totalCentavos: number
}

const MODE_OPTIONS = [
  { value: 'customer', label: 'Customer' },
  { value: 'walkin', label: 'Walk-in' },
] as const

const PAYMENT_OPTIONS = [
  { value: 'cash', label: 'Cash' },
  { value: 'partial', label: 'Partial' },
  { value: 'credit', label: 'Full credit' },
] as const

const DISCOUNT_KIND_OPTIONS = [
  { value: 'AMOUNT', label: '₱' },
  { value: 'PERCENT', label: '%' },
] as const

const DISCOUNT_MODE_OPTIONS = [
  { value: 'STACK', label: 'On top of theirs' },
  { value: 'REPLACE', label: 'Instead of theirs' },
] as const

export function OrderRail({
  customers,
  selection,
  onSelectionChange,
  paymentMode,
  onPaymentModeChange,
  lines,
  onRemoveLine,
  totalCentavos,
  discountCentavos,
  subtotalCentavos,
  discountAmount,
  onDiscountAmountChange,
  discountKind,
  onDiscountKindChange,
  discountMode,
  onDiscountModeChange,
  discountIsValid,
  customerHasStandingDiscount,
  orderDiscountApplied,
  availableCreditCentavos,
  creditAppliedCentavos,
  useCredit,
  onUseCreditChange,
  dueCentavos,
  cash,
  onCashChange,
  cashIsValid,
  chargeCentavos,
  changeCentavos,
  shortCentavos,
  onSave,
  canSave,
  pending,
  error,
}: {
  customers: CustomerWithDiscount[]
  selection: RailSelection | null
  onSelectionChange: (selection: RailSelection | null) => void
  paymentMode: CustomerPaymentMode
  onPaymentModeChange: (mode: CustomerPaymentMode) => void
  lines: RailLine[]
  onRemoveLine: (productId: number) => void
  totalCentavos: number
  discountCentavos: number
  subtotalCentavos: number
  discountAmount: string
  onDiscountAmountChange: (value: string) => void
  discountKind: DiscountKind
  onDiscountKindChange: (kind: DiscountKind) => void
  discountMode: OrderDiscountMode
  onDiscountModeChange: (mode: OrderDiscountMode) => void
  discountIsValid: boolean
  /** Whether the selected customer carries a discount of their own. */
  customerHasStandingDiscount: boolean
  /** Whether the ad-hoc field currently holds a discount that bites. */
  orderDiscountApplied: boolean
  /** What the shop is holding for this customer, in centavos. */
  availableCreditCentavos: number
  /** How much of it this order will actually absorb. */
  creditAppliedCentavos: number
  useCredit: boolean
  onUseCreditChange: (value: boolean) => void
  /** The total less any credit applied — what is left to collect. */
  dueCentavos: number
  cash: string
  onCashChange: (value: string) => void
  cashIsValid: boolean
  chargeCentavos: number
  changeCentavos: number
  shortCentavos: number
  onSave: () => void
  canSave: boolean
  pending: boolean
  error: string | null
}) {
  const mode: 'customer' | 'walkin' = selection?.kind === 'walkin' ? 'walkin' : 'customer'
  const showCashField = mode === 'walkin' || paymentMode !== 'credit'

  return (
    <Card variant="raised" className="flex max-h-[calc(100vh-3rem)] flex-col">
      <div className="shrink-0">
        <SegmentedControl
          ariaLabel="Sale type"
          options={MODE_OPTIONS}
          value={mode}
          onValueChange={(value) => {
            onSelectionChange(value === 'walkin' ? { kind: 'walkin' } : null)
            onCashChange('')
          }}
        />

        <div className="mt-3">
          {mode === 'walkin' ? (
            <div className="flex h-10 items-center text-xl font-semibold text-ink">
              Walk-in (cash)
            </div>
          ) : (
            <CustomerCombobox
              customers={customers}
              selection={selection}
              onSelect={onSelectionChange}
            />
          )}
        </div>

        {selection?.kind === 'customer' && (
          <div className="mt-3">
            <div className="mb-1 text-xs font-semibold uppercase tracking-wide text-ink-muted">
              Payment
            </div>
            <SegmentedControl
              ariaLabel="Customer payment method"
              options={PAYMENT_OPTIONS}
              value={paymentMode}
              onValueChange={(value) => {
                onPaymentModeChange(value as CustomerPaymentMode)
                onCashChange('')
              }}
            />
          </div>
        )}
      </div>

      <div className="mt-4 min-h-0 flex-1 overflow-y-auto border-t border-line pt-2">
        {lines.length === 0 ? (
          <EmptyState>Nothing tallied yet.</EmptyState>
        ) : (
          <div>
            {lines.map((line) => (
              <TapeRow key={line.productId}>
                <TapeCell>
                  <div className="truncate text-sm font-medium text-ink">{line.name}</div>
                  <div className="text-sm text-ink-muted">× {line.quantity}</div>
                </TapeCell>
                <TapeCell align="end">
                  <div className="flex items-center gap-3">
                    <Money centavos={line.totalCentavos} scale="strong" />
                    <button
                      type="button"
                      aria-label={`Remove ${line.name}`}
                      onClick={() => onRemoveLine(line.productId)}
                      className="font-sans text-ink-subtle transition-colors duration-150 hover:text-owed"
                    >
                      ×
                    </button>
                  </div>
                </TapeCell>
              </TapeRow>
            ))}
          </div>
        )}
      </div>

      <div className="mt-4 shrink-0 border-t border-line pt-4">
        <div className="mb-3">
          <div className="mb-1 text-xs font-semibold uppercase tracking-wide text-ink-muted">
            Order discount
          </div>
          <div className="flex items-center gap-2">
            <Input
              inputMode="decimal"
              value={discountAmount}
              onChange={(event) => onDiscountAmountChange(event.target.value)}
              placeholder={discountKind === 'PERCENT' ? '0.00 %' : '0.00'}
              aria-label={
                discountKind === 'PERCENT'
                  ? 'Order discount percentage'
                  : 'Order discount amount in pesos'
              }
              className="min-w-0 flex-1 tabular-nums"
            />
            <SegmentedControl
              ariaLabel="Discount type"
              options={DISCOUNT_KIND_OPTIONS}
              value={discountKind}
              onValueChange={(value) => onDiscountKindChange(value as DiscountKind)}
            />
          </div>

          {/* Only offered when the choice means something. A customer with no
              standing discount has nothing for this to stack on or replace,
              and a toggle whose two settings are identical is a control the
              operator has to read before discovering it does nothing. */}
          {customerHasStandingDiscount && orderDiscountApplied && (
            <div className="mt-2">
              <SegmentedControl
                ariaLabel="How this discount combines with the customer's own"
                options={DISCOUNT_MODE_OPTIONS}
                value={discountMode}
                onValueChange={(value) => onDiscountModeChange(value as OrderDiscountMode)}
                className="w-full"
              />
            </div>
          )}

          {!discountIsValid && (
            <FormError className="mt-2">Enter a discount like 50 or 10.5</FormError>
          )}
        </div>

        {/* Neutral, never `money-in`: a discount is value given away, not cash
            that arrived. */}
        {discountCentavos > 0 && (
          <>
            <div className="mb-1 flex items-baseline justify-between">
              <span className="text-sm text-ink-muted">Subtotal</span>
              <Money centavos={subtotalCentavos} tone="neutral" className="text-ink-muted" />
            </div>
            <div className="mb-3 flex items-baseline justify-between">
              <span className="text-sm text-ink-muted">Discount</span>
              <span className="text-sm text-ink-muted">
                −<Money centavos={discountCentavos} tone="neutral" />
              </span>
            </div>
          </>
        )}

        {/* Offered only when there is something to offer. A credit is the
            customer's money sitting with the shop, so this is opt-in: she may
            well want it kept for next time, and spending it silently would be
            deciding that for her. */}
        {selection?.kind === 'customer' && availableCreditCentavos > 0 && (
          <label className="mb-3 flex cursor-pointer items-start gap-2 rounded-control border border-accent/40 bg-accent-soft px-3 py-2">
            <input
              type="checkbox"
              checked={useCredit}
              onChange={(event) => onUseCreditChange(event.target.checked)}
              className="mt-0.5 h-4 w-4 shrink-0"
            />
            <span className="min-w-0 text-sm">
              <span className="block font-medium text-accent">
                Use this customer&apos;s credit
              </span>
              <span className="block text-xs text-ink-muted">
                {/* Neutral, not `money-in`. This is money the shop OWES her,
                    not cash that has arrived. */}
                <Money centavos={availableCreditCentavos} scale="body" /> on file
                {useCredit && creditAppliedCentavos > 0 && (
                  <>
                    {' · using '}
                    <Money centavos={creditAppliedCentavos} scale="body" />
                  </>
                )}
              </span>
            </span>
          </label>
        )}

        {showCashField ? (
          <Field
            label={
              mode === 'walkin' || paymentMode === 'cash'
                ? 'Cash received (leave blank for exact cash)'
                : 'Cash received (required for partial payment)'
            }
            className="mb-3"
          >
            <Input
              inputMode="decimal"
              value={cash}
              onChange={(event) => onCashChange(event.target.value)}
              placeholder={paymentMode === 'partial' ? '0.00' : 'Exact cash'}
              className="w-full tabular-nums"
            />
          </Field>
        ) : (
          <p className="mb-3 rounded-control border border-line bg-surface-sunk px-3 py-2 text-sm text-ink-muted">
            The full total will be added to this customer&apos;s account.
          </p>
        )}

        {/* Cash received sits ABOVE the total now. She types what was handed
            over and reads the change immediately underneath it, in the order
            the transaction actually happens — the total used to sit between
            the two halves of one question. */}
        <div className="flex items-baseline justify-between border-t border-line pt-3">
          <span className="text-sm text-ink-muted">Total</span>
          <Money centavos={totalCentavos} scale="hero" />
        </div>

        {/* Only when credit changes the answer. With none applied this line
            would repeat the total directly above it. */}
        {creditAppliedCentavos > 0 && (
          <>
            <div className="mt-2 flex items-baseline justify-between">
              <span className="text-sm text-ink-muted">Paid from credit</span>
              <span className="text-sm text-ink-muted">
                −<Money centavos={creditAppliedCentavos} scale="body" />
              </span>
            </div>
            <div className="mt-1 flex items-baseline justify-between border-t border-line pt-2">
              <span className="text-sm font-medium text-ink">Left to pay</span>
              <Money centavos={dueCentavos} scale="strong" />
            </div>
          </>
        )}

        {selection?.kind === 'customer' && paymentMode === 'credit' && (
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-sm text-ink-muted">Credit</span>
            <Money centavos={totalCentavos} tone="owed" scale="strong" />
          </div>
        )}

        {selection?.kind === 'customer' && paymentMode === 'partial' && (
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-sm text-ink-muted">Credit</span>
            <Money centavos={chargeCentavos} tone="owed" scale="strong" />
          </div>
        )}

        {selection?.kind === 'customer' && paymentMode === 'cash' && (
          shortCentavos > 0 ? (
            <div className="mt-3 flex items-baseline justify-between">
              <span className="text-sm text-ink-muted">Short by</span>
              <Money centavos={shortCentavos} tone="owed" scale="strong" />
            </div>
          ) : (
            <div className="mt-3 flex items-baseline justify-between">
              <span className="text-sm text-ink-muted">Change due</span>
              <Money centavos={changeCentavos} tone="neutral" scale="strong" />
            </div>
          )
        )}

        {selection?.kind === 'walkin' && (
          shortCentavos > 0 ? (
            <div className="mt-3 flex items-baseline justify-between">
              <span className="text-sm text-ink-muted">Short by</span>
              <Money centavos={shortCentavos} tone="owed" scale="strong" />
            </div>
          ) : (
            <div className="mt-3 flex items-baseline justify-between">
              <span className="text-sm text-ink-muted">Change due</span>
              <Money centavos={changeCentavos} tone="neutral" scale="strong" />
            </div>
          )
        )}

        {/* A walk-in is cash-only, so short cash has nowhere to go. Rather
            than a disabled button with no reason attached, name the way out:
            put it on somebody's account. */}
        {selection?.kind === 'walkin' && shortCentavos > 0 && (
          <p className="mt-3 rounded-control border border-warn/40 bg-warn/10 px-3 py-2 text-sm text-warn">
            Pick a customer to put the rest on utang.
          </p>
        )}

        {!cashIsValid && <FormError className="mt-3">Enter an amount like 50 or 1,000</FormError>}
        {error && <FormError className="mt-3">{error}</FormError>}

        <Button
          variant="success"
          size="wide"
          className="mt-4 w-full"
          onClick={onSave}
          disabled={!canSave}
        >
          {pending ? 'Saving…' : selection?.kind === 'walkin' ? 'Save cash sale' : 'Save order'}
        </Button>
      </div>
    </Card>
  )
}
