import Link from 'next/link'
import { notFound } from 'next/navigation'
import { getCustomer } from '@/server/customers'
import { getPlan } from '@/server/utang'
import { dayKey } from '@/lib/dates'
import { bookEntry } from '@/lib/routes'
import { DocumentShell } from '@/components/DocumentShell'
import {
  DocumentFacts,
  DocumentFooter,
  DocumentHeading,
  DocumentTerms,
} from '@/components/DocumentHeading'
import { documentNumber, DOCUMENT_TITLES } from '@/lib/document-number'
import { getStoreProfile } from '@/server/store-profile'
import { formatPeso } from '@/lib/money'
import { InstallmentStatusCell } from '@/components/InstallmentStatus'
import { Badge } from '@/components/ui/Badge'
import { Money } from '@/components/ui/Money'

export const dynamic = 'force-dynamic'

function longDate(date: Date): string {
  return date.toLocaleDateString('en-PH', { month: 'long', day: 'numeric', year: 'numeric' })
}

/**
 * The document this whole feature exists for: the arithmetic that turns a
 * borrowing into a total, followed by the month-by-month schedule.
 *
 * A customer holding this should be able to see how ₱3,000 became ₱3,450
 * without anyone explaining it, so the derivation is spelled out as three
 * lines that add up rather than a single total to be taken on trust.
 */
export default async function PlanInvoicePage({
  params,
}: {
  params: Promise<{ id: string; planId: string }>
}) {
  const { id, planId } = await params
  const customerId = Number(id)
  const planNumber = Number(planId)
  if (!Number.isInteger(customerId) || !Number.isInteger(planNumber)) notFound()

  const [customer, plan] = await Promise.all([getCustomer(customerId), getPlan(planNumber)])
  if (!customer || !plan) notFound()
  // A plan reached through the wrong customer's URL is a 404, not somebody
  // else's account rendered under this name.
  if (plan.customerId !== customerId) notFound()

  const profile = await getStoreProfile()
  const todayKey = dayKey(new Date())

  // Stated with this plan's OWN figures rather than as generic boilerplate.
  // A terms block that says "interest is charged at the agreed rate" tells a
  // borrower nothing they could later hold anyone to; one that names the rate,
  // the method, the instalment and the dates is the actual agreement.
  const firstDue = plan.installments[0]
  const lastDue = plan.installments[plan.installments.length - 1]
  const TERMS: string[] = [
    `The borrower acknowledges receipt of ${formatPeso(plan.principalCentavos)} on ${longDate(plan.startedAt)}.`,
    plan.interestRateBps === 0
      ? 'No interest is charged on this account.'
      : `Interest of ${formatPeso(plan.interestCentavos)} is charged on the basis of ${plan.termsLabel}. Interest is calculated once, at the start of the term, and does not increase.`,
    `The total amount payable is ${formatPeso(plan.totalCentavos)}, payable in ${plan.termMonths} monthly instalment${plan.termMonths === 1 ? '' : 's'}${firstDue ? `, the first falling due on ${longDate(firstDue.dueAt)}` : ''}${lastDue && plan.termMonths > 1 ? ` and the last on ${longDate(lastDue.dueAt)}` : ''}.`,
    'Payments are applied to the oldest unpaid instalment first.',
    'Payment may be made in full at any time before the final due date without additional charge.',
    'An instalment not settled by its due date is recorded as overdue. No further interest, penalty or charge accrues beyond the total stated above.',
    `Every payment received is receipted individually. A statement of account for this borrower is available from ${profile.name} on request.`,
  ]

  return (
    <DocumentShell
      actions={
        <>
          <Link
            href={bookEntry(customerId)}
            className="inline-flex h-10 items-center justify-center rounded-control border border-line-strong bg-surface-raised px-4 text-sm font-medium text-ink hover:border-accent hover:bg-accent-soft"
          >
            Back to {customer.name}
          </Link>
          {plan.isVoided && <Badge tone="muted">VOIDED</Badge>}
        </>
      }
    >
      <DocumentHeading
        profile={profile}
        title={DOCUMENT_TITLES.CREDIT_AGREEMENT}
        reference={documentNumber('CREDIT_AGREEMENT', plan.id, plan.startedAt)}
        issuedAt={plan.startedAt}
      />

      <DocumentFacts
        items={[
          {
            label: 'Customer',
            value: (
              <>
                {customer.name}
                {customer.phone && (
                  <div className="font-normal text-ink-muted">{customer.phone}</div>
                )}
              </>
            ),
          },
          { label: 'Terms', value: plan.termsLabel, align: 'end' },
        ]}
      />

      {/* The derivation. Three lines that add up, in the order they happen. */}
      <section className="doc-keep-together py-5">
        <h2 className="mb-3 text-base font-semibold text-ink">How this total is worked out</h2>
        <dl className="grid gap-2 text-sm">
          <div className="flex justify-between">
            <dt className="text-ink-muted">Amount borrowed on {longDate(plan.startedAt)}</dt>
            <dd><Money centavos={plan.principalCentavos} /></dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-ink-muted">
              Interest — {plan.termsLabel}
            </dt>
            <dd><Money centavos={plan.interestCentavos} /></dd>
          </div>
          <div className="flex items-baseline justify-between border-t border-line pt-2">
            {/* Neutral, never green: this is money owed, not cash received. */}
            <dt className="font-semibold text-ink">Total to repay</dt>
            <dd><Money centavos={plan.totalCentavos} scale="strong" /></dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-ink-muted">Paid so far</dt>
            {/* `in`: cash the store actually received. */}
            <dd><Money centavos={plan.paidCentavos} tone="in" /></dd>
          </div>
          <div className="flex items-baseline justify-between border-t border-line pt-2">
            <dt className="font-semibold text-ink">Still outstanding</dt>
            <dd>
              <Money
                centavos={plan.outstandingCentavos}
                tone={plan.outstandingCentavos > 0 && !plan.isVoided ? 'owed' : 'zero'}
                scale="strong"
              />
            </dd>
          </div>
        </dl>
      </section>

      <section>
        <h2 className="mb-3 text-base font-semibold text-ink">
          Payment schedule — {plan.termMonths} month{plan.termMonths === 1 ? '' : 's'}
        </h2>
        <table className="doc-table w-full text-sm">
          <thead className="border-b border-line text-left text-xs uppercase tracking-wide text-ink-muted">
            <tr>
              <th className="py-3 pr-3">#</th>
              <th className="px-3 py-3">Due date</th>
              <th className="px-3 py-3 text-right">Principal</th>
              <th className="px-3 py-3 text-right">Interest</th>
              <th className="px-3 py-3 text-right">Amount</th>
              <th className="py-3 pl-3 text-right">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {plan.installments.map((installment) => {
              const late =
                !plan.isVoided &&
                !installment.isSettled &&
                dayKey(installment.dueAt) < todayKey
              return (
                <tr key={installment.sequence}>
                  <td className="py-3 pr-3 font-mono tabular-nums text-ink-muted">
                    {installment.sequence}
                  </td>
                  <td data-label="Due" className="px-3 py-3">{longDate(installment.dueAt)}</td>
                  <td data-label="Principal" className="px-3 py-3 text-right">
                    <Money centavos={installment.principalCentavos} />
                  </td>
                  <td data-label="Interest" className="px-3 py-3 text-right">
                    <Money centavos={installment.interestCentavos} />
                  </td>
                  <td data-label="Amount" className="px-3 py-3 text-right">
                    <Money centavos={installment.amountCentavos} className="font-semibold" />
                  </td>
                  <td data-label="Status" className="py-3 pl-3 text-right">
                    <InstallmentStatusCell installment={installment} late={late} />
                  </td>
                </tr>
              )
            })}
          </tbody>
          <tfoot>
            <tr className="border-t border-line-strong">
              <td colSpan={4} className="doc-roll-hide py-3 pr-3 font-semibold text-ink">
                Total
              </td>
              <td data-label="Total" className="px-3 py-3 text-right">
                <Money centavos={plan.totalCentavos} scale="strong" />
              </td>
              <td className="hidden sm:table-cell" />
            </tr>
          </tfoot>
        </table>
      </section>

      {plan.note && (
        <p className="mt-6 text-sm text-ink-muted">Note: {plan.note}</p>
      )}

      {plan.isVoided && (
        <section className="mt-6 rounded-control border border-owed/40 bg-owed/10 p-4 text-sm text-owed">
          <div className="font-semibold">This record was voided.</div>
          <div className="mt-1">
            The charge no longer stands. Any payments already made remain on the account.
          </div>
        </section>
      )}

      <DocumentTerms
        title="Terms of this credit agreement"
        items={TERMS}
      />


      <DocumentFooter>
        By signing above, both parties acknowledge the amounts and dates set out in this
        document.
      </DocumentFooter>
    </DocumentShell>
  )
}
