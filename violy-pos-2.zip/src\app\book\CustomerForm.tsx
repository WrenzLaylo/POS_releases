'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createCustomer, updateCustomer } from '@/server/customers'
import { parsePesoInput, formatPeso } from '@/lib/money'
import {
  isDiscountBasis,
  isDiscountKind,
  MAX_BPS,
  type DiscountBasis,
  type DiscountKind,
} from '@/lib/discount'
import type { CategoryCheapest, CustomerWithDiscount } from '@/lib/types'
import { Button } from '@/components/ui/Button'
import { Dialog } from '@/components/ui/Dialog'
import { Field } from '@/components/ui/Field'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'
import { SegmentedControl } from '@/components/ui/SegmentedControl'
import { Textarea } from '@/components/ui/Textarea'

const DISCOUNT_KIND_OPTIONS = [
  { value: 'AMOUNT', label: '₱' },
  { value: 'PERCENT', label: '%' },
] as const

const DISCOUNT_BASIS_OPTIONS = [
  { value: 'PER_UNIT', label: 'Per unit' },
  { value: 'ORDER_TOTAL', label: 'Whole order' },
] as const

/** Kept identical to `Field`'s own label, which these sit alongside. */
const FIELD_LABEL = 'text-xs font-medium uppercase tracking-[0.08em] text-ink-muted'

type Props = {
  categories: CategoryCheapest[]
  /** Unit kinds the catalog sells in — "bag", "kilo" — for scoping a per-unit
   *  discount. Empty when nothing is in the catalog yet, which hides the
   *  chooser rather than offering an empty one. */
  units: string[]
  customer: CustomerWithDiscount | null
  onClose: () => void
}

/**
 * The caller (`CustomerList`) only mounts this component while it should be
 * open, so `Dialog`'s own `open` is always `true` here — closing means the
 * parent stops rendering this component, not `open` flipping to `false` on
 * a persistent instance. That is deliberate: a fresh mount means every field
 * below re-initialises from the current `customer` prop instead of carrying
 * over whatever was typed the previous time the form was open.
 *
 * All Escape-to-close, focus-trapping, body-scroll-locking, and
 * focus-restoration behaviour comes from `Dialog`/`Overlay` — this component
 * adds none of its own, and must not.
 */
export function CustomerForm({ categories, units, customer, onClose }: Props) {
  const router = useRouter()
  const [name, setName] = useState(customer?.name ?? '')
  const [phone, setPhone] = useState(customer?.phone ?? '')
  const [notes, setNotes] = useState(customer?.notes ?? '')
  const [discountKind, setDiscountKind] = useState<DiscountKind>(
    customer && isDiscountKind(customer.discountKind) ? customer.discountKind : 'AMOUNT',
  )
  const [discountBasis, setDiscountBasis] = useState<DiscountBasis>(
    customer && isDiscountBasis(customer.discountBasis) ? customer.discountBasis : 'PER_UNIT',
  )
  // One field for both kinds — the toggle decides whether what she types is
  // pesos or percent. Seeded from whichever column the saved kind uses; both
  // are stored to two decimal places, so the /100 is the same either way.
  const [discountRaw, setDiscountRaw] = useState(() => {
    if (!customer) return ''
    if (isDiscountKind(customer.discountKind) && customer.discountKind === 'PERCENT') {
      return customer.discountBps > 0 ? String(customer.discountBps / 100) : ''
    }
    return customer.discountCentavos > 0 ? String(customer.discountCentavos / 100) : ''
  })
  const [categoryIds, setCategoryIds] = useState<number[]>(
    customer?.discountCategories.map((c) => c.id) ?? [],
  )
  // '' means every unit — the behaviour every customer had before discounts
  // could name one.
  const [discountUnit, setDiscountUnit] = useState<string>(customer?.discountUnit ?? '')
  const [error, setError] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)

  function toggleCategory(id: number) {
    setCategoryIds((prev) =>
      prev.includes(id) ? prev.filter((existing) => existing !== id) : [...prev, id],
    )
  }

  // Blank means no discount. A non-empty value that fails to parse is a
  // validation error, never a silent zero — see parsePesoInput's contract.
  const discountTrimmed = discountRaw.trim()
  const parsedDiscount = discountTrimmed === '' ? 0 : parsePesoInput(discountTrimmed)
  const discountInvalid = discountTrimmed !== '' && parsedDiscount === null

  // The "this would make those lines free" warning is only meaningful for a
  // peso amount taken per unit. A percentage cannot exceed the price it is a
  // percentage OF unless it is 100%, and an order-total discount has no
  // per-line cheapest to compare against — so rather than compute something
  // misleading for those, the warning stands down.
  const warnable = discountKind === 'AMOUNT' && discountBasis === 'PER_UNIT'

  const warnings =
    discountInvalid || !warnable
      ? []
      : categories
          .filter(
            (category) =>
              categoryIds.includes(category.id) &&
              category.cheapestCentavos !== null &&
              parsedDiscount !== null &&
              category.cheapestCentavos <= parsedDiscount,
          )
          .map((category) => ({
            id: category.id,
            message: `${formatPeso(parsedDiscount as number)} is more than ${category.cheapestName} costs (${formatPeso(category.cheapestCentavos as number)}). Those lines will be free.`,
          }))

  async function handleSubmit() {
    setError(null)

    if (discountInvalid) {
      setError(
        discountKind === 'PERCENT'
          ? 'Enter a percentage like 5 or 12.5'
          : 'Enter an amount like 50 or 1,000',
      )
      return
    }
    if (discountKind === 'PERCENT' && (parsedDiscount ?? 0) > MAX_BPS) {
      setError('A discount cannot be more than 100%.')
      return
    }

    setSaving(true)
    const input = {
      name,
      phone,
      notes,
      // The unused column is written as zero rather than left alone. Switching
      // a customer from "₱50 off" to "5%" must not leave the old ₱50 sitting
      // in discountCentavos, where flipping the kind back would silently
      // resurrect it.
      discountCentavos: discountKind === 'AMOUNT' ? (parsedDiscount ?? 0) : 0,
      discountBps: discountKind === 'PERCENT' ? (parsedDiscount ?? 0) : 0,
      discountKind,
      discountBasis,
      // Same reasoning as the ticks below: a whole-order discount has no
      // per-line scope, so a unit saved against one would sit inert and then
      // surprise somebody who later switched the basis back.
      discountUnit: discountBasis === 'PER_UNIT' ? discountUnit : '',
      // A whole-order discount has no category scope, so the ticks are
      // discarded rather than saved to sit inert against a basis that never
      // reads them.
      discountCategoryIds: discountBasis === 'PER_UNIT' ? categoryIds : [],
    }

    const result = customer
      ? await updateCustomer(customer.id, input)
      : await createCustomer(input)

    setSaving(false)
    if (!result.ok) {
      setError(result.error)
      return
    }
    router.refresh()
    onClose()
  }

  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title={customer ? 'Edit customer' : 'New customer'}
      footer={
        <div className="flex justify-end gap-2">
          <Button type="button" variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" form="customer-form" variant="primary" disabled={saving}>
            {saving ? 'Saving…' : 'Save'}
          </Button>
        </div>
      }
    >
      <form
        id="customer-form"
        onSubmit={(e) => {
          e.preventDefault()
          handleSubmit()
        }}
        className="grid gap-4"
      >
        <Field label="Name">
          <Input
            name="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            className="w-full"
            placeholder="Juan Dela Cruz"
          />
        </Field>

        <Field label="Phone">
          <Input
            name="phone"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="w-full"
            placeholder="09XX XXX XXXX"
          />
        </Field>

        <Field label="Notes">
          <Textarea
            name="notes"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={2}
            className="w-full"
          />
        </Field>

        {/* Not a `Field`: that renders a <label> wrapping its children, and a
            radiogroup nested inside a label is the wrong element for the job.
            The label styling is copied from `Field` so the form still reads as
            one set of controls. */}
        <div className="grid gap-2">
          <span className={FIELD_LABEL}>Discount</span>
          <div className="flex items-center gap-2">
            <Input
              name="discount"
              inputMode="decimal"
              value={discountRaw}
              onChange={(e) => setDiscountRaw(e.target.value)}
              className="min-w-0 flex-1 tabular-nums"
              placeholder="0.00"
              aria-label={discountKind === 'PERCENT' ? 'Discount percentage' : 'Discount in pesos'}
            />
            <SegmentedControl
              ariaLabel="Discount type"
              options={DISCOUNT_KIND_OPTIONS}
              value={discountKind}
              onValueChange={(value) => setDiscountKind(value as DiscountKind)}
            />
          </div>
          <SegmentedControl
            ariaLabel="What the discount applies to"
            options={DISCOUNT_BASIS_OPTIONS}
            value={discountBasis}
            onValueChange={(value) => setDiscountBasis(value as DiscountBasis)}
            className="w-full"
          />
          {/* Which unit the discount is per. A category can hold both sizes —
              Pigrolac sells sacks and a 1kg Booster — so "₱20 off Pigrolac per
              unit" would otherwise take ₱20 off a ₱110 kilo pack as readily as
              off a ₱2,050 sack. Naming the unit is what stops that. */}
          {discountBasis === 'PER_UNIT' && units.length > 0 && (
            <SegmentedControl
              ariaLabel="Which unit the discount is per"
              options={[
                { value: '', label: 'Any unit' },
                ...units.map((unit) => ({ value: unit, label: `Per ${unit}` })),
              ]}
              value={discountUnit}
              onValueChange={setDiscountUnit}
              className="w-full"
            />
          )}
          <p className="text-xs text-ink-subtle">
            {discountBasis === 'PER_UNIT'
              ? `${
                  discountKind === 'PERCENT'
                    ? 'Taken off each unit’s price'
                    : 'Taken off each unit'
                }${discountUnit === '' ? '' : ` sold by the ${discountUnit}`}, in the ticked categories only.`
              : 'Taken off the order total, whatever is on it.'}
          </p>
        </div>

        {/* Ticks only exist for a per-unit discount; an order-total one has no
            per-line scope to narrow. Hidden rather than disabled, so the form
            never shows a control that cannot affect the saved record. */}
        {discountBasis === 'PER_UNIT' && categories.length > 0 && (
          <div className="grid gap-2">
            <span className={FIELD_LABEL}>Discounted categories</span>
            <div className="grid gap-2">
              {categories.map((category) => (
                <label key={category.id} className="flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={categoryIds.includes(category.id)}
                    onChange={() => toggleCategory(category.id)}
                  />
                  {category.name}
                </label>
              ))}
            </div>
          </div>
        )}

        {warnings.map((warning) => (
          <p key={warning.id} className="animate-fade-in text-sm text-warn">
            {warning.message}
          </p>
        ))}

        {error && <FormError>{error}</FormError>}
      </form>
    </Dialog>
  )
}
