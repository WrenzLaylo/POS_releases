'use client'

import { useCallback, useEffect, useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import type {
  CustomerWithDiscount,
  OrderResult,
  ProductWithCategory,
  SaleResult,
} from '@/lib/types'
import { parsePesoInput } from '@/lib/money'
import {
  computeOrderTotals,
  customerDiscountOf,
  hasOrderDiscount,
  MAX_BPS,
  type DiscountKind,
  type OrderDiscount,
  type OrderDiscountMode,
} from '@/lib/discount'
import { createOrder } from '@/server/orders'
import { createSale } from '@/server/sales'
import { CatalogColumn } from './CatalogColumn'
import {
  OrderRail,
  type CustomerPaymentMode,
  type RailLine,
  type RailSelection,
} from './OrderRail'
import { OrderReceipt } from './OrderReceipt'
import { useSavedOrder } from './use-saved-order'

type Receipt =
  | { kind: 'walkin'; data: SaleResult }
  | { kind: 'customer'; customerName: string; data: OrderResult }

function newCheckoutKey(): string {
  return globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`
}

export function OrderScreen({
  products,
  customers,
  creditByCustomer,
}: {
  products: ProductWithCategory[]
  customers: CustomerWithDiscount[]
  /** Customer id to credit held, in centavos. Absent means none. */
  creditByCustomer: Record<number, number>
}) {
  const router = useRouter()
  const [selection, setSelection] = useState<RailSelection | null>(null)
  const [paymentMode, setPaymentMode] = useState<CustomerPaymentMode>('cash')
  // Opt-in, always. A credit is the customer's money; nothing spends it
  // without being asked to, and she may well want it kept for next time.
  const [useCredit, setUseCredit] = useState(false)
  const [quantities, setQuantities] = useState<Map<number, number>>(new Map())
  const [cash, setCash] = useState('')
  const [discountAmount, setDiscountAmount] = useState('')
  const [discountKind, setDiscountKind] = useState<DiscountKind>('AMOUNT')
  const [discountMode, setDiscountMode] = useState<OrderDiscountMode>('STACK')
  const [search, setSearch] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [receipt, setReceipt] = useState<Receipt | null>(null)
  const [checkoutKey, setCheckoutKey] = useState(newCheckoutKey)
  const [pending, startTransition] = useTransition()
  const [resetKey, setResetKey] = useState(0)
  const { restored, ready, save: saveOrder, clear: clearSavedOrder } = useSavedOrder()

  // Restores once, after the first client pass. Guarded on `restored` being
  // non-null so it does not fight later edits, and it runs before any save
  // effect below can write the empty initial state back over it.
  useEffect(() => {
    if (!restored) return
    setQuantities(new Map(restored.lines))
    setSelection(
      restored.walkin
        ? { kind: 'walkin' }
        : restored.customerId !== null && restored.customerName !== null
          ? { kind: 'customer', id: restored.customerId, name: restored.customerName }
          : null,
    )
    setPaymentMode(restored.paymentMode as CustomerPaymentMode)
    setCash(restored.cash)
    setDiscountAmount(restored.discountAmount)
    setDiscountKind(restored.discountKind as DiscountKind)
    setDiscountMode(restored.discountMode as OrderDiscountMode)
  }, [restored])

  // Writes on every change, but only once the restore pass has run — without
  // `ready` the first render would persist an empty order over a saved one and
  // erase exactly what this exists to keep.
  useEffect(() => {
    if (!ready) return
    saveOrder({
      lines: [...quantities.entries()],
      customerId: selection?.kind === 'customer' ? selection.id : null,
      customerName: selection?.kind === 'customer' ? selection.name : null,
      walkin: selection?.kind === 'walkin',
      paymentMode,
      cash,
      discountAmount,
      discountKind,
      discountMode,
    })
    // `saveOrder` is stable enough for this: it closes over nothing that
    // changes between renders.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, quantities, selection, paymentMode, cash, discountAmount, discountKind, discountMode])

  const dismissReceipt = useCallback(() => setReceipt(null), [])

  const lines = [...quantities.entries()]
    .filter(([, quantity]) => quantity > 0)
    .map(([productId, quantity]) => ({ productId, quantity }))

  const selectedCustomer =
    selection?.kind === 'customer'
      ? (customers.find((customer) => customer.id === selection.id) ?? null)
      : null

  // A blank field is no discount, not a zero-value one. Anything unparseable
  // is a validation failure that blocks Save, exactly like the cash field —
  // never silently coerced to zero.
  const discountBlank = discountAmount.trim() === ''
  const parsedDiscount = discountBlank ? 0 : parsePesoInput(discountAmount)
  const discountIsValid = parsedDiscount !== null

  // `parsePesoInput` scales by 100, which is what both readings of this field
  // need: "50" is 5000 centavos and "10.5" is 1050 basis points — pesos and
  // percentages are both quoted to two decimal places, so one parse serves
  // both and the toggle only decides which field it lands in.
  const discountValue = parsedDiscount ?? 0
  const orderDiscount: OrderDiscount = {
    kind: discountKind,
    amountCentavos: discountKind === 'AMOUNT' ? discountValue : 0,
    bps: discountKind === 'PERCENT' ? Math.min(discountValue, MAX_BPS) : 0,
    mode: discountMode,
  }

  // The same `computeOrderTotals` the Server Action calls. This preview is
  // what she reads out to the customer, so it cannot be a second
  // implementation that agrees with the server most of the time.
  const totals = computeOrderTotals({
    lines: lines.flatMap(({ productId, quantity }) => {
      const product = products.find((candidate) => candidate.id === productId)
      return product
        ? [
            {
              productId,
              quantity,
              priceCentavos: product.price,
              categoryId: product.categoryId,
              unit: product.unit,
            },
          ]
        : []
    }),
    customer: selectedCustomer ? customerDiscountOf(selectedCustomer) : null,
    order: orderDiscount,
  })

  const totalsByProduct = new Map(totals.lines.map((line) => [line.productId, line]))

  const railLines: RailLine[] = lines.map(({ productId, quantity }) => {
    const product = products.find((candidate) => candidate.id === productId)
    return {
      productId,
      name: product?.name ?? 'Unknown product',
      quantity,
      totalCentavos: totalsByProduct.get(productId)?.lineTotalCentavos ?? 0,
    }
  })

  const totalCentavos = totals.totalCentavos
  const discountCentavos = totals.totalDiscountCentavos

  const cashBlank = cash.trim() === ''
  const parsedCash = cashBlank ? 0 : parsePesoInput(cash)
  const cashIsValid = parsedCash !== null
  const cashCentavos = parsedCash ?? 0

  // What the shop is holding for this customer, and how much of it this
  // order can actually absorb — never more than the order is worth, or the
  // change would be cash the shop never received.
  const availableCreditCentavos =
    selection?.kind === 'customer' ? (creditByCustomer[selection.id] ?? 0) : 0
  const creditAppliedCentavos =
    useCredit && selection?.kind === 'customer'
      ? Math.min(availableCreditCentavos, totalCentavos)
      : 0

  // Everything below prices against what is left AFTER credit. Comparing
  // against the full total would ask her for cash the credit already covered,
  // and would compute the change against the wrong figure.
  const dueCentavos = Math.max(0, totalCentavos - creditAppliedCentavos)

  const exactCashMode =
    selection?.kind === 'walkin' ||
    (selection?.kind === 'customer' && paymentMode === 'cash')
  const displayedTenderCentavos = cashBlank && exactCashMode ? dueCentavos : cashCentavos
  const chargeCentavos =
    selection?.kind === 'customer' && paymentMode === 'credit'
      ? dueCentavos
      : Math.max(0, dueCentavos - displayedTenderCentavos)
  const changeCentavos = Math.max(0, displayedTenderCentavos - dueCentavos)
  const shortCentavos =
    exactCashMode && !cashBlank && cashIsValid
      ? Math.max(0, dueCentavos - cashCentavos)
      : 0

  function setQuantity(productId: number, quantity: number) {
    setQuantities((previous) => {
      const next = new Map(previous)
      if (quantity <= 0) next.delete(productId)
      else next.set(productId, quantity)
      return next
    })
  }

  function resetAfterSave() {
    // The saved draft goes with the order it belonged to. Leaving it would
    // repopulate the counter with a sale that has already been rung up.
    clearSavedOrder()
    setSelection(null)
    setPaymentMode('cash')
    setQuantities(new Map())
    setCash('')
    // The discount belongs to the order that just closed, not the next one.
    setDiscountAmount('')
    setDiscountKind('AMOUNT')
    setDiscountMode('STACK')
    setSearch('')
    setCheckoutKey(newCheckoutKey())
    setResetKey((value) => value + 1)
  }

  function save() {
    if (!selection) return
    setError(null)
    const key = checkoutKey

    startTransition(async () => {
      if (selection.kind === 'walkin') {
        const result = await createSale({
          items: lines,
          cashTenderedCentavos: cashBlank ? null : cashCentavos,
          orderDiscount,
          clientOrderKey: key,
        })
        if (!result.ok) {
          setError(result.error)
          return
        }
        setReceipt({ kind: 'walkin', data: result.data })
      } else {
        const tender =
          paymentMode === 'credit' ? 0 : cashBlank && paymentMode === 'cash' ? null : cashCentavos
        const result = await createOrder({
          customerId: selection.id,
          lines,
          cashPaidCentavos: tender,
          // The server re-reads her live balance and caps this itself; what is
          // sent is a request, not an authority.
          creditAppliedCentavos: creditAppliedCentavos || undefined,
          orderDiscount,
          clientOrderKey: key,
        })
        if (!result.ok) {
          setError(result.error)
          return
        }
        setReceipt({ kind: 'customer', customerName: selection.name, data: result.data })
      }

      resetAfterSave()
      router.refresh()
    })
  }

  const paymentIsValid = (() => {
    if (!selection) return false
    if (!cashIsValid) return false
    if (selection.kind === 'walkin') return cashBlank || cashCentavos >= totalCentavos
    if (paymentMode === 'credit') return true
    // Against `dueCentavos`, so a credit that covers the whole order leaves
    // nothing to collect and an empty cash box is still a complete payment.
    if (paymentMode === 'cash') return cashBlank || cashCentavos >= dueCentavos
    return !cashBlank && cashCentavos > 0 && cashCentavos < dueCentavos
  })()

  const canSave =
    selection !== null && lines.length > 0 && paymentIsValid && discountIsValid && !pending

  return (
    // Side by side from `lg` (1024px), not `xl` (1280px). The rail carries the
    // running total, and below the old threshold it dropped BENEATH the catalog
    // — so on any laptop narrower than 1280 she was adding items with the total
    // scrolled off screen, which is the one thing a point of sale cannot do. It
    // narrows to 20rem before it gives up the row, rather than stacking.
    <div className="flex flex-col gap-6 lg:h-full lg:min-h-0 lg:flex-row">
      <div className="min-w-0 flex-1 lg:flex lg:min-h-0 lg:flex-col">
        <CatalogColumn
          products={products}
          quantities={quantities}
          onChange={setQuantity}
          search={search}
          onSearchChange={setSearch}
          resetKey={resetKey}
        />
      </div>

      {/* The rail scrolls on its own too. A twenty-line order used to run off
          the bottom with no way to reach the rest of it, now that the page
          itself no longer scrolls. */}
      <div className="w-full shrink-0 lg:w-80 lg:overflow-y-auto xl:w-96">
        <div>
          {receipt ? (
            receipt.kind === 'walkin' ? (
              <OrderReceipt
                kind="walkin"
                saleId={receipt.data.saleId}
                createdAt={receipt.data.createdAt}
                lines={receipt.data.lines}
                totalCentavos={receipt.data.totalCentavos}
                cashPaidCentavos={receipt.data.cashPaidCentavos}
                cashTenderedCentavos={receipt.data.cashTenderedCentavos}
                changeCentavos={receipt.data.changeCentavos}
                onDismiss={dismissReceipt}
              />
            ) : (
              <OrderReceipt
                kind="customer"
                saleId={receipt.data.saleId}
                createdAt={receipt.data.createdAt}
                customerName={receipt.customerName}
                lines={receipt.data.lines}
                totalCentavos={receipt.data.totalCentavos}
                cashPaidCentavos={receipt.data.cashPaidCentavos}
                cashTenderedCentavos={receipt.data.cashTenderedCentavos}
                chargedCentavos={receipt.data.chargedCentavos}
                changeCentavos={receipt.data.changeCentavos}
                newBalanceCentavos={receipt.data.newBalanceCentavos}
                onDismiss={dismissReceipt}
              />
            )
          ) : (
            <OrderRail
              customers={customers}
              selection={selection}
              onSelectionChange={(next) => {
                setSelection(next)
                setPaymentMode('cash')
                setCash('')
                // Belongs to the customer who was selected, not to the order.
                setUseCredit(false)
              }}
              paymentMode={paymentMode}
              onPaymentModeChange={setPaymentMode}
              lines={railLines}
              onRemoveLine={(productId) => setQuantity(productId, 0)}
              totalCentavos={totalCentavos}
              discountCentavos={discountCentavos}
              subtotalCentavos={totals.subtotalCentavos}
              discountAmount={discountAmount}
              onDiscountAmountChange={setDiscountAmount}
              discountKind={discountKind}
              onDiscountKindChange={setDiscountKind}
              discountMode={discountMode}
              onDiscountModeChange={setDiscountMode}
              discountIsValid={discountIsValid}
              customerHasStandingDiscount={
                selectedCustomer !== null &&
                (selectedCustomer.discountKind === 'PERCENT'
                  ? selectedCustomer.discountBps > 0
                  : selectedCustomer.discountCentavos > 0)
              }
              orderDiscountApplied={hasOrderDiscount(orderDiscount)}
              availableCreditCentavos={availableCreditCentavos}
              creditAppliedCentavos={creditAppliedCentavos}
              useCredit={useCredit}
              onUseCreditChange={setUseCredit}
              dueCentavos={dueCentavos}
              cash={cash}
              onCashChange={setCash}
              cashIsValid={cashIsValid}
              chargeCentavos={chargeCentavos}
              changeCentavos={changeCentavos}
              shortCentavos={shortCentavos}
              onSave={save}
              canSave={canSave}
              pending={pending}
              error={error}
            />
          )}
        </div>
      </div>
    </div>
  )
}
