import { describe, it, expect } from 'vitest'
import { startOfDay, startOfWeek, startOfMonth, addDays, dayKey, parseDayKey } from '@/lib/dates'

describe('startOfDay', () => {
  it('zeroes the time portion', () => {
    const result = startOfDay(new Date(2026, 6, 25, 14, 30, 45, 123))
    expect(result.getFullYear()).toBe(2026)
    expect(result.getMonth()).toBe(6)
    expect(result.getDate()).toBe(25)
    expect(result.getHours()).toBe(0)
    expect(result.getMinutes()).toBe(0)
    expect(result.getSeconds()).toBe(0)
    expect(result.getMilliseconds()).toBe(0)
  })
})

describe('startOfWeek', () => {
  it('returns Monday for a mid-week date', () => {
    // 2026-07-25 is a Saturday
    const result = startOfWeek(new Date(2026, 6, 25, 12, 0, 0))
    expect(result.getDate()).toBe(20) // Monday
    expect(result.getHours()).toBe(0)
  })

  it('returns the same day when given a Monday', () => {
    const result = startOfWeek(new Date(2026, 6, 20, 12, 0, 0))
    expect(result.getDate()).toBe(20)
  })

  it('returns the previous Monday when given a Sunday', () => {
    // 2026-07-26 is a Sunday
    const result = startOfWeek(new Date(2026, 6, 26, 12, 0, 0))
    expect(result.getDate()).toBe(20)
  })
})

describe('startOfMonth', () => {
  it('returns the first of the month at midnight', () => {
    const result = startOfMonth(new Date(2026, 6, 25, 12, 0, 0))
    expect(result.getDate()).toBe(1)
    expect(result.getMonth()).toBe(6)
    expect(result.getHours()).toBe(0)
  })
})

describe('addDays', () => {
  it('moves forward across a month boundary', () => {
    const result = addDays(new Date(2026, 6, 30), 3)
    expect(result.getMonth()).toBe(7)
    expect(result.getDate()).toBe(2)
  })

  it('moves backward with a negative count', () => {
    const result = addDays(new Date(2026, 6, 2), -3)
    expect(result.getMonth()).toBe(5)
    expect(result.getDate()).toBe(29)
  })
})

describe('dayKey', () => {
  it('formats a local date as YYYY-MM-DD', () => {
    expect(dayKey(new Date(2026, 6, 5, 23, 59))).toBe('2026-07-05')
  })
})

describe('parseDayKey', () => {
  it('parses a YYYY-MM-DD value as local midnight', () => {
    const result = parseDayKey('2026-08-03')

    expect(result).not.toBeNull()
    expect(result?.getFullYear()).toBe(2026)
    expect(result?.getMonth()).toBe(7)
    expect(result?.getDate()).toBe(3)
    expect(result?.getHours()).toBe(0)
  })

  it('rejects invalid formats and calendar rollovers', () => {
    for (const raw of ['', '2026-8-03', '03-08-2026', '2026-02-29', '2026-13-01', '2026-04-31']) {
      expect(parseDayKey(raw)).toBeNull()
    }
  })
})
