#!/usr/bin/env node
/**
 * Installs an update, then starts the app again.
 *
 * Runs in its OWN console window, detached from the server it is about to
 * stop. It cannot run inside the server process: on Windows the running app
 * holds locks on the files an update has to replace — `prisma generate` has
 * already failed in this project with EPERM because a dev server held the
 * Prisma query engine open, and `next build` cannot rewrite `.next` while it
 * is being served from.
 *
 * Order matters, and it is chosen so that the worst case is recoverable:
 *
 *   1. back up the database          — before anything else touches the disk
 *   2. ask what the newest build is  — and stop early if there is nothing new
 *   3. STOP the running app          — nothing else can replace locked files
 *   4. download, VERIFY, then unpack — nothing is overwritten until the zip
 *                                      has been checked against its hash
 *   5. install, migrate, build
 *   6. start the app again
 *
 * There is no git here. It used to fetch and fast-forward, which required git
 * installed on the shop laptop and a GitHub sign-in for a private repository —
 * two things to set up, and a credential that expires quietly a year later.
 *
 * If any step fails the window stays open with the reason, the backup already
 * exists, and the previous version is still on disk — a failed update leaves a
 * working shop, which matters more than a fast one.
 */

import { execSync, spawn } from 'node:child_process'
import { createWriteStream, existsSync, readFileSync, rmSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { cp, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { Readable } from 'node:stream'
import { pipeline } from 'node:stream/promises'
import path from 'node:path'
import readline from 'node:readline'

const ROOT = process.cwd()
const CHANNEL = JSON.parse(readFileSync(new URL('../release-channel.json', import.meta.url), 'utf8'))
const MANIFEST_URL = `${CHANNEL.baseUrl}/${CHANNEL.manifestFile}`
const PORT = process.env.PORT ?? '3000'
const NEWLINE = String.fromCharCode(10)

const say = (message) => console.log(message)
const step = (n, message) => console.log(`\n[${n}/7] ${message}`)

function sh(command, options = {}) {
  return execSync(command, { cwd: ROOT, stdio: 'inherit', ...options })
}

function shQuiet(command) {
  return execSync(command, { cwd: ROOT, encoding: 'utf8', windowsHide: true }).trim()
}

/**
 * Stops whatever is serving the app, by port rather than by remembered PID.
 *
 * A PID file goes stale the moment the app is started another way — a
 * double-clicked shortcut, a terminal, a reboot — and a stale PID either kills
 * nothing or, worse, kills whatever inherited that number. The port is the
 * thing that is actually true: if something is answering on it, that is the
 * app, and it has to stop before its files can be replaced.
 *
 * Failure here is not fatal. If nothing is listening, there was nothing to
 * close.
 */
function stopServer() {
  try {
    if (process.platform === 'win32') {
      const lines = execSync(`netstat -ano -p tcp | findstr LISTENING | findstr :${PORT}`, {
        encoding: 'utf8',
        windowsHide: true,
      })
      const pids = new Set(
        lines
          .split(NEWLINE)
          .map((line) => line.trim().split(/\s+/).pop())
          .filter((pid) => pid && /^\d+$/.test(pid) && pid !== '0'),
      )
      for (const pid of pids) {
        try {
          execSync(`taskkill /PID ${pid} /F /T`, { stdio: 'ignore', windowsHide: true })
        } catch {
          // Already gone between listing and killing.
        }
      }
    } else {
      execSync(`lsof -ti tcp:${PORT} | xargs -r kill -9`, { stdio: 'ignore' })
    }
  } catch {
    // Nothing was listening. Nothing to stop.
  }
}

async function waitForKey() {
  // Keeps the window open so a failure can actually be read. Without this the
  // console closes on exit and the person sees an app that simply never
  // returned.
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
  await new Promise((resolve) => rl.question('\nPress Enter to close this window. ', resolve))
  rl.close()
}

async function fail(message, error) {
  say(`\n────────────────────────────────────────`)
  say(`UPDATE STOPPED: ${message}`)
  if (error) say(String(error.message ?? error).split('\n').slice(0, 6).join('\n'))
  say('')
  say('Nothing was broken. The app is still the version you had before,')
  say('and a backup of your data was saved in the "backups" folder.')
  say('')
  say('Start the app again the way you normally do, and tell whoever')
  say('looks after this what the message above says.')
  say(`────────────────────────────────────────`)
  await waitForKey()
  process.exit(1)
}

/**
 * Which build this copy is. Absent means it was installed from source.
 */
async function readInstalled() {
  try {
    const raw = await readFile(path.join(ROOT, 'release.json'), 'utf8')
    const value = JSON.parse(raw)
    if (typeof value.build !== 'number' || !Number.isInteger(value.build)) return null
    return { build: value.build, version: String(value.version ?? value.build) }
  } catch {
    return null
  }
}

/**
 * Asks the public releases channel what the newest build is.
 *
 * `no-store` matters: this file changes, and the CDN in front of it would
 * otherwise hand back a cached copy for an hour after a release.
 */
async function fetchManifest() {
  const response = await fetch(MANIFEST_URL, {
    cache: 'no-store',
    signal: AbortSignal.timeout(20_000),
  })
  if (!response.ok) throw new Error(`update server returned ${response.status}`)

  const value = await response.json()
  if (typeof value.build !== 'number' || !Number.isInteger(value.build)) {
    throw new Error('the update server sent something this app could not read')
  }
  if (typeof value.zipUrl !== 'string' || !value.zipUrl.startsWith('https://')) {
    // HTTPS only. A plain-HTTP download is one anybody on the same network can
    // replace, and what it replaces is the application.
    throw new Error('the update server offered a download that is not https')
  }
  if (typeof value.sha256 !== 'string' || !/^[0-9a-f]{64}$/i.test(value.sha256)) {
    throw new Error('the update server offered a download with no checksum')
  }
  return {
    build: value.build,
    version: String(value.version ?? value.build),
    zipUrl: value.zipUrl,
    sha256: value.sha256.toLowerCase(),
    notes: Array.isArray(value.notes) ? value.notes.filter((n) => typeof n === 'string') : [],
  }
}

/**
 * Downloads the zip to a temporary folder and checks it against its hash.
 *
 * The hash is not ceremony. This writes over a working till, and a download
 * truncated by a dropped connection is a perfectly ordinary event on a shop's
 * internet — one that would otherwise unpack as a half-application.
 */
async function downloadAndVerify(manifest) {
  const staging = await mkdtemp(path.join(tmpdir(), 'violy-update-'))
  const zipPath = path.join(staging, 'update.zip')

  const response = await fetch(manifest.zipUrl, { signal: AbortSignal.timeout(180_000) })
  if (!response.ok) throw new Error(`download returned ${response.status}`)
  await pipeline(Readable.fromWeb(response.body), createWriteStream(zipPath))

  const actual = createHash('sha256').update(await readFile(zipPath)).digest('hex')
  if (actual !== manifest.sha256) {
    throw new Error(`the download did not match its checksum (expected ${manifest.sha256.slice(0, 12)}…, got ${actual.slice(0, 12)}…)`)
  }
  say(`  verified (${manifest.sha256.slice(0, 12)}…)`)

  // Expanded with PowerShell on Windows and `unzip` elsewhere, rather than
  // adding a zip library to a script that has to run before `npm install` has
  // had a chance to fix anything.
  const outDir = path.join(staging, 'app')
  if (process.platform === 'win32') {
    sh(
      `powershell -NoProfile -Command "Expand-Archive -LiteralPath '${zipPath}' -DestinationPath '${outDir}' -Force"`,
      { stdio: 'ignore' },
    )
  } else {
    sh(`unzip -q -o "${zipPath}" -d "${outDir}"`, { stdio: 'ignore' })
  }

  // Releases are packaged with everything at the top level, but a zip built
  // another way may wrap it in one folder. Unwrap that rather than writing a
  // nested copy over the install.
  const entries = await import('node:fs/promises').then((fs) => fs.readdir(outDir))
  if (entries.length === 1) {
    const inner = path.join(outDir, entries[0])
    const stat = await import('node:fs/promises').then((fs) => fs.stat(inner))
    if (stat.isDirectory() && !existsSync(path.join(outDir, 'package.json'))) return inner
  }
  return outDir
}

/**
 * Copies the new files over the install.
 *
 * What is NOT in the zip is the point: the database, `.env`, `backups/`,
 * `data/` and `node_modules/` are never packaged, so they cannot be
 * overwritten by an update. The shop's data survives because it was never in
 * the delivery, not because something remembered to skip it.
 */
async function applyFiles(sourceDir, manifest) {
  await cp(sourceDir, ROOT, { recursive: true, force: true })

  // Stamped last, so a copy that failed halfway does not claim to be the new
  // build and skip the update next time.
  await writeFile(
    path.join(ROOT, 'release.json'),
    JSON.stringify(
      { build: manifest.build, version: manifest.version, installedAt: new Date().toISOString() },
      null,
      2,
    ) + NEWLINE,
    'utf8',
  )

  await rm(path.dirname(sourceDir), { recursive: true, force: true }).catch(() => {})
}

async function restartAndExit() {
  const launcher = path.join(ROOT, 'start-pos.cmd')
  const child = existsSync(launcher) && process.platform === 'win32'
    ? spawn('cmd.exe', ['/c', 'start', '""', launcher], { cwd: ROOT, detached: true, stdio: 'ignore' })
    : spawn('npm', ['start'], { cwd: ROOT, detached: true, stdio: 'ignore', shell: true })
  child.unref()
  say('\nThe app is starting. You can close this window.')
  await waitForKey()
}

async function main() {
  say('════════════════════════════════════════')
  say('  Violy Store — installing an update')
  say('════════════════════════════════════════')
  say('\nPlease do not close this window until it says it is finished.')

  // ── 1. back up first, always ───────────────────────────────────────────
  step(1, 'Saving a backup of your data…')
  try {
    sh('npm run backup')
  } catch (error) {
    // The one failure that stops everything: without a backup there is no way
    // back from a bad migration.
    await fail('could not save a backup of your data.', error)
  }

  // ── 2. what is installed, and what is published ────────────────────────
  //
  // No git anywhere in here any more. It used to run `git status`, `git fetch`
  // and `git merge --ff-only`, which meant the shop laptop needed git INSTALLED
  // and signed in to GitHub, because the source repository is private. Two
  // things to set up, and a credential that expires quietly months later,
  // leaving a till that stops receiving fixes with nothing on screen to say so.
  step(2, 'Checking for a new version…')

  const installed = await readInstalled()
  if (!installed) {
    await fail(
      'this copy was installed from source rather than from a release, so it cannot update itself. Pull and rebuild instead.',
    )
  }

  let manifest
  try {
    manifest = await fetchManifest()
  } catch (error) {
    await fail('could not reach the update server. Check the internet connection.', error)
  }

  if (manifest.build <= installed.build) {
    say(`\n  Already up to date — you have build ${installed.build} (${installed.version}).`)
    say('\nNothing to install.')
    await restartAndExit()
    return
  }

  say(`  installed: build ${installed.build} (${installed.version})`)
  say(`  available: build ${manifest.build} (${manifest.version})`)

  // ── 3. stop the running app ────────────────────────────────────────────
  //
  // This is the step that makes the rest possible. While the server runs it
  // holds `node_modules` and `.next` open, and on Windows that turns
  // `npm install` and `next build` into permission errors rather than
  // failures anyone can interpret.
  step(3, 'Closing the app…')
  stopServer()
  say('  closed.')

  // ── 4. download, verify, unpack ────────────────────────────────────────
  step(4, 'Downloading the update…')
  let staged
  try {
    staged = await downloadAndVerify(manifest)
  } catch (error) {
    await fail('could not download the update, or it arrived damaged.', error)
  }

  // Only now, with a VERIFIED copy on disk, is anything overwritten. Unpacking
  // a half-downloaded zip over a working till is the one failure this ordering
  // exists to prevent.
  say('  unpacking…')
  try {
    await applyFiles(staged, manifest)
  } catch (error) {
    await fail('could not write the updated files.', error)
  }

  {
    // ── 5-7. dependencies, database, build ───────────────────────────────
    step(5, 'Installing the parts it needs…')
    try {
      sh('npm install')
    } catch (error) {
      await fail('could not install the updated parts.', error)
    }

    step(6, 'Updating the database…')
    try {
      // `migrate deploy`, never `migrate dev`: deploy applies existing
      // migrations and nothing else. `dev` can decide the database has drifted
      // and offer to RESET it, which on a shop laptop means deleting the
      // ledger.
      sh('npx prisma migrate deploy')
      sh('npx prisma generate')
    } catch (error) {
      await fail('could not update the database. Your backup is safe.', error)
    }

    step(7, 'Preparing the app…')
    try {
      // Throw away the previous build first. Twice while building this, a
      // `next build` started moments after the server was killed died with
      // eighteen copies of "Can't resolve '@vercel/turbopack-next/internal/
      // font/google/font'" — a message that says nothing about the real
      // cause, which is a Turbopack cache left half-written by the process
      // that was serving from it. `rm -rf .next` fixed it both times.
      //
      // This updater does exactly that sequence: it stops the server by port
      // and then builds. Removing the folder costs a slower build once and
      // removes the chance of an update failing on a message nobody in this
      // shop could act on.
      rmSync('.next', { recursive: true, force: true })
      sh('npm run build')
    } catch (error) {
      await fail('could not prepare the updated app.', error)
    }
  }

  // ── start again ────────────────────────────────────────────────────────
  say('\n════════════════════════════════════════')
  say(`  Updated to build ${manifest.build} (${manifest.version}). Starting the app…`)
  say('════════════════════════════════════════')

  await restartAndExit()
}

main().catch(async (error) => {
  await fail('something unexpected went wrong.', error)
})
