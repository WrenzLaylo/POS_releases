import { describe, expect, it } from 'vitest'
import {
  MAX_LINE_QUANTITY,
  MAX_UNIT_COST_CENTAVOS,
  deliveryTotal,
  lineCost,
  outstandingOf,
  validateDelivery,
  chargeableCentavos,
  chargeableQuantity,
  isDeliveryTerms,
  unaccountedQuantity,
  validateReconcile,
  type DeliveryInput,
} from './delivery'

const TODAY = new Date(2026, 7, 17, 14, 0, 0)

function input(overrides: Partial<DeliveryInput> = {}): DeliveryInput {
  return {
    supplierId: 1,
    terms: 'OUTRIGHT',
    receivedAt: new Date(2026, 7, 17),
    reference: 'DR-1234',
    note: '',
    lines: [{ productId: 10, quantity: 20, unitCostCentavos: 180_000 }],
    amountPaidCentavos: 0,
    ...overrides,
  }
}

describe('what a delivery comes to', () => {
  it('sums the lines', () => {
    expect(
      deliveryTotal([
        { productId: 1, quantity: 20, unitCostCentavos: 180_000 },
        { productId: 2, quantity: 5, unitCostCentavos: 110_00 },
      ]),
    ).toBe(20 * 180_000 + 5 * 11_000)
  })

  it('rounds a fractional quantity once, to the centavo', () => {
    // 18.5 kilos is a real line, and the product of a float quantity and an
    // integer cost is not an integer. Rounding here — once — is what keeps the
    // preview and the stored total identical.
    const line = { productId: 1, quantity: 18.5, unitCostCentavos: 11_033 }
    expect(lineCost(line)).toBe(Math.round(18.5 * 11_033))
    expect(Number.isInteger(lineCost(line))).toBe(true)
    expect(Number.isInteger(deliveryTotal([line]))).toBe(true)
  })

  it('is zero for no lines', () => {
    expect(deliveryTotal([])).toBe(0)
  })
})

describe('what is still owed', () => {
  it('is the total less what has been paid', () => {
    expect(
      outstandingOf({ chargeableCentavos: 100_000, amountPaidCentavos: 40_000, isVoided: false }),
    ).toBe(60_000)
  })

  it('is nothing on a voided consignment', () => {
    // The delivery did not happen, so neither did the debt.
    expect(
      outstandingOf({ chargeableCentavos: 100_000, amountPaidCentavos: 0, isVoided: true }),
    ).toBe(0)
  })

  it('never goes negative', () => {
    // A negative here would quietly reduce the payables total for every OTHER
    // supplier, which is the kind of wrong that looks like good news.
    expect(
      outstandingOf({ chargeableCentavos: 100_000, amountPaidCentavos: 150_000, isVoided: false }),
    ).toBe(0)
  })
})

describe('validateDelivery', () => {
  it('accepts a plain, correct consignment', () => {
    expect(validateDelivery(input(), TODAY)).toBeNull()
  })

  it.each([
    ['no supplier', { supplierId: 0 }],
    ['a negative supplier id', { supplierId: -1 }],
    ['no lines', { lines: [] }],
  ])('refuses %s', (_label, override) => {
    expect(validateDelivery(input(override), TODAY)).not.toBeNull()
  })

  it('complains about missing lines before it complains about the date', () => {
    // Being told the date is wrong when nothing has been added yet is not
    // help, it is noise.
    const problem = validateDelivery(
      input({ lines: [], receivedAt: new Date(2030, 0, 1) }),
      TODAY,
    )
    expect(problem).toMatch(/at least one item/i)
  })

  it('refuses a delivery dated in the future', () => {
    expect(validateDelivery(input({ receivedAt: new Date(2026, 7, 18) }), TODAY)).toMatch(
      /future/i,
    )
  })

  it('accepts one dated earlier today, whatever the time now is', () => {
    // Compared against the END of today: recording this morning's delivery at
    // two in the afternoon must not be refused for being "in the future".
    expect(validateDelivery(input({ receivedAt: new Date(2026, 7, 17, 8, 0) }), TODAY)).toBeNull()
    expect(validateDelivery(input({ receivedAt: new Date(2026, 7, 17, 23, 30) }), TODAY)).toBeNull()
  })

  it('accepts a back-dated delivery', () => {
    // Paperwork catches up days later; that is normal, not an error.
    expect(validateDelivery(input({ receivedAt: new Date(2026, 6, 1) }), TODAY)).toBeNull()
  })

  it('refuses an unreadable date', () => {
    expect(validateDelivery(input({ receivedAt: new Date('nonsense') }), TODAY)).not.toBeNull()
  })

  it.each([
    ['a zero quantity', 0],
    ['a negative quantity', -5],
    ['an infinite quantity', Number.POSITIVE_INFINITY],
    ['a quantity that is not a number', Number.NaN],
    ['an implausible quantity', MAX_LINE_QUANTITY + 1],
  ])('refuses %s', (_label, quantity) => {
    expect(
      validateDelivery(
        input({ lines: [{ productId: 10, quantity, unitCostCentavos: 180_000 }] }),
        TODAY,
      ),
    ).not.toBeNull()
  })

  it('accepts a fractional quantity', () => {
    // Sacks come in whole numbers; kilos do not.
    expect(
      validateDelivery(
        input({ lines: [{ productId: 10, quantity: 18.5, unitCostCentavos: 11_000 }] }),
        TODAY,
      ),
    ).toBeNull()
  })

  it.each([
    ['a negative cost', -1],
    ['a fractional centavo', 180_000.5],
    ['an implausible cost', MAX_UNIT_COST_CENTAVOS + 1],
  ])('refuses %s', (_label, unitCostCentavos) => {
    expect(
      validateDelivery(
        input({ lines: [{ productId: 10, quantity: 1, unitCostCentavos }] }),
        TODAY,
      ),
    ).not.toBeNull()
  })

  it('accepts a zero cost, which is a free or promotional consignment', () => {
    expect(
      validateDelivery(
        input({ lines: [{ productId: 10, quantity: 1, unitCostCentavos: 0 }] }),
        TODAY,
      ),
    ).toBeNull()
  })

  it('refuses the same product twice rather than merging it', () => {
    // Unlike the counter's cart, where a repeated tap means "one more". Two
    // rows for one sack at two different costs is a transcription error, and
    // silently picking one of the costs would be a guess about money.
    expect(
      validateDelivery(
        input({
          lines: [
            { productId: 10, quantity: 5, unitCostCentavos: 180_000 },
            { productId: 10, quantity: 5, unitCostCentavos: 190_000 },
          ],
        }),
        TODAY,
      ),
    ).toMatch(/twice/i)
  })

  it('refuses a line with no product chosen', () => {
    expect(
      validateDelivery(
        input({ lines: [{ productId: 0, quantity: 1, unitCostCentavos: 100 }] }),
        TODAY,
      ),
    ).not.toBeNull()
  })

  it.each([
    ['a negative payment', -1],
    ['a fractional centavo', 100.5],
  ])('refuses %s', (_label, amountPaidCentavos) => {
    expect(validateDelivery(input({ amountPaidCentavos }), TODAY)).not.toBeNull()
  })

  it('refuses paying more than the delivery comes to', () => {
    // Almost always a typo, and treating it as supplier credit would mean
    // inventing a supplier ledger to hold it.
    const one = input({ lines: [{ productId: 10, quantity: 1, unitCostCentavos: 100_000 }] })
    expect(validateDelivery({ ...one, amountPaidCentavos: 100_001 }, TODAY)).toMatch(/more than/i)
    expect(validateDelivery({ ...one, amountPaidCentavos: 100_000 }, TODAY)).toBeNull()
  })

  it('accepts an unpaid consignment, which is the common case', () => {
    expect(validateDelivery(input({ amountPaidCentavos: 0 }), TODAY)).toBeNull()
  })
})


describe('consignment against outright', () => {
  const line = {
    quantity: 50,
    quantitySettled: 0,
    quantityReturned: 0,
    unitCostCentavos: 180_000,
  }

  it('owes everything on an outright purchase the day it arrives', () => {
    expect(chargeableQuantity(line, 'OUTRIGHT')).toBe(50)
    expect(chargeableCentavos([line], 'OUTRIGHT')).toBe(50 * 180_000)
  })

  it('owes nothing on a consignment until something sells', () => {
    // The whole point. Treating a consignment as a purchase opens a debt that
    // does not exist and overstates what the shop owes by the value of every
    // sack still on the shelf.
    expect(chargeableQuantity(line, 'CONSIGNMENT')).toBe(0)
    expect(chargeableCentavos([line], 'CONSIGNMENT')).toBe(0)
  })

  it('owes for exactly what has been settled as sold', () => {
    const sold = { ...line, quantitySettled: 32 }
    expect(chargeableCentavos([sold], 'CONSIGNMENT')).toBe(32 * 180_000)
    // The other 18 are still the supplier's.
    expect(unaccountedQuantity(sold)).toBe(18)
  })

  it('does not charge for stock sent back, on either terms', () => {
    const returned = { ...line, quantityReturned: 10 }
    expect(chargeableCentavos([returned], 'OUTRIGHT')).toBe(40 * 180_000)

    const consigned = { ...line, quantitySettled: 32, quantityReturned: 18 }
    expect(chargeableCentavos([consigned], 'CONSIGNMENT')).toBe(32 * 180_000)
    expect(unaccountedQuantity(consigned)).toBe(0)
  })

  it('recognises only the two terms it knows', () => {
    expect(isDeliveryTerms('OUTRIGHT')).toBe(true)
    expect(isDeliveryTerms('CONSIGNMENT')).toBe(true)
    for (const bad of ['', 'outright', 'CONSIGN', 'anything']) {
      expect(isDeliveryTerms(bad), bad).toBe(false)
    }
  })

  it('refuses money paid against a consignment on arrival', () => {
    expect(
      validateDelivery(input({ terms: 'CONSIGNMENT', amountPaidCentavos: 1 }), TODAY),
    ).toMatch(/until it sells/i)
    expect(validateDelivery(input({ terms: 'CONSIGNMENT' }), TODAY)).toBeNull()
  })

  it('refuses unrecognised terms', () => {
    expect(
      validateDelivery(input({ terms: 'RENTAL' as unknown as 'OUTRIGHT' }), TODAY),
    ).not.toBeNull()
  })
})

describe('validateReconcile', () => {
  const lines = [
    { productId: 10, quantity: 50, quantitySettled: 0, quantityReturned: 0, unitCostCentavos: 180_000 },
  ]

  it('accepts a straightforward settlement', () => {
    expect(
      validateReconcile('CONSIGNMENT', lines, [
        { productId: 10, soldQuantity: 32, returnedQuantity: 18 },
      ]),
    ).toBeNull()
  })

  it('refuses more than arrived', () => {
    // The invariant: settled + returned can never exceed what came. Breaking
    // it bills for sacks that were never there.
    expect(
      validateReconcile('CONSIGNMENT', lines, [
        { productId: 10, soldQuantity: 40, returnedQuantity: 20 },
      ]),
    ).toMatch(/more than arrived/i)
  })

  it('counts what is already recorded, because a consignment is settled in visits', () => {
    const partly = [{ ...lines[0], quantitySettled: 30 }]
    expect(
      validateReconcile('CONSIGNMENT', partly, [
        { productId: 10, soldQuantity: 15, returnedQuantity: 10 },
      ]),
    ).toMatch(/more than arrived/i)
    expect(
      validateReconcile('CONSIGNMENT', partly, [
        { productId: 10, soldQuantity: 10, returnedQuantity: 10 },
      ]),
    ).toBeNull()
  })

  it('refuses settling an outright purchase, which is already owed in full', () => {
    expect(
      validateReconcile('OUTRIGHT', lines, [
        { productId: 10, soldQuantity: 5, returnedQuantity: 0 },
      ]),
    ).toMatch(/outright/i)
  })

  it('allows returning from an outright purchase', () => {
    // Torn sacks go back and are not paid for.
    expect(
      validateReconcile('OUTRIGHT', lines, [
        { productId: 10, soldQuantity: 0, returnedQuantity: 2 },
      ]),
    ).toBeNull()
  })

  it.each([
    ['nothing at all', [{ productId: 10, soldQuantity: 0, returnedQuantity: 0 }]],
    ['a negative quantity', [{ productId: 10, soldQuantity: -1, returnedQuantity: 0 }]],
    ['a product not on the delivery', [{ productId: 99, soldQuantity: 1, returnedQuantity: 0 }]],
    ['no lines', []],
  ])('refuses %s', (_label, updates) => {
    expect(validateReconcile('CONSIGNMENT', lines, updates)).not.toBeNull()
  })

  it('refuses the same product twice in one reconciliation', () => {
    expect(
      validateReconcile('CONSIGNMENT', lines, [
        { productId: 10, soldQuantity: 1, returnedQuantity: 0 },
        { productId: 10, soldQuantity: 1, returnedQuantity: 0 },
      ]),
    ).toMatch(/twice/i)
  })
})
