import { getStoreProfile } from '@/server/store-profile'
import { getBackupStatus } from '@/lib/backup-run'
import { PageHeader } from '@/components/ui/PageHeader'
import { StoreProfileForm } from './StoreProfileForm'
import { BackupPanel } from './BackupPanel'
import { DataTransfer } from './DataTransfer'
import { UpdatePanel } from './UpdatePanel'

export const dynamic = 'force-dynamic'

export default async function SettingsPage() {
  // Read on the server so the panel arrives already knowing when the last
  // backup was. A client fetch on mount would show "no backups yet" for a beat
  // first, which is the single most alarming thing this panel could say.
  const [profile, backups] = await Promise.all([getStoreProfile(), getBackupStatus()])

  return (
    <PageHeader title="Settings">
      <div className="grid gap-6">
        <StoreProfileForm profile={profile} />
        <BackupPanel status={backups} />
        <DataTransfer />
        <UpdatePanel />
      </div>
    </PageHeader>
  )
}
