'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import type { DeliveryDetail } from '@/server/deliveries'
import { reconcileDelivery } from '@/server/deliveries'
import { validateReconcile, type ReconcileLine } from '@/lib/delivery'
import { Button } from '@/components/ui/Button'
import { Dialog } from '@/components/ui/Dialog'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'
import { Money } from '@/components/ui/Money'

type Entry = { sold: string; returned: string }

/**
 * The supplier's visit: what sold, and what goes back.
 *
 * On a consignment this is the moment a liability appears — until it happens
 * the shop owes nothing, however much stock is on the shelf. On an outright
 * purchase only the return column is offered, because it was owed in full the
 * day it arrived and "sold" is not a state it can pass through.
 */
export function SettleDialog({
  delivery,
  onClose,
}: {
  delivery: DeliveryDetail
  onClose: () => void
}) {
  const router = useRouter()
  const [pending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)
  const consignment = delivery.terms === 'CONSIGNMENT'

  const [entries, setEntries] = useState<Record<number, Entry>>(() =>
    Object.fromEntries(delivery.lines.map((line) => [line.productId, { sold: '', returned: '' }])),
  )

  function set(productId: number, patch: Partial<Entry>) {
    setEntries((current) => ({ ...current, [productId]: { ...current[productId], ...patch } }))
  }

  const updates: ReconcileLine[] = delivery.lines
    .map((line) => {
      const entry = entries[line.productId] ?? { sold: '', returned: '' }
      return {
        productId: line.productId,
        soldQuantity: entry.sold.trim() === '' ? 0 : Number(entry.sold),
        returnedQuantity: entry.returned.trim() === '' ? 0 : Number(entry.returned),
      }
    })
    .filter((update) => update.soldQuantity !== 0 || update.returnedQuantity !== 0)

  // The same check the server runs, against the same line state, so a disabled
  // Save button always has a sentence next to it explaining itself.
  const problem = validateReconcile(delivery.terms, delivery.lines, updates)

  // What this visit adds to the bill, previewed before anything is written.
  const addedCentavos = updates.reduce((total, update) => {
    const line = delivery.lines.find((candidate) => candidate.productId === update.productId)
    if (!line) return total
    const chargeable = consignment ? update.soldQuantity : -update.returnedQuantity
    return total + Math.round(chargeable * line.unitCostCentavos)
  }, 0)

  function save() {
    setError(null)
    startTransition(async () => {
      const result = await reconcileDelivery(delivery.id, updates)
      if (!result.ok) {
        setError(result.error)
        return
      }
      router.refresh()
      onClose()
    })
  }

  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title={consignment ? 'Settle this consignment' : 'Return stock to the supplier'}
      description={
        consignment
          ? 'Enter how many sold and how many are going back. Only what sold becomes owed.'
          : 'Enter how many are going back. They come off the shelf and off the bill.'
      }
      footer={
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button variant="success" onClick={save} disabled={pending || problem !== null}>
            {pending ? 'Saving…' : 'Save'}
          </Button>
        </div>
      }
    >
      <div className="grid gap-4">
        <div className="overflow-hidden rounded-control border border-line">
          <table className="w-full text-sm">
            <thead className="bg-surface-sunk text-left text-xs uppercase tracking-wide text-ink-muted">
              <tr>
                <th className="px-3 py-2 font-medium">Product</th>
                <th className="px-3 py-2 text-right font-medium">Left</th>
                {consignment && <th className="w-24 px-3 py-2 font-medium">Sold</th>}
                <th className="w-24 px-3 py-2 font-medium">Back</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {delivery.lines.map((line) => {
                const entry = entries[line.productId] ?? { sold: '', returned: '' }
                return (
                  <tr key={line.productId}>
                    <td className="px-3 py-2">
                      <span className="block text-sm font-medium text-ink">{line.name}</span>
                      <span className="block text-xs text-ink-subtle">
                        {line.quantity} {line.unit} @{' '}
                        <Money centavos={line.unitCostCentavos} scale="body" />
                      </span>
                    </td>
                    {/* What is still unaccounted for — the ceiling on both
                        boxes, and the number the agent is counting against. */}
                    <td className="px-3 py-2 text-right font-mono text-xs tabular-nums text-ink-muted">
                      {line.unaccountedQuantity}
                    </td>
                    {consignment && (
                      <td className="px-3 py-2">
                        <Input
                          aria-label={`Sold, ${line.name}`}
                          inputMode="decimal"
                          value={entry.sold}
                          onChange={(event) => set(line.productId, { sold: event.target.value })}
                          placeholder="0"
                          className="w-20 tabular-nums"
                        />
                      </td>
                    )}
                    <td className="px-3 py-2">
                      <Input
                        aria-label={`Returned, ${line.name}`}
                        inputMode="decimal"
                        value={entry.returned}
                        onChange={(event) => set(line.productId, { returned: event.target.value })}
                        placeholder="0"
                        className="w-20 tabular-nums"
                      />
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>

        <div className="rounded-card border border-line bg-surface-sunk p-4">
          <dl className="grid gap-1 text-sm">
            <div className="flex justify-between">
              <dt className="text-ink-muted">Owed before this</dt>
              <dd>
                <Money centavos={delivery.chargeableCentavos} scale="body" />
              </dd>
            </div>
            <div className="flex justify-between border-t border-line pt-2">
              <dt className="font-semibold text-ink">Owed after</dt>
              <dd>
                {/* Owed, never `money-in`: this is the shop's debt moving. */}
                <Money
                  centavos={Math.max(0, delivery.chargeableCentavos + addedCentavos)}
                  tone="owed"
                  scale="strong"
                />
              </dd>
            </div>
          </dl>
        </div>

        {problem && updates.length > 0 && <p className="text-sm text-warn">{problem}</p>}
        {error && <FormError>{error}</FormError>}
      </div>
    </Dialog>
  )
}
