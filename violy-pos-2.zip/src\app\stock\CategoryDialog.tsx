'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import type { CategoryRow } from '@/server/categories'
import { createCategory, deleteCategory, renameCategory } from '@/server/categories'
import { Button } from '@/components/ui/Button'
import { Dialog } from '@/components/ui/Dialog'
import { Field } from '@/components/ui/Field'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'

/**
 * Adding and renaming the brands a product can belong to.
 *
 * There was no way to do this at all until now — every category came from a
 * seed script, and the CSV importer refuses unknown ones rather than inventing
 * them. So a shop that started stocking a new brand had no way to say so.
 *
 * One dialog rather than a screen of its own, and reached from Stock, because
 * a category exists only to group products: it is a property of the catalogue,
 * not a place to visit. Same shape as the supplier list on Deliveries.
 */
export function CategoryDialog({
  categories,
  onClose,
}: {
  categories: CategoryRow[]
  onClose: () => void
}) {
  const router = useRouter()
  const [pending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)

  const [name, setName] = useState('')
  const [editingId, setEditingId] = useState<number | null>(null)
  const [confirmingId, setConfirmingId] = useState<number | null>(null)

  function reset() {
    setName('')
    setEditingId(null)
  }

  function save() {
    setError(null)
    startTransition(async () => {
      const result =
        editingId === null ? await createCategory(name) : await renameCategory(editingId, name)
      if (!result.ok) {
        setError(result.error)
        return
      }
      reset()
      router.refresh()
    })
  }

  function remove(id: number) {
    setError(null)
    startTransition(async () => {
      const result = await deleteCategory(id)
      if (!result.ok) {
        setError(result.error)
        setConfirmingId(null)
        return
      }
      setConfirmingId(null)
      router.refresh()
    })
  }

  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title="Categories"
      description="The brands and groups a product can belong to. They are the chips along the top of the counter."
      footer={
        <div className="flex justify-end">
          <Button variant="secondary" onClick={onClose}>
            Done
          </Button>
        </div>
      }
    >
      <div className="grid gap-4">
        <div className="flex flex-wrap items-end gap-2">
          <Field label={editingId === null ? 'New category' : 'Rename category'}>
            <Input
              value={name}
              onChange={(event) => setName(event.target.value)}
              placeholder="e.g. Gamefowl"
              className="w-56"
              autoFocus
            />
          </Field>
          <Button variant="primary" onClick={save} disabled={pending || name.trim() === ''}>
            {editingId === null ? 'Add' : 'Save'}
          </Button>
          {editingId !== null && (
            <Button variant="ghost" onClick={reset} disabled={pending}>
              Cancel
            </Button>
          )}
        </div>

        {error && <FormError>{error}</FormError>}

        <ul className="divide-y divide-line rounded-control border border-line">
          {categories.map((category) => (
            <li key={category.id} className="flex items-center justify-between gap-3 px-3 py-2">
              <span className="min-w-0">
                <span className="block truncate text-sm font-medium text-ink">{category.name}</span>
                <span className="block text-xs text-ink-subtle">
                  {category.productCount} product{category.productCount === 1 ? '' : 's'}
                </span>
              </span>

              <span className="flex shrink-0 items-center gap-1">
                <Button
                  variant="ghost"
                  size="sm"
                  disabled={pending}
                  onClick={() => {
                    setError(null)
                    setEditingId(category.id)
                    setName(category.name)
                  }}
                >
                  Rename
                </Button>

                {/* Removal is offered only for an empty category. A category
                    holding products cannot go without deciding where those
                    products land, and that is the shop's decision — so the
                    button is absent rather than present and refusing. */}
                {category.productCount === 0 &&
                  (confirmingId === category.id ? (
                    <>
                      <Button
                        variant="destructive"
                        size="sm"
                        disabled={pending}
                        onClick={() => remove(category.id)}
                      >
                        Remove
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        disabled={pending}
                        onClick={() => setConfirmingId(null)}
                      >
                        Keep
                      </Button>
                    </>
                  ) : (
                    <Button
                      variant="danger"
                      size="sm"
                      disabled={pending}
                      onClick={() => {
                        setError(null)
                        setConfirmingId(category.id)
                      }}
                    >
                      Remove
                    </Button>
                  ))}
              </span>
            </li>
          ))}
        </ul>

        <p className="text-xs text-ink-subtle">
          Renaming is safe at any time — every product follows the new name. New categories are
          added at the end of the counter&apos;s chip strip.
        </p>
      </div>
    </Dialog>
  )
}
