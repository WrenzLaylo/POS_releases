'use client'

import { useState } from 'react'
import type { ProductWithCategory } from '@/lib/types'
import type { CategoryRow } from '@/server/categories'
import type { ProductSortKey } from '@/lib/product-sort'
import type { SortState } from '@/lib/sorting'
import { Button } from '@/components/ui/Button'
import { InventoryFilters } from './InventoryFilters'
import { InventoryTable } from './InventoryTable'
import { CategoryDialog } from './CategoryDialog'
import { ProductForm } from './ProductForm'

/**
 * Holds the one piece of state the filter row and the table both need: whether
 * the new-product form is open.
 *
 * "New product" belongs on the filter row — it used to sit in a block of its
 * own beneath, leaving a band of empty page between the filters and the table
 * with the primary action stranded in it. But the form it opens is the table's
 * concern, so something has to own that state above both. This does, and
 * nothing else moves.
 */
export function StockScreen({
  products,
  categories,
  categoryRows,
  sort,
  filters,
}: {
  products: ProductWithCategory[]
  categories: { id: number; name: string }[]
  /** The same categories with their product counts, for managing them. */
  categoryRows: CategoryRow[]
  sort: SortState<ProductSortKey>
  filters: { q?: string; category?: string; stock?: string; archived?: string }
}) {
  const [newOpen, setNewOpen] = useState(false)
  const [categoriesOpen, setCategoriesOpen] = useState(false)

  return (
    <>
      <div className="mb-4">
        <InventoryFilters
          categories={categories}
          q={filters.q}
          category={filters.category}
          stock={filters.stock}
          archived={filters.archived}
          action={
            <div className="flex flex-wrap items-center gap-2">
              {/* Beside New product, because adding a brand is something you
                  discover you need WHILE adding the first product in it. */}
              <Button variant="secondary" onClick={() => setCategoriesOpen(true)}>
                Categories
              </Button>
              <Button variant="primary" onClick={() => setNewOpen(true)}>
                New product
              </Button>
            </div>
          }
        />
      </div>

      <InventoryTable products={products} categories={categories} sort={sort} />

      {categoriesOpen && (
        <CategoryDialog categories={categoryRows} onClose={() => setCategoriesOpen(false)} />
      )}

      {/* Mounted only while open, so each opening starts from empty fields
          rather than whatever was typed and abandoned last time. */}
      {newOpen && (
        <ProductForm
          categories={categories}
          product={null}
          onClose={() => setNewOpen(false)}
        />
      )}
    </>
  )
}
