'use client'

import { useRef, useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { csvBlobParts } from '@/lib/csv'
import { dayKey } from '@/lib/dates'
import { EXPORT_TABLES, type ExportTable } from '@/lib/export-tables'
import { exportTableCsv } from '@/server/export-data'
import { applyImport, previewImport, type ImportPreview, type ImportTable } from '@/server/import-data'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { FormError } from '@/components/ui/FormError'
import { SegmentedControl } from '@/components/ui/SegmentedControl'
import { cn } from '@/lib/cn'

const IMPORT_TABLES = [
  { value: 'products', label: 'Products' },
  { value: 'customers', label: 'Customers' },
] as const

/**
 * Getting data out of the app and back into it.
 *
 * Export is unconditional — it only reads. Import never writes without showing
 * what it is about to do first: a spreadsheet is edited by hand, so a column
 * can be shifted, a price can be a word, and a mistyped name creates a
 * duplicate product rather than updating the one that exists. Finding that out
 * afterwards means finding it out in the data.
 */
export function DataTransfer() {
  const router = useRouter()
  const [busy, startTransition] = useTransition()

  // ── export ──────────────────────────────────────────────────────────────
  const [exporting, setExporting] = useState<ExportTable | null>(null)
  const [exportError, setExportError] = useState<string | null>(null)

  function download(table: ExportTable) {
    setExportError(null)
    setExporting(table)
    startTransition(async () => {
      try {
        const csv = await exportTableCsv(table)
        // The BOM is added here rather than on the server: it exists purely so
        // Excel on Windows reads the file as UTF-8 instead of the local
        // codepage, which otherwise turns every ₱ into mojibake.
        const blob = new Blob([csvBlobParts(csv)], { type: 'text/csv;charset=utf-8' })
        const url = URL.createObjectURL(blob)
        const link = document.createElement('a')
        link.href = url
        link.download = `violy-${table}-${dayKey(new Date())}.csv`
        link.click()
        URL.revokeObjectURL(url)
      } catch {
        setExportError('Could not build that file. Try again.')
      } finally {
        setExporting(null)
      }
    })
  }

  // ── import ──────────────────────────────────────────────────────────────
  const fileRef = useRef<HTMLInputElement>(null)
  const [importTable, setImportTable] = useState<ImportTable>('products')
  const [csvText, setCsvText] = useState<string | null>(null)
  const [fileName, setFileName] = useState<string | null>(null)
  const [preview, setPreview] = useState<ImportPreview | null>(null)
  const [importError, setImportError] = useState<string | null>(null)
  const [applied, setApplied] = useState<{ created: number; updated: number; failed: number } | null>(null)

  function reset() {
    setCsvText(null)
    setFileName(null)
    setPreview(null)
    setImportError(null)
    setApplied(null)
    if (fileRef.current) fileRef.current.value = ''
  }

  async function chooseFile(file: File) {
    setImportError(null)
    setApplied(null)
    const text = await file.text()
    setCsvText(text)
    setFileName(file.name)

    startTransition(async () => {
      const result = await previewImport(importTable, text)
      if (!result.ok) {
        setPreview(null)
        setImportError(result.error)
        return
      }
      setPreview(result.data)
    })
  }

  function apply() {
    if (!csvText) return
    setImportError(null)
    startTransition(async () => {
      const result = await applyImport(importTable, csvText)
      if (!result.ok) {
        setImportError(result.error)
        return
      }
      setApplied(result.data)
      setPreview(null)
      setCsvText(null)
      setFileName(null)
      if (fileRef.current) fileRef.current.value = ''
      router.refresh()
    })
  }

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card>
        <h2 className="mb-1 text-base font-semibold">Export to CSV</h2>
        <p className="mb-4 text-sm text-ink-muted">
          Opens directly in Excel and Google Sheets. Money is written as pesos, so a column
          sums to what you expect.
        </p>

        <div className="grid gap-2">
          {EXPORT_TABLES.map((table) => (
            <div
              key={table.value}
              className="flex items-center justify-between gap-3 rounded-control border border-line px-3 py-2"
            >
              <div className="min-w-0">
                <div className="text-sm font-medium text-ink">{table.label}</div>
                <div className="text-xs text-ink-subtle">{table.note}</div>
              </div>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => download(table.value)}
                disabled={busy}
              >
                {exporting === table.value ? 'Building…' : 'Download'}
              </Button>
            </div>
          ))}
        </div>

        {exportError && <FormError className="mt-3">{exportError}</FormError>}

        <p className="mt-4 rounded-control border border-line bg-surface-sunk px-3 py-2 text-xs text-ink-muted">
          These are readable copies, not a backup — a spreadsheet cannot be turned back into the
          app. For a restorable copy of everything, use <span className="font-medium">Backups</span>{' '}
          above.
        </p>
      </Card>

      <Card>
        <h2 className="mb-1 text-base font-semibold">Import from CSV</h2>
        <p className="mb-4 text-sm text-ink-muted">
          Products and customers only. Nothing is written until you have seen what will change.
          A row is matched by name — same name updates, new name creates.
        </p>

        <div className="mb-3">
          <SegmentedControl
            ariaLabel="What to import"
            options={IMPORT_TABLES}
            value={importTable}
            onValueChange={(value) => {
              setImportTable(value as ImportTable)
              reset()
            }}
          />
        </div>

        <input
          ref={fileRef}
          type="file"
          accept=".csv,text/csv"
          aria-label="Choose a CSV file"
          disabled={busy}
          onChange={(event) => {
            const file = event.target.files?.[0]
            if (file) void chooseFile(file)
          }}
          className="block w-full text-sm text-ink-muted file:mr-3 file:h-9 file:cursor-pointer file:rounded-control file:border file:border-line-strong file:bg-surface-raised file:px-3 file:text-sm file:font-medium file:text-ink hover:file:border-accent hover:file:bg-accent-soft"
        />

        {fileName && (
          <p className="mt-2 text-xs text-ink-subtle">
            {fileName}
            {preview && ` · ${preview.rows.length} rows`}
          </p>
        )}

        {importError && <FormError className="mt-3">{importError}</FormError>}

        {applied && (
          <p className="mt-3 rounded-control border border-money-in/30 bg-money-in/10 px-3 py-2 text-sm text-money-in">
            {applied.created} created, {applied.updated} updated
            {applied.failed > 0 && `, ${applied.failed} skipped`}.
          </p>
        )}

        {preview && (
          <div className="mt-4">
            <div className="mb-2 flex flex-wrap items-center gap-3 text-sm">
              <span className="font-medium text-ink">
                {preview.createCount} new · {preview.updateCount} changed
              </span>
              {preview.errorCount > 0 && (
                <span className="font-medium text-owed">{preview.errorCount} cannot be read</span>
              )}
            </div>

            <div className="max-h-64 overflow-y-auto rounded-control border border-line">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-surface-sunk text-left text-xs uppercase tracking-wide text-ink-muted">
                  <tr>
                    <th className="px-3 py-2 font-medium">Row</th>
                    <th className="px-3 py-2 font-medium">Name</th>
                    <th className="px-3 py-2 font-medium">What happens</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line">
                  {preview.rows.map((row) => (
                    <tr
                      key={row.line}
                      className={cn(row.error && 'bg-owed/10', row.action === 'create' && 'bg-money-in/5')}
                    >
                      <td className="px-3 py-1.5 font-mono tabular-nums text-ink-subtle">
                        {row.line}
                      </td>
                      <td className="px-3 py-1.5">{row.name || <span className="text-ink-subtle">—</span>}</td>
                      <td className="px-3 py-1.5">
                        {row.error ? (
                          <span className="text-owed">{row.error}</span>
                        ) : row.action === 'skip' ? (
                          <span className="text-ink-subtle">no change</span>
                        ) : (
                          <span className="text-ink-muted">
                            <span className="font-medium text-ink">
                              {row.action === 'create' ? 'Create' : 'Update'}
                            </span>{' '}
                            — {row.changes.join(', ')}
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-2">
              <Button
                variant="success"
                onClick={apply}
                disabled={busy || preview.createCount + preview.updateCount === 0}
              >
                {busy
                  ? 'Importing…'
                  : `Apply ${preview.createCount + preview.updateCount} change${
                      preview.createCount + preview.updateCount === 1 ? '' : 's'
                    }`}
              </Button>
              <Button variant="ghost" onClick={reset} disabled={busy}>
                Cancel
              </Button>
              {preview.errorCount > 0 && (
                <span className="text-xs text-ink-subtle">
                  Unreadable rows are skipped, not guessed at.
                </span>
              )}
            </div>
          </div>
        )}
      </Card>
    </div>
  )
}
