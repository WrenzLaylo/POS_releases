'use client'

import { useEffect, useRef, useState } from 'react'
import { cn } from '@/lib/cn'
import { Icon } from './Icon'

export type RowActionMenuItem = {
  label: string
  onSelect: () => void
  destructive?: boolean
  disabled?: boolean
}

export type RowActionMenuProps = {
  items: RowActionMenuItem[]
  ariaLabel?: string
  className?: string
}

export function RowActionMenu({ items, ariaLabel = 'Row actions', className }: RowActionMenuProps) {
  const [open, setOpen] = useState(false)
  const rootRef = useRef<HTMLDivElement>(null)
  const triggerRef = useRef<HTMLButtonElement>(null)
  const itemRefs = useRef<Array<HTMLButtonElement | null>>([])

  const enabledIndexes = () => items.flatMap((item, index) => item.disabled ? [] : [index])

  useEffect(() => {
    if (!open) return
    itemRefs.current[enabledIndexes()[0]]?.focus()

    const handlePointerDown = (event: PointerEvent) => {
      if (!rootRef.current?.contains(event.target as Node)) setOpen(false)
    }
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return
      event.preventDefault()
      setOpen(false)
      queueMicrotask(() => triggerRef.current?.focus())
    }
    document.addEventListener('pointerdown', handlePointerDown)
    document.addEventListener('keydown', handleEscape)
    return () => {
      document.removeEventListener('pointerdown', handlePointerDown)
      document.removeEventListener('keydown', handleEscape)
    }
  }, [open])

  return (
    <div ref={rootRef} className={cn('relative inline-flex', className)}>
      <button
        ref={triggerRef}
        type="button"
        aria-label={ariaLabel}
        aria-haspopup="menu"
        aria-expanded={open}
        // `h-8`, the row-action size AGENTS.md sets, not `h-10`. At h-10 this
        // trigger was the tallest thing in a stock row and set the row height
        // on its own — 40px of it against 20px of text — so compacting every
        // other cell moved the row by four pixels and no further. The menu
        // ITEMS stay h-10: they are a normal control surface, not a row action.
        className="inline-flex h-8 w-8 items-center justify-center rounded-control text-ink-muted transition-colors hover:bg-surface-sunk hover:text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-canvas"
        onClick={() => setOpen((current) => !current)}
      >
        <Icon name="more-horizontal" className="h-4 w-4" />
      </button>
      {open ? (
        <div
          role="menu"
          className="absolute right-0 top-full z-40 mt-1 min-w-40 rounded-control border border-line bg-surface-raised p-1 shadow-raised"
          onKeyDown={(event) => {
            if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') return
            event.preventDefault()
            const enabled = enabledIndexes()
            if (enabled.length === 0) return
            const current = itemRefs.current.findIndex((item) => item === document.activeElement)
            const currentPosition = enabled.indexOf(current)
            const direction = event.key === 'ArrowDown' ? 1 : -1
            const nextPosition = (currentPosition + direction + enabled.length) % enabled.length
            itemRefs.current[enabled[nextPosition]]?.focus()
          }}
        >
          {items.map((item, index) => (
            <button
              key={item.label}
              ref={(element) => { itemRefs.current[index] = element }}
              type="button"
              role="menuitem"
              disabled={item.disabled}
              className={cn(
                'flex h-10 w-full items-center rounded-control px-3 text-left text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent disabled:opacity-50',
                item.destructive ? 'text-owed hover:bg-accent-soft' : 'text-ink hover:bg-surface-sunk',
              )}
              onClick={() => {
                if (item.disabled) return
                setOpen(false)
                item.onSelect()
              }}
            >
              {item.label}
            </button>
          ))}
        </div>
      ) : null}
    </div>
  )
}
