/**
 * Every discount this app grants, resolved in one place.
 *
 * Two kinds of discount exist and they compose:
 *
 * - A customer's **standing** discount, configured once on their record. It is
 *   either a peso amount or a percentage, and it applies either per unit
 *   (scoped to chosen categories) or against the whole order.
 * - An **ad-hoc** discount typed at the counter for one order, which either
 *   stacks on top of the standing one or replaces it.
 *
 * `computeOrderTotals` is used by BOTH the order screen's live preview and the
 * server action that commits the sale. That sharing is the point: a preview
 * and a commit that each do their own arithmetic will eventually disagree, and
 * the disagreement is money — the figure she read out loud to the customer
 * against the figure that hit the books.
 */

import { lineTotal } from './money'

import { ANY_UNIT, unitMatches } from './unit'

export type DiscountKind = 'AMOUNT' | 'PERCENT'
export type DiscountBasis = 'PER_UNIT' | 'ORDER_TOTAL'
export type OrderDiscountMode = 'STACK' | 'REPLACE'

/** 100.00%. Nothing may discount more than the thing costs. */
export const MAX_BPS = 10_000

export function isDiscountKind(value: string): value is DiscountKind {
  return value === 'AMOUNT' || value === 'PERCENT'
}

export function isDiscountBasis(value: string): value is DiscountBasis {
  return value === 'PER_UNIT' || value === 'ORDER_TOTAL'
}

export function isOrderDiscountMode(value: string): value is OrderDiscountMode {
  return value === 'STACK' || value === 'REPLACE'
}

export type CustomerDiscount = {
  kind: DiscountKind
  /** Centavos off. Per unit when basis is PER_UNIT, off the order otherwise. */
  amountCentavos: number
  /** Basis points off — 500 is 5.00%. Read only when kind is PERCENT. */
  bps: number
  basis: DiscountBasis
  /**
   * Categories the discount covers. Empty means it applies to nothing, which
   * is inert rather than an error — a stored amount with no scope.
   *
   * Read only when basis is PER_UNIT. An ORDER_TOTAL discount is against the
   * order as a whole and has no per-line scope to check.
   */
  categoryIds: ReadonlySet<number>
  /**
   * Which unit the discount is per — "bag", "kilo". Empty means every unit.
   *
   * A second scope on top of the categories, not a replacement for one. A
   * category can hold both sizes: Pigrolac sells sacks and a 1kg Booster, so
   * "₱20 off Pigrolac per unit" would otherwise take ₱20 off a ₱110 kilo pack
   * as readily as off a ₱2,050 sack.
   */
  unit: string
}

export type OrderDiscount = {
  kind: DiscountKind
  amountCentavos: number
  bps: number
  mode: OrderDiscountMode
}

export const NO_ORDER_DISCOUNT: OrderDiscount = {
  kind: 'AMOUNT',
  amountCentavos: 0,
  bps: 0,
  mode: 'STACK',
}

/**
 * Reads a customer row's four discount columns into the shape the pipeline
 * wants. Structurally typed rather than importing Prisma's `Customer`, so the
 * client-side preview can call it with the same object the server does.
 *
 * An unrecognised string falls back to the historical behaviour rather than
 * throwing. SQLite has no enums, so a bad value is reachable in principle —
 * and refusing to price an order because a discount column holds nonsense
 * would stop a sale over something the operator cannot see or fix from the
 * counter.
 */
export function customerDiscountOf(customer: {
  discountKind: string
  discountCentavos: number
  discountBps: number
  discountBasis: string
  discountUnit?: string
  discountCategories: readonly { id: number }[]
}): CustomerDiscount {
  return {
    kind: isDiscountKind(customer.discountKind) ? customer.discountKind : 'AMOUNT',
    amountCentavos: customer.discountCentavos,
    bps: customer.discountBps,
    basis: isDiscountBasis(customer.discountBasis) ? customer.discountBasis : 'PER_UNIT',
    // Optional, and defaulting to "every unit": a customer row written before
    // this column existed has no value for it, and must keep pricing exactly
    // as it did.
    unit: customer.discountUnit ?? ANY_UNIT,
    categoryIds: new Set(customer.discountCategories.map((category) => category.id)),
  }
}

/** The ad-hoc discount as it arrives from the browser, before validation. */
export type OrderDiscountInput = {
  kind: string
  amountCentavos: number
  bps: number
  mode: string
}

/**
 * The write boundary for an ad-hoc discount. Both `kind` and `mode` are
 * validated at runtime rather than trusted from the type, for the same reason
 * `isLedgerEntryType` exists: these cross a Server Action boundary, so the
 * compiler's word for what the client sent is not evidence.
 *
 * A missing discount is not an error — it is the ordinary case.
 */
export function validateOrderDiscount(
  input: OrderDiscountInput | null | undefined,
): { ok: true; value: OrderDiscount } | { ok: false; error: string } {
  if (!input) return { ok: true, value: NO_ORDER_DISCOUNT }

  if (!isDiscountKind(input.kind)) {
    return { ok: false, error: 'Unrecognised discount type.' }
  }
  if (!isOrderDiscountMode(input.mode)) {
    return { ok: false, error: 'Unrecognised discount mode.' }
  }
  if (!Number.isInteger(input.amountCentavos) || input.amountCentavos < 0) {
    return { ok: false, error: 'The discount must be a whole, non-negative amount.' }
  }
  if (!Number.isInteger(input.bps) || input.bps < 0 || input.bps > MAX_BPS) {
    return { ok: false, error: 'The discount percentage must be between 0 and 100.' }
  }

  return {
    ok: true,
    value: {
      kind: input.kind,
      amountCentavos: input.amountCentavos,
      bps: input.bps,
      mode: input.mode,
    },
  }
}

export type DiscountLineInput = {
  productId: number
  quantity: number
  priceCentavos: number
  categoryId: number
  /** The product's unit, so a discount scoped to bags skips the kilo lines. */
  unit: string
}

export type DiscountedLine = DiscountLineInput & {
  /** The per-unit discount actually granted; stored as `discountAtSale`. */
  discountPerUnitCentavos: number
  lineTotalCentavos: number
}

export type OrderTotals = {
  lines: DiscountedLine[]
  /** List price × quantity, summed, before any discount at all. */
  subtotalCentavos: number
  /** Everything taken off per unit, summed across lines. */
  lineDiscountCentavos: number
  /** The order-level slice of the customer's standing discount. */
  customerDiscountCentavos: number
  /** The ad-hoc discount typed at the counter. */
  orderDiscountCentavos: number
  /** Every discount added together — what a receipt prints on one line. */
  totalDiscountCentavos: number
  /** What is actually owed. Never negative. */
  totalCentavos: number
}

/** Rounds half away from zero, like every other money conversion here. */
export function percentOf(centavos: number, bps: number): number {
  return Math.round((centavos * bps) / MAX_BPS)
}

/** Whether a discount would actually take anything off. */
export function hasOrderDiscount(discount: OrderDiscount | null): boolean {
  if (!discount) return false
  return discount.kind === 'PERCENT' ? discount.bps > 0 : discount.amountCentavos > 0
}

function perUnitDiscountFor(
  line: DiscountLineInput,
  customer: CustomerDiscount | null,
): number {
  if (!customer) return 0
  if (customer.basis !== 'PER_UNIT') return 0
  if (!customer.categoryIds.has(line.categoryId)) return 0
  if (!unitMatches(line.unit, customer.unit)) return 0

  const raw =
    customer.kind === 'PERCENT'
      ? percentOf(line.priceCentavos, customer.bps)
      : customer.amountCentavos

  // Floored at the price. A discount bigger than the item makes it free; it
  // never makes the line negative, which would have the store paying someone
  // to take the sack away.
  return Math.min(Math.max(0, raw), line.priceCentavos)
}

/**
 * The whole discount pipeline, in the order the design fixed:
 *
 *   1. per-unit customer discount off each line
 *   2. order-level customer discount off that subtotal
 *   3. ad-hoc counter discount off what remains
 *
 * A percentage at step 3 is therefore taken against the already-discounted
 * figure, not the list subtotal. That ordering is arbitrary in principle but
 * has to be fixed in practice, or "10% off" means two different pesos
 * depending on which code path computed it.
 */
export function computeOrderTotals(input: {
  lines: readonly DiscountLineInput[]
  customer?: CustomerDiscount | null
  order?: OrderDiscount | null
}): OrderTotals {
  const order = input.order ?? null

  // REPLACE only bites when an ad-hoc discount was actually entered. Leaving
  // the mode on "instead of" with an empty amount field must not silently
  // strip a customer of the discount they are owed.
  const replacing = order !== null && order.mode === 'REPLACE' && hasOrderDiscount(order)
  const customer = replacing ? null : (input.customer ?? null)

  const lines: DiscountedLine[] = input.lines.map((line) => {
    const discountPerUnitCentavos = perUnitDiscountFor(line, customer)
    return {
      ...line,
      discountPerUnitCentavos,
      lineTotalCentavos: lineTotal(
        line.priceCentavos - discountPerUnitCentavos,
        line.quantity,
      ),
    }
  })

  const subtotalCentavos = input.lines.reduce(
    (total, line) => total + lineTotal(line.priceCentavos, line.quantity),
    0,
  )
  const afterLines = lines.reduce((total, line) => total + line.lineTotalCentavos, 0)
  const lineDiscountCentavos = subtotalCentavos - afterLines

  const customerDiscountCentavos =
    customer && customer.basis === 'ORDER_TOTAL'
      ? clamp(
          customer.kind === 'PERCENT'
            ? percentOf(afterLines, customer.bps)
            : customer.amountCentavos,
          afterLines,
        )
      : 0

  const afterCustomer = afterLines - customerDiscountCentavos

  const orderDiscountCentavos =
    order && hasOrderDiscount(order)
      ? clamp(
          order.kind === 'PERCENT'
            ? percentOf(afterCustomer, order.bps)
            : order.amountCentavos,
          afterCustomer,
        )
      : 0

  return {
    lines,
    subtotalCentavos,
    lineDiscountCentavos,
    customerDiscountCentavos,
    orderDiscountCentavos,
    totalDiscountCentavos:
      lineDiscountCentavos + customerDiscountCentavos + orderDiscountCentavos,
    totalCentavos: afterCustomer - orderDiscountCentavos,
  }
}

/** Keeps a discount inside [0, ceiling]. Nothing takes off more than is there. */
function clamp(value: number, ceiling: number): number {
  return Math.min(Math.max(0, value), Math.max(0, ceiling))
}
