/** All boundaries are local time — the store owner's clock, not UTC. */

export function startOfDay(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate())
}

export function startOfWeek(d: Date): Date {
  const start = startOfDay(d)
  // getDay(): 0 = Sunday. Shift so Monday is 0.
  const offset = (start.getDay() + 6) % 7
  start.setDate(start.getDate() - offset)
  return start
}

export function startOfMonth(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), 1)
}

export function addDays(d: Date, n: number): Date {
  const next = new Date(d)
  next.setDate(next.getDate() + n)
  return next
}

/**
 * Adds whole months, clamping to the last day of the target month.
 *
 * `setMonth` alone overflows: 31 January + 1 month becomes 3 March, because
 * 31 February does not exist and the Date rolls forward. On an instalment
 * schedule that error compounds — every later due date inherits the slip, and
 * a plan started on the 31st drifts a few days further out every month.
 *
 * Returns local midnight, like every other boundary in this file.
 */
export function addMonthsClamped(d: Date, months: number): Date {
  const day = d.getDate()
  // The 1st always exists in every month, so this arithmetic cannot overflow.
  const target = new Date(d.getFullYear(), d.getMonth() + months, 1)
  // Day 0 of the following month is the last day of the target month.
  const lastDay = new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate()
  target.setDate(Math.min(day, lastDay))
  return target
}

export function dayKey(d: Date): string {
  const month = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${d.getFullYear()}-${month}-${day}`
}

/** Strictly parses an HTML date input as local midnight. `new Date(raw)` is
 * deliberately avoided: date-only ISO strings are UTC and can become the
 * previous calendar day in the store's timezone. */
export function parseDayKey(raw: string): Date | null {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(raw)
  if (!match) return null

  const year = Number(match[1])
  const month = Number(match[2])
  const day = Number(match[3])
  const parsed = new Date(year, month - 1, day)

  if (
    parsed.getFullYear() !== year ||
    parsed.getMonth() !== month - 1 ||
    parsed.getDate() !== day
  ) {
    return null
  }
  return parsed
}
