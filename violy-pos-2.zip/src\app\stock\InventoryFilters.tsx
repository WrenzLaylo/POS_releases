'use client'

import { useRef } from 'react'
import { usePathname, useRouter } from 'next/navigation'
import { Button } from '@/components/ui/Button'
import { Field } from '@/components/ui/Field'
import { FilterChips } from '@/components/ui/FilterChips'
import { Input } from '@/components/ui/Input'
import { STOCK_LEVEL_OPTIONS } from '@/lib/stock-level'
import type { ReactNode } from 'react'

export function InventoryFilters({
  categories,
  q,
  category,
  stock,
  archived,
  action,
}: {
  categories: { id: number; name: string }[]
  q?: string
  category?: string
  stock?: string
  archived?: string
  /** The screen's primary action, placed on the filter row's right edge. */
  action?: ReactNode
}) {
  const router = useRouter()
  const pathname = usePathname()

  const searchRef = useRef<HTMLInputElement>(null)
  const archivedRef = useRef<HTMLInputElement>(null)

  // Chips apply the moment they are tapped — no separate submit — so they
  // behave like filters rather than form fields.
  //
  // Search and Show-archived are read from the LIVE inputs, not from the `q`
  // and `archived` props. The props hold what the URL last committed, so using
  // them would throw away anything typed or ticked since: type "starter", tap
  // a chip, and the navigation re-mounts the field at its stale `defaultValue`,
  // wiping the text. Reading the DOM keeps an uncommitted filter alive across
  // a chip tap, without `useSearchParams` and the Suspense boundary that would
  // demand.
  //
  // Written as a patch over the current values rather than one function per
  // chip row. With two rows and a third plausible, "rebuild the whole query
  // string, remembering every other facet" is the step that gets forgotten,
  // and forgetting it silently drops a filter the operator can still see
  // selected on screen.
  function apply(patch: { category?: string; stock?: string }) {
    const params = new URLSearchParams()
    const search = searchRef.current?.value ?? q ?? ''
    const showArchived = archivedRef.current?.checked ?? archived === '1'
    const nextCategory = patch.category ?? category ?? ''
    const nextStock = patch.stock ?? stock ?? ''

    if (search) params.set('q', search)
    if (showArchived) params.set('archived', '1')
    if (nextCategory) params.set('category', nextCategory)
    if (nextStock) params.set('stock', nextStock)
    // Page 4 of the old filter is meaningless under the new one.
    params.set('page', '1')
    router.push(`${pathname}?${params.toString()}`)
  }

  const brandOptions = [
    { value: '', label: 'All brands' },
    ...categories.map((c) => ({ value: String(c.id), label: c.name })),
  ]

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap gap-x-8 gap-y-4">
        <FilterChips
          label="Brand"
          ariaLabel="Filter by brand"
          options={brandOptions}
          value={category ?? ''}
          onChange={(value) => apply({ category: value })}
        />

        {/* The facet this table was missing. Every product reads "0 left"
            until stock is counted in, and once it is, the question she
            actually asks the Stock screen is "what do I need to reorder" —
            which no amount of scrolling a name-sorted list answers. */}
        <FilterChips
          label="Stock level"
          ariaLabel="Filter by stock level"
          options={STOCK_LEVEL_OPTIONS}
          value={stock ?? ''}
          onChange={(value) => apply({ stock: value })}
        />
      </div>

      <form className="flex flex-wrap items-end gap-3">
        <input type="hidden" name="page" value="1" />
        {/* The chips above put these on the URL; these hidden fields stop
            Filter's submit from dropping them. */}
        <input type="hidden" name="category" value={category ?? ''} />
        <input type="hidden" name="stock" value={stock ?? ''} />

        <Field label="Search">
          <Input
            ref={searchRef}
            type="search"
            name="q"
            defaultValue={q ?? ''}
            placeholder="Product name"
            className="w-64"
          />
        </Field>

        <label className="flex h-10 items-center gap-2 text-sm text-ink">
          <input
            ref={archivedRef}
            type="checkbox"
            name="archived"
            value="1"
            defaultChecked={archived === '1'}
            className="h-4 w-4"
          />
          Show archived
        </label>

        <Button type="submit" variant="secondary" size="wide">
          Filter
        </Button>

        {/* Pushed to the right edge of this same row. It used to sit in its
            own full-width block below, which left a band of empty page
            between the filters and the table and made the primary action look
            stranded. */}
        {action && <div className="ml-auto">{action}</div>}
      </form>
    </div>
  )
}
