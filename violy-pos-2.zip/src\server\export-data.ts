'use server'

import { prisma } from '@/lib/db'
import { centavosToCsv, toCsv } from '@/lib/csv'
import { dayKey } from '@/lib/dates'
import { sumBalance } from '@/lib/ledger-balance'
import type { ExportTable } from '@/lib/export-tables'

/**
 * A table as CSV text.
 *
 * Money is written as decimal pesos, not the integer centavos the database
 * holds: this file is going into a spreadsheet where someone will sum a
 * column, and a column of centavos sums to a number a hundred times too big.
 * `products` and `customers` are shaped to match what the importer reads, so
 * an export can be edited and sent straight back.
 */
export async function exportTableCsv(table: ExportTable): Promise<string> {
  switch (table) {
    case 'products': {
      const rows = await prisma.product.findMany({
        include: { category: { select: { name: true } } },
        orderBy: [{ name: 'asc' }],
      })
      return toCsv(
        ['name', 'category', 'unit', 'price', 'cost', 'stock', 'low_stock_at', 'archived'],
        rows.map((product) => [
          product.name,
          product.category.name,
          product.unit,
          centavosToCsv(product.price),
          centavosToCsv(product.costPrice),
          String(product.stockQty),
          String(product.lowStockThreshold),
          product.isArchived ? 'yes' : 'no',
        ]),
      )
    }

    case 'customers': {
      const rows = await prisma.customer.findMany({
        include: {
          entries: {
            where: { isVoided: false },
            select: { id: true, type: true, amountCentavos: true, isVoided: true },
          },
        },
        orderBy: [{ name: 'asc' }],
      })
      return toCsv(
        ['name', 'phone', 'notes', 'discount_kind', 'discount_value', 'discount_basis', 'balance', 'archived'],
        rows.map((customer) => [
          customer.name,
          customer.phone ?? '',
          customer.notes,
          customer.discountKind,
          // The value column follows the kind: pesos for AMOUNT, percent for
          // PERCENT. Two columns, one of which is always blank, is worse to
          // read and worse to edit.
          customer.discountKind === 'PERCENT'
            ? String(customer.discountBps / 100)
            : centavosToCsv(customer.discountCentavos),
          customer.discountBasis,
          centavosToCsv(sumBalance(customer.entries)),
          customer.isArchived ? 'yes' : 'no',
        ]),
      )
    }

    case 'sales': {
      const rows = await prisma.sale.findMany({
        include: { customer: { select: { name: true } } },
        orderBy: [{ createdAt: 'desc' }],
      })
      return toCsv(
        ['date', 'reference', 'customer', 'total', 'cash_kept', 'change', 'discount', 'voided'],
        rows.map((sale) => [
          dayKey(sale.createdAt),
          String(sale.id),
          sale.customer?.name ?? 'Walk-in',
          centavosToCsv(sale.totalAmount),
          centavosToCsv(sale.cashPaidCentavos),
          centavosToCsv(sale.changeCentavos),
          centavosToCsv(sale.customerDiscountCentavos + sale.orderDiscountCentavos),
          sale.isVoided ? 'yes' : 'no',
        ]),
      )
    }

    case 'ledger': {
      const rows = await prisma.ledgerEntry.findMany({
        include: { customer: { select: { name: true } } },
        orderBy: [{ occurredAt: 'asc' }, { id: 'asc' }],
      })
      return toCsv(
        ['date', 'customer', 'type', 'amount', 'note', 'sale_id', 'plan_id', 'voided'],
        rows.map((entry) => [
          dayKey(entry.occurredAt),
          entry.customer.name,
          entry.type,
          centavosToCsv(entry.amountCentavos),
          entry.note,
          entry.saleId === null ? '' : String(entry.saleId),
          entry.planId === null ? '' : String(entry.planId),
          entry.isVoided ? 'yes' : 'no',
        ]),
      )
    }
  }
}
