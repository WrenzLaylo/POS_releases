'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import type { ProductWithCategory } from '@/lib/types'
import { lineTotal } from '@/lib/money'
import { groupByCategory, matchesSearch, soleMatch, suggestProducts } from '@/lib/catalog'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Dialog } from '@/components/ui/Dialog'
import { Input } from '@/components/ui/Input'
import { EmptyState } from '@/components/ui/EmptyState'
import { Money } from '@/components/ui/Money'
import { ProductImage } from '@/components/ui/ProductImage'
import { SegmentedControl } from '@/components/ui/SegmentedControl'
import { cn } from '@/lib/cn'

type CatalogView = 'cards' | 'list'

const VIEW_OPTIONS = [
  { value: 'cards', label: 'Cards' },
  { value: 'list', label: 'List' },
] as const

const VIEW_STORAGE_KEY = 'violy.catalog-view'

/** Everything a product needs to draw itself, whichever shape it draws in. */
type TileProps = {
  product: ProductWithCategory
  quantity: number
  highlighted: boolean
  /** The pulse's tick, or null when this product is not pulsing. */
  pulseTick: number | null
  onRequestChange: (productId: number, quantity: number) => void
}

export function CatalogColumn({
  products,
  quantities,
  onChange,
  search,
  onSearchChange,
  resetKey,
}: {
  products: ProductWithCategory[]
  quantities: Map<number, number>
  onChange: (productId: number, quantity: number) => void
  search: string
  onSearchChange: (value: string) => void
  resetKey: number
}) {
  // Trimmed and lowercased once, here, and reused for every display/filter
  // decision below. `matchesSearch`/`soleMatch` also trim+lowercase the
  // needle they're given internally, so re-passing this already-normalised
  // string to them is idempotent, not a double-trim bug — trimming a
  // trimmed string and lowercasing a lowercased one are both no-ops. The one
  // exception is the Enter fast path, which deliberately passes the raw
  // `search` prop straight to `soleMatch`, matching the call the brief
  // specifies, since `soleMatch` itself decides what counts as empty.
  const needle = search.trim().toLowerCase()

  // Grouped from the full, unfiltered catalog — not the search-narrowed
  // list — so a category chip's "selected" count never shrinks just because
  // a search hides some of its matches, and the chip list itself never
  // reshuffles while typing.
  const groups = groupByCategory(products)

  // `null` means "All" — every category's products, flattened into one
  // grid. No accordion, no per-category open/closed state: a chip is either
  // the active filter or it isn't.
  const [activeCategory, setActiveCategory] = useState<string | null>(null)

  // Cards or list. Cards show a photo and survive a narrow column; the list
  // fits roughly twice as many products on a shop laptop and never truncates
  // a name, because a row has the catalog's whole width to spend on one
  // product instead of dividing it between six.
  //
  // Deliberately NOT reset by `resetKey`: the chip and the highlight go back
  // to their defaults after a save because they belong to the sale that just
  // ended, but how she prefers to read the catalog is not part of a sale.
  const [view, setView] = useState<CatalogView>('cards')

  // Read AFTER mount, never in the useState initialiser: the initialiser runs
  // on the server pass too, where localStorage does not exist — and a value
  // read there would disagree with the server's HTML and warn about hydration.
  // Same reasoning as `AppRail`.
  useEffect(() => {
    if (window.localStorage.getItem(VIEW_STORAGE_KEY) === 'list') setView('list')
  }, [])

  function chooseView(next: CatalogView) {
    setView(next)
    window.localStorage.setItem(VIEW_STORAGE_KEY, next)
  }

  // A fresh sale starts back at "All" rather than remembering whatever chip
  // was last tapped — mirrors the old accordion's reset-to-first-category
  // behaviour after Save order. The keyboard highlight resets alongside it
  // for the same reason: a highlighted product from the last sale should
  // not survive into the next one.
  useEffect(() => {
    setActiveCategory(null)
    setHighlightedId(null)
    setPendingOversell(null)
    setOversellApproved(new Set())
  }, [resetKey])

  const searching = needle.length > 0

  // Search always looks across the whole catalog, active chip or not — the
  // same trade the old accordion made by forcing every section open while
  // typing. Otherwise, the active chip narrows to its category, or "All"
  // passes everything through untouched.
  const scoped = activeCategory
    ? (groups.find((g) => g.categoryName === activeCategory)?.products ?? [])
    : products

  // Searching deliberately reads `products`, not `scoped`. The Enter fast
  // path below calls `soleMatch(products, …)` against the whole catalog, so
  // narrowing the grid to the active chip would let Enter add an item the
  // grid had just declared missing — "No products match" on screen while a
  // line quietly appears in the rail.
  const visibleProducts = searching ? products.filter((p) => matchesSearch(p, needle)) : scoped

  // Computed only when the search actually found nothing. It walks the whole
  // catalog scoring edit distances, and there is nothing to suggest while real
  // matches are on screen.
  const suggestions = useMemo(
    () => (searching && visibleProducts.length === 0 ? suggestProducts(products, needle) : []),
    [searching, visibleProducts.length, products, needle],
  )

  // { id, tick } rather than just the product id. `tick` restarts the
  // clear-after-600ms effect below, but its real job is downstream: a
  // small overlay inside the card (not the card itself) is keyed on it, so
  // a repeat tap on the same product changes that key and forces React to
  // remount just the overlay. A CSS animation does not restart while its
  // class stays applied across a re-render — only a remount replays it from
  // its first keyframe. The card and its stepper buttons keep a stable key
  // so focus survives both the tap and the 600ms timer expiry.
  const [pulse, setPulse] = useState<{ id: number; tick: number } | null>(null)

  // The keyboard-navigated product, independent of quantity or focus.
  // `null` means nothing is highlighted, which is also the state after a
  // save, a category switch invalidates the previous highlight, or Esc.
  const [highlightedId, setHighlightedId] = useState<number | null>(null)
  const [pendingOversell, setPendingOversell] = useState<{
    productId: number
    name: string
    stockQty: number
    quantity: number
  } | null>(null)
  const [oversellApproved, setOversellApproved] = useState<Set<number>>(new Set())

  function commitChange(productId: number, quantity: number) {
    onChange(productId, quantity)
    setPulse((previous) => ({ id: productId, tick: (previous?.tick ?? 0) + 1 }))
  }

  function requestChange(productId: number, quantity: number) {
    const product = products.find((candidate) => candidate.id === productId)
    const current = quantities.get(productId) ?? 0
    const crossingIntoNegative =
      product && quantity > product.stockQty && quantity > current && !oversellApproved.has(productId)

    if (crossingIntoNegative) {
      setPendingOversell({
        productId,
        name: product.name,
        stockQty: product.stockQty,
        quantity,
      })
      return
    }
    commitChange(productId, quantity)
  }

  useEffect(() => {
    if (pulse === null) return
    const timer = setTimeout(() => setPulse(null), 600)
    return () => clearTimeout(timer)
  }, [pulse])

  const searchRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    searchRef.current?.focus()
  }, [])

  // One listener for every catalog shortcut, so "ignore while typing" is
  // enforced in exactly one place rather than duplicated per key. Esc is
  // the sole exception — it must still clear the highlight and the search
  // box even when the search input itself has focus, which is also why it
  // is checked before, not after, the typing guard below.
  //
  // Cards and list behave identically here: every shortcut is driven by
  // `visibleProducts`, the same ordered list whichever shape it is drawn in,
  // so nothing below needs to know which view is showing.
  //
  // These were dead for a while, and why is worth keeping. The guard below
  // bails on any open listbox, and `CustomerCombobox` used to open its own on
  // mount and hold it there until a customer was picked — so every shortcut
  // here was disabled from page load, on the screen they exist to speed up.
  // Fixed in the combobox, which now opens only when she touches the customer
  // field, rather than by teaching this guard about one particular component.
  // If they ever go quiet again, look for a `role="dialog"` or
  // `role="listbox"` left open on screen before suspecting this handler.
  //
  // No key here ever calls `onChange` with anything but a quantity, and
  // nothing here can reach `save()` — Enter is deliberately unbound. The
  // only thing a stray keypress can do is add or remove catalog lines,
  // which still requires a separate, deliberate click on Save to become
  // money.
  useEffect(() => {
    function onKeyDown(event: KeyboardEvent) {
      // Bail out entirely while any transient overlay is open: the ⌘K
      // command palette, any Dialog/Drawer/Popover (all built on `Overlay`,
      // which always renders its surface with role="dialog" into a portal
      // on document.body), or the customer combobox's dropdown
      // (`CustomerCombobox`, role="listbox" — it is NOT `Overlay`-based,
      // and its own Escape handler does not stopPropagation). All three are
      // surfaces the operator expects Escape to close without side effects
      // behind them. Without this guard, Escape dismissing any of them
      // would also silently clear this search box, and `/` would reach
      // past the overlay's own focus trap to focus this input instead —
      // one check guarding the whole handler, not one per key.
      if (document.querySelector('[role="dialog"], [role="listbox"]')) return

      if (event.key === 'Escape') {
        setHighlightedId(null)
        onSearchChange('')
        return
      }

      const target = event.target as HTMLElement | null
      const typing =
        !!target && (target.tagName === 'INPUT' || target.tagName === 'SELECT' || target.tagName === 'TEXTAREA')
      if (typing) return

      if (event.key === '/') {
        event.preventDefault()
        searchRef.current?.focus()
        return
      }

      if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
        if (visibleProducts.length === 0) return
        event.preventDefault()
        const current =
          highlightedId === null ? -1 : visibleProducts.findIndex((p) => p.id === highlightedId)
        const next =
          event.key === 'ArrowDown'
            ? Math.min(current + 1, visibleProducts.length - 1)
            : Math.max(current - 1, 0)
        setHighlightedId(visibleProducts[next]?.id ?? null)
        return
      }

      if (event.key === '+' || event.key === '-') {
        if (highlightedId === null) return
        event.preventDefault()
        const quantity = quantities.get(highlightedId) ?? 0
        const nextQuantity = event.key === '-' ? Math.max(0, quantity - 1) : quantity + 1
        requestChange(highlightedId, nextQuantity)
      }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [visibleProducts, highlightedId, quantities, onSearchChange, products, oversellApproved])

  return (
    // A full-height column on wide screens: the header, the brand chips and
    // the search box stay put, and only the products move. Before this the
    // page itself scrolled, which carried the running total, the cash field
    // and "Save order" off the top — a till cannot hide the total while
    // somebody is still adding sacks to the order.
    <Card className="lg:flex lg:h-full lg:min-h-0 lg:flex-col">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-base font-semibold">Products</h2>
        <div className="flex flex-wrap items-center gap-2">
          <Input
            ref={searchRef}
            type="search"
            value={search}
            onChange={(e) => onSearchChange(e.target.value)}
            onKeyDown={(event) => {
              if (event.key !== 'Enter') return
              const only = soleMatch(products, search)
              if (!only) return
              event.preventDefault()
              requestChange(only.id, (quantities.get(only.id) ?? 0) + 1)
              onSearchChange('')
            }}
            placeholder="Search products"
            className="w-64"
          />
          {/* Words, not two icons. A grid glyph and a list glyph are a
              convention for people who already know the convention, and this
              till is used by somebody who should not have to learn one. */}
          <SegmentedControl
            ariaLabel="Catalog view"
            options={VIEW_OPTIONS}
            value={view}
            onValueChange={(value) => chooseView(value === 'list' ? 'list' : 'cards')}
          />
        </div>
      </div>

      {/* The strip runs along the top at every width. As a sidebar it cost
          the grid a fixed 160px column and truncated the longer category
          names into "Medicine and Vi…"; wrapping across the full width costs
          one row of chips and gives every name room to be read. `h-9` on
          every chip is the sanctioned bespoke exception. */}
      <div className="lg:flex lg:min-h-0 lg:flex-1 lg:flex-col">
        <div className="flex flex-col gap-4 lg:min-h-0 lg:flex-1">
          <div className="shrink-0 flex flex-row flex-wrap gap-1 border-b border-line pb-3">
          <button
            type="button"
            onClick={() => setActiveCategory(null)}
            aria-pressed={activeCategory === null}
            className={cn(
              'flex h-9 items-center rounded-control px-3 text-left text-sm font-medium transition-colors duration-150',
              activeCategory === null
                ? 'bg-accent-soft text-accent'
                : 'text-ink-muted hover:bg-surface-sunk hover:text-ink',
            )}
          >
            All
          </button>
          {groups.map((group) => {
            // Tallied against the full, unfiltered category — not the
            // search-narrowed view — so the badge cannot shrink just
            // because a search hides some of her taps.
            const selectedCount = group.products.filter(
              (p) => (quantities.get(p.id) ?? 0) > 0,
            ).length
            const active = activeCategory === group.categoryName
            return (
              <button
                key={group.categoryName}
                type="button"
                onClick={() => setActiveCategory(group.categoryName)}
                aria-pressed={active}
                className={cn(
                  'flex h-9 items-center justify-between gap-2 rounded-control px-3 text-left text-sm font-medium transition-colors duration-150',
                  active
                    ? 'bg-accent-soft text-accent'
                    : 'text-ink-muted hover:bg-surface-sunk hover:text-ink',
                )}
              >
                <span>{group.categoryName}</span>
                {selectedCount > 0 && (
                  <span className="inline-flex h-5 min-w-5 shrink-0 items-center justify-center rounded-full bg-accent px-1.5 text-xs font-semibold text-canvas">
                    {selectedCount}
                  </span>
                )}
              </button>
            )
          })}
          </div>

          <div className="min-w-0 lg:-mr-2 lg:min-h-0 lg:flex-1 lg:overflow-y-auto lg:pr-2">
            {visibleProducts.length === 0 ? (
              searching ? (
                <div className="rounded-card border border-line bg-surface-sunk p-6 text-center">
                  <p className="text-sm text-ink-muted">
                    No products match &quot;{needle}&quot;.
                  </p>

                  {/* "Did you mean". Offered as real Add buttons rather than
                      as text, because the answer to "I mistyped it" is the
                      product, not a spelling lesson. */}
                  {suggestions.length > 0 && (
                    <div className="mt-4">
                      <p className="text-xs font-semibold uppercase tracking-wide text-ink-subtle">
                        Did you mean
                      </p>
                      <div className="mt-2 flex flex-wrap justify-center gap-2">
                        {suggestions.map((product) => (
                          <button
                            key={product.id}
                            type="button"
                            onClick={() => {
                              requestChange(product.id, (quantities.get(product.id) ?? 0) + 1)
                              onSearchChange('')
                            }}
                            className="inline-flex h-9 items-center gap-2 rounded-control border border-line-strong bg-surface px-3 text-sm font-medium transition-colors duration-150 hover:border-accent hover:bg-accent-soft hover:text-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                          >
                            {product.name}
                            <Money centavos={product.price} scale="body" className="text-ink-muted" />
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <EmptyState>No products in this category.</EmptyState>
              )
            ) : view === 'list' ? (
              // One bordered container with hairlines between rows, rather
              // than a border per row: at forty products, a box each turns
              // the list into a stack of boxes and the eye stops reading it
              // as one column of prices.
              <div className="overflow-hidden rounded-card border border-line">
                {visibleProducts.map((product) => (
                  <ProductRow
                    key={product.id}
                    product={product}
                    quantity={quantities.get(product.id) ?? 0}
                    highlighted={highlightedId === product.id}
                    pulseTick={pulse?.id === product.id ? pulse.tick : null}
                    onRequestChange={requestChange}
                  />
                ))}
              </div>
            ) : (
              /* `auto-fill` + `minmax`, not `grid-cols-N` breakpoints. Tailwind's
                 `sm:`/`xl:` respond to the VIEWPORT, but this grid is a column
                 that has already given up ~220px of rail, ~384px of order panel
                 and ~188px of category list. At a 1280px viewport `xl:grid-cols-4`
                 fired while the container was ~400px wide, giving 88px cards that
                 truncated every product name. The grid now counts its own columns
                 from the space it actually has, so it stays correct at any width
                 and when the rail collapses.

                 13rem, not 9.5rem. At 9.5rem this packed eight ~157px columns
                 into the catalog, and "ADM Broodsow (sako)" needs about 150px
                 at this size — so nearly every feed truncated, and it
                 truncated at the DISTINGUISHING word. "ADM Broods…",
                 "AMO Grower (sa…" and "ADM Gold Mix (s…" all read alike at a
                 glance, which is a picking-error risk rather than merely an
                 ugly one. */
              <div className="grid gap-4 [grid-template-columns:repeat(auto-fill,minmax(13rem,1fr))]">
                {visibleProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    quantity={quantities.get(product.id) ?? 0}
                    highlighted={highlightedId === product.id}
                    pulseTick={pulse?.id === product.id ? pulse.tick : null}
                    onRequestChange={requestChange}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      <Dialog
        open={pendingOversell !== null}
        onOpenChange={(open) => {
          if (!open) setPendingOversell(null)
        }}
        title="Stock will go negative"
        description={
          pendingOversell
            ? `${pendingOversell.name} has only ${pendingOversell.stockQty} in stock.`
            : undefined
        }
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setPendingOversell(null)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                if (!pendingOversell) return
                const approved = new Set(oversellApproved)
                approved.add(pendingOversell.productId)
                setOversellApproved(approved)
                commitChange(pendingOversell.productId, pendingOversell.quantity)
                setPendingOversell(null)
              }}
            >
              Continue anyway
            </Button>
          </div>
        }
      >
        {pendingOversell && (
          <p className="text-sm text-ink-muted">
            This quantity would leave{' '}
            <span className="font-mono font-semibold text-warn">
              {pendingOversell.stockQty - pendingOversell.quantity}
            </span>{' '}
            in stock. Confirm only when the physical stock is available and the inventory count will be corrected.
          </p>
        )}
      </Dialog>
    </Card>
  )
}

/**
 * The card: a photo, a name with room to wrap, and a whole-face Add target.
 *
 * The card is a non-interactive `role="group"`. Its Add surface and its two
 * steppers are SIBLING buttons, never nested inside one another — a button
 * inside a button is invalid, and keyboard and screen-reader users end up
 * unable to reach the inner one.
 */
function ProductCard({ product, quantity, highlighted, pulseTick, onRequestChange }: TileProps) {
  const low = product.stockQty <= product.lowStockThreshold

  return (
    <div
      role="group"
      aria-label={product.name}
      className={cn(
        // `border-2`, not the hairline. A 1px line at this card size read as
        // a faint suggestion of a boundary rather than an edge, and the cards
        // ran together.
        'flex flex-col overflow-hidden rounded-card border-2 transition-colors duration-150',
        quantity > 0
          ? // Full `accent-soft`, not `/40`. On the dark theme this was a dark
            // navy that needed knocking back; the light tint it became is
            // already pale, and at 40% over white the "in this order" state
            // was invisible.
            'border-accent bg-accent-soft'
          : 'border-line bg-surface hover:border-line-strong',
        highlighted && 'ring-2 ring-accent ring-offset-2 ring-offset-canvas',
      )}
    >
      {/* Still the big tap target for adding — the whole card face, not just
          the small button below it. */}
      <button
        type="button"
        aria-label={`Add one ${product.name} to the order`}
        onClick={() => onRequestChange(product.id, quantity + 1)}
        className="group flex flex-1 cursor-pointer flex-col text-left transition-colors duration-150 hover:bg-surface-sunk focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-accent"
      >
        {/* Only reserve the 4:3 well when there is actually a photo to put in
            it. With no images the placeholder was spending ~145px of every
            card — the tallest element on screen — to show nothing, and cut the
            catalog to six visible products on a shop laptop. A card with no
            photo is now just its text. */}
        {product.imagePath && (
          <div className="aspect-[4/3] w-full shrink-0 bg-surface-sunk">
            <ProductImage
              src={product.imagePath}
              className="h-full w-full"
              fallbackClassName="h-full w-full"
            />
          </div>
        )}

        {/* `isolate` gives the pulse overlay its own stacking context so the
            wash stays behind the product text. */}
        <div className="relative isolate flex flex-1 flex-col gap-3 p-4 pb-3">
          {pulseTick !== null && (
            <div
              key={pulseTick}
              aria-hidden="true"
              className="animate-row-pulse pointer-events-none absolute inset-0 -z-10"
            />
          )}

          <div className="min-w-0">
            {/* Two lines rather than one truncated one. The name is the only
                thing on this card that tells two similar sacks apart, so it is
                the last thing that should be cut. */}
            <div className="line-clamp-2 text-sm font-medium leading-snug">{product.name}</div>
            <div className="mt-0.5 truncate text-xs text-ink-subtle">{product.unit}</div>
          </div>

          {quantity === 0 && (
            <span
              aria-hidden="true"
              className="order-last mt-1 flex h-8 w-full items-center justify-center rounded-lg border border-line-strong text-sm font-medium text-ink-muted transition-colors duration-150 group-hover:border-accent group-hover:bg-accent-soft group-hover:text-accent"
            >
              Add
            </span>
          )}

          {/* Price and stock share a line: they are read together ("how much,
              and is there any"), and stacking them was two of the four tiers
              that made this card feel like a paragraph. */}
          <div className="mt-auto flex items-baseline justify-between gap-2">
            <Money centavos={product.price} scale="body" className="font-medium" />
            <span
              className={cn(
                'font-mono text-xs tabular-nums text-ink-subtle',
                low && 'font-semibold text-warn',
              )}
            >
              {product.stockQty} left
            </span>
          </div>
        </div>
      </button>

      {/* The stepper appears only once the item is in the order. On every card
          at once it was a screenful of permanent zeros for a sale that normally
          holds one to three lines — and it made a selected card look much like
          an untouched one. An idle card offers a single Add target; a selected
          card shows the count and what that line comes to, which is the number
          she reads out. */}
      {quantity > 0 && (
        <div className="border-t border-line px-3 py-2">
          <div className="flex items-center justify-between gap-2">
            <button
              type="button"
              aria-label={`Decrease ${product.name}`}
              onClick={() => onRequestChange(product.id, Math.max(0, quantity - 1))}
              className="h-8 w-8 shrink-0 rounded-lg border border-line-strong text-base leading-none transition-colors duration-150 hover:bg-surface-sunk focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2"
            >
              −
            </button>
            <span className="text-sm font-semibold tabular-nums" aria-live="polite">
              {quantity}
            </span>
            <button
              type="button"
              aria-label={`Increase ${product.name}`}
              onClick={() => onRequestChange(product.id, quantity + 1)}
              className="h-8 w-8 shrink-0 rounded-lg border border-line-strong text-base leading-none transition-colors duration-150 hover:bg-surface-sunk focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2"
            >
              +
            </button>
            <Money
              centavos={lineTotal(product.price, quantity)}
              className="ml-1 min-w-0 flex-1 truncate text-right font-semibold"
            />
          </div>
        </div>
      )}
    </div>
  )
}

/**
 * The row: the same product, laid out as a line in a price list.
 *
 * The reason to offer this at all is that a row owns the catalog's full width.
 * A card divides that width by six, which is what forced product names onto
 * two clamped lines and left "ADM Gold Mix (s…" as a real picking-error risk;
 * a row simply fits the name. It also fits roughly twice as many products on a
 * shop laptop, which matters when the catalog is forty sacks and the photo
 * would be an empty grey square for every one of them.
 *
 * The column widths are fixed rather than content-sized so that every peso
 * figure lines up down the page. That vertical alignment IS the feature —
 * comparing prices down a ragged right edge is the thing a list is supposed to
 * make easy.
 *
 * Structure mirrors the card exactly: a non-interactive `role="group"`, one
 * Add button, and steppers as its siblings. Notably the "Add" affordance lives
 * INSIDE the button rather than beside it — as a sibling it would look like a
 * button while doing nothing when clicked.
 */
function ProductRow({ product, quantity, highlighted, pulseTick, onRequestChange }: TileProps) {
  const low = product.stockQty <= product.lowStockThreshold

  return (
    <div
      role="group"
      aria-label={product.name}
      className={cn(
        // `relative isolate` so the pulse wash can sit behind this row's text.
        // The accent state is a left bar rather than the card's full border:
        // a 2px box around a row fights the hairlines separating it from its
        // neighbours, and the bar reads along the column instead of across it.
        'relative isolate flex items-center gap-2 border-l-4 pr-2 transition-colors duration-150',
        'border-b border-b-line last:border-b-0',
        quantity > 0
          ? 'border-l-accent bg-accent-soft'
          : 'border-l-transparent hover:bg-surface-sunk',
        // `ring-inset`: the container clips its overflow to keep the rounded
        // corners, so an outset ring would be cut off on the first and last
        // rows only — visible on some rows and not others.
        highlighted && 'ring-2 ring-inset ring-accent',
      )}
    >
      {pulseTick !== null && (
        <div
          key={pulseTick}
          aria-hidden="true"
          className="animate-row-pulse pointer-events-none absolute inset-0 -z-10"
        />
      )}

      <button
        type="button"
        aria-label={`Add one ${product.name} to the order`}
        onClick={() => onRequestChange(product.id, quantity + 1)}
        className="group flex min-w-0 flex-1 cursor-pointer items-center gap-3 py-1.5 pl-3 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-accent"
      >
        {/* Same rule as the card: no photo, no reserved space. A row of empty
            grey squares costs width that the name is the whole point of
            keeping. */}
        {product.imagePath && (
          <ProductImage
            src={product.imagePath}
            className="h-10 w-10 shrink-0 rounded-lg"
            fallbackClassName="h-10 w-10 shrink-0 rounded-lg"
          />
        )}

        {/* Name and unit on ONE line, unlike the card's two. The unit is four
            words at most ("sako (50kg)"), and giving it its own line spent
            16px on every row — a third of the row's height — to say something
            that fits in the gap after the name. One line is what makes this
            view worth switching to: twelve products on a shop laptop against
            the card grid's six. */}
        <span className="flex min-w-0 flex-1 items-baseline gap-2">
          <span className="truncate text-sm font-medium">{product.name}</span>
          <span className="shrink-0 text-xs text-ink-subtle">{product.unit}</span>
        </span>

        <Money centavos={product.price} scale="body" className="w-24 shrink-0 text-right font-medium" />

        <span
          className={cn(
            'w-20 shrink-0 text-right font-mono text-xs tabular-nums text-ink-subtle',
            low && 'font-semibold text-warn',
          )}
        >
          {product.stockQty} left
        </span>

        {quantity === 0 && (
          <span
            aria-hidden="true"
            className="flex h-8 w-28 shrink-0 items-center justify-end text-sm font-medium text-ink-subtle"
          >
            <span className="flex h-8 items-center rounded-lg border border-line-strong px-4 transition-colors duration-150 group-hover:border-accent group-hover:bg-accent-soft group-hover:text-accent">
              Add
            </span>
          </span>
        )}
      </button>

      {/* Exactly as wide as the Add slot it replaces, so the peso column does
          not shift sideways the moment something is added to the order.

          No line total here, unlike the card. The order rail is open beside
          this list showing every line and what it comes to, so repeating it in
          the row buys nothing and costs about 100px — which the product name,
          the one thing that tells two similar sacks apart, needs more. */}
      {quantity > 0 && (
        <div className="flex h-8 w-28 shrink-0 items-center gap-2">
          <button
            type="button"
            aria-label={`Decrease ${product.name}`}
            onClick={() => onRequestChange(product.id, Math.max(0, quantity - 1))}
            className="h-8 w-8 shrink-0 rounded-lg border border-line-strong text-base leading-none transition-colors duration-150 hover:bg-surface-sunk focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
          >
            −
          </button>
          <span className="min-w-0 flex-1 text-center text-sm font-semibold tabular-nums" aria-live="polite">
            {quantity}
          </span>
          <button
            type="button"
            aria-label={`Increase ${product.name}`}
            onClick={() => onRequestChange(product.id, quantity + 1)}
            className="h-8 w-8 shrink-0 rounded-lg border border-line-strong text-base leading-none transition-colors duration-150 hover:bg-surface-sunk focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
          >
            +
          </button>
        </div>
      )}
    </div>
  )
}
