import { listDeliveries, totalPayable } from '@/server/deliveries'
import { listSuppliers } from '@/server/suppliers'
import { parsePage } from '@/lib/pagination'
import { Pagination } from '@/components/Pagination'
import { PageHeader } from '@/components/ui/PageHeader'
import { DeliveriesScreen } from './DeliveriesScreen'

export const dynamic = 'force-dynamic'

type Props = {
  searchParams: Promise<{ page?: string; supplier?: string; unpaid?: string }>
}

export default async function DeliveriesPage({ searchParams }: Props) {
  const params = await searchParams
  const supplierId = Number(params.supplier)

  const [deliveries, suppliers, payable] = await Promise.all([
    listDeliveries(
      {
        supplierId: Number.isInteger(supplierId) && supplierId > 0 ? supplierId : undefined,
        unpaidOnly: params.unpaid === '1',
      },
      parsePage(params.page),
    ),
    listSuppliers(),
    totalPayable(),
  ])

  return (
    <PageHeader
      title="Deliveries"
      actions={<span className="text-sm text-ink-muted">{deliveries.total} recorded</span>}
    >
      <DeliveriesScreen
        deliveries={deliveries.rows}
        suppliers={suppliers}
        payableCentavos={payable}
        filters={{ supplier: params.supplier, unpaid: params.unpaid }}
      />

      <Pagination
        page={deliveries.page}
        pageCount={deliveries.pageCount}
        params={{ supplier: params.supplier, unpaid: params.unpaid }}
      />
    </PageHeader>
  )
}
