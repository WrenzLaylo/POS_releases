'use client'

import { useState } from 'react'
import Link from 'next/link'
import type { UtangPlanView } from '@/lib/types'
import { accountStatement } from '@/lib/routes'
import { Button } from '@/components/ui/Button'
import { PaymentDialog } from './PaymentDialog'
import { UtangPlanDialog } from './UtangPlanDialog'

/**
 * The two money actions on a customer's page. Both are dialogs, and both are
 * mounted only while open, so each opening starts from clean fields rather
 * than whatever was typed and abandoned last time.
 */
export function CustomerActions({
  customerId,
  plans,
  todayKey,
  balanceCentavos,
  unplannedCentavos,
}: {
  customerId: number
  /** Live plans only — a voided record cannot take a payment. */
  plans: UtangPlanView[]
  todayKey: string
  /** What is owed right now, so the payment dialog can question an overpayment. */
  balanceCentavos: number
  /** The part of that balance belonging to no plan; convertible when positive. */
  unplannedCentavos: number
}) {
  const [open, setOpen] = useState<'payment' | 'plan' | 'convert' | null>(null)

  return (
    <>
      <div className="mb-6 flex flex-wrap gap-2">
        <Button variant="success" onClick={() => setOpen('payment')}>
          Record a payment
        </Button>
        <Button variant="secondary" onClick={() => setOpen('plan')}>
          New utang
        </Button>
        {/* Only offered when there is something to schedule. */}
        {unplannedCentavos > 0 && (
          <Button variant="secondary" onClick={() => setOpen('convert')}>
            Put balance on terms
          </Button>
        )}
        <Link
          href={accountStatement(customerId)}
          className="inline-flex h-10 items-center justify-center rounded-control px-4 text-sm font-medium text-accent hover:bg-accent-soft"
        >
          Statement
        </Link>
      </div>

      {open === 'payment' && (
        <PaymentDialog
          customerId={customerId}
          plans={plans}
          todayKey={todayKey}
          balanceCentavos={balanceCentavos}
          onClose={() => setOpen(null)}
        />
      )}
      {open === 'plan' && (
        <UtangPlanDialog customerId={customerId} onClose={() => setOpen(null)} />
      )}
      {open === 'convert' && (
        <UtangPlanDialog
          customerId={customerId}
          convertCentavos={unplannedCentavos}
          onClose={() => setOpen(null)}
        />
      )}
    </>
  )
}
