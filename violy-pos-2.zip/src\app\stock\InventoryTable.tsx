'use client'

import { useState, useTransition } from 'react'
import { useRouter, usePathname, useSearchParams } from 'next/navigation'
import { archiveProduct, restoreProduct } from '@/server/products'
import type { ProductWithCategory } from '@/lib/types'
import { ProductForm } from './ProductForm'
import { ProductViewModal } from './ProductViewModal'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { EmptyState } from '@/components/ui/EmptyState'
import { Money } from '@/components/ui/Money'
import { ProductImage } from '@/components/ui/ProductImage'
import { FormError } from '@/components/ui/FormError'
import { RowActionMenu } from '@/components/ui/RowActionMenu'
import { SortableHeader } from '@/components/ui/SortableHeader'
import { nextSort, type SortState } from '@/lib/sorting'
import type { ProductSortKey } from '@/lib/product-sort'
import { cn } from '@/lib/cn'

type Props = {
  products: ProductWithCategory[]
  categories: { id: number; name: string }[]
  sort: SortState<ProductSortKey>
}

export function InventoryTable({ products, categories, sort }: Props) {
  const router = useRouter()
  const pathname = usePathname()
  const searchParams = useSearchParams()
  const [editing, setEditing] = useState<ProductWithCategory | null>(null)
  const [formOpen, setFormOpen] = useState(false)
  const [viewing, setViewing] = useState<ProductWithCategory | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [confirmingId, setConfirmingId] = useState<number | null>(null)
  const [pending, startTransition] = useTransition()

  // Sorting is a navigation, not local state: the table is server-paginated,
  // so the ORDER has to reach the query that fetches the page. Sorting the
  // twelve rows already on screen would reorder one page against itself.
  // Paging resets to 1 — staying on page 5 of a freshly reordered list lands
  // on rows that have nothing to do with what was clicked.
  function applySort(key: ProductSortKey, descendingFirst = false) {
    const next = nextSort(sort, key, descendingFirst)
    const query = new URLSearchParams(searchParams.toString())
    query.set('sort', next.key)
    query.set('dir', next.direction)
    query.delete('page')
    router.push(`${pathname}?${query.toString()}`)
  }

  function openEdit(product: ProductWithCategory) {
    setEditing(product)
    setFormOpen(true)
  }

  function handleArchive(product: ProductWithCategory) {
    setError(null)
    startTransition(async () => {
      const result = await archiveProduct(product.id)
      if (!result.ok) {
        setError(result.error)
        return
      }
      setConfirmingId(null)
      router.refresh()
    })
  }

  // No confirmation step, unlike archiving: restoring puts a record back and
  // takes nothing away, so the destructive-confirm pattern would be noise —
  // same call `CustomerList` makes for `restoreCustomer`.
  function handleRestore(product: ProductWithCategory) {
    setError(null)
    startTransition(async () => {
      const result = await restoreProduct(product.id)
      if (!result.ok) {
        setError(result.error)
        return
      }
      router.refresh()
    })
  }

  return (
    <div>
      {error && <FormError className="mb-4">{error}</FormError>}

      {products.length === 0 ? (
        <EmptyState>No products match these filters.</EmptyState>
      ) : (
        // No inner scroll. It used to be `max-h-[65vh] overflow-auto`, which
        // meant scrolling a table inside a scrolling page — two scrollbars for
        // one list. A page is now twelve rows, which fits, so paging does the
        // job the scroll box was doing badly. `thead` loses its `sticky` with
        // it: there is no scrolling ancestor left for it to stick to.
        <div className="overflow-hidden rounded-xl border border-line bg-surface">
          <table className="w-full text-sm">
            <thead className="bg-surface-sunk text-left text-xs uppercase tracking-wide text-ink-muted">
              <tr>
                <SortableHeader
                  label="Product"
                  active={sort.key === 'name'}
                  direction={sort.direction}
                  onSort={() => applySort('name')}
                />
                <SortableHeader
                  label="Category"
                  active={sort.key === 'category'}
                  direction={sort.direction}
                  onSort={() => applySort('category')}
                />
                <SortableHeader
                  label="Price"
                  align="end"
                  active={sort.key === 'price'}
                  direction={sort.direction}
                  onSort={() => applySort('price', true)}
                />
                <SortableHeader
                  label="Cost"
                  align="end"
                  active={sort.key === 'cost'}
                  direction={sort.direction}
                  onSort={() => applySort('cost', true)}
                />
                {/* Ascending first here, unlike the money columns: the reason
                    to sort by stock is to find what is running out. */}
                <SortableHeader
                  label="Stock"
                  align="end"
                  active={sort.key === 'stock'}
                  direction={sort.direction}
                  onSort={() => applySort('stock')}
                />
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {products.map((product) => {
                const out = product.stockQty <= 0
                const low = !out && product.stockQty <= product.lowStockThreshold
                const confirming = confirmingId === product.id
                return (
                  <tr
                    key={product.id}
                    // The whole row is the click target for viewing. Not a
                    // <button>, because a row contains its own action menu and
                    // nesting one button in another is the pattern this repo
                    // already removed from the catalog cards. `onClick` on the
                    // <tr> plus a keyboard handler gives the same reach
                    // without the nesting.
                    role="button"
                    tabIndex={0}
                    aria-label={`View ${product.name}`}
                    onClick={() => setViewing(product)}
                    onKeyDown={(event) => {
                      if (event.key !== 'Enter' && event.key !== ' ') return
                      // Only when the row itself has focus. Otherwise Space
                      // typed inside the archive confirmation would open the
                      // view behind it.
                      if (event.target !== event.currentTarget) return
                      event.preventDefault()
                      setViewing(product)
                    }}
                    className={cn(
                      'cursor-pointer transition-colors duration-150',
                      'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-accent',
                      // Tinted whole rows rather than a badge off to one side.
                      // A wash is visible while scanning the Product column,
                      // which is where the eye actually is; a chip in the last
                      // numeric column is not. Both tints are ~8% so the text
                      // over them keeps its contrast — the row has to stay
                      // readable, which is the whole point of highlighting it.
                      out
                        ? 'bg-owed/10 hover:bg-owed/[0.16]'
                        : low
                          ? 'bg-warn/10 hover:bg-warn/[0.16]'
                          : 'hover:bg-surface-sunk',
                      product.isArchived && 'opacity-50',
                    )}
                  >
                    {/* One line, not two. The unit on its own row made every
                        row 65px, so twelve of them overflowed the screen by
                        235px — measured — and paging you cannot see the bottom
                        of is not paging. Inline it is 44px and a page fits. */}
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-3">
                        {/* Only when there is a photo. None of the catalog
                            carries one today, so the placeholder was an empty
                            beige square on every row — the same mistake the
                            counter's product cards already dropped. */}
                        {product.imagePath && (
                          <ProductImage
                            src={product.imagePath}
                            className="h-8 w-8 shrink-0 rounded"
                            fallbackClassName="h-8 w-8 shrink-0 rounded"
                          />
                        )}
                        <div className="flex min-w-0 flex-wrap items-baseline gap-x-2">
                          <span className="font-medium">{product.name}</span>
                          <span className="text-xs text-ink-subtle">{product.unit}</span>
                          {product.isArchived && <Badge tone="muted">Archived</Badge>}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-2.5 text-ink-muted">{product.category.name}</td>
                    <td className="px-4 py-2.5 text-right">
                      <Money centavos={product.price} scale="body" />
                    </td>
                    <td className="px-4 py-2.5 text-right">
                      <Money centavos={product.costPrice} scale="body" />
                    </td>
                    <td className="px-4 py-2.5 text-right font-medium">
                      <span
                        className={cn(
                          'font-mono tabular-nums',
                          low && 'font-semibold text-warn',
                          out && 'font-semibold text-owed',
                        )}
                      >
                        {product.stockQty}
                      </span>
                      {out && (
                        <Badge tone="owed" className="ml-2">
                          out
                        </Badge>
                      )}
                    </td>
                    {/* Stops a click on the menu, or on the archive
                        confirmation, from also opening the view behind it. */}
                    <td
                      className="px-4 py-2.5 text-right"
                      onClick={(event) => event.stopPropagation()}
                    >
                      {confirming ? (
                        <span className="flex flex-wrap items-center justify-end gap-3">
                          <span className="text-sm text-ink">
                            Archive <span className="font-semibold">{product.name}</span>? Past
                            sales keep their record.
                          </span>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleArchive(product)}
                            disabled={pending}
                          >
                            Yes, archive it
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => setConfirmingId(null)}
                            disabled={pending}
                          >
                            Cancel
                          </Button>
                        </span>
                      ) : (
                        <div className="flex justify-end">
                          <RowActionMenu
                            ariaLabel={`Actions for ${product.name}`}
                            items={[
                              { label: 'View', onSelect: () => setViewing(product) },
                              { label: 'Edit', onSelect: () => openEdit(product) },
                              product.isArchived
                                ? {
                                    label: 'Restore',
                                    onSelect: () => handleRestore(product),
                                    disabled: pending,
                                  }
                                : {
                                    label: 'Archive',
                                    onSelect: () => setConfirmingId(product.id),
                                    destructive: true,
                                    disabled: pending,
                                  },
                            ]}
                          />
                        </div>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}

      {formOpen && (
        <ProductForm
          categories={categories}
          product={editing}
          onClose={() => setFormOpen(false)}
        />
      )}

      {viewing && (
        <ProductViewModal
          product={viewing}
          onClose={() => setViewing(null)}
          onEdit={() => {
            setEditing(viewing)
            setViewing(null)
            setFormOpen(true)
          }}
        />
      )}
    </div>
  )
}
