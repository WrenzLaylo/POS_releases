'use client'

import { useEffect, useState, type ReactNode } from 'react'
import { Button } from '@/components/ui/Button'
import { SegmentedControl } from '@/components/ui/SegmentedControl'
import { cn } from '@/lib/cn'

const STORAGE_KEY = 'doc-paper'

const PAPER_OPTIONS = [
  { value: 'a4', label: 'A4' },
  { value: 'roll', label: '80mm' },
] as const

export type PaperSize = (typeof PAPER_OPTIONS)[number]['value']

function isPaperSize(value: string | null): value is PaperSize {
  return value === 'a4' || value === 'roll'
}

const PAGE_RULES: Record<PaperSize, string> = {
  a4: '@page { size: A4; margin: 12mm; }',
  roll: '@page { size: 80mm auto; margin: 4mm; }',
}

/**
 * The frame every printable document renders inside — sale receipt, payment
 * receipt, plan invoice, account statement. It owns the actions bar, the paper
 * size, and the sheet element, so a document itself is only its content and
 * all four print identically.
 *
 * `actions` holds whatever is specific to one document (Back, Void). Print is
 * always here, because every document has it.
 */
export function DocumentShell({
  actions,
  children,
}: {
  actions?: ReactNode
  children: ReactNode
}) {
  const [paper, setPaper] = useState<PaperSize>('a4')

  // Read AFTER mount, never in the useState initialiser: the initialiser runs
  // on the server pass too, where localStorage does not exist. Same reason
  // `AppRail` reads its collapsed state in an effect.
  useEffect(() => {
    const stored = window.localStorage.getItem(STORAGE_KEY)
    if (isPaperSize(stored)) setPaper(stored)
  }, [])

  // `@page` takes no class selector — there is no way to write "A4 when this
  // element has class X". So the chosen rule is injected as its own <style>
  // and swapped on change. Appended to <head>, it lands after globals.css and
  // wins the cascade against the default rule there.
  useEffect(() => {
    const style = document.createElement('style')
    style.textContent = PAGE_RULES[paper]
    document.head.appendChild(style)
    return () => style.remove()
  }, [paper])

  function choose(next: PaperSize) {
    setPaper(next)
    window.localStorage.setItem(STORAGE_KEY, next)
  }

  return (
    <div className="doc-page mx-auto max-w-3xl p-6 lg:p-10">
      <div
        data-print="hide"
        className="mb-5 flex flex-wrap items-center justify-between gap-3"
      >
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="primary" onClick={() => window.print()}>
            Print / Save PDF
          </Button>
          {actions}
        </div>
        <div className="flex flex-col items-end gap-1">
          <SegmentedControl
            ariaLabel="Paper size"
            options={PAPER_OPTIONS}
            value={paper}
            onValueChange={(value) => {
              if (isPaperSize(value)) choose(value)
            }}
          />
          {/* The question this answers: "why is there no 80mm option?" The
              browser's paper list comes from the DESTINATION printer, and
              "Microsoft Print to PDF" only ever offers A4/Letter/Legal — so
              an 80mm document lands on Letter and spills to two sheets. The
              roll size appears once the receipt printer is the destination. */}
          {paper === 'roll' && (
            <p className="max-w-64 text-right text-xs text-ink-subtle">
              Pick your receipt printer under <span className="font-medium">Destination</span> —
              80mm shows up in its paper list. Print to PDF only offers A4, Letter and Legal.
            </p>
          )}
        </div>
      </div>

      {/* The sheet narrows on screen when the roll is selected, so the shape
          of the paper is visible before it is spent. */}
      <article
        className={cn(
          'doc-sheet rounded-card border border-line bg-surface-raised p-6 shadow-raised sm:p-8',
          paper === 'roll' && 'doc-sheet-roll',
        )}
      >
        {children}
      </article>
    </div>
  )
}
