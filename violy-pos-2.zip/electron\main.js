/**
 * The desktop shell for Violy Store POS.
 *
 * A WINDOW around the local server, deliberately not a bundle of the app.
 * The Next application stays ordinary files on disk, so the updater in
 * `scripts/update.mjs` keeps working exactly as it does without Electron —
 * download, unpack, rebuild, restart. Packaging the app inside the executable
 * would have meant shipping two update mechanisms instead of one.
 *
 * What this owns:
 *   · starting and stopping the Next server
 *   · a branded splash while it boots, so a slow start is not a blank screen
 *   · checking for updates before the shop opens, and telling her three ways
 *   · start-when-the-computer-turns-on
 *   · taking backups on a schedule, because nobody remembers to
 */

const { app, BrowserWindow, Menu, Notification, dialog, shell } = require('electron')
const { spawn, execFile } = require('node:child_process')
const { readFileSync } = require('node:fs')
const path = require('node:path')
const net = require('node:net')

const PORT = Number(process.env.POS_PORT ?? 3000)
const URL = `http://localhost:${PORT}`
const ROOT = path.join(__dirname, '..')

/** The server this shell started, if it started one. */
let serverProcess = null
let mainWindow = null
let splashWindow = null

// ── server ────────────────────────────────────────────────────────────────

/** Whether something is already answering on the port. */
function portInUse() {
  return new Promise((resolve) => {
    const socket = net.connect({ port: PORT, host: '127.0.0.1' })
    socket.setTimeout(600)
    socket.on('connect', () => {
      socket.destroy()
      resolve(true)
    })
    socket.on('error', () => resolve(false))
    socket.on('timeout', () => {
      socket.destroy()
      resolve(false)
    })
  })
}

async function waitForServer(timeoutMs = 90_000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    if (await portInUse()) return true
    await new Promise((resolve) => setTimeout(resolve, 400))
  }
  return false
}

/**
 * Starts the Next server, unless one is already running.
 *
 * The already-running check matters: opening the app twice must not start a
 * second server that fails on a taken port and leaves the second window
 * blank. It simply attaches to the one that is there.
 */
async function startServer() {
  if (await portInUse()) return 'already-running'

  serverProcess = spawn(
    process.execPath,
    [path.join(ROOT, 'node_modules', 'next', 'dist', 'bin', 'next'), 'start', '-p', String(PORT)],
    {
      cwd: ROOT,
      // ELECTRON_RUN_AS_NODE makes Electron's bundled binary behave as plain
      // Node for this child, so the server runs without Node needing to be
      // installed separately on her laptop.
      env: { ...process.env, ELECTRON_RUN_AS_NODE: '1', NODE_ENV: 'production' },
      stdio: 'ignore',
      windowsHide: true,
    },
  )
  serverProcess.on('error', () => {
    serverProcess = null
  })
  return 'started'
}

function stopServer() {
  if (!serverProcess) return
  try {
    // `/T` kills the tree: `next start` spawns workers, and killing only the
    // parent leaves them holding the port so the next launch cannot bind.
    if (process.platform === 'win32') {
      execFile('taskkill', ['/PID', String(serverProcess.pid), '/F', '/T'], () => {})
    } else {
      serverProcess.kill('SIGTERM')
    }
  } catch {
    // Already gone.
  }
  serverProcess = null
}

// ── backups ───────────────────────────────────────────────────────────────

/**
 * How often to ASK for a backup — not how often one is taken.
 *
 * The schedule itself lives in `src/lib/backup-policy.ts`, and the script
 * answers "there is already a recent one" when it is too soon. Asking every
 * hour and being refused costs a few hundred milliseconds and means this file
 * holds no second copy of the interval that could drift away from the sentence
 * in Settings telling her how often backups happen.
 */
const BACKUP_TICK_MS = 60 * 60 * 1000

/**
 * Runs the same backup script that `npm run backup` and the updater run.
 *
 * Through tsx, and through Electron's own binary as Node, so this works whether
 * or not Node is on the PATH — the same reason the server is started that way.
 */
function runBackup({ auto }) {
  return new Promise((resolve) => {
    const child = spawn(
      process.execPath,
      [
        path.join(ROOT, 'node_modules', 'tsx', 'dist', 'cli.mjs'),
        path.join(ROOT, 'scripts', 'backup-db.ts'),
        ...(auto ? ['--auto'] : []),
      ],
      {
        cwd: ROOT,
        env: { ...process.env, ELECTRON_RUN_AS_NODE: '1' },
        stdio: ['ignore', 'pipe', 'pipe'],
        windowsHide: true,
      },
    )

    let output = ''
    child.stdout.on('data', (chunk) => {
      output += chunk
    })
    child.stderr.on('data', (chunk) => {
      output += chunk
    })
    child.on('error', () => resolve({ ok: false, output: 'Could not start the backup.' }))
    child.on('close', (code) => resolve({ ok: code === 0, output: output.trim() }))
  })
}

/**
 * The menu's "Back up now", which always takes one.
 *
 * It reports either way. A backup button that says nothing is the same as no
 * backup button — the answer she needs is not "it probably worked".
 */
async function backupNowFromMenu() {
  const result = await runBackup({ auto: false })
  await dialog.showMessageBox({
    type: result.ok ? 'info' : 'error',
    title: 'Violy Store',
    message: result.ok ? 'Your data has been backed up.' : 'Could not save a backup.',
    detail: result.ok
      ? 'A full copy is in the backups folder. Copy that folder to a USB stick now and then — a backup on this laptop does not survive losing the laptop.'
      : 'Check there is space on the computer, then try again. Nothing has been changed.',
    buttons: ['OK'],
  })
}

// ── updates ───────────────────────────────────────────────────────────────

/** Where the shop laptop looks for new builds. Public, and read-only.
 *  One definition, shared with the app and the updater — see
 *  `release-channel.json`. */
const CHANNEL = require('../release-channel.json')
const MANIFEST_URL = `${CHANNEL.baseUrl}/${CHANNEL.manifestFile}`

/**
 * Which build this copy is. Absent means it was installed from source.
 */
function installedBuild() {
  try {
    const raw = readFileSync(path.join(ROOT, 'release.json'), 'utf8')
    const value = JSON.parse(raw)
    return Number.isInteger(value.build) ? value : null
  } catch {
    return null
  }
}

/**
 * Asks the public releases channel whether there is a newer build.
 *
 * No git. It used to run `git fetch` and compare commits, which meant this
 * laptop needed git installed AND signed in to GitHub, because the source
 * repository is private — two things to set up and a credential that expires
 * quietly. Now it is one small JSON file over plain HTTPS.
 *
 * Times out deliberately short: the shop's connection is not guaranteed, and a
 * check that hangs must never be the reason the till is slow to open.
 */
async function checkForUpdates() {
  const installed = installedBuild()
  if (!installed) return { available: false, reachable: true, fromSource: true, notes: [] }

  try {
    const response = await fetch(MANIFEST_URL, {
      cache: 'no-store',
      signal: AbortSignal.timeout(8000),
    })
    if (!response.ok) return { available: false, reachable: false, notes: [] }

    const value = await response.json()
    if (!Number.isInteger(value.build)) return { available: false, reachable: false, notes: [] }

    return {
      available: value.build > installed.build,
      reachable: true,
      version: String(value.version ?? value.build),
      notes: Array.isArray(value.notes) ? value.notes.filter((n) => typeof n === 'string') : [],
    }
  } catch {
    return { available: false, reachable: false, notes: [] }
  }
}

function notifyUpdate(version) {
  if (!Notification.isSupported()) return
  new Notification({
    title: 'Violy Store — update ready',
    body: `Version ${version} is ready to install.`,
  }).show()
}

/**
 * Hands over to the updater and closes.
 *
 * The updater has to stop this server and replace files the app holds open,
 * which cannot happen from inside the process doing the holding — Windows
 * refuses, as `prisma generate` in this project has already demonstrated with
 * EPERM. So it runs in its own console window and this shell gets out of the
 * way.
 */
function runUpdater() {
  spawn('cmd.exe', ['/c', 'start', '"Violy Store update"', 'cmd', '/k', 'node', 'scripts/update.mjs'], {
    cwd: ROOT,
    detached: true,
    stdio: 'ignore',
  }).unref()

  stopServer()
  app.exit(0)
}

async function offerUpdate({ silentWhenNone } = { silentWhenNone: true }) {
  const status = await checkForUpdates()

  if (!status.available) {
    if (!silentWhenNone) {
      await dialog.showMessageBox({
        type: 'info',
        title: 'Violy Store',
        message: status.fromSource
          ? 'This copy was installed from source, so it updates by rebuilding rather than downloading.'
          : status.reachable
            ? 'You have the latest version.'
            : 'Could not check for updates. Check the internet connection.',
        buttons: ['OK'],
      })
    }
    return
  }

  notifyUpdate(status.version)

  const { response } = await dialog.showMessageBox({
    type: 'question',
    title: 'Violy Store — update ready',
    message: `Version ${status.version} is ready to install.`,
    // Plain sentences, capped: a wall of twenty release notes is not a choice
    // anybody can make.
    detail: `${status.notes.slice(0, 6).join('\n')}${
      status.notes.length > 6 ? `\n…and ${status.notes.length - 6} more.` : ''
    }\n\nThe app will close while it installs, then open again by itself. Your data is backed up first.`,
    buttons: ['Install now', 'Later'],
    defaultId: 1,
    cancelId: 1,
  })

  if (response === 0) runUpdater()
}

// ── start on boot ─────────────────────────────────────────────────────────

function startsOnLogin() {
  return app.getLoginItemSettings().openAtLogin
}

function setStartsOnLogin(enabled) {
  // `args: [ROOT]` is not optional. This app is not a packaged executable —
  // `process.execPath` is Electron's own binary, and launching that alone
  // opens Electron's default window, not the till. It needs the app directory
  // as its argument, exactly as `electron .` passes it.
  app.setLoginItemSettings({
    openAtLogin: enabled,
    path: process.execPath,
    args: [ROOT],
  })
  buildMenu()
}

// ── windows ───────────────────────────────────────────────────────────────

function createSplash() {
  splashWindow = new BrowserWindow({
    width: 420,
    height: 300,
    frame: false,
    resizable: false,
    center: true,
    show: true,
    backgroundColor: '#f4f0e6',
  })
  splashWindow.loadFile(path.join(__dirname, 'splash.html'))
}

function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    show: false,
    backgroundColor: '#f4f0e6',
    title: 'Violy Store',
    icon: path.join(__dirname, 'icon.png'),
    webPreferences: { contextIsolation: true, nodeIntegration: false },
  })

  mainWindow.loadURL(URL)

  mainWindow.once('ready-to-show', () => {
    if (splashWindow && !splashWindow.isDestroyed()) splashWindow.destroy()
    splashWindow = null
    mainWindow.maximize()
    mainWindow.show()
  })

  // Anything that is not this app opens in the real browser rather than
  // replacing the till with a web page she cannot navigate back from.
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (!url.startsWith(URL)) shell.openExternal(url)
    return { action: 'deny' }
  })

  mainWindow.on('closed', () => {
    mainWindow = null
  })
}

function buildMenu() {
  const template = [
    {
      label: 'Violy Store',
      submenu: [
        { label: 'Reload', accelerator: 'F5', click: () => mainWindow?.reload() },
        { type: 'separator' },
        { label: 'Check for updates…', click: () => offerUpdate({ silentWhenNone: false }) },
        {
          label: 'Start when the computer turns on',
          type: 'checkbox',
          checked: startsOnLogin(),
          click: (item) => setStartsOnLogin(item.checked),
        },
        { type: 'separator' },
        { label: 'Back up now', click: () => backupNowFromMenu() },
        { label: 'Open backups folder', click: () => shell.openPath(path.join(ROOT, 'backups')) },
        { type: 'separator' },
        { label: 'Quit', accelerator: 'Alt+F4', role: 'quit' },
      ],
    },
    {
      label: 'Edit',
      submenu: [
        { role: 'undo' },
        { role: 'redo' },
        { type: 'separator' },
        { role: 'cut' },
        { role: 'copy' },
        { role: 'paste' },
        { role: 'selectAll' },
      ],
    },
    {
      label: 'Help',
      submenu: [
        {
          label: 'About',
          click: () =>
            dialog.showMessageBox({
              type: 'info',
              title: 'Violy Store',
              message: 'Violy Store — Point of Sale',
              detail: 'Made by Wrenz.',
              buttons: ['OK'],
            }),
        },
      ],
    },
  ]
  Menu.setApplicationMenu(Menu.buildFromTemplate(template))
}

// ── lifecycle ─────────────────────────────────────────────────────────────

// One instance only. A second launch focuses the window that exists instead
// of starting a rival server against the same database.
if (!app.requestSingleInstanceLock()) {
  app.exit(0)
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore()
      mainWindow.focus()
    }
  })

  app.whenReady().then(async () => {
    buildMenu()
    createSplash()

    await startServer()
    const up = await waitForServer()

    if (!up) {
      if (splashWindow && !splashWindow.isDestroyed()) splashWindow.destroy()
      await dialog.showMessageBox({
        type: 'error',
        title: 'Violy Store',
        message: 'The app could not start.',
        detail:
          'Try turning the computer off and on again. If it still does not open, tell whoever looks after this app.',
        buttons: ['Close'],
      })
      app.exit(1)
      return
    }

    createMainWindow()

    // A backup at launch, and one every so often after that. Silent on
    // purpose: this is the one that has to happen on the mornings she is busy,
    // and anything she has to acknowledge is something she will eventually
    // click past. It runs BEFORE the update prompt, so the copy exists whether
    // or not she chooses to install anything.
    void runBackup({ auto: true })
    setInterval(() => void runBackup({ auto: true }), BACKUP_TICK_MS)

    // Checked AFTER the POS is up, never before: an update prompt must not
    // stand between her and a customer waiting at the counter.
    setTimeout(() => offerUpdate({ silentWhenNone: true }), 4_000)
  })

  app.on('window-all-closed', () => {
    stopServer()
    app.quit()
  })

  // The server is this shell's child; leaving it running after the window
  // closes would hold the port and the database file.
  app.on('before-quit', stopServer)
  process.on('exit', stopServer)
}
