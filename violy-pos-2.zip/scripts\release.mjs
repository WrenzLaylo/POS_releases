#!/usr/bin/env node
/**
 * Packages a release for the shop laptop to download.
 *
 *   npm run release -- "What changed, in one sentence" ["another sentence"]
 *
 * Produces two files in `release-out/`:
 *
 *   violy-pos-<build>.zip   the app, without any of the shop's data
 *   latest.json             build number, notes, download URL, SHA-256
 *
 * Both then go into the PUBLIC releases repository. That repository holds only
 * these two things; the source stays private. The laptop reads `latest.json`
 * over plain HTTPS — no git, no GitHub account, nothing that expires.
 *
 * WHAT IS DELIBERATELY NOT IN THE ZIP, and this is the safety rather than an
 * optimisation: the database, `.env`, `backups/`, `data/uploads`, `exports/`,
 * `node_modules/` and `.git`. The shop's data survives an update because it was
 * never in the delivery — not because the updater remembered to skip it. The
 * seed scripts holding real customer names and supplier prices are excluded for
 * the same reason: the releases repository is public.
 */

import { execSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { mkdir, readFile, rm } from 'node:fs/promises'
import path from 'node:path'

const ROOT = process.cwd()
const OUT = path.join(ROOT, 'release-out')
const NEWLINE = String.fromCharCode(10)

/** Where the laptop will fetch it from. One definition, shared with the app,
 *  the desktop shell and the updater. */
const CHANNEL = JSON.parse(readFileSync(path.join(ROOT, 'release-channel.json'), 'utf8'))
const BASE_URL = CHANNEL.baseUrl

/**
 * Everything the app needs to RUN, and nothing else.
 *
 * An allow-list, not a list of exclusions. An exclusion list silently ships
 * whatever is added to the project later — including, one day, something
 * holding the shop's data.
 */
const INCLUDE = [
  'src',
  'public',
  'prisma/schema.prisma',
  'prisma/migrations',
  'electron',
  'scripts',
  'package.json',
  'package-lock.json',
  'next.config.ts',
  'tsconfig.json',
  'postcss.config.mjs',
  'vitest.config.ts',
  '.env.example',
  'release-channel.json',
  'install.cmd',
  'run-pos.vbs',
  'start-pos.cmd',
  'INSTALL.md',
]

/**
 * Files matching these never travel, even from inside an included folder.
 *
 * `real-data.ts` and `chicken-feeds.ts` are one-time loaders holding 45 real
 * customer names and real supplier prices. They have already been run; the data
 * lives in the database now. The releases repository is public, so they stay
 * behind.
 */
const EXCLUDE_NAMES = ['real-data.ts', 'chicken-feeds.ts', 'demo.ts', 'demo-clear.ts']

const say = (message) => console.log(message)

function nextBuild() {
  // Read from the last release if there is one, so build numbers keep rising
  // across runs. A build number that repeats would leave every laptop already
  // "up to date" with an older app.
  const previous = path.join(OUT, 'latest.json')
  if (existsSync(previous)) {
    try {
      const value = JSON.parse(readFileSync(previous, 'utf8'))
      if (Number.isInteger(value.build)) return value.build + 1
    } catch {
      // Unreadable. Fall through to 1 and let the caller notice.
    }
  }
  return 1
}

function today() {
  const now = new Date()
  const pad = (n) => String(n).padStart(2, '0')
  return `${now.getFullYear()}.${pad(now.getMonth() + 1)}.${pad(now.getDate())}`
}

async function main() {
  const notes = process.argv.slice(2).filter((note) => note.trim() !== '')
  if (notes.length === 0) {
    console.error('Say what changed:')
    console.error('  npm run release -- "Deliveries can now be recorded on consignment"')
    process.exit(1)
  }

  const build = nextBuild()
  const version = today()
  const zipName = `violy-pos-${build}.zip`

  say(`\nPackaging build ${build} (${version})…`)

  // Built first, so a release that cannot compile never reaches the shop.
  say('  building…')
  execSync('npm run build', { cwd: ROOT, stdio: 'inherit' })

  const staging = path.join(OUT, 'staging')
  await rm(staging, { recursive: true, force: true })
  await mkdir(staging, { recursive: true })

  for (const entry of INCLUDE) {
    const from = path.join(ROOT, entry)
    if (!existsSync(from)) continue
    const to = path.join(staging, entry)
    await mkdir(path.dirname(to), { recursive: true })
    execSync(
      process.platform === 'win32'
        ? `powershell -NoProfile -Command "Copy-Item -LiteralPath '${from}' -Destination '${to}' -Recurse -Force"`
        : `cp -R "${from}" "${to}"`,
      { stdio: 'ignore' },
    )
  }

  for (const name of EXCLUDE_NAMES) {
    await rm(path.join(staging, 'prisma', name), { force: true })
  }

  // The stamp the laptop compares against. Written into the zip, so an
  // installed copy always knows which build it is.
  writeFileSync(
    path.join(staging, 'release.json'),
    JSON.stringify({ build, version, installedAt: null }, null, 2) + NEWLINE,
    'utf8',
  )

  const zipPath = path.join(OUT, zipName)
  await rm(zipPath, { force: true })
  say('  zipping…')
  execSync(
    process.platform === 'win32'
      ? `powershell -NoProfile -Command "Compress-Archive -Path '${staging}\\*' -DestinationPath '${zipPath}' -Force"`
      : `cd "${staging}" && zip -qr "${zipPath}" .`,
    { stdio: 'ignore' },
  )

  const bytes = await readFile(zipPath)
  const sha256 = createHash('sha256').update(bytes).digest('hex')

  const manifest = {
    build,
    version,
    publishedAt: new Date().toISOString(),
    notes,
    zipUrl: `${BASE_URL}/${zipName}`,
    sha256,
  }
  writeFileSync(path.join(OUT, 'latest.json'), JSON.stringify(manifest, null, 2) + NEWLINE, 'utf8')
  await rm(staging, { recursive: true, force: true })

  say(`\n  ${zipName}  ${(bytes.length / 1_000_000).toFixed(1)} MB`)
  say(`  sha256 ${sha256.slice(0, 16)}…`)
  say(`\nWritten to ${OUT}`)
  say('\nTo publish, copy BOTH files into the public releases repository and push:')
  say(`  ${zipName}`)
  say('  latest.json')
  say('\nPush latest.json LAST. A manifest that names a zip nobody has uploaded')
  say('yet sends every laptop to a 404.\n')
}

main().catch((error) => {
  console.error(`\nRelease FAILED: ${error instanceof Error ? error.message : String(error)}\n`)
  process.exit(1)
})
