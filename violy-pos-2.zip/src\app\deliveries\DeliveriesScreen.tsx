'use client'

import { useState, useTransition } from 'react'
import { usePathname, useRouter } from 'next/navigation'
import type { DeliveryRow } from '@/server/deliveries'
import { getDelivery, payDelivery, voidDelivery } from '@/server/deliveries'
import type { DeliveryDetail } from '@/server/deliveries'
import { parsePesoInput } from '@/lib/money'
import { NEW_DELIVERY } from '@/lib/routes'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Dialog } from '@/components/ui/Dialog'
import { EmptyState } from '@/components/ui/EmptyState'
import { Field } from '@/components/ui/Field'
import { FilterChips } from '@/components/ui/FilterChips'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'
import { Money } from '@/components/ui/Money'
import { RowActionMenu } from '@/components/ui/RowActionMenu'
import { TapeCell, TapeRow } from '@/components/ui/Tape'
import { SettleDialog } from './SettleDialog'
import { SupplierDialog } from './SupplierDialog'

export type SupplierOption = {
  id: number
  name: string
  contactNumber: string
  notes: string
  isArchived: boolean
}

function shortDate(date: Date): string {
  return new Intl.DateTimeFormat('en-PH', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(date)
}

/**
 * What the shop bought, and what it still owes for it.
 *
 * The counterpart to the Book. That screen answers "who owes me"; this one
 * answers "who do I owe" — a question the app could not previously ask,
 * because stock only ever left and arrived by somebody editing a number.
 */
export function DeliveriesScreen({
  deliveries,
  suppliers,
  payableCentavos,
  filters,
}: {
  deliveries: DeliveryRow[]
  suppliers: SupplierOption[]
  payableCentavos: number
  filters: { supplier?: string; unpaid?: string }
}) {
  const router = useRouter()
  const pathname = usePathname()
  const [pending, startTransition] = useTransition()

  const [suppliersOpen, setSuppliersOpen] = useState(false)
  const [paying, setPaying] = useState<DeliveryRow | null>(null)
  const [voiding, setVoiding] = useState<DeliveryRow | null>(null)
  // Loaded on demand rather than shipped with every row: the settle dialog
  // needs each line's settled and returned counts, and a list of thirty
  // deliveries should not carry every line of all of them.
  const [settling, setSettling] = useState<DeliveryDetail | null>(null)
  const [error, setError] = useState<string | null>(null)

  const [payAmount, setPayAmount] = useState('')
  const [voidReason, setVoidReason] = useState('')

  function apply(patch: { supplier?: string; unpaid?: string }) {
    const params = new URLSearchParams()
    const supplier = patch.supplier ?? filters.supplier ?? ''
    const unpaid = patch.unpaid ?? filters.unpaid ?? ''
    if (supplier) params.set('supplier', supplier)
    if (unpaid === '1') params.set('unpaid', '1')
    params.set('page', '1')
    router.push(`${pathname}?${params.toString()}`)
  }

  function submitPayment() {
    if (!paying) return
    setError(null)
    const centavos = parsePesoInput(payAmount)
    if (centavos === null || centavos <= 0) {
      setError('Enter an amount greater than zero.')
      return
    }
    startTransition(async () => {
      const result = await payDelivery(paying.id, centavos)
      if (!result.ok) {
        setError(result.error)
        return
      }
      setPaying(null)
      setPayAmount('')
      router.refresh()
    })
  }

  function submitVoid() {
    if (!voiding) return
    setError(null)
    startTransition(async () => {
      const result = await voidDelivery(voiding.id, voidReason)
      if (!result.ok) {
        setError(result.error)
        return
      }
      setVoiding(null)
      setVoidReason('')
      router.refresh()
    })
  }

  const supplierOptions = [
    { value: '', label: 'All suppliers' },
    ...suppliers.map((supplier) => ({ value: String(supplier.id), label: supplier.name })),
  ]

  return (
    <>
      {/* Leads the page, mirroring "Total utang" on the Book. Never `money-in`:
          this is money the shop OWES, not cash that has arrived. */}
      <div className="mb-6 rounded-card border border-line-strong bg-surface-raised px-5 py-4 shadow-panel">
        <TapeRow>
          <TapeCell>
            <span className="text-xs font-semibold uppercase tracking-[0.14em] text-ink-muted">
              Owed to suppliers
            </span>
          </TapeCell>
          <TapeCell align="end">
            <Money centavos={payableCentavos} tone="owed" scale="hero" />
          </TapeCell>
        </TapeRow>
      </div>

      <div className="mb-4 flex flex-wrap items-end justify-between gap-4">
        <div className="flex flex-wrap gap-x-8 gap-y-4">
          <FilterChips
            label="Supplier"
            ariaLabel="Filter by supplier"
            options={supplierOptions}
            value={filters.supplier ?? ''}
            onChange={(value) => apply({ supplier: value })}
          />
          <FilterChips
            label="Settled"
            ariaLabel="Filter by whether it is paid"
            options={[
              { value: '', label: 'All' },
              { value: '1', label: 'Still owing' },
            ]}
            value={filters.unpaid === '1' ? '1' : ''}
            onChange={(value) => apply({ unpaid: value })}
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Button variant="secondary" onClick={() => setSuppliersOpen(true)}>
            Suppliers
          </Button>
          {/* Goes to a PAGE now, not a dialog. A delivery can run to a dozen
              lines and deserves the width — squeezed into a dialog the product
              picker was six characters wide and every option read "Ch…". */}
          <Button
            variant="primary"
            onClick={() => router.push(NEW_DELIVERY)}
            disabled={suppliers.length === 0}
          >
            Record delivery
          </Button>
        </div>
      </div>

      {error && !paying && !voiding && <FormError className="mb-4">{error}</FormError>}

      {suppliers.length === 0 && (
        <Card className="mb-4">
          <p className="text-sm text-ink-muted">
            Add a supplier first — a delivery has to have come from somewhere.
          </p>
        </Card>
      )}

      {deliveries.length === 0 ? (
        <EmptyState>
          {filters.supplier || filters.unpaid
            ? 'No deliveries match these filters.'
            : 'Nothing received yet.'}
        </EmptyState>
      ) : (
        <div className="overflow-x-auto rounded-card border border-line bg-surface">
          <table className="w-full text-sm">
            <thead className="bg-surface-sunk text-left text-xs uppercase tracking-wide text-ink-muted">
              <tr>
                <th className="px-3 py-2 font-medium">Received</th>
                <th className="px-3 py-2 font-medium">Supplier</th>
                <th className="px-3 py-2 font-medium">Reference</th>
                <th className="px-3 py-2 text-right font-medium">Items</th>
                <th className="px-3 py-2 text-right font-medium">Cost</th>
                <th className="px-3 py-2 text-right font-medium">Still owing</th>
                <th className="w-10 px-3 py-2" />
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {deliveries.map((delivery) => (
                <tr key={delivery.id} className={delivery.isVoided ? 'opacity-60' : undefined}>
                  <td className="px-3 py-2 tabular-nums">{shortDate(delivery.receivedAt)}</td>
                  <td className="px-3 py-2">
                    <span className="font-medium text-ink">{delivery.supplierName}</span>
                    {delivery.terms === 'CONSIGNMENT' && (
                      <span className="ml-2 align-middle">
                        {/* Neutral: consignment is a fact about the terms, not
                            a warning and not a settled state. */}
                        <Badge tone="neutral">Consignment</Badge>
                      </span>
                    )}
                    {delivery.isVoided && (
                      <span className="ml-2 align-middle">
                        {/* `muted`, not `paid`: this record is dead, not
                            settled. */}
                        <Badge tone="muted">Voided</Badge>
                      </span>
                    )}
                  </td>
                  <td className="px-3 py-2 text-ink-muted">{delivery.reference || '—'}</td>
                  <td className="px-3 py-2 text-right tabular-nums text-ink-muted">
                    {delivery.lineCount}
                  </td>
                  <td className="px-3 py-2 text-right">
                    {/* Neutral. Money leaving is not `money-in`, and it is not
                        a debt on its own either — the debt is the column
                        beside it. */}
                    <Money centavos={delivery.totalCostCentavos} scale="body" />
                  </td>
                  <td className="px-3 py-2 text-right">
                    {delivery.outstandingCentavos > 0 ? (
                      <Money centavos={delivery.outstandingCentavos} tone="owed" scale="body" />
                    ) : delivery.unaccountedCentavos > 0 ? (
                      // Owes nothing YET, which is not the same as settled. A
                      // green "Settled" chip here would say the consignment
                      // was finished when most of it is still on the shelf.
                      <span className="text-xs text-ink-subtle">
                        <Money centavos={delivery.unaccountedCentavos} scale="body" /> unsold
                      </span>
                    ) : (
                      <Badge tone="paid">Settled</Badge>
                    )}
                  </td>
                  <td className="px-3 py-2">
                    {!delivery.isVoided && (
                      <RowActionMenu
                        ariaLabel={`Actions for delivery ${delivery.id}`}
                        items={[
                          {
                            label:
                              delivery.terms === 'CONSIGNMENT'
                                ? 'Settle what sold'
                                : 'Return stock',
                            onSelect: () => {
                              setError(null)
                              startTransition(async () => {
                                const detail = await getDelivery(delivery.id)
                                if (!detail) {
                                  setError('That delivery could not be opened.')
                                  return
                                }
                                setSettling(detail)
                              })
                            },
                          },
                          ...(delivery.outstandingCentavos > 0
                            ? [
                                {
                                  label: 'Record payment',
                                  onSelect: () => {
                                    setError(null)
                                    setPayAmount('')
                                    setPaying(delivery)
                                  },
                                },
                              ]
                            : []),
                          {
                            label: 'Void this delivery',
                            destructive: true,
                            onSelect: () => {
                              setError(null)
                              setVoidReason('')
                              setVoiding(delivery)
                            },
                          },
                        ]}
                      />
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {suppliersOpen && (
        <SupplierDialog suppliers={suppliers} onClose={() => setSuppliersOpen(false)} />
      )}

      {settling && <SettleDialog delivery={settling} onClose={() => setSettling(null)} />}

      <Dialog
        open={paying !== null}
        onOpenChange={(open) => {
          if (!open) setPaying(null)
        }}
        title="Record a payment to the supplier"
        description={
          paying
            ? `${paying.supplierName} — delivery of ${shortDate(paying.receivedAt)}`
            : undefined
        }
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setPaying(null)}>
              Cancel
            </Button>
            {/* `success`: terminal and money-committing, like Save payment on
                the Book. */}
            <Button variant="success" onClick={submitPayment} disabled={pending}>
              {pending ? 'Saving…' : 'Save payment'}
            </Button>
          </div>
        }
      >
        {paying && (
          <div className="grid gap-4">
            <div className="flex items-baseline justify-between rounded-control bg-surface-sunk px-3 py-2 text-sm">
              <span className="text-ink-muted">Still owing</span>
              <Money centavos={paying.outstandingCentavos} tone="owed" />
            </div>
            <Field label="Amount">
              <Input
                inputMode="decimal"
                value={payAmount}
                onChange={(event) => setPayAmount(event.target.value)}
                placeholder="0.00"
                className="w-full tabular-nums"
                autoFocus
              />
            </Field>
            {error && <FormError>{error}</FormError>}
          </div>
        )}
      </Dialog>

      <Dialog
        open={voiding !== null}
        onOpenChange={(open) => {
          if (!open) setVoiding(null)
        }}
        title="Void this delivery"
        description="The stock it added comes back off, and the amount owed for it goes away."
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setVoiding(null)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={submitVoid} disabled={pending}>
              {pending ? 'Voiding…' : 'Yes, void it'}
            </Button>
          </div>
        }
      >
        <div className="grid gap-4">
          <Field label="Why is it being voided?">
            <Input
              value={voidReason}
              onChange={(event) => setVoidReason(event.target.value)}
              placeholder="e.g. Entered twice"
              className="w-full"
              autoFocus
            />
          </Field>
          <p className="text-xs text-ink-subtle">
            The record stays on this list, marked, with the reason on it. Nothing is deleted.
          </p>
          {error && <FormError>{error}</FormError>}
        </div>
      </Dialog>
    </>
  )
}
