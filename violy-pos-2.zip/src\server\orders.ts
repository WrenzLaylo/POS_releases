'use server'

import { prisma } from '@/lib/db'
import { lineTotal } from '@/lib/money'
import {
  computeOrderTotals,
  customerDiscountOf,
  validateOrderDiscount,
  type OrderDiscountInput,
} from '@/lib/discount'
import { startOfDay, addDays } from '@/lib/dates'
import { sumBalance } from '@/lib/ledger-balance'
import { reconcileCustomerDueAt } from '@/server/account-due'
import type {
  ActionResult,
  DayOrder,
  OrderLineInput,
  OrderResult,
  ReceiptLine,
} from '@/lib/types'
import { ROUTES } from '@/lib/routes'
import { prismaErrorCode } from '@/lib/prisma-errors'
import { revalidateRoutes } from './revalidate'

class OrderError extends Error {}

export type CreateOrderInput = {
  customerId: number
  lines: OrderLineInput[]
  /** Cash handed over. The server stores only the portion retained as cash paid. */
  cashPaidCentavos: number | null
  /** The ad-hoc discount typed at the counter. Omitted means none. */
  orderDiscount?: OrderDiscountInput | null
  /**
   * How much of the customer's existing credit to put toward this order.
   *
   * Only ever REDUCES the cash she has to hand over. It posts no ledger entry
   * of its own: the charge this order already writes is `total - cash kept`,
   * and that moves a negative balance toward zero exactly as it moves a zero
   * balance upward. Adding a second posting would consume the credit twice.
   */
  creditAppliedCentavos?: number
  clientOrderKey?: string
  occurredAt?: Date
}

function receiptLines(
  lines: readonly {
    productId: number
    quantity: number
    priceAtSale: number
    discountAtSale: number
    product: { name: string; unit: string }
  }[],
): ReceiptLine[] {
  return lines.map((line) => ({
    productId: line.productId,
    name: line.product.name,
    unit: line.product.unit,
    quantity: line.quantity,
    priceAtSale: line.priceAtSale,
    discountAtSale: line.discountAtSale,
    lineTotalCentavos: lineTotal(line.priceAtSale - line.discountAtSale, line.quantity),
  }))
}

async function existingOrderResult(clientOrderKey: string): Promise<OrderResult | null> {
  const sale = await prisma.sale.findUnique({
    where: { clientOrderKey },
    include: {
      items: { include: { product: { select: { name: true, unit: true } } } },
      ledgerEntry: { select: { amountCentavos: true, isVoided: true } },
    },
  })
  if (!sale) return null
  return {
    saleId: sale.id,
    createdAt: sale.createdAt.toISOString(),
    totalCentavos: sale.totalAmount,
    cashPaidCentavos: sale.cashPaidCentavos,
    cashTenderedCentavos: sale.cashTenderedCentavos ?? sale.cashPaidCentavos,
    changeCentavos: sale.changeCentavos,
    chargedCentavos:
      sale.ledgerEntry && !sale.ledgerEntry.isVoided ? sale.ledgerEntry.amountCentavos : 0,
    newBalanceCentavos: sale.customerBalanceAfterCentavos ?? 0,
    lines: receiptLines(sale.items),
  }
}

export async function createOrder(
  input: CreateOrderInput,
): Promise<ActionResult<OrderResult>> {
  if (input.lines.length === 0) {
    return { ok: false, error: 'No items yet. Add at least one.' }
  }
  for (const line of input.lines) {
    if (!Number.isFinite(line.quantity) || line.quantity <= 0) {
      return { ok: false, error: "Each line's quantity must be more than zero." }
    }
  }
  if (
    input.cashPaidCentavos !== null &&
    (!Number.isInteger(input.cashPaidCentavos) || input.cashPaidCentavos < 0)
  ) {
    return { ok: false, error: 'Cash must be a non-negative whole number of centavos.' }
  }

  const creditRequested = input.creditAppliedCentavos ?? 0
  if (!Number.isInteger(creditRequested) || creditRequested < 0) {
    return { ok: false, error: 'Credit applied must be a whole number of centavos.' }
  }

  const discount = validateOrderDiscount(input.orderDiscount)
  if (!discount.ok) return { ok: false, error: discount.error }
  const orderDiscount = discount.value

  const clientOrderKey = input.clientOrderKey?.trim() || null
  if (clientOrderKey && (clientOrderKey.length < 8 || clientOrderKey.length > 128)) {
    return { ok: false, error: 'The checkout key is invalid. Start a fresh order and try again.' }
  }
  if (clientOrderKey) {
    const existing = await existingOrderResult(clientOrderKey)
    if (existing) return { ok: true, data: existing }
  }

  const merged = new Map<number, number>()
  for (const line of input.lines) {
    merged.set(line.productId, (merged.get(line.productId) ?? 0) + line.quantity)
  }

  const occurredAt = input.occurredAt ?? new Date()
  let result: OrderResult
  try {
    result = await prisma.$transaction(async (tx) => {
      const customer = await tx.customer.findUnique({
        where: { id: input.customerId },
        include: {
          discountCategories: { select: { id: true } },
          entries: {
            where: { isVoided: false },
            select: { id: true, type: true, amountCentavos: true, isVoided: true },
          },
        },
      })
      if (!customer) throw new OrderError('That customer no longer exists.')
      if (customer.isArchived) throw new OrderError(`${customer.name} is archived.`)

      const products = await tx.product.findMany({
        where: { id: { in: [...merged.keys()] } },
      })
      const byId = new Map(products.map((product) => [product.id, product]))

      // Availability is checked here; pricing is not. Everything about what a
      // line costs lives in `computeOrderTotals`, which the order screen's
      // live preview also calls — the figure she reads to the customer and
      // the figure that hits the books come out of one function.
      for (const productId of merged.keys()) {
        const product = byId.get(productId)
        if (!product) throw new OrderError('An item in this order no longer exists.')
        if (product.isArchived) throw new OrderError(`${product.name} is no longer available.`)
      }

      const totals = computeOrderTotals({
        lines: [...merged.entries()].map(([productId, quantity]) => {
          const product = byId.get(productId)!
          return {
            productId,
            quantity,
            priceCentavos: product.price,
            categoryId: product.categoryId,
            unit: product.unit,
          }
        }),
        customer: customerDiscountOf(customer),
        order: orderDiscount,
      })

      const lines = totals.lines.map((line) => {
        const product = byId.get(line.productId)!
        return {
          productId: line.productId,
          quantity: line.quantity,
          priceAtSale: line.priceCentavos,
          costAtSale: product.costPrice,
          discountAtSale: line.discountPerUnitCentavos,
          product: { name: product.name, unit: product.unit },
        }
      })

      const totalAmount = totals.totalCentavos
      const previousBalance = sumBalance(customer.entries)

      // A negative balance is credit the shop holds for her. Read INSIDE the
      // transaction against her live entries, never from what the browser was
      // showing — a payment recorded on another screen a minute ago must not
      // be spent twice.
      const availableCredit = Math.max(0, -previousBalance)
      if (creditRequested > availableCredit) {
        throw new OrderError(
          availableCredit === 0
            ? 'This customer has no credit to use.'
            : 'That is more credit than this customer has.',
        )
      }
      // Capped at the order too: credit beyond the total would hand back cash
      // the shop never received.
      const creditApplied = Math.min(creditRequested, totalAmount)

      // What is left for her to cover once credit has done its part.
      const dueAfterCredit = totalAmount - creditApplied
      const cashTendered = input.cashPaidCentavos ?? dueAfterCredit
      const keptCentavos = Math.min(cashTendered, dueAfterCredit)
      const changeCentavos = Math.max(0, cashTendered - dueAfterCredit)

      // The single posting that does everything. `total - kept` is the charge
      // whether it is funded by credit, by utang, or by both: applying credit
      // simply means less cash was kept, so the charge is larger and eats into
      // the negative balance. No separate credit entry exists, and adding one
      // would consume the credit twice.
      const chargedCentavos = Math.max(0, totalAmount - keptCentavos)
      const newBalanceCentavos = previousBalance + chargedCentavos

      const sale = await tx.sale.create({
        data: {
          totalAmount,
          customerId: customer.id,
          cashPaidCentavos: keptCentavos,
          cashTenderedCentavos: cashTendered,
          changeCentavos,
          creditAppliedCentavos: creditApplied,
          customerBalanceAfterCentavos: newBalanceCentavos,
          // Snapshotted alongside the resulting peso figure, so a receipt
          // reprinted next year can still say "10% off" rather than leaving
          // the reader to reverse-engineer it from the total.
          customerDiscountCentavos: totals.customerDiscountCentavos,
          orderDiscountCentavos: totals.orderDiscountCentavos,
          orderDiscountKind: orderDiscount.kind,
          orderDiscountBps: orderDiscount.bps,
          orderDiscountMode: orderDiscount.mode,
          clientOrderKey,
          createdAt: occurredAt,
          items: { create: lines.map(({ product, ...line }) => line) },
        },
      })

      for (const line of lines) {
        await tx.product.update({
          where: { id: line.productId },
          data: { stockQty: { decrement: line.quantity } },
        })
        await tx.stockMovement.create({
          data: {
            productId: line.productId,
            saleId: sale.id,
            type: 'SALE',
            quantity: -line.quantity,
            note: `Sale #${sale.id}`,
          },
        })
      }

      if (chargedCentavos > 0) {
        await tx.ledgerEntry.create({
          data: {
            customerId: customer.id,
            type: 'CHARGE',
            amountCentavos: chargedCentavos,
            occurredAt,
            saleId: sale.id,
          },
        })
        await reconcileCustomerDueAt(tx, customer.id, occurredAt)
      }

      return {
        saleId: sale.id,
        createdAt: sale.createdAt.toISOString(),
        totalCentavos: totalAmount,
        cashPaidCentavos: keptCentavos,
        cashTenderedCentavos: cashTendered,
        changeCentavos,
        chargedCentavos,
        newBalanceCentavos,
        lines: receiptLines(lines),
      }
    })
  } catch (error) {
    if (error instanceof OrderError) return { ok: false, error: error.message }
    if (clientOrderKey && prismaErrorCode(error) === 'P2002') {
      const existing = await existingOrderResult(clientOrderKey)
      if (existing) return { ok: true, data: existing }
    }
    return { ok: false, error: 'Could not save the order. Please try again.' }
  }

  revalidateRoutes(
    [ROUTES.counter, ROUTES.history, ROUTES.book, ROUTES.dashboard, ROUTES.stock],
    { layout: true },
  )
  return { ok: true, data: result }
}

/** One day's orders, newest first, shaped the way the notebook page reads. */
export async function listOrdersForDay(day: Date): Promise<DayOrder[]> {
  const from = startOfDay(day)
  const to = addDays(from, 1)

  const sales = await prisma.sale.findMany({
    where: { createdAt: { gte: from, lt: to } },
    include: {
      customer: { select: { id: true, name: true } },
      items: { include: { product: { select: { name: true, unit: true } } } },
      ledgerEntry: { select: { isVoided: true } },
    },
    orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
  })

  return sales.map((sale) => ({
    saleId: sale.id,
    customerId: sale.customer?.id ?? null,
    customerName: sale.customer?.name ?? null,
    totalCentavos: sale.totalAmount,
    cashPaidCentavos: sale.cashPaidCentavos,
    hasLiveCharge: sale.ledgerEntry !== null && !sale.ledgerEntry.isVoided,
    isVoided: sale.isVoided,
    createdAt: sale.createdAt,
    lines: sale.items.map((item) => ({
      name: item.product.name,
      unit: item.product.unit,
      quantity: item.quantity,
    })),
  }))
}
