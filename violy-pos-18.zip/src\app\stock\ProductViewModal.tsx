'use client'

import type { ProductWithCategory } from '@/lib/types'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { ProductImage } from '@/components/ui/ProductImage'
import { Dialog } from '@/components/ui/Dialog'
import { Money } from '@/components/ui/Money'

type Props = {
  product: ProductWithCategory
  onClose: () => void
  onEdit: () => void
}

/** Read-only detail popup, opened from a row's `RowActionMenu` in
 *  `InventoryTable`. Its own Edit button hands off to `ProductForm` — this
 *  component never writes anything itself.
 *
 *  All Escape-to-close, focus-trapping, body-scroll-locking, and
 *  focus-restoration behaviour comes from `Dialog`/`Overlay` — this
 *  component adds none of its own, and must not. */
export function ProductViewModal({ product, onClose, onEdit }: Props) {
  const low = product.stockQty <= product.lowStockThreshold

  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title={
        <span className="flex items-center gap-2">
          {product.name}
          {product.isArchived && <Badge tone="muted">Archived</Badge>}
        </span>
      }
      footer={
        <div className="flex justify-end gap-2">
          <Button type="button" variant="ghost" onClick={onClose}>
            Close
          </Button>
          {/* Kept, deliberately — this is the "don't delete the edit button"
              handoff into ProductForm. */}
          <Button type="button" variant="primary" onClick={onEdit}>
            Edit
          </Button>
        </div>
      }
    >
      <div className="flex gap-4">
        <ProductImage
          src={product.imagePath}
          className="h-28 w-28 shrink-0 rounded-lg"
          fallbackClassName="h-28 w-28 shrink-0 rounded-lg"
        />

        <dl className="grid flex-1 grid-cols-2 gap-x-4 gap-y-2 text-sm">
          <dt className="text-ink-muted">Category</dt>
          <dd className="text-right font-medium">{product.category.name}</dd>

          <dt className="text-ink-muted">Unit</dt>
          <dd className="text-right font-medium">{product.unit}</dd>

          <dt className="text-ink-muted">Price</dt>
          <dd className="text-right font-medium">
            <Money centavos={product.price} scale="body" />
          </dd>

          <dt className="text-ink-muted">Cost</dt>
          <dd className="text-right font-medium">
            <Money centavos={product.costPrice} scale="body" />
          </dd>

          <dt className="text-ink-muted">Sealed</dt>
          <dd className="text-right font-medium">
            <span className="font-mono tabular-nums">{product.stockQty}</span>
            {low && (
              <Badge tone="warn" className="ml-2">
                low
              </Badge>
            )}
          </dd>

          {/* Only when there are any. A row reading "Open bags 0" on all
              fifty-five products is a fact nobody needed. The label says bags
              rather than kilos on purpose: what is IN an open sack is still not
              counted, and never claims to be. */}
          {product.openBags > 0 && (
            <>
              <dt className="text-ink-muted">Open bags</dt>
              <dd className="text-right font-medium">
                <span className="font-mono tabular-nums">{product.openBags}</span>
                <span className="ml-2 text-xs font-normal text-ink-muted">
                  sold by the kilo; the loose feed is not counted
                </span>
              </dd>
            </>
          )}

          <dt className="text-ink-muted">Low stock at</dt>
          <dd className="text-right font-mono font-medium tabular-nums">
            {product.lowStockThreshold}
          </dd>
        </dl>
      </div>

      {product.description && (
        <p className="mt-4 whitespace-pre-wrap text-sm text-ink-muted">{product.description}</p>
      )}
    </Dialog>
  )
}
