import { beforeEach, describe, expect, it } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'
import { finishBag, openBag } from './open-bag'

beforeEach(resetDb)

async function makeProduct(stockQty = 20, isArchived = false) {
  const category = await prisma.category.create({ data: { name: 'Atlas' } })
  return prisma.product.create({
    data: {
      categoryId: category.id,
      name: 'Hog Grower (Premium)',
      unit: 'bag (50kg)',
      price: 201_000,
      costPrice: 0,
      stockQty,
      isArchived,
    },
  })
}

describe('opening a bag', () => {
  it('takes one sealed bag out of stock', async () => {
    const product = await makeProduct(20)
    const result = await openBag(product.id)

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.remaining).toBe(19)
    expect((await prisma.product.findUniqueOrThrow({ where: { id: product.id } })).stockQty).toBe(19)
  })

  it('records WHY the stock moved, which is the entire point', async () => {
    // Before this existed the only way to account for an opened bag was to
    // edit the figure by hand, which is indistinguishable from a mistake a
    // week later.
    const product = await makeProduct(20)
    await openBag(product.id)

    const movement = await prisma.stockMovement.findFirstOrThrow({ where: { productId: product.id } })
    expect(movement.type).toBe('OPENED')
    expect(movement.quantity).toBe(-1)
    expect(movement.note).toContain('per kilo')
  })

  it('keeps its own type, distinct from a hand correction', async () => {
    // MANUAL means "somebody typed a number". OPENED means "a bag was opened".
    // Collapsing them would make the history unable to answer the question
    // this feature exists for.
    const product = await makeProduct(20)
    await openBag(product.id)
    expect(await prisma.stockMovement.count({ where: { type: 'MANUAL' } })).toBe(0)
    expect(await prisma.stockMovement.count({ where: { type: 'OPENED' } })).toBe(1)
  })

  it('takes a reason when one is given', async () => {
    const product = await makeProduct(20)
    await openBag(product.id, 'For Aling Nena, 5kg')
    const movement = await prisma.stockMovement.findFirstOrThrow()
    expect(movement.note).toBe('For Aling Nena, 5kg')
  })

  it('records it even when the app thinks there are none left', async () => {
    // She is telling the app what she just did on the floor. Refusing would
    // leave the record wrong AND the bag still open. A negative figure is the
    // app's existing signal that the count is stale.
    const product = await makeProduct(0)
    const result = await openBag(product.id)
    expect(result.ok).toBe(true)
    if (result.ok) expect(result.data.remaining).toBe(-1)
  })

  it('opens several one at a time', async () => {
    const product = await makeProduct(3)
    await openBag(product.id)
    await openBag(product.id)
    expect((await prisma.product.findUniqueOrThrow({ where: { id: product.id } })).stockQty).toBe(1)
    expect(await prisma.stockMovement.count({ where: { type: 'OPENED' } })).toBe(2)
  })

  it('refuses an archived product', async () => {
    const product = await makeProduct(20, true)
    const result = await openBag(product.id)
    expect(result.ok).toBe(false)
    expect((await prisma.product.findUniqueOrThrow({ where: { id: product.id } })).stockQty).toBe(20)
  })

  it('refuses a product that does not exist, without writing a movement', async () => {
    expect((await openBag(999_999)).ok).toBe(false)
    expect(await prisma.stockMovement.count()).toBe(0)
  })
})

/**
 * The count exists so the shelf and the app agree. Twenty sacks with two open
 * used to read as eighteen, full stop — the two open ones were invisible until
 * somebody walked the shelves.
 */
describe('counting the sacks that are open', () => {
  it('moves a sack from sealed to open, which is one event seen twice', async () => {
    const product = await makeProduct(20)
    const result = await openBag(product.id)

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.remaining).toBe(19)
    expect(result.data.openBags).toBe(1)

    const after = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
    expect(after.stockQty).toBe(19)
    expect(after.openBags).toBe(1)
    // Nineteen sealed plus the one open is still the twenty on the shelf.
    expect(after.stockQty + after.openBags).toBe(20)
  })

  it('starts every product at none open', async () => {
    const product = await makeProduct(20)
    expect(product.openBags).toBe(0)
  })

  it('counts several open at once', async () => {
    const product = await makeProduct(20)
    await openBag(product.id)
    await openBag(product.id)

    const after = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
    expect(after.openBags).toBe(2)
    expect(after.stockQty).toBe(18)
  })
})

describe('finishing an open bag', () => {
  /**
   * Without this the count is not "sacks that are open" but "sacks ever
   * opened", which climbs forever and is wrong within a week.
   */
  it('brings the open count back down', async () => {
    const product = await makeProduct(20)
    await openBag(product.id)
    const result = await finishBag(product.id)

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.openBags).toBe(0)
  })

  /**
   * The sack left the sealed count when it was opened, and the feed went out
   * by the kilo as its own product. Finishing it moves no goods.
   */
  it('does not touch stock, because nothing moved', async () => {
    const product = await makeProduct(20)
    await openBag(product.id)
    const before = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })

    await finishBag(product.id)

    const after = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
    expect(after.stockQty).toBe(before.stockQty)
  })

  it('writes no movement, because there is no stock change to explain', async () => {
    const product = await makeProduct(20)
    await openBag(product.id)
    const before = await prisma.stockMovement.count({ where: { productId: product.id } })

    await finishBag(product.id)

    expect(await prisma.stockMovement.count({ where: { productId: product.id } })).toBe(before)
  })

  /** A count that can go negative is not a count of anything. */
  it('refuses when there is no open bag on record', async () => {
    const product = await makeProduct(20)
    const result = await finishBag(product.id)

    expect(result.ok).toBe(false)
    const after = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
    expect(after.openBags).toBe(0)
  })
})
