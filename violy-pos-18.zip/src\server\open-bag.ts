'use server'

import { prisma } from '@/lib/db'
import type { ActionResult } from '@/lib/types'
import { ROUTES } from '@/lib/routes'
import { revalidateRoutes } from './revalidate'

/**
 * Records that a sealed bag was opened to sell feed by the kilo.
 *
 * This does NOT track the loose feed, and that is the whole design. Nobody can
 * say how many kilos are left in an open sack without weighing it, so a figure
 * for it would be invented — and an invented number in an inventory is worse
 * than no number, because everything downstream believes it.
 *
 * What it does is explain the stock. Twenty bags becoming nineteen now has a
 * reason on the record: one was opened, not lost, not miscounted, not stolen.
 * Before this, the only way to account for an opened bag was to edit the stock
 * figure by hand, which looks identical to a mistake a week later.
 *
 * So: sealed bags go down by one, a movement says why, and the loose feed is
 * deliberately outside the system. Kilo sales are rung up as their own product
 * and take nothing off the bag count, which is correct — the bag already left
 * the count when it was opened.
 *
 * What DID change: the opened sack now has somewhere to live. `openBags` counts
 * sacks that are open — not what is in them. A sack is either open or it is
 * not, so that is countable and is counted; how many kilos remain inside one
 * still is not, and still is not guessed at. On the shelf there are twenty
 * sacks and two are open; the app used to be able to say only eighteen.
 */
export async function openBag(
  productId: number,
  note = '',
): Promise<ActionResult<{ remaining: number; openBags: number; productName: string }>> {
  if (!Number.isInteger(productId) || productId <= 0) {
    return { ok: false, error: 'That product does not exist.' }
  }

  const product = await prisma.product.findUnique({
    where: { id: productId },
    select: { id: true, name: true, unit: true, stockQty: true, isArchived: true },
  })
  if (!product) return { ok: false, error: 'That product no longer exists.' }
  if (product.isArchived) {
    return { ok: false, error: `${product.name} is archived. Restore it first.` }
  }

  let remaining: number
  let openBags: number
  try {
    const updated = await prisma.$transaction(async (tx) => {
      const next = await tx.product.update({
        where: { id: productId },
        // One statement, so the sealed count going down and the open count
        // going up cannot half-happen. They are the same event described from
        // two sides: the sack left the shelf and is now on the floor open.
        data: { stockQty: { decrement: 1 }, openBags: { increment: 1 } },
        select: { stockQty: true, openBags: true },
      })
      await tx.stockMovement.create({
        data: {
          productId,
          // A type of its own rather than MANUAL. "Somebody typed a number"
          // and "a bag was opened" are different events, and only one of them
          // is a correction — collapsing them would make the history unable
          // to answer the question this feature exists for.
          type: 'OPENED',
          quantity: -1,
          note: note.trim() || 'Opened a bag to sell per kilo',
        },
      })
      return next
    })
    remaining = updated.stockQty
    openBags = updated.openBags
  } catch {
    return { ok: false, error: 'Could not record the opened bag. Nothing was changed.' }
  }

  // Deliberately NOT refused when it takes stock below zero. She is telling
  // the app what she just did on the shop floor; refusing would leave the
  // record wrong AND the bag still open. A negative figure is the app's
  // existing signal that the count is stale, and the Count stock screen is
  // how that gets fixed.
  revalidateRoutes([ROUTES.stock, ROUTES.counter, ROUTES.dashboard], { layout: true })
  return { ok: true, data: { remaining, openBags, productName: product.name } }
}

/**
 * Records that an open sack has been emptied.
 *
 * Without this, `openBags` is not a count of open sacks — it is a count of
 * sacks ever opened, which climbs forever and is wrong by the end of the first
 * week. A number that is only ever incremented describes history, not a shelf.
 *
 * NOTHING happens to stock here, and that is correct rather than an omission.
 * The sack left the sealed count the moment it was opened, and the feed inside
 * it was sold by the kilo as its own product. Finishing it moves no goods; it
 * only stops the app claiming there is an open sack when there is not.
 *
 * No `StockMovement` either, for the same reason: a movement exists to explain
 * a change in stock, and there is no change to explain. A zero-quantity row
 * would be a record of nothing having happened to the stock, sitting in the
 * history of things that did.
 */
export async function finishBag(
  productId: number,
): Promise<ActionResult<{ openBags: number; productName: string }>> {
  if (!Number.isInteger(productId) || productId <= 0) {
    return { ok: false, error: 'That product does not exist.' }
  }

  const product = await prisma.product.findUnique({
    where: { id: productId },
    select: { id: true, name: true, openBags: true },
  })
  if (!product) return { ok: false, error: 'That product no longer exists.' }
  if (product.openBags <= 0) {
    return { ok: false, error: `${product.name} has no open bags on record.` }
  }

  let openBags: number
  try {
    const updated = await prisma.product.update({
      where: { id: productId },
      data: { openBags: { decrement: 1 } },
      select: { openBags: true },
    })
    openBags = updated.openBags
  } catch {
    return { ok: false, error: 'Could not record that. Nothing was changed.' }
  }

  revalidateRoutes([ROUTES.stock, ROUTES.counter, ROUTES.dashboard], { layout: true })
  return { ok: true, data: { openBags, productName: product.name } }
}
