import { describe, expect, it } from 'vitest'
import { type DeliveryDraft, restoreDraft } from './delivery-draft'

function draft(overrides: Partial<DeliveryDraft> = {}): DeliveryDraft {
  return {
    savedOn: '2026-08-25',
    customerId: 7,
    customerName: 'Aling Nena',
    deliverAt: '2026-08-27',
    deliverTo: 'Aling Nena',
    address: 'Bagac, back gate',
    instructions: 'Leave with the caretaker',
    fee: '300',
    discountAmount: '150',
    discountKind: 'AMOUNT',
    rows: [{ productId: '4', quantity: '3' }],
    paymentMode: 'credit',
    cash: '',
    clientOrderKey: 'abc-123',
    ...overrides
  }
}

describe('restoreDraft', () => {
  it('brings back everything she typed when the draft is from today', () => {
    expect(restoreDraft(draft(), '2026-08-25')).toEqual(draft())
  })

  /**
   * The one field that is not restored, and the reason is paper rather than
   * validation. Backdating is DELIBERATE here — a load that went out yesterday
   * gets typed up this morning, and `validateDeliveryDetails` allows it on
   * purpose. So a past date is not an error and cannot be treated as one.
   *
   * What is dangerous is a date that has gone stale without her noticing: a
   * draft started on Monday and finished on Wednesday still says Monday, and
   * saving it prints the wrong date on a note somebody signs. The trigger is
   * therefore the CALENDAR moving, not the date being in the past.
   */
  it('drops the delivery date when the draft is from an earlier day', () => {
    const stale = restoreDraft(draft({ savedOn: '2026-08-24' }), '2026-08-25')
    expect(stale.deliverAt).toBe('')
  })

  it('keeps everything else on a stale draft — the address is still good', () => {
    const stale = restoreDraft(draft({ savedOn: '2026-08-24' }), '2026-08-25')
    expect(stale.address).toBe('Bagac, back gate')
    expect(stale.instructions).toBe('Leave with the caretaker')
    expect(stale.rows).toEqual([{ productId: '4', quantity: '3' }])
    expect(stale.customerId).toBe(7)
    expect(stale.fee).toBe('300')
  })

  /**
   * A date she deliberately backdated WITHIN the same day is hers, not stale.
   * Clearing it would fight the backdating the validator exists to allow.
   */
  it('keeps a deliberately backdated date while the day has not turned', () => {
    const same = restoreDraft(draft({ deliverAt: '2026-08-20' }), '2026-08-25')
    expect(same.deliverAt).toBe('2026-08-20')
  })

  /**
   * The idempotency key travels with the draft. If a save failed and she left
   * the screen and came back, retrying must reuse it — `createOrder` looks the
   * sale up by this key and returns the existing one rather than charging a
   * customer twice, which AGENTS.md calls the most damaging bug this app can
   * ship. A fresh key on return would defeat that.
   */
  it('carries the order key, so a retry after leaving cannot double-charge', () => {
    expect(restoreDraft(draft({ savedOn: '2026-08-01' }), '2026-08-25').clientOrderKey).toBe(
      'abc-123',
    )
  })
})
