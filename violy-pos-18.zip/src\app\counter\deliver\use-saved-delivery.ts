'use client'

import { useEffect, useState } from 'react'
import { dayKey } from '@/lib/dates'
import { type DeliveryDraft, restoreDraft } from '@/lib/delivery-draft'

const STORAGE_KEY = 'deliver-draft'

/**
 * Keeps a half-built delivery order alive across navigation.
 *
 * The same shape and the same reasoning as `use-saved-order.ts`, deliberately:
 * `sessionStorage` rather than `localStorage`, so a draft outlasts a tab switch
 * but not a closed app. A delivery order from three days ago reappearing is
 * worse than none at all, because it looks like today's — and here that risk is
 * sharper than at the counter, since this screen carries a DATE. What the
 * calendar turning does to that date is decided by `restoreDraft`.
 *
 * Read AFTER mount, never in a `useState` initialiser: the initialiser also
 * runs on the server pass, where `sessionStorage` does not exist. Same rule
 * `AppRail` follows for its collapsed state.
 */
export function useSavedDelivery(): {
  restored: DeliveryDraft | null
  ready: boolean
  save: (draft: Omit<DeliveryDraft, 'savedOn'>) => void
  clear: () => void
} {
  const [restored, setRestored] = useState<DeliveryDraft | null>(null)
  const [ready, setReady] = useState(false)

  useEffect(() => {
    try {
      const raw = window.sessionStorage.getItem(STORAGE_KEY)
      if (raw) setRestored(restoreDraft(JSON.parse(raw) as DeliveryDraft, dayKey(new Date())))
    } catch {
      // Malformed or unreadable storage is not worth an error at the counter.
      // The worst case is starting from an empty form, which is where every
      // delivery starts anyway.
    }
    setReady(true)
  }, [])

  function save(draft: Omit<DeliveryDraft, 'savedOn'>) {
    try {
      // Nothing typed yet is not worth keeping, and writing it would resurrect
      // an empty draft over a form she has deliberately cleared. "Something
      // typed" is judged on the fields she actually fills in, not on the date,
      // which is pre-filled with today and is therefore never evidence of work.
      const empty =
        draft.customerId === null &&
        draft.deliverTo.trim() === '' &&
        draft.address.trim() === '' &&
        draft.instructions.trim() === '' &&
        draft.fee.trim() === '' &&
        draft.discountAmount.trim() === '' &&
        draft.cash.trim() === '' &&
        draft.rows.every((row) => row.productId === '' && row.quantity === '')

      if (empty) window.sessionStorage.removeItem(STORAGE_KEY)
      else {
        window.sessionStorage.setItem(
          STORAGE_KEY,
          JSON.stringify({ ...draft, savedOn: dayKey(new Date()) } satisfies DeliveryDraft),
        )
      }
    } catch {
      // Storage can be full or blocked; the order itself does not depend on it.
    }
  }

  function clear() {
    try {
      window.sessionStorage.removeItem(STORAGE_KEY)
    } catch {
      // Same: nothing here is load-bearing for money.
    }
  }

  return { restored, ready, save, clear }
}
