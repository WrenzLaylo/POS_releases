import { describe, expect, it } from 'vitest'
import { KILOS_PER_BAG, kiloCostCentavos, lineKey, parseLineKey, unitSold } from './per-kilo'

describe('KILOS_PER_BAG', () => {
  /**
   * A constant rather than a column, because every bag in this shop is 50
   * kilos. Four products were recorded as "bag (25kg)" and are mis-entered —
   * the label is only a label, and nothing reads a weight off it.
   */
  it('is 50, because that is what a bag is here', () => {
    expect(KILOS_PER_BAG).toBe(50)
  })
})

describe('kiloCostCentavos', () => {
  it('splits the bag cost across the kilos in it', () => {
    // A 1,900.00 sack is 38.00 a kilo.
    expect(kiloCostCentavos(190_000)).toBe(3_800)
  })

  /**
   * Centavos are whole numbers everywhere in this app. A cost that divides
   * unevenly must not carry a fraction into `costAtSale`, which is an Int.
   */
  it('rounds to a whole centavo', () => {
    // 1,479.00 / 50 = 29.58 exactly.
    expect(kiloCostCentavos(147_900)).toBe(2_958)
    // 1,959.00 / 50 = 39.18 exactly.
    expect(kiloCostCentavos(195_900)).toBe(3_918)
    // Something that genuinely does not divide: 1,000.03 / 50 = 20.0006.
    expect(Number.isInteger(kiloCostCentavos(100_003))).toBe(true)
  })

  /** Every cost price in the catalogue is 0 today, so this is the common case. */
  it('costs nothing when the bag cost has not been typed in yet', () => {
    expect(kiloCostCentavos(0)).toBe(0)
  })
})

describe('lineKey', () => {
  /**
   * The whole reason a composite key exists. Two bags of Broodsow and five
   * kilos out of the open one is ONE order with TWO lines — merging them on
   * `productId` alone would add 2 and 5 into a single line of 7 at whichever
   * price won, which is either seven bags or seven kilos and wrong both ways.
   */
  it('keeps bags and kilos of the same product apart', () => {
    expect(lineKey(4, false)).not.toBe(lineKey(4, true))
  })

  it('still merges two rows of the same kind', () => {
    expect(lineKey(4, false)).toBe(lineKey(4, false))
    expect(lineKey(4, true)).toBe(lineKey(4, true))
  })

  it('keeps different products apart', () => {
    expect(lineKey(4, true)).not.toBe(lineKey(5, true))
  })
})

describe('unitSold', () => {
  /** A kilo line printing "3 bag" on a receipt is a wrong document. */
  it('says kilo for a per-kilo line, whatever the product is packed in', () => {
    expect(unitSold('bag (50kg)', true)).toBe('kilo')
    expect(unitSold('bag', true)).toBe('kilo')
  })

  it('leaves an ordinary line alone', () => {
    expect(unitSold('bag (50kg)', false)).toBe('bag (50kg)')
    expect(unitSold('pack (25x1kg)', false)).toBe('pack (25x1kg)')
  })
})

describe('parseLineKey', () => {
  it('round-trips a sack line', () => {
    expect(parseLineKey(lineKey(4, false))).toEqual({ productId: 4, soldPerKilo: false })
  })

  it('round-trips a kilo line', () => {
    expect(parseLineKey(lineKey(9, true))).toEqual({ productId: 9, soldPerKilo: true })
  })

  /**
   * The counter's saved draft used to key its lines by a bare product id, and a
   * draft written by an older build must still restore — the same rule
   * `lineDiscounts` follows in `use-saved-order.ts`. A bare id is a sack.
   */
  it('reads an old draft key, which was just a product id', () => {
    expect(parseLineKey('4')).toEqual({ productId: 4, soldPerKilo: false })
  })

  it('refuses a key it cannot read rather than inventing a product', () => {
    expect(parseLineKey('')).toBeNull()
    expect(parseLineKey('banana')).toBeNull()
    expect(parseLineKey(':kilo')).toBeNull()
  })
})
