/**
 * Selling loose feed out of an open sack, by the kilo.
 *
 * A bag and a kilo of the same feed are the SAME product with two prices, not
 * two products. So a product carries `pricePerKiloCentavos` alongside `price`,
 * and a sale line carries `soldPerKilo` to say which of the two it was priced
 * at. Everything downstream — totals, discounts, receipts, profit — already
 * works in "price per unit × quantity" and needs no idea that kilos exist.
 *
 * The rules live here rather than in the two sale writers because `sales.ts`
 * (walk-in) and `orders.ts` (customer and delivery) both need every one of
 * them, and a copy in each is a copy that drifts.
 */

/**
 * Every bag in this shop is 50 kilos.
 *
 * A constant rather than a column, decided 25 Aug 2026. Four products were
 * recorded as "bag (25kg)" — all pre-starter or high-density types — and are
 * mis-entered; the unit is a label and nothing reads a weight off it. If the
 * shop ever genuinely stocks two sack sizes this has to become a field on the
 * product, because it decides what a kilo COSTS and therefore what the profit
 * on it is.
 */
export const KILOS_PER_BAG = 50

/**
 * What one kilo out of a sack cost the shop.
 *
 * Derived rather than typed, unlike the price. A cost is a fact about a sack
 * that has already been bought — splitting it is arithmetic, and asking her to
 * type the same figure twice invites the two to disagree. The PRICE is typed,
 * because what she charges for breaking bulk is a decision rather than a
 * division: a 1,910.00 sack works out at 38.20 a kilo, and nobody sells it for
 * that.
 *
 * Rounded to a whole centavo because `costAtSale` is an Int, as every money
 * column in this app is.
 */
export function kiloCostCentavos(bagCostCentavos: number): number {
  return Math.round(bagCostCentavos / KILOS_PER_BAG)
}

/**
 * How a sale line is identified while rows are merged into lines.
 *
 * Composite because two bags of Broodsow and five kilos out of the open one is
 * one order with TWO lines. Merging on `productId` alone would add 2 and 5 into
 * a line of 7 at whichever price won — seven bags or seven kilos, wrong either
 * way, and wrong in pesos.
 */
export function lineKey(productId: number, soldPerKilo: boolean): string {
  return `${productId}:${soldPerKilo ? 'kilo' : 'unit'}`
}

/**
 * The other half of `lineKey`, for the counter — which holds its order as a map
 * keyed this way and has to get a product id back out to save it.
 *
 * A bare number is read as a sack. The counter's saved draft used to key its
 * lines by product id alone, and a draft written by an older build must still
 * restore — the same courtesy `use-saved-order.ts` already extends to
 * `lineDiscounts`. Returns null rather than guessing at anything it cannot
 * read, so a corrupt draft loses a line instead of inventing a product.
 */
export function parseLineKey(key: string): { productId: number; soldPerKilo: boolean } | null {
  const [rawId, kind] = key.split(':')
  if (!/^\d+$/.test(rawId)) return null
  if (kind !== undefined && kind !== 'kilo' && kind !== 'unit') return null
  return { productId: Number(rawId), soldPerKilo: kind === 'kilo' }
}

/** What the line is measured in, for anything that prints or displays it. */
export function unitSold(productUnit: string, soldPerKilo: boolean): string {
  return soldPerKilo ? 'kilo' : productUnit
}
