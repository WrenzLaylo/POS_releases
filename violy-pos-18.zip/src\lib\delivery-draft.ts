/**
 * What survives leaving the delivery screen and coming back.
 *
 * The counter has kept a half-built order alive since `use-saved-order.ts` —
 * "tapping Book to check what somebody owes, then coming back to a cleared
 * counter, means re-tallying a physical pile of sacks from memory". The
 * delivery screen never got the same treatment, which is backwards: it holds
 * strictly more typing than the counter does. A customer, a date, an address,
 * the line printed on the note, the driver's instructions, a fee, a discount
 * and every line of the load.
 */
export type DeliveryDraft = {
  /** The day the draft was written, which is what decides if its date is stale. */
  savedOn: string
  customerId: number | null
  customerName: string | null
  deliverAt: string
  deliverTo: string
  address: string
  instructions: string
  fee: string
  discountAmount: string
  discountKind: string
  rows: { productId: string; quantity: string }[]
  paymentMode: string
  cash: string
  /**
   * Carried deliberately.
   *
   * `createOrder` looks a sale up by this key and returns the existing one
   * rather than writing a second — so if a save failed, she left the screen and
   * came back, the retry must reuse the key. Minting a fresh one on return
   * would turn the retry into the double charge the key exists to prevent, and
   * AGENTS.md calls that the most damaging bug this app can ship.
   */
  clientOrderKey: string
}

/**
 * The draft as it should come back, given what day it is now.
 *
 * Everything returns except a delivery date that has gone stale, and the test
 * for stale is the CALENDAR MOVING rather than the date being in the past.
 * That distinction is the whole rule: `validateDeliveryDetails` allows
 * backdating on purpose, because a load that went out yesterday gets typed up
 * this morning and refusing that would push her to date it today — putting a
 * wrong date on the note somebody signed. So a past date is not an error and
 * must not be treated as one.
 *
 * The danger is narrower: a draft started on Monday and finished on Wednesday
 * still says Monday, and saving it prints that on the note. Once the day has
 * turned, the date comes back empty and she picks it again. Everything else —
 * the address, the instructions, the load — is still perfectly good and is kept.
 */
export function restoreDraft(draft: DeliveryDraft, today: string): DeliveryDraft {
  if (draft.savedOn === today) return draft
  return { ...draft, deliverAt: '' }
}
