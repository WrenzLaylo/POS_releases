'use server'

import type { Prisma } from '@prisma/client'
import { prisma } from '@/lib/db'
import { unitKeywordsOf } from '@/lib/unit'
import { toCentavos } from '@/lib/money'
import { deleteProductImage, saveProductImage } from '@/server/uploads'
import { PAGE_SIZE, pageCountOf, clampPage } from '@/lib/pagination'
import type { ActionResult, LowStockItem, Paged, ProductFilters, ProductWithCategory } from '@/lib/types'
import type { ProductSortKey } from '@/lib/product-sort'
import { ROUTES } from '@/lib/routes'
import { revalidateRoutes } from './revalidate'

const WITH_CATEGORY = { category: { select: { id: true, name: true } } }

export async function listProducts(): Promise<ProductWithCategory[]> {
  return prisma.product.findMany({
    where: { isArchived: false },
    include: WITH_CATEGORY,
    orderBy: [
      { category: { sortOrder: 'asc' } },
      { category: { name: 'asc' } },
      { name: 'asc' },
    ],
  })
}

/** One low-stock definition for the dashboard and global bell. Prisma/SQLite
 * cannot compare two columns in a where clause, so the threshold comparison
 * happens after selecting only live products. */
export async function listLowStockProducts(): Promise<LowStockItem[]> {
  const products = await prisma.product.findMany({
    where: { isArchived: false },
    select: { id: true, name: true, unit: true, stockQty: true, lowStockThreshold: true },
  })

  return products
    .filter((product) => product.stockQty <= product.lowStockThreshold)
    .sort((a, b) => a.stockQty - b.stockQty || a.name.localeCompare(b.name))
}

/**
 * Sorting happens in the DATABASE, not in the page component. The table is
 * server-paginated, so reordering the twelve rows already fetched would sort
 * one page against itself and leave the other pages untouched — which looks
 * like a bug and hides the row you were sorting to find.
 *
 * `id` is appended to every ordering as a tiebreaker: two products at the same
 * price would otherwise come back in an arbitrary order that can differ
 * between page 1 and page 2, duplicating one row and dropping another.
 */
function productOrderBy(
  sort: ProductSortKey,
  direction: 'asc' | 'desc',
): Prisma.ProductOrderByWithRelationInput[] {
  switch (sort) {
    case 'category':
      return [{ category: { name: direction } }, { name: 'asc' }, { id: 'asc' }]
    case 'price':
      return [{ price: direction }, { name: 'asc' }, { id: 'asc' }]
    case 'cost':
      return [{ costPrice: direction }, { name: 'asc' }, { id: 'asc' }]
    case 'stock':
      return [{ stockQty: direction }, { name: 'asc' }, { id: 'asc' }]
    case 'name':
    default:
      return [{ name: direction }, { id: 'asc' }]
  }
}

export async function listAllProducts(
  filters: ProductFilters = {},
  page = 1,
  sort: ProductSortKey = 'name',
  direction: 'asc' | 'desc' = 'asc',
): Promise<Paged<ProductWithCategory>> {
  const where: Prisma.ProductWhereInput = {}

  if (!filters.includeArchived) where.isArchived = false
  if (filters.categoryId) where.categoryId = filters.categoryId
  // SQLite's LIKE is already case-insensitive for plain ASCII, and Prisma
  // does not support `mode: 'insensitive'` on this provider.
  if (filters.q?.trim()) where.name = { contains: filters.q.trim() }

  // "Low" is a comparison between two COLUMNS on the same row, not against a
  // constant — every product carries its own threshold, because thirty sacks
  // is comfortable for a bestseller and a year's supply of something else.
  // `prisma.product.fields.lowStockThreshold` is Prisma's field reference,
  // which compiles to a plain `stockQty <= lowStockThreshold` in SQL. Without
  // it this would mean reading every row into memory to filter it, which
  // would also break the pagination and the count above.
  //
  // The three branches mirror `stockLevelOf` exactly and must keep doing so:
  // out is `<= 0` and never merely `= 0`, since a sale is allowed to push a
  // count negative when the shop has stock it has not counted in yet.
  if (filters.stock === 'out') {
    where.stockQty = { lte: 0 }
  } else if (filters.stock === 'low') {
    where.stockQty = { gt: 0, lte: prisma.product.fields.lowStockThreshold }
  } else if (filters.stock === 'in') {
    where.stockQty = { gt: prisma.product.fields.lowStockThreshold }
  }

  const total = await prisma.product.count({ where })
  const pageCount = pageCountOf(total)
  const current = clampPage(page, pageCount)

  const rows = await prisma.product.findMany({
    where,
    include: WITH_CATEGORY,
    orderBy: productOrderBy(sort, direction),
    skip: (current - 1) * PAGE_SIZE,
    take: PAGE_SIZE,
  })

  return { rows, total, page: current, pageCount }
}

/**
 * The unit kinds the catalog actually sells in — "bag", "kilo", "pack".
 *
 * Read from the products rather than a fixed list, so a shop that starts
 * selling by the drum gets "drum" offered without a code change. Archived
 * products count: a discount scoped to a unit should not stop being offerable
 * because the last product using it was archived this morning.
 */
export async function listProductUnits(): Promise<string[]> {
  const products = await prisma.product.findMany({ select: { unit: true } })
  return unitKeywordsOf(products)
}

export async function listCategories(): Promise<{ id: number; name: string }[]> {
  return prisma.category.findMany({
    select: { id: true, name: true },
    orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
  })
}

type ParsedProduct = {
  name: string
  categoryId: number
  unit: string
  price: number
  /** Null means this feed is never sold loose, which is most of them. */
  pricePerKiloCentavos: number | null
  costPrice: number
  stockQty: number
  lowStockThreshold: number
  description: string
}

function parseForm(form: FormData): ParsedProduct | string {
  const name = String(form.get('name') ?? '').trim()
  if (!name) return 'Name is required.'

  const unit = String(form.get('unit') ?? '').trim()
  if (!unit) return 'Unit is required.'

  const categoryId = Number(form.get('categoryId'))
  if (!Number.isInteger(categoryId) || categoryId <= 0) return 'Category is required.'

  const price = Number(form.get('price'))
  const costPrice = Number(form.get('costPrice'))
  const stockQty = Number(form.get('stockQty'))
  const lowStockThreshold = Number(form.get('lowStockThreshold') ?? 0)

  // Blank is a real answer here, and the common one — it means this feed is
  // not sold by the kilo. Distinguished from a typed zero, which would be
  // giving it away.
  const rawPerKilo = String(form.get('pricePerKiloCentavos') ?? '').trim()
  const perKilo = rawPerKilo === '' ? null : Number(rawPerKilo)

  if (!Number.isFinite(price) || price < 0) return 'Price must be zero or more.'
  if (!Number.isFinite(costPrice) || costPrice < 0) return 'Cost price must be zero or more.'
  if (perKilo !== null && (!Number.isFinite(perKilo) || perKilo < 0)) {
    return 'Price per kilo must be zero or more, or left blank.'
  }
  if (!Number.isFinite(stockQty)) return 'Stock quantity must be a number.'
  if (!Number.isFinite(lowStockThreshold) || lowStockThreshold < 0)
    return 'Low stock threshold must be zero or more.'

  return {
    name,
    categoryId,
    unit,
    price: toCentavos(price),
    pricePerKiloCentavos: perKilo === null ? null : toCentavos(perKilo),
    costPrice: toCentavos(costPrice),
    stockQty,
    lowStockThreshold,
    description: String(form.get('description') ?? '').trim(),
  }
}

class ProductImageError extends Error {}

async function readImagePath(form: FormData): Promise<string | null> {
  const image = form.get('image')
  if (!(image instanceof File) || image.size === 0) return null
  const saved = await saveProductImage(image)
  if (!saved) {
    throw new ProductImageError(
      'The product image was not accepted. Use a PNG, JPG, WebP or GIF up to 5 MB.',
    )
  }
  return saved
}

/**
 * The product already on file under this name, if there is one.
 *
 * Matched case-insensitively and ignoring surrounding spaces, the same way
 * `import-data.ts` matches, because "atlas grower " typed at the end of a long
 * day is the same sack as "Atlas Grower" and a second row for it is worse than
 * a refusal. Two products sharing a name are indistinguishable everywhere the
 * operator can see them — the till shows a name and a unit — so the stock
 * splits across two rows, the CSV importer can no longer tell which one a
 * spreadsheet row means, and the counter's type-and-Enter shortcut stops
 * finding a sole match.
 *
 * `contains` first, then an exact comparison in JS: SQLite's `=` is
 * case-sensitive, its LIKE is not, and Prisma has no `mode: 'insensitive'` on
 * this provider. So the LIKE narrows to a handful of candidates and the real
 * test happens here.
 *
 * Archived products count. They still hold the name, and the answer she needs
 * is "restore the old one", not a second copy alongside the first.
 */
async function findByName(
  name: string,
  excludeId?: number,
): Promise<{ id: number; name: string; isArchived: boolean } | null> {
  const needle = name.trim().toLowerCase()
  if (!needle) return null

  const candidates = await prisma.product.findMany({
    where: { name: { contains: needle } },
    select: { id: true, name: true, isArchived: true },
  })

  return (
    candidates.find(
      (row) => row.name.trim().toLowerCase() === needle && row.id !== excludeId,
    ) ?? null
  )
}

function duplicateMessage(existing: { name: string; isArchived: boolean }): string {
  return existing.isArchived
    ? `“${existing.name}” already exists but is archived. Restore it from the archived list instead of adding it again.`
    : `“${existing.name}” is already in the list. Edit that product instead, or give this one a different name.`
}

export async function createProduct(form: FormData): Promise<ActionResult<number>> {
  const parsed = parseForm(form)
  if (typeof parsed === 'string') return { ok: false, error: parsed }

  // Checked BEFORE the image is written: a refused product must not leave an
  // orphaned photo behind on disk.
  const clash = await findByName(parsed.name)
  if (clash) return { ok: false, error: duplicateMessage(clash) }

  let productId: number
  let imagePath: string | null = null
  try {
    const category = await prisma.category.findUnique({ where: { id: parsed.categoryId } })
    if (!category) return { ok: false, error: 'Category not found.' }

    imagePath = await readImagePath(form)

    const product = await prisma.$transaction(async (tx) => {
      const created = await tx.product.create({ data: { ...parsed, imagePath } })
      if (parsed.stockQty !== 0) {
        await tx.stockMovement.create({
          data: {
            productId: created.id,
            type: 'MANUAL',
            quantity: parsed.stockQty,
            note: 'Opening stock',
          },
        })
      }
      return created
    })
    productId = product.id
  } catch (error) {
    if (imagePath) await deleteProductImage(imagePath)
    if (error instanceof ProductImageError) return { ok: false, error: error.message }
    return { ok: false, error: 'Could not save the product.' }
  }

  revalidateRoutes([ROUTES.stock, ROUTES.counter], { layout: true })
  return { ok: true, data: productId }
}

export async function updateProduct(form: FormData): Promise<ActionResult<void>> {
  const id = Number(form.get('id'))
  if (!Number.isInteger(id) || id <= 0) return { ok: false, error: 'Product id is required.' }

  const parsed = parseForm(form)
  if (typeof parsed === 'string') return { ok: false, error: parsed }

  // Renaming onto a name another product already holds is the same collision
  // as creating one, and is the easier of the two to do by accident. `id` is
  // excluded so saving a product without touching its name is not a clash
  // with itself.
  const clash = await findByName(parsed.name, id)
  if (clash) return { ok: false, error: duplicateMessage(clash) }

  let newImagePath: string | null = null
  try {
    const existing = await prisma.product.findUnique({ where: { id } })
    if (!existing) return { ok: false, error: 'Product not found.' }

    const category = await prisma.category.findUnique({ where: { id: parsed.categoryId } })
    if (!category) return { ok: false, error: 'Category not found.' }

    newImagePath = await readImagePath(form)
    const stockDelta = parsed.stockQty - existing.stockQty

    await prisma.$transaction(async (tx) => {
      await tx.product.update({
        data: { ...parsed, ...(newImagePath ? { imagePath: newImagePath } : {}) },
        where: { id },
      })
      if (stockDelta !== 0) {
        await tx.stockMovement.create({
          data: {
            productId: id,
            type: 'MANUAL',
            quantity: stockDelta,
            note: 'Stock corrected from product form',
          },
        })
      }
    })

    if (newImagePath && existing.imagePath && newImagePath !== existing.imagePath) {
      await deleteProductImage(existing.imagePath)
    }
  } catch (error) {
    if (newImagePath) await deleteProductImage(newImagePath)
    if (error instanceof ProductImageError) return { ok: false, error: error.message }
    return { ok: false, error: 'Could not save the product.' }
  }

  revalidateRoutes([ROUTES.stock, ROUTES.counter], { layout: true })
  return { ok: true, data: undefined }
}

export async function archiveProduct(id: number): Promise<ActionResult<void>> {
  if (!Number.isInteger(id) || id <= 0) return { ok: false, error: 'Product id is required.' }

  try {
    const existing = await prisma.product.findUnique({ where: { id } })
    if (!existing) return { ok: false, error: 'Product not found.' }

    await prisma.product.update({ data: { isArchived: true }, where: { id } })
  } catch {
    return { ok: false, error: 'Could not archive the product.' }
  }

  revalidateRoutes([ROUTES.stock, ROUTES.counter], { layout: true })
  return { ok: true, data: undefined }
}

/** The way back from `archiveProduct`. Archiving was previously a one-way
 *  door — a mis-click needed a direct database edit to undo. Mirrors
 *  `restoreCustomer` in `customers.ts`, which closed the same gap for
 *  customers first. */
export async function restoreProduct(id: number): Promise<ActionResult<void>> {
  if (!Number.isInteger(id) || id <= 0) return { ok: false, error: 'Product id is required.' }

  try {
    const existing = await prisma.product.findUnique({ where: { id } })
    if (!existing) return { ok: false, error: 'Product not found.' }

    await prisma.product.update({ data: { isArchived: false }, where: { id } })
  } catch {
    return { ok: false, error: 'Could not restore the product.' }
  }

  revalidateRoutes([ROUTES.stock, ROUTES.counter], { layout: true })
  return { ok: true, data: undefined }
}
