'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createProduct, updateProduct } from '@/server/products'
import { toPesos } from '@/lib/money'
import type { ProductWithCategory } from '@/lib/types'
import { Button } from '@/components/ui/Button'
import { Dialog } from '@/components/ui/Dialog'
import { Field } from '@/components/ui/Field'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'
import { Select } from '@/components/ui/Select'
import { Textarea } from '@/components/ui/Textarea'

type Props = {
  categories: { id: number; name: string }[]
  product: ProductWithCategory | null
  onClose: () => void
}

/**
 * The caller (`InventoryTable`) only mounts this component while it should be
 * open, so `Dialog`'s own `open` is always `true` here — closing means the
 * parent stops rendering this component, not `open` flipping to `false` on a
 * persistent instance. Same convention as `CustomerForm` in `src/app/book/`,
 * and for the same reason: a fresh mount means every field below
 * re-initialises from the current `product` prop instead of carrying over
 * whatever was typed the previous time the form was open.
 *
 * All Escape-to-close, focus-trapping, body-scroll-locking, and
 * focus-restoration behaviour comes from `Dialog`/`Overlay` — this component
 * adds none of its own, and must not.
 */
export function ProductForm({ categories, product, onClose }: Props) {
  const router = useRouter()
  const [error, setError] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [imageName, setImageName] = useState<string | null>(null)

  /**
   * `onSubmit`, deliberately not `action`.
   *
   * A form with an `action` function is RESET by React once the action
   * returns — including when it returns a failure. So every rejected save
   * emptied every field: type a long product name, be told it is already in
   * the list, and find the box blank with nothing to correct. That applies to
   * every error, not only duplicates; a mistyped price wiped the name too.
   *
   * Handling submit ourselves keeps the fields exactly as she left them, which
   * is the whole point of showing her an error rather than a blank form.
   */
  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const formData = new FormData(event.currentTarget)

    setSaving(true)
    setError(null)

    const result = product ? await updateProduct(formData) : await createProduct(formData)

    setSaving(false)
    if (!result.ok) {
      setError(result.error)
      return
    }
    router.refresh()
    onClose()
  }

  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title={product ? 'Edit product' : 'New product'}
      footer={
        <div className="flex justify-end gap-2">
          <Button type="button" variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          {/* Lives in the footer, outside the <form>, so it submits via the
              standard `form` attribute rather than nesting into Dialog's
              own layout. */}
          <Button type="submit" form="product-form" variant="primary" disabled={saving}>
            {saving ? 'Saving…' : 'Save'}
          </Button>
        </div>
      }
    >
      <form id="product-form" onSubmit={handleSubmit} className="grid gap-4">
        {product && <input type="hidden" name="id" value={product.id} />}

        <Field label="Name">
          <Input
            name="name"
            defaultValue={product?.name ?? ''}
            required
            className="w-full"
            placeholder="Hog Grower"
          />
        </Field>

        <div className="grid grid-cols-2 gap-4">
          <Field label="Category">
            <Select
              name="categoryId"
              defaultValue={product?.categoryId ?? categories[0]?.id}
              className="w-full"
            >
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </Select>
          </Field>

          <Field label="Unit">
            <Input
              name="unit"
              defaultValue={product?.unit ?? ''}
              required
              className="w-full"
              placeholder="bag (50kg)"
            />
          </Field>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <Field label="Selling price (₱)">
            <Input
              name="price"
              type="number"
              step="0.01"
              min="0"
              defaultValue={product ? toPesos(product.price) : ''}
              required
              className="w-full"
            />
          </Field>

          <Field label="Cost price (₱)">
            <Input
              name="costPrice"
              type="number"
              step="0.01"
              min="0"
              defaultValue={product ? toPesos(product.costPrice) : ''}
              required
              className="w-full"
            />
          </Field>
        </div>

        {/* Not required, and blank is the ordinary answer — most feed is only
            ever sold by the sack. Filling it in is what makes "Add a kilo"
            appear at the counter once a bag of this feed is open.

            Typed rather than worked out from the sack price: what she charges
            for breaking bulk is a decision, not a division. A ₱1,910 sack is
            ₱38.20 a kilo and nobody sells it for that. The COST of a kilo is
            derived from the sack cost, so there is no second cost box. */}
        <Field label="Price per kilo (₱) — blank if never sold loose">
          <Input
            name="pricePerKiloCentavos"
            type="number"
            step="0.01"
            min="0"
            defaultValue={
              product?.pricePerKiloCentavos != null ? toPesos(product.pricePerKiloCentavos) : ''
            }
            className="w-full"
          />
        </Field>

        <div className="grid grid-cols-2 gap-4">
          {/* `step="1"` on the two quantity fields, NOT `step="0.01"`. These
              count sacks and kilos, so the spinner arrows have to move by one
              — nudging a sack count to 0.09, as reported, is never what
              anybody meant.

              And deliberately NO `min` here. `min` sets the step base, which
              turns `step="1"` into "whole numbers only" and rejects the 18.5
              kilos that Broodsow (kilo) actually holds. Without it the arrows
              still move by one while a typed decimal stays valid — verified
              against the browser, not assumed. Negatives are refused by
              `parseProductForm` in products.ts, which is where that check
              belongs anyway: the form is a convenience, the server is the
              rule. Stock itself is allowed to go negative, since the counter
              can oversell with a confirmation. */}
          <Field label="Stock quantity">
            <Input
              name="stockQty"
              type="number"
              step="1"
              defaultValue={product?.stockQty ?? 0}
              required
              className="w-full"
            />
          </Field>

          <Field label="Low stock alert at">
            <Input
              name="lowStockThreshold"
              type="number"
              step="1"
              defaultValue={product?.lowStockThreshold ?? 0}
              className="w-full"
            />
          </Field>
        </div>

        <Field label="Description">
          <Textarea
            name="description"
            defaultValue={product?.description ?? ''}
            rows={2}
            className="w-full"
          />
        </Field>

        <div className="grid gap-1 text-sm">
          <span className="font-medium">Image</span>
          <div className="flex items-center gap-3">
            {/* The native control is visually hidden but still focusable and
                still wrapped by its label, so clicking the styled label opens
                the picker and keyboard users reach it normally. */}
            <label className="inline-flex h-10 cursor-pointer items-center justify-center rounded-control border border-line-strong bg-surface px-4 text-sm font-medium text-ink transition-colors duration-150 hover:bg-surface-sunk focus-within:ring-2 focus-within:ring-accent focus-within:ring-offset-2">
              Choose image
              <input
                name="image"
                type="file"
                accept="image/*"
                className="sr-only"
                onChange={(e) => setImageName(e.target.files?.[0]?.name ?? null)}
              />
            </label>
            <span className="text-sm text-ink-muted">
              {imageName ?? 'No file chosen'}
            </span>
          </div>
          {product?.imagePath && (
            <span className="text-xs text-ink-muted">
              Leave empty to keep the current image.
            </span>
          )}
        </div>

        {error && <FormError>{error}</FormError>}
      </form>
    </Dialog>
  )
}
