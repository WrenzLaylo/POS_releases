-- Loose feed can be sold, not just accounted for.
--
-- Opening a bag already took the sack out of the sealed count and said why. It
-- left the kilos with nowhere to go: there was no way to ring up "five kilos of
-- Broodsow" unless somebody had made a separate per-kilo product, and the
-- catalogue has exactly one of those. So the feed went out of the door and the
-- app recorded no sale for it — missing from benta and from profit both.
--
-- A bag and a kilo of the same feed are the SAME product with two prices, not
-- two products. `pricePerKiloCentavos` is that second price; NULL means this
-- feed is not sold loose, which is most of them.
--
-- The price is typed, not derived. What she charges for breaking bulk is a
-- decision rather than a division — a 1,910.00 sack works out at 38.20 a kilo
-- and nobody sells it for that. The COST of a kilo IS derived, at bag cost over
-- fifty, because that is arithmetic on a sack already bought and asking her to
-- type the same figure twice only invites the two to disagree.
ALTER TABLE "Product" ADD COLUMN "pricePerKiloCentavos" INTEGER;

-- Which of the two prices a line was sold at.
--
-- Snapshotted beside `priceAtSale` and `costAtSale`, and for the same reason:
-- a line reading "3" is three bags or three kilos, and without this the only
-- way to tell is to reverse-engineer it from the price — which changes. Every
-- sale written before today is by the sack, so FALSE is the correct backfill
-- and not merely a convenient default.
ALTER TABLE "SaleItem" ADD COLUMN "soldPerKilo" BOOLEAN NOT NULL DEFAULT false;
