import type { Customer, Product, Sale, SaleItem } from '@prisma/client'
import type { InstallmentStatus, InterestMethod } from './utang'
import type { StockLevel } from './stock-level'

export type ActionResult<T = void> =
  | { ok: true; data: T }
  | { ok: false; error: string }

export type TrendPoint = { day: string; totalCentavos: number }
export type TopProduct = { productId: number; name: string; unit: string; quantitySold: number; revenueCentavos: number }
export type LowStockItem = { id: number; name: string; unit: string; stockQty: number; lowStockThreshold: number }
export type OverdueAccountNotification = {
  customerId: number
  name: string
  balanceCentavos: number
  dueAt: Date
}
export type NotificationSummary = {
  /** Past the deadline. */
  overdueAccounts: OverdueAccountNotification[]
  /** Deadline is TODAY — still collectable, which is the point of separating
   *  it. Once it joins `overdueAccounts` the easy moment has passed. */
  dueToday: OverdueAccountNotification[]
  /** Kept as its own group rather than folded into `overdueAccounts`:
   *  "three months behind on a plan" and "has an old unpaid balance" are
   *  different problems and are chased differently. */
  overdueInstallments: OverdueInstallmentNotification[]
  lowStock: LowStockItem[]
  /** How many updates are waiting, if this copy can check. Zero otherwise. */
  updatesAvailable: number
  total: number
}

export type DashboardData = {
  todayCentavos: number
  weekCentavos: number
  monthCentavos: number
  monthProfitCentavos: number
  /** Cash actually received in the window: cash paid at order time plus
   *  PAYMENT entries. Diverges from benta the moment utang exists. */
  todayCashCentavos: number
  weekCashCentavos: number
  monthCashCentavos: number
  totalUtangCentavos: number
  topBalances: CustomerBalance[]
  trend: TrendPoint[]
  topProducts: TopProduct[]
  lowStock: LowStockItem[]
}

export type ProductWithCategory = Product & {
  category: { id: number; name: string }
}

export type SaleWithItems = Sale & {
  customer: { id: number; name: string } | null
  items: (SaleItem & { product: { id: number; name: string; unit: string } })[]
  /** The charge this sale created, if it went on credit. Null when paid at
   *  the time. `isVoided` matters: a voided charge means the sale is no
   *  longer on the tab. */
  ledgerEntry: { isVoided: boolean } | null
}

export type Paged<T> = {
  rows: T[]
  total: number
  /** The page actually returned, after clamping. May differ from the page
   *  that was asked for. */
  page: number
  pageCount: number
  /** Sum over the whole filtered set, not just the rows on this page — the
   *  number that answers "how much did I sell under these filters." Only
   *  populated by callers where a peso total is meaningful (listSales). */
  sumCentavos?: number
}

export type SaleStatusFilter = 'all' | 'cash' | 'credit' | 'partial' | 'voided'

export type SalesFilters = {
  from?: string
  to?: string
  /** A customer id, or 'walkin' for sales with no customer. */
  customerId?: number | 'walkin'
  status?: SaleStatusFilter
  /** Sales containing at least one product of this brand/category. */
  categoryId?: number
}

export type ProductFilters = {
  q?: string
  categoryId?: number
  includeArchived?: boolean
  /** In stock, low, or out — see `stockLevelOf` in `lib/stock-level.ts`. */
  stock?: StockLevel
}

export type LedgerEntryType = 'OPENING' | 'CHARGE' | 'PAYMENT'

export type CustomerBalance = {
  customerId: number
  name: string
  balanceCentavos: number
}

export type CustomerWithBalance = CustomerBalance & {
  phone: string | null
  notes: string
  isArchived: boolean
  lastOrderedAt: Date | null
  /** When this customer last actually paid — the newest non-voided PAYMENT
   *  entry's occurredAt, or null if they have never paid. Distinct from
   *  `lastOrderedAt`: ordering recently says nothing about paying recently,
   *  and it is the payment gap that signals collection risk. */
  lastPaymentAt: Date | null
  dueAt: Date | null
}

/** One row of a customer's ledger, in occurredAt order, with the balance
 *  as it stood after that row. Voided entries carry the running balance
 *  unchanged — they are shown struck through, not hidden. */
export type LedgerLine = {
  id: number
  type: LedgerEntryType
  amountCentavos: number
  occurredAt: Date
  note: string
  isVoided: boolean
  saleId: number | null
  /** The utang plan this row belongs to, if any. */
  planId: number | null
  runningBalanceCentavos: number
}

export type OrderLineInput = {
  productId: number
  quantity: number
  /** A discount typed at the counter against this line, in centavos. */
  discountPerUnitCentavos?: number
  /** 'EACH' | 'ONCE' — whether that figure is per unit or for the whole line. */
  discountMode?: string
}

export type ReceiptLine = {
  productId: number
  name: string
  unit: string
  quantity: number
  priceAtSale: number
  discountAtSale: number
  lineTotalCentavos: number
}

export type SaleResult = {
  saleId: number
  createdAt: string
  totalCentavos: number
  cashPaidCentavos: number
  cashTenderedCentavos: number
  changeCentavos: number
  lines: ReceiptLine[]
}

export type OrderResult = SaleResult & {
  /** What went onto the utang. Zero when cash covered the order. */
  chargedCentavos: number
  newBalanceCentavos: number
}

export type DayOrder = {
  saleId: number
  customerId: number | null
  customerName: string | null
  totalCentavos: number
  cashPaidCentavos: number
  /** Whether a live, non-voided CHARGE ledger entry exists for this sale —
   *  the input `saleStatus` (`src/lib/money-display.ts`) needs to tell a
   *  sale still on the tab apart from one whose charge was voided.
   *  Mirrors `SaleWithItems.ledgerEntry`, collapsed to a flag because
   *  `DayView` never needs more than this. */
  hasLiveCharge: boolean
  isVoided: boolean
  createdAt: Date
  lines: { name: string; unit: string; quantity: number }[]
}

export type CustomerWithDiscount = Customer & {
  discountCategories: { id: number; name: string }[]
  discountProducts: { id: number; name: string }[]
}

/** A category plus its cheapest live product, so the customer form can warn
 *  when a discount would zero out a line. */
export type CategoryCheapest = {
  id: number
  name: string
  cheapestName: string | null
  cheapestCentavos: number | null
}

/**
 * A stored plan with its schedule and how far it has been paid.
 *
 * `paidCentavos` counts only non-voided PAYMENT entries carrying this plan's
 * id. Account-level payments — money put against the balance generally rather
 * than against one borrowing — deliberately do not reduce any plan, or two
 * plans would both claim the same peso.
 */
export type UtangPlanView = {
  id: number
  customerId: number
  principalCentavos: number
  interestMethod: InterestMethod
  interestRateBps: number
  termMonths: number
  interestCentavos: number
  totalCentavos: number
  startedAt: Date
  note: string
  isVoided: boolean
  /** Human wording of the terms, e.g. "3 months at 5% per month, flat". */
  termsLabel: string
  paidCentavos: number
  outstandingCentavos: number
  installments: InstallmentStatus[]
  nextDue: InstallmentStatus | null
  overdue: InstallmentStatus[]
}

export type PlanInput = {
  customerId: number
  principalCentavos: number
  interestMethod: string
  interestRateBps: number
  termMonths: number
  startedAt: Date
  note?: string
}

/** One customer's overdue instalments, for the notification bell. */
export type OverdueInstallmentNotification = {
  customerId: number
  name: string
  planId: number
  /** How many of this plan's instalments are past due and unpaid. */
  count: number
  /** The oldest unpaid instalment's date. */
  oldestDueAt: Date
  amountCentavos: number
}

export type BatchPaymentRow = {
  customerId: number
  amountCentavos: number
  occurredAt: Date
  note?: string
}

/** Per-row outcome. A batch is deliberately NOT atomic: twenty rows deep,
 *  one typo discarding the lot is how a person stops using a tool. */
export type BatchPaymentResult = {
  recorded: number
  failures: { index: number; error: string }[]
}
