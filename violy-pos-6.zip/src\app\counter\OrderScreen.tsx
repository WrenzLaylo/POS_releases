'use client'

import { useCallback, useEffect, useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import type {
  CustomerWithDiscount,
  OrderResult,
  ProductWithCategory,
  SaleResult,
} from '@/lib/types'
import { parsePesoInput, formatPeso } from '@/lib/money'
import {
  computeOrderTotals,
  customerDiscountOf,
  hasOrderDiscount,
  MAX_BPS,
  type DiscountKind,
  type OrderDiscount,
  type LineDiscountMode,
  type OrderDiscountMode,
} from '@/lib/discount'
import { createOrder } from '@/server/orders'
import { createSale } from '@/server/sales'
import { CatalogColumn } from './CatalogColumn'
import {
  OrderRail,
  type CustomerPaymentMode,
  type RailLine,
  type RailSelection,
} from './OrderRail'
import { OrderReceipt } from './OrderReceipt'
import { useSavedOrder } from './use-saved-order'

type Receipt =
  | { kind: 'walkin'; data: SaleResult }
  | { kind: 'customer'; customerName: string; data: OrderResult }

function newCheckoutKey(): string {
  return globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`
}

export function OrderScreen({
  products,
  customers,
  creditByCustomer,
}: {
  products: ProductWithCategory[]
  customers: CustomerWithDiscount[]
  /** Customer id to credit held, in centavos. Absent means none. */
  creditByCustomer: Record<number, number>
}) {
  const router = useRouter()
  const [selection, setSelection] = useState<RailSelection | null>(null)
  const [paymentMode, setPaymentMode] = useState<CustomerPaymentMode>('cash')
  // Opt-in, always. A credit is the customer's money; nothing spends it
  // without being asked to, and she may well want it kept for next time.
  const [useCredit, setUseCredit] = useState(false)
  const [quantities, setQuantities] = useState<Map<number, number>>(new Map())
  // productId → what she typed against that line, kept as raw text for the
  // same reason `discountAmount` is: "1," and "1.5" have to be typeable on the
  // way to a number, and a half-typed figure is not a zero.
  const [lineDiscounts, setLineDiscounts] = useState<Map<number, string>>(new Map())
  // Which line's discount editor is open. Held here rather than in the rail so
  // it survives the rail re-rendering as the total changes, and so saving or
  // removing the line can close it.
  const [editingDiscountFor, setEditingDiscountFor] = useState<number | null>(null)
  /** productId → whether her figure is per unit or for the whole line. */
  const [lineDiscountKinds, setLineDiscountKinds] = useState<Map<number, LineDiscountMode>>(
    new Map(),
  )
  const [cash, setCash] = useState('')
  const [discountAmount, setDiscountAmount] = useState('')
  const [discountKind, setDiscountKind] = useState<DiscountKind>('AMOUNT')
  const [discountMode, setDiscountMode] = useState<OrderDiscountMode>('STACK')
  // Separate from the order discount's mode, and defaulting the other way —
  // a figure typed against one line is a price for that sack, not a further
  // gesture on top of the sale. See `discount.ts`.
  const [lineDiscountMode, setLineDiscountMode] = useState<OrderDiscountMode>('REPLACE')
  const [search, setSearch] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [receipt, setReceipt] = useState<Receipt | null>(null)
  const [checkoutKey, setCheckoutKey] = useState(newCheckoutKey)
  const [pending, startTransition] = useTransition()
  const [resetKey, setResetKey] = useState(0)
  const { restored, ready, save: saveOrder, clear: clearSavedOrder } = useSavedOrder()

  // Restores once, after the first client pass. Guarded on `restored` being
  // non-null so it does not fight later edits, and it runs before any save
  // effect below can write the empty initial state back over it.
  useEffect(() => {
    if (!restored) return
    setQuantities(new Map(restored.lines))
    setLineDiscounts(new Map(restored.lineDiscounts ?? []))
    setSelection(
      restored.walkin
        ? { kind: 'walkin' }
        : restored.customerId !== null && restored.customerName !== null
          ? { kind: 'customer', id: restored.customerId, name: restored.customerName }
          : null,
    )
    setPaymentMode(restored.paymentMode as CustomerPaymentMode)
    setCash(restored.cash)
    setDiscountAmount(restored.discountAmount)
    setDiscountKind(restored.discountKind as DiscountKind)
    setDiscountMode(restored.discountMode as OrderDiscountMode)
  }, [restored])

  // Writes on every change, but only once the restore pass has run — without
  // `ready` the first render would persist an empty order over a saved one and
  // erase exactly what this exists to keep.
  useEffect(() => {
    if (!ready) return
    saveOrder({
      lines: [...quantities.entries()],
      lineDiscounts: [...lineDiscounts.entries()],
      customerId: selection?.kind === 'customer' ? selection.id : null,
      customerName: selection?.kind === 'customer' ? selection.name : null,
      walkin: selection?.kind === 'walkin',
      paymentMode,
      cash,
      discountAmount,
      discountKind,
      discountMode,
    })
    // `saveOrder` is stable enough for this: it closes over nothing that
    // changes between renders.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    ready,
    quantities,
    lineDiscounts,
    selection,
    paymentMode,
    cash,
    discountAmount,
    discountKind,
    discountMode,
  ])

  const dismissReceipt = useCallback(() => setReceipt(null), [])

  /**
   * A line's typed discount in centavos, or null while it is unparseable.
   *
   * Blank is zero, not an error — an empty box is the ordinary line. Anything
   * else that will not parse blocks the save rather than silently pricing at
   * zero, which is the same contract `discountAmount` has.
   */
  function parsedLineDiscount(productId: number): number | null {
    const raw = (lineDiscounts.get(productId) ?? '').trim()
    if (raw === '') return 0
    return parsePesoInput(raw)
  }

  const lines = [...quantities.entries()]
    .filter(([, quantity]) => quantity > 0)
    .map(([productId, quantity]) => ({
      productId,
      quantity,
      discountPerUnitCentavos: parsedLineDiscount(productId) ?? 0,
      discountMode: lineDiscountKinds.get(productId) ?? 'EACH',
    }))

  // Every typed line discount has to parse before anything can be saved. A
  // line whose box holds "5o" would otherwise be sent as no discount at all,
  // and she would read one figure aloud while another hit the books.
  const lineDiscountsAreValid = [...quantities.entries()]
    .filter(([, quantity]) => quantity > 0)
    .every(([productId]) => parsedLineDiscount(productId) !== null)

  const selectedCustomer =
    selection?.kind === 'customer'
      ? (customers.find((customer) => customer.id === selection.id) ?? null)
      : null

  // A blank field is no discount, not a zero-value one. Anything unparseable
  // is a validation failure that blocks Save, exactly like the cash field —
  // never silently coerced to zero.
  const discountBlank = discountAmount.trim() === ''
  const parsedDiscount = discountBlank ? 0 : parsePesoInput(discountAmount)
  const discountIsValid = parsedDiscount !== null

  // `parsePesoInput` scales by 100, which is what both readings of this field
  // need: "50" is 5000 centavos and "10.5" is 1050 basis points — pesos and
  // percentages are both quoted to two decimal places, so one parse serves
  // both and the toggle only decides which field it lands in.
  const discountValue = parsedDiscount ?? 0
  const orderDiscount: OrderDiscount = {
    kind: discountKind,
    amountCentavos: discountKind === 'AMOUNT' ? discountValue : 0,
    bps: discountKind === 'PERCENT' ? Math.min(discountValue, MAX_BPS) : 0,
    mode: discountMode,
  }

  // The same `computeOrderTotals` the Server Action calls. This preview is
  // what she reads out to the customer, so it cannot be a second
  // implementation that agrees with the server most of the time.
  const totals = computeOrderTotals({
    lines: lines.flatMap(({ productId, quantity, discountPerUnitCentavos, discountMode }) => {
      const product = products.find((candidate) => candidate.id === productId)
      return product
        ? [
            {
              productId,
              quantity,
              priceCentavos: product.price,
              categoryId: product.categoryId,
              unit: product.unit,
              manualDiscountPerUnitCentavos: discountPerUnitCentavos,
              manualDiscountMode: discountMode,
            },
          ]
        : []
    }),
    customer: selectedCustomer ? customerDiscountOf(selectedCustomer) : null,
    order: orderDiscount,
    lineMode: lineDiscountMode,
  })

  const totalsByProduct = new Map(totals.lines.map((line) => [line.productId, line]))

  // The same order priced as if she had typed nothing against any line. Its
  // only job is to answer "does her own discount already cover this line",
  // which is what decides whether the overlap choice is worth showing.
  const standingOnly = computeOrderTotals({
    lines: lines.flatMap(({ productId, quantity }) => {
      const product = products.find((candidate) => candidate.id === productId)
      return product
        ? [
            {
              productId,
              quantity,
              priceCentavos: product.price,
              categoryId: product.categoryId,
              unit: product.unit,
            },
          ]
        : []
    }),
    customer: selectedCustomer ? customerDiscountOf(selectedCustomer) : null,
  })
  const standingByProduct = new Map(standingOnly.lines.map((line) => [line.productId, line]))

  /** The customer's standing discount in words, so the rail can say it exists. */
  const standingDiscountLabel = (() => {
    if (!selectedCustomer) return null
    const isPercent = selectedCustomer.discountKind === 'PERCENT'
    const value = isPercent
      ? selectedCustomer.discountBps > 0
        ? `${selectedCustomer.discountBps / 100}%`
        : ''
      : selectedCustomer.discountCentavos > 0
        ? formatPeso(selectedCustomer.discountCentavos)
        : ''
    if (value === '') return null
    const basis =
      selectedCustomer.discountBasis === 'ORDER_TOTAL'
        ? 'off the order'
        : selectedCustomer.discountBasis === 'ONCE_PER_ORDER'
          ? 'off the order, once'
          : `off each ${selectedCustomer.discountUnit || 'unit'}`
    return `${selectedCustomer.name} gets ${value} ${basis}`
  })()

  const railLines: RailLine[] = lines.map(({ productId, quantity }) => {
    const product = products.find((candidate) => candidate.id === productId)
    return {
      productId,
      name: product?.name ?? 'Unknown product',
      quantity,
      totalCentavos: totalsByProduct.get(productId)?.lineTotalCentavos ?? 0,
      // Raw text, so the rail's box shows exactly what she typed, and the
      // resolved figure, so it can say what actually came off — which differs
      // whenever a standing discount is what applied.
      discountRaw: lineDiscounts.get(productId) ?? '',
      discountKind: lineDiscountKinds.get(productId) ?? 'EACH',
      // What the customer's own rate would give this line, ignoring anything
      // typed — so the rail can tell an overlap from a plain line discount.
      standingDiscountPerUnitCentavos:
        standingByProduct.get(productId)?.discountPerUnitCentavos ?? 0,
      discountIsValid: parsedLineDiscount(productId) !== null,
      appliedDiscountPerUnitCentavos:
        totalsByProduct.get(productId)?.discountPerUnitCentavos ?? 0,
    }
  })

  /**
   * Keeps only what can be part of a peso figure.
   *
   * Refused as she types rather than flagged afterwards. The box used to
   * accept "500zz", paint itself red and block the save — which is a
   * correction, not a guard, and it stops the sale at the worst moment. A
   * keypad cannot type a letter into a till drawer and neither should this.
   *
   * One decimal point only, and nothing before a leading dot is invented —
   * ".5" is left as she typed it for `parsePesoInput` to read.
   */
  function digitsOnly(raw: string): string {
    const kept = raw.replace(/[^0-9.]/g, '')
    const firstDot = kept.indexOf('.')
    if (firstDot === -1) return kept
    return kept.slice(0, firstDot + 1) + kept.slice(firstDot + 1).replace(/\./g, '')
  }

  function setLineDiscountKind(productId: number, mode: LineDiscountMode) {
    setLineDiscountKinds((previous) => {
      const next = new Map(previous)
      if (mode === 'EACH') next.delete(productId)
      else next.set(productId, mode)
      return next
    })
  }

  function setLineDiscount(productId: number, rawInput: string) {
    const raw = digitsOnly(rawInput)
    setLineDiscounts((previous) => {
      const next = new Map(previous)
      // An emptied box is removed rather than stored blank, so a draft does
      // not accumulate a key per product she once touched.
      if (raw.trim() === '') next.delete(productId)
      else next.set(productId, raw)
      return next
    })
  }

  const totalCentavos = totals.totalCentavos
  const discountCentavos = totals.totalDiscountCentavos

  const cashBlank = cash.trim() === ''
  const parsedCash = cashBlank ? 0 : parsePesoInput(cash)
  const cashIsValid = parsedCash !== null
  const cashCentavos = parsedCash ?? 0

  // What the shop is holding for this customer, and how much of it this
  // order can actually absorb — never more than the order is worth, or the
  // change would be cash the shop never received.
  const availableCreditCentavos =
    selection?.kind === 'customer' ? (creditByCustomer[selection.id] ?? 0) : 0
  const creditAppliedCentavos =
    useCredit && selection?.kind === 'customer'
      ? Math.min(availableCreditCentavos, totalCentavos)
      : 0

  // Everything below prices against what is left AFTER credit. Comparing
  // against the full total would ask her for cash the credit already covered,
  // and would compute the change against the wrong figure.
  const dueCentavos = Math.max(0, totalCentavos - creditAppliedCentavos)

  const exactCashMode =
    selection?.kind === 'walkin' ||
    (selection?.kind === 'customer' && paymentMode === 'cash')
  const displayedTenderCentavos = cashBlank && exactCashMode ? dueCentavos : cashCentavos
  const chargeCentavos =
    selection?.kind === 'customer' && paymentMode === 'credit'
      ? dueCentavos
      : Math.max(0, dueCentavos - displayedTenderCentavos)
  const changeCentavos = Math.max(0, displayedTenderCentavos - dueCentavos)
  const shortCentavos =
    exactCashMode && !cashBlank && cashIsValid
      ? Math.max(0, dueCentavos - cashCentavos)
      : 0

  function setQuantity(productId: number, quantity: number) {
    setQuantities((previous) => {
      const next = new Map(previous)
      if (quantity <= 0) next.delete(productId)
      else next.set(productId, quantity)
      return next
    })
  }

  function resetAfterSave() {
    // The saved draft goes with the order it belonged to. Leaving it would
    // repopulate the counter with a sale that has already been rung up.
    clearSavedOrder()
    setSelection(null)
    setPaymentMode('cash')
    setQuantities(new Map())
    setLineDiscounts(new Map())
    setLineDiscountKinds(new Map())
    setEditingDiscountFor(null)
    setCash('')
    // The discount belongs to the order that just closed, not the next one.
    setDiscountAmount('')
    setDiscountKind('AMOUNT')
    setDiscountMode('STACK')
    setLineDiscountMode('REPLACE')
    setSearch('')
    setCheckoutKey(newCheckoutKey())
    setResetKey((value) => value + 1)
  }

  function save() {
    if (!selection) return
    setError(null)
    const key = checkoutKey

    startTransition(async () => {
      if (selection.kind === 'walkin') {
        const result = await createSale({
          items: lines,
          cashTenderedCentavos: cashBlank ? null : cashCentavos,
          orderDiscount,
          lineDiscountMode,
          clientOrderKey: key,
        })
        if (!result.ok) {
          setError(result.error)
          return
        }
        setReceipt({ kind: 'walkin', data: result.data })
      } else {
        const tender =
          paymentMode === 'credit' ? 0 : cashBlank && paymentMode === 'cash' ? null : cashCentavos
        const result = await createOrder({
          customerId: selection.id,
          lines,
          cashPaidCentavos: tender,
          // The server re-reads her live balance and caps this itself; what is
          // sent is a request, not an authority.
          creditAppliedCentavos: creditAppliedCentavos || undefined,
          orderDiscount,
          lineDiscountMode,
          clientOrderKey: key,
        })
        if (!result.ok) {
          setError(result.error)
          return
        }
        setReceipt({ kind: 'customer', customerName: selection.name, data: result.data })
      }

      resetAfterSave()
      router.refresh()
    })
  }

  const paymentIsValid = (() => {
    if (!selection) return false
    if (!cashIsValid) return false
    if (selection.kind === 'walkin') return cashBlank || cashCentavos >= totalCentavos
    if (paymentMode === 'credit') return true
    // Against `dueCentavos`, so a credit that covers the whole order leaves
    // nothing to collect and an empty cash box is still a complete payment.
    if (paymentMode === 'cash') return cashBlank || cashCentavos >= dueCentavos
    return !cashBlank && cashCentavos > 0 && cashCentavos < dueCentavos
  })()

  const canSave =
    selection !== null &&
    lines.length > 0 &&
    paymentIsValid &&
    discountIsValid &&
    lineDiscountsAreValid &&
    !pending

  return (
    // Side by side from `lg` (1024px), not `xl` (1280px). The rail carries the
    // running total, and below the old threshold it dropped BENEATH the catalog
    // — so on any laptop narrower than 1280 she was adding items with the total
    // scrolled off screen, which is the one thing a point of sale cannot do. It
    // narrows to 20rem before it gives up the row, rather than stacking.
    <div className="flex flex-col gap-6 lg:h-full lg:min-h-0 lg:flex-row">
      <div className="min-w-0 flex-1 lg:flex lg:min-h-0 lg:flex-col">
        <CatalogColumn
          products={products}
          quantities={quantities}
          onChange={setQuantity}
          search={search}
          onSearchChange={setSearch}
          resetKey={resetKey}
        />
      </div>

      {/* The rail scrolls on its own too. A twenty-line order used to run off
          the bottom with no way to reach the rest of it, now that the page
          itself no longer scrolls. */}
      <div className="w-full shrink-0 lg:w-80 lg:overflow-y-auto xl:w-96">
        <div>
          {receipt ? (
            receipt.kind === 'walkin' ? (
              <OrderReceipt
                kind="walkin"
                saleId={receipt.data.saleId}
                createdAt={receipt.data.createdAt}
                lines={receipt.data.lines}
                totalCentavos={receipt.data.totalCentavos}
                cashPaidCentavos={receipt.data.cashPaidCentavos}
                cashTenderedCentavos={receipt.data.cashTenderedCentavos}
                changeCentavos={receipt.data.changeCentavos}
                onDismiss={dismissReceipt}
              />
            ) : (
              <OrderReceipt
                kind="customer"
                saleId={receipt.data.saleId}
                createdAt={receipt.data.createdAt}
                customerName={receipt.customerName}
                lines={receipt.data.lines}
                totalCentavos={receipt.data.totalCentavos}
                cashPaidCentavos={receipt.data.cashPaidCentavos}
                cashTenderedCentavos={receipt.data.cashTenderedCentavos}
                chargedCentavos={receipt.data.chargedCentavos}
                changeCentavos={receipt.data.changeCentavos}
                newBalanceCentavos={receipt.data.newBalanceCentavos}
                onDismiss={dismissReceipt}
              />
            )
          ) : (
            <OrderRail
              customers={customers}
              selection={selection}
              onSelectionChange={(next) => {
                setSelection(next)
                setPaymentMode('cash')
                setCash('')
                // Belongs to the customer who was selected, not to the order.
                setUseCredit(false)
              }}
              paymentMode={paymentMode}
              onPaymentModeChange={setPaymentMode}
              lines={railLines}
            onLineDiscountChange={setLineDiscount}
            editingDiscountFor={editingDiscountFor}
            onLineDiscountKindChange={setLineDiscountKind}
            onEditDiscountFor={setEditingDiscountFor}
              onRemoveLine={(productId) => {
              // A removed line cannot leave its editor open over the row that
              // moves up into its place.
              if (editingDiscountFor === productId) setEditingDiscountFor(null)
              setQuantity(productId, 0)
            }}
              totalCentavos={totalCentavos}
              discountCentavos={discountCentavos}
              subtotalCentavos={totals.subtotalCentavos}
              discountAmount={discountAmount}
              onDiscountAmountChange={setDiscountAmount}
              discountKind={discountKind}
              onDiscountKindChange={setDiscountKind}
              discountMode={discountMode}
              onDiscountModeChange={setDiscountMode}
              discountIsValid={discountIsValid}
              lineDiscountMode={lineDiscountMode}
              onLineDiscountModeChange={setLineDiscountMode}
              // Whether the choice can change anything: at least one line she
              // typed a figure against ALSO carries a standing rate. Offered
              // only then, for the same reason the order-level one is.
              lineDiscountOverlaps={railLines.some(
                (railLine) =>
                  railLine.discountRaw.trim() !== '' && railLine.standingDiscountPerUnitCentavos > 0,
              )}
              standingDiscountLabel={standingDiscountLabel}
              customerHasStandingDiscount={
                selectedCustomer !== null &&
                (selectedCustomer.discountKind === 'PERCENT'
                  ? selectedCustomer.discountBps > 0
                  : selectedCustomer.discountCentavos > 0)
              }
              availableCreditCentavos={availableCreditCentavos}
              creditAppliedCentavos={creditAppliedCentavos}
              useCredit={useCredit}
              onUseCreditChange={setUseCredit}
              dueCentavos={dueCentavos}
              cash={cash}
              onCashChange={setCash}
              cashIsValid={cashIsValid}
              chargeCentavos={chargeCentavos}
              changeCentavos={changeCentavos}
              shortCentavos={shortCentavos}
              onSave={save}
              canSave={canSave}
              pending={pending}
              error={error}
            />
          )}
        </div>
      </div>
    </div>
  )
}
