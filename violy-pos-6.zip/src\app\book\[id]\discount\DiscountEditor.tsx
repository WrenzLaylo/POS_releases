'use client'

import { useMemo, useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import type { CustomerWithDiscount, ProductWithCategory } from '@/lib/types'
import { formatPeso, parsePesoInput } from '@/lib/money'
import { bookEntry } from '@/lib/routes'
import { updateCustomer } from '@/server/customers'
import {
  MAX_BPS,
  isDiscountBasis,
  isDiscountKind,
  isDiscountScope,
  type DiscountBasis,
  type DiscountKind,
  type DiscountScope,
} from '@/lib/discount'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Field } from '@/components/ui/Field'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'
import { SegmentedControl } from '@/components/ui/SegmentedControl'
import { cn } from '@/lib/cn'

const KIND_OPTIONS = [
  { value: 'AMOUNT', label: '₱' },
  { value: 'PERCENT', label: '%' },
] as const

const BASIS_OPTIONS = [
  { value: 'PER_UNIT', label: 'each unit' },
  { value: 'ONCE_PER_ORDER', label: 'once an order' },
  { value: 'ORDER_TOTAL', label: 'the whole order' },
] as const

const SCOPE_OPTIONS = [
  { value: 'ALL', label: 'Everything' },
  { value: 'CATEGORIES', label: 'These brands' },
  { value: 'PRODUCTS', label: 'These products' },
] as const

/**
 * A customer's standing discount, on a screen of its own.
 *
 * It used to be four stacked controls and a checkbox-per-brand crammed into
 * the bottom of the Edit customer dialog, which was already the tallest thing
 * in the app. Naming individual products was never going to fit there —
 * fifty-five checkboxes in a dialog is not a control, it is a wall.
 *
 * So the dialog goes back to being what a customer record is (name, phone,
 * notes) and the discount gets room: a sentence you assemble left to right,
 * a picker that searches instead of listing everything, and the rule written
 * back out in plain words underneath. The sentence is the point — a discount
 * she cannot read aloud is one she cannot check.
 */
export function DiscountEditor({
  customer,
  products,
  categories,
}: {
  customer: CustomerWithDiscount
  products: ProductWithCategory[]
  categories: { id: number; name: string }[]
}) {
  const router = useRouter()
  const [pending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)
  const [saved, setSaved] = useState(false)

  const [kind, setKind] = useState<DiscountKind>(
    isDiscountKind(customer.discountKind) ? customer.discountKind : 'AMOUNT',
  )
  const [basis, setBasis] = useState<DiscountBasis>(
    isDiscountBasis(customer.discountBasis) ? customer.discountBasis : 'PER_UNIT',
  )
  const [scope, setScope] = useState<DiscountScope>(
    isDiscountScope(customer.discountScope) ? customer.discountScope : 'CATEGORIES',
  )
  const [raw, setRaw] = useState(() => {
    if (isDiscountKind(customer.discountKind) && customer.discountKind === 'PERCENT') {
      return customer.discountBps > 0 ? String(customer.discountBps / 100) : ''
    }
    return customer.discountCentavos > 0 ? String(customer.discountCentavos / 100) : ''
  })
  const [unit, setUnit] = useState(customer.discountUnit ?? '')
  const [categoryIds, setCategoryIds] = useState<number[]>(
    customer.discountCategories.map((c) => c.id),
  )
  const [productIds, setProductIds] = useState<number[]>(
    customer.discountProducts.map((p) => p.id),
  )
  const [search, setSearch] = useState('')

  const units = useMemo(() => {
    const seen = new Set<string>()
    for (const product of products) {
      const first = product.unit.split(' ')[0].toLowerCase()
      if (first) seen.add(first)
    }
    return [...seen].sort()
  }, [products])

  const trimmed = raw.trim()
  const parsed = trimmed === '' ? 0 : parsePesoInput(trimmed)
  const invalid = trimmed !== '' && parsed === null
  const value = parsed ?? 0

  // Only what the search matches, and only once she has typed. A list of every
  // product in the shop is the wall this screen exists to avoid — but the ones
  // already chosen always show, or unticking would mean hunting for them.
  const chosenProducts = products.filter((p) => productIds.includes(p.id))
  const needle = search.trim().toLowerCase()
  const matches =
    needle === ''
      ? []
      : products
          .filter((p) => !productIds.includes(p.id) && p.name.toLowerCase().includes(needle))
          .slice(0, 8)

  function toggle(list: number[], set: (next: number[]) => void, id: number) {
    set(list.includes(id) ? list.filter((each) => each !== id) : [...list, id])
  }

  /** The rule, in the words she would use to explain it to a customer. */
  const sentence = (() => {
    if (value <= 0) return 'No discount yet — type an amount above.'
    const money = kind === 'PERCENT' ? `${value / 100}%` : formatPeso(value)
    const per =
      basis === 'ORDER_TOTAL'
        ? 'off the whole order'
        : basis === 'ONCE_PER_ORDER'
          ? 'off the order, once'
          : `off each ${unit === '' ? 'unit' : unit}`

    if (basis === 'ORDER_TOTAL') return `${money} ${per}, whatever is on it.`

    const what =
      scope === 'ALL'
        ? 'anything'
        : scope === 'PRODUCTS'
          ? chosenProducts.length === 0
            ? 'nothing yet — choose a product'
            : chosenProducts.map((p) => p.name).join(', ')
          : categoryIds.length === 0
            ? 'nothing yet — tick a brand'
            : categories
                .filter((c) => categoryIds.includes(c.id))
                .map((c) => c.name)
                .join(', ')

    return `${money} ${per} of ${what}.`
  })()

  function save() {
    setError(null)
    setSaved(false)

    if (invalid) {
      setError(kind === 'PERCENT' ? 'Enter a percentage like 5 or 12.5' : 'Enter an amount like 50')
      return
    }
    if (kind === 'PERCENT' && value > MAX_BPS) {
      setError('A discount cannot be more than 100%.')
      return
    }

    startTransition(async () => {
      const result = await updateCustomer(customer.id, {
        name: customer.name,
        phone: customer.phone ?? '',
        notes: customer.notes,
        discountCentavos: kind === 'AMOUNT' ? value : 0,
        discountBps: kind === 'PERCENT' ? value : 0,
        discountKind: kind,
        discountBasis: basis,
        // A whole-order discount has no per-line scope, so nothing is stored
        // for one — the same reason the unused amount column is zeroed.
        discountUnit: basis === 'ORDER_TOTAL' ? '' : unit,
        discountScope: basis === 'ORDER_TOTAL' ? 'ALL' : scope,
        discountCategoryIds: categoryIds,
        discountProductIds: productIds,
      })
      if (!result.ok) {
        setError(result.error)
        return
      }
      setSaved(true)
      router.refresh()
    })
  }

  const scoped = basis !== 'ORDER_TOTAL'

  return (
    <Card>
      <div className="grid gap-5">
        <div className="flex flex-wrap items-end gap-3">
          <Field label="Take">
            <div className="flex items-center gap-2">
              <Input
                inputMode="decimal"
                value={raw}
                onChange={(event) => setRaw(event.target.value)}
                placeholder="0.00"
                aria-label={kind === 'PERCENT' ? 'Discount percentage' : 'Discount in pesos'}
                aria-invalid={invalid || undefined}
                className={cn('w-32 tabular-nums', invalid && 'border-owed')}
              />
              <SegmentedControl
                ariaLabel="Discount type"
                options={KIND_OPTIONS}
                value={kind}
                onValueChange={(v) => setKind(v as DiscountKind)}
              />
            </div>
          </Field>

          <Field label="Off">
            <SegmentedControl
              ariaLabel="What the discount comes off"
              options={BASIS_OPTIONS}
              value={basis}
              onValueChange={(v) => setBasis(v as DiscountBasis)}
            />
          </Field>

          {scoped && units.length > 0 && (
            <Field label="Sold by the">
              <SegmentedControl
                ariaLabel="Which unit the discount is per"
                options={[
                  { value: '', label: 'any unit' },
                  ...units.map((each) => ({ value: each, label: each })),
                ]}
                value={unit}
                onValueChange={setUnit}
              />
            </Field>
          )}
        </div>

        {scoped && (
          <div className="grid gap-3 border-t border-line pt-5">
            <Field label="Which items">
              <SegmentedControl
                ariaLabel="What the discount covers"
                options={SCOPE_OPTIONS}
                value={scope}
                onValueChange={(v) => setScope(v as DiscountScope)}
              />
            </Field>

            {scope === 'CATEGORIES' && (
              <div className="flex flex-wrap gap-2">
                {categories.map((category) => {
                  const on = categoryIds.includes(category.id)
                  return (
                    <button
                      key={category.id}
                      type="button"
                      aria-pressed={on}
                      onClick={() => toggle(categoryIds, setCategoryIds, category.id)}
                      className={cn(
                        'flex h-9 items-center rounded-control border px-3 text-sm font-medium transition-colors duration-150',
                        on
                          ? 'border-accent bg-accent-soft text-accent'
                          : 'border-line text-ink-muted hover:border-line-strong hover:text-ink',
                      )}
                    >
                      {category.name}
                    </button>
                  )
                })}
              </div>
            )}

            {scope === 'PRODUCTS' && (
              <div className="grid gap-3">
                {/* Chosen first and always visible. A picker that hides what
                    you already picked behind the same search box makes
                    removing one a hunt. */}
                {chosenProducts.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {chosenProducts.map((product) => (
                      <button
                        key={product.id}
                        type="button"
                        onClick={() => toggle(productIds, setProductIds, product.id)}
                        aria-label={`Remove ${product.name}`}
                        className="flex h-9 items-center gap-2 rounded-control border border-accent bg-accent-soft px-3 text-sm font-medium text-accent"
                      >
                        {product.name}
                        <span aria-hidden="true" className="text-ink-subtle">
                          ×
                        </span>
                      </button>
                    ))}
                  </div>
                )}

                <Field label="Add a product">
                  <Input
                    type="search"
                    value={search}
                    onChange={(event) => setSearch(event.target.value)}
                    placeholder="Start typing a name"
                    className="w-full max-w-md"
                  />
                </Field>

                {matches.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {matches.map((product) => (
                      <button
                        key={product.id}
                        type="button"
                        onClick={() => {
                          toggle(productIds, setProductIds, product.id)
                          setSearch('')
                        }}
                        className="flex h-9 items-center rounded-control border border-line px-3 text-sm text-ink-muted hover:border-accent hover:bg-accent-soft hover:text-accent"
                      >
                        {product.name}
                        <span className="ml-2 text-xs text-ink-subtle">{product.unit}</span>
                      </button>
                    ))}
                  </div>
                )}

                {needle !== '' && matches.length === 0 && (
                  <p className="text-sm text-ink-subtle">Nothing matches that name.</p>
                )}
              </div>
            )}
          </div>
        )}

        {/* The rule read back in plain words. A discount she cannot say out
            loud is one she cannot check, and this is the line that catches
            "₱20 off nothing yet" before it is saved and quietly does nothing. */}
        <p className="rounded-control border border-line bg-surface-sunk px-4 py-3 text-sm text-ink">
          {sentence}
        </p>

        {error && <FormError>{error}</FormError>}
        {saved && !error && <p className="text-sm text-money-in">Saved.</p>}

        <div className="flex items-center gap-2">
          <Button variant="success" onClick={save} disabled={pending}>
            {pending ? 'Saving…' : 'Save discount'}
          </Button>
          <Button variant="ghost" onClick={() => router.push(bookEntry(customer.id))}>
            Back to {customer.name}
          </Button>
        </div>
      </div>
    </Card>
  )
}
