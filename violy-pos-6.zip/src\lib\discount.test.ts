import { describe, expect, it } from 'vitest'
import {
  computeOrderTotals,
  customerDiscountOf,
  hasOrderDiscount,
  percentOf,
  type CustomerDiscount,
  type OrderDiscount,
} from './discount'

const FEEDS = 1
const MEDICINE = 2

/** A ₱1,000 sack of feeds, quantity 1, unless a test says otherwise. */
function line(overrides: Partial<Parameters<typeof computeOrderTotals>[0]['lines'][number]> = {}) {
  return {
    productId: 1,
    quantity: 1,
    priceCentavos: 100_000,
    categoryId: FEEDS,
    unit: 'bag (50kg)',
    ...overrides,
  }
}

function customer(overrides: Partial<CustomerDiscount> = {}): CustomerDiscount {
  return {
    kind: 'AMOUNT',
    amountCentavos: 0,
    bps: 0,
    basis: 'PER_UNIT',
    // Empty: every existing case in this file was written before discounts
    // could name a unit, and must keep pricing the same way.
    unit: '',
    scope: 'CATEGORIES',
    categoryIds: new Set([FEEDS]),
    productIds: new Set<number>(),
    ...overrides,
  }
}

function order(overrides: Partial<OrderDiscount> = {}): OrderDiscount {
  return { kind: 'AMOUNT', amountCentavos: 0, bps: 0, mode: 'STACK', ...overrides }
}

describe('percentOf', () => {
  it('converts basis points to centavos', () => {
    expect(percentOf(100_000, 500)).toBe(5_000) // 5% of ₱1,000 is ₱50
    expect(percentOf(145_000, 500)).toBe(7_250) // 5% of ₱1,450 is ₱72.50
    expect(percentOf(100_000, 10_000)).toBe(100_000) // 100% is the whole thing
    expect(percentOf(100_000, 0)).toBe(0)
  })

  it('rounds to whole centavos rather than carrying a fraction', () => {
    // 3.33% of ₱10.00 is 3.33 centavos, which does not exist.
    expect(percentOf(1_000, 333)).toBe(33)
    expect(Number.isInteger(percentOf(99_999, 777))).toBe(true)
  })
})

describe('hasOrderDiscount', () => {
  it('reads the field its kind actually uses', () => {
    // A leftover bps on an AMOUNT discount is not a discount, and vice versa.
    expect(hasOrderDiscount(order({ kind: 'AMOUNT', amountCentavos: 0, bps: 500 }))).toBe(false)
    expect(hasOrderDiscount(order({ kind: 'PERCENT', bps: 0, amountCentavos: 5_000 }))).toBe(false)
    expect(hasOrderDiscount(order({ kind: 'AMOUNT', amountCentavos: 5_000 }))).toBe(true)
    expect(hasOrderDiscount(order({ kind: 'PERCENT', bps: 500 }))).toBe(true)
    expect(hasOrderDiscount(null)).toBe(false)
  })
})

describe('no discount', () => {
  it('leaves the total as the plain subtotal', () => {
    const totals = computeOrderTotals({ lines: [line({ quantity: 3 })] })
    expect(totals.subtotalCentavos).toBe(300_000)
    expect(totals.totalCentavos).toBe(300_000)
    expect(totals.totalDiscountCentavos).toBe(0)
  })
})

describe('customer discount, per unit', () => {
  it('takes a peso amount off each unit in a covered category', () => {
    const totals = computeOrderTotals({
      lines: [line({ quantity: 3 })],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 5_000 }),
    })
    expect(totals.lines[0].discountPerUnitCentavos).toBe(5_000)
    expect(totals.totalCentavos).toBe(285_000) // 3 × ₱950
    expect(totals.lineDiscountCentavos).toBe(15_000)
  })

  it('takes a percentage off each unit in a covered category', () => {
    const totals = computeOrderTotals({
      lines: [line({ priceCentavos: 145_000, quantity: 2 })],
      customer: customer({ kind: 'PERCENT', bps: 500 }),
    })
    expect(totals.lines[0].discountPerUnitCentavos).toBe(7_250) // 5% of ₱1,450
    expect(totals.totalCentavos).toBe(275_500) // 2 × ₱1,377.50
  })

  it('leaves categories outside the discount alone', () => {
    const totals = computeOrderTotals({
      lines: [line({ categoryId: MEDICINE })],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 5_000 }),
    })
    expect(totals.lines[0].discountPerUnitCentavos).toBe(0)
    expect(totals.totalCentavos).toBe(100_000)
  })

  it('applies to nothing when the discount has no categories', () => {
    const totals = computeOrderTotals({
      lines: [line()],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 5_000, categoryIds: new Set() }),
    })
    expect(totals.totalCentavos).toBe(100_000)
  })

  it('makes a line free rather than negative when the discount exceeds the price', () => {
    const totals = computeOrderTotals({
      lines: [line({ priceCentavos: 3_000, quantity: 4 })],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 5_000 }),
    })
    expect(totals.lines[0].discountPerUnitCentavos).toBe(3_000)
    expect(totals.totalCentavos).toBe(0)
  })
})

describe('customer discount, whole order', () => {
  it('takes a percentage off the order and ignores category scoping', () => {
    const totals = computeOrderTotals({
      lines: [line(), line({ productId: 2, categoryId: MEDICINE })],
      customer: customer({ kind: 'PERCENT', bps: 1_000, basis: 'ORDER_TOTAL' }),
    })
    // Both lines count, including the one outside the discounted category.
    expect(totals.customerDiscountCentavos).toBe(20_000)
    expect(totals.lineDiscountCentavos).toBe(0)
    expect(totals.totalCentavos).toBe(180_000)
  })

  it('never takes off more than the order is worth', () => {
    const totals = computeOrderTotals({
      lines: [line({ priceCentavos: 5_000 })],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 900_000, basis: 'ORDER_TOTAL' }),
    })
    expect(totals.customerDiscountCentavos).toBe(5_000)
    expect(totals.totalCentavos).toBe(0)
  })
})

describe('customer discount, once an order', () => {
  it('takes a peso amount off once, however many she buys', () => {
    // The whole reason this basis exists. ₱20 off Atlas is sometimes ₱20 off
    // the visit, not ₱20 off every sack — five sacks would otherwise be ₱100.
    const totals = computeOrderTotals({
      lines: [line({ quantity: 5 })],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 2_000, basis: 'ONCE_PER_ORDER' }),
    })
    expect(totals.lineDiscountCentavos).toBe(0)
    expect(totals.customerDiscountCentavos).toBe(2_000)
    expect(totals.totalCentavos).toBe(498_000)
  })

  it('takes nothing when the order has nothing in the scope', () => {
    const totals = computeOrderTotals({
      lines: [line({ categoryId: MEDICINE })],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 2_000, basis: 'ONCE_PER_ORDER' }),
    })
    expect(totals.customerDiscountCentavos).toBe(0)
    expect(totals.totalCentavos).toBe(100_000)
  })

  it('still takes it once when the order holds several matching lines', () => {
    // Once per ORDER, not once per line — three Atlas products on one ticket
    // is still one ₱20.
    const totals = computeOrderTotals({
      lines: [line(), line({ productId: 2 }), line({ productId: 3 })],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 2_000, basis: 'ONCE_PER_ORDER' }),
    })
    expect(totals.customerDiscountCentavos).toBe(2_000)
    expect(totals.totalCentavos).toBe(298_000)
  })

  it('honours the unit scope, exactly as a per-unit discount does', () => {
    // A category holds both sizes. "₱20 off Pigrolac, once" must not fire on
    // an order that only has the 1kg pack on it.
    const scoped = customer({
      kind: 'AMOUNT',
      amountCentavos: 2_000,
      basis: 'ONCE_PER_ORDER',
      unit: 'bag',
    })
    const kiloOnly = computeOrderTotals({
      lines: [line({ unit: 'kilo', priceCentavos: 11_000 })],
      customer: scoped,
    })
    expect(kiloOnly.customerDiscountCentavos).toBe(0)

    const withBag = computeOrderTotals({
      lines: [line({ unit: 'kilo', priceCentavos: 11_000 }), line({ productId: 2 })],
      customer: scoped,
    })
    expect(withBag.customerDiscountCentavos).toBe(2_000)
  })

  it('measures a percentage against the matching lines only', () => {
    // The medicine line is outside the scope and must not be part of what the
    // 10% is 10% OF — which is the difference from ORDER_TOTAL.
    const totals = computeOrderTotals({
      lines: [line(), line({ productId: 2, categoryId: MEDICINE })],
      customer: customer({ kind: 'PERCENT', bps: 1_000, basis: 'ONCE_PER_ORDER' }),
    })
    expect(totals.customerDiscountCentavos).toBe(10_000)
    expect(totals.totalCentavos).toBe(190_000)
  })

  it('never takes off more than the order is worth', () => {
    const totals = computeOrderTotals({
      lines: [line({ priceCentavos: 5_000 })],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 900_000, basis: 'ONCE_PER_ORDER' }),
    })
    expect(totals.customerDiscountCentavos).toBe(5_000)
    expect(totals.totalCentavos).toBe(0)
  })

  it('leaves each line’s own discount at zero', () => {
    // It comes off the order, not off a line, so nothing lands in
    // SaleItem.discountAtSale and the receipt prints one clean figure.
    const totals = computeOrderTotals({
      lines: [line(), line({ productId: 2 })],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 2_000, basis: 'ONCE_PER_ORDER' }),
    })
    expect(totals.lines.map((l) => l.discountPerUnitCentavos)).toEqual([0, 0])
  })

  it('is replaced by an ad-hoc discount set to REPLACE, like any other', () => {
    const totals = computeOrderTotals({
      lines: [line()],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 2_000, basis: 'ONCE_PER_ORDER' }),
      order: order({ kind: 'AMOUNT', amountCentavos: 5_000, mode: 'REPLACE' }),
    })
    expect(totals.customerDiscountCentavos).toBe(0)
    expect(totals.orderDiscountCentavos).toBe(5_000)
    expect(totals.totalCentavos).toBe(95_000)
  })
})

describe('what a standing discount covers', () => {
  it('covers only the products it names', () => {
    // The arrangement this exists for: "₱20 off Atlas Grower" is a real thing
    // a shop agrees to, and scoping it to the whole Atlas brand would give
    // away the other nine products in it.
    const scoped = customer({
      kind: 'AMOUNT',
      amountCentavos: 2_000,
      scope: 'PRODUCTS',
      productIds: new Set([1]),
    })
    const totals = computeOrderTotals({
      lines: [line({ productId: 1 }), line({ productId: 2 })],
      customer: scoped,
    })
    expect(totals.lines.map((l) => l.discountPerUnitCentavos)).toEqual([2_000, 0])
  })

  it('ignores the categories entirely when it names products', () => {
    // The three scopes are exclusive. A rule set to PRODUCTS must not quietly
    // also honour whatever categories were ticked before she switched.
    const scoped = customer({
      kind: 'AMOUNT',
      amountCentavos: 2_000,
      scope: 'PRODUCTS',
      productIds: new Set([9]),
      categoryIds: new Set([FEEDS]),
    })
    const totals = computeOrderTotals({ lines: [line({ productId: 1 })], customer: scoped })
    expect(totals.lines[0].discountPerUnitCentavos).toBe(0)
  })

  it('covers everything when the scope says so', () => {
    const all = customer({
      kind: 'AMOUNT',
      amountCentavos: 2_000,
      scope: 'ALL',
      categoryIds: new Set<number>(),
    })
    const totals = computeOrderTotals({
      lines: [line(), line({ productId: 2, categoryId: MEDICINE })],
      customer: all,
    })
    expect(totals.lines.map((l) => l.discountPerUnitCentavos)).toEqual([2_000, 2_000])
  })

  it('still honours the unit scope whichever way it is aimed', () => {
    // The unit narrows every scope, including ALL — otherwise "₱20 off
    // everything, per bag" would take ₱20 off a ₱110 kilo pack.
    const all = customer({
      kind: 'AMOUNT',
      amountCentavos: 2_000,
      scope: 'ALL',
      unit: 'bag',
      categoryIds: new Set<number>(),
    })
    const totals = computeOrderTotals({
      lines: [line({ unit: 'bag (50kg)' }), line({ productId: 2, unit: 'kilo', priceCentavos: 11_000 })],
      customer: all,
    })
    expect(totals.lines.map((l) => l.discountPerUnitCentavos)).toEqual([2_000, 0])
  })

  it('applies to nothing when it names no products at all', () => {
    // Same rule the empty category list has always had: a stored amount with
    // no scope is inert, not an error, and never a free-for-all.
    const empty = customer({
      kind: 'AMOUNT',
      amountCentavos: 2_000,
      scope: 'PRODUCTS',
      productIds: new Set<number>(),
    })
    const totals = computeOrderTotals({ lines: [line()], customer: empty })
    expect(totals.lines[0].discountPerUnitCentavos).toBe(0)
  })

  it('reads an unrecognised scope as CATEGORIES rather than refusing to price', () => {
    // SQLite has no enums, so a bad value is reachable. Falling back to the
    // historical behaviour beats stopping a sale over a column she cannot see.
    const resolved = customerDiscountOf({
      discountKind: 'AMOUNT',
      discountCentavos: 2_000,
      discountBps: 0,
      discountBasis: 'PER_UNIT',
      discountScope: 'nonsense',
      discountCategories: [{ id: FEEDS }],
    })
    expect(resolved.scope).toBe('CATEGORIES')
    expect(
      computeOrderTotals({ lines: [line()], customer: resolved }).lines[0]
        .discountPerUnitCentavos,
    ).toBe(2_000)
  })

  it('defaults a row written before the column existed to CATEGORIES', () => {
    const resolved = customerDiscountOf({
      discountKind: 'AMOUNT',
      discountCentavos: 2_000,
      discountBps: 0,
      discountBasis: 'PER_UNIT',
      discountCategories: [{ id: FEEDS }],
    })
    expect(resolved.scope).toBe('CATEGORIES')
    expect(resolved.productIds.size).toBe(0)
  })

  it('scopes a once-an-order discount by product too', () => {
    const scoped = customer({
      kind: 'AMOUNT',
      amountCentavos: 2_000,
      basis: 'ONCE_PER_ORDER',
      scope: 'PRODUCTS',
      productIds: new Set([1]),
    })
    expect(
      computeOrderTotals({ lines: [line({ productId: 1, quantity: 5 })], customer: scoped })
        .customerDiscountCentavos,
    ).toBe(2_000)
    expect(
      computeOrderTotals({ lines: [line({ productId: 2 })], customer: scoped })
        .customerDiscountCentavos,
    ).toBe(0)
  })
})

describe('a discount typed against one line', () => {
  it('comes off that line, per unit', () => {
    const totals = computeOrderTotals({
      lines: [line({ quantity: 3, manualDiscountPerUnitCentavos: 5_000 })],
    })
    expect(totals.lines[0].discountPerUnitCentavos).toBe(5_000)
    expect(totals.lineDiscountCentavos).toBe(15_000)
    expect(totals.totalCentavos).toBe(285_000)
  })

  it('leaves every other line alone', () => {
    const totals = computeOrderTotals({
      lines: [line({ manualDiscountPerUnitCentavos: 5_000 }), line({ productId: 2 })],
    })
    expect(totals.lines.map((l) => l.discountPerUnitCentavos)).toEqual([5_000, 0])
    expect(totals.totalCentavos).toBe(195_000)
  })

  it('replaces the standing per-unit discount on that line, rather than adding to it', () => {
    // The figure she typed is what she agreed while the customer stood there.
    // Adding would double-discount a regular customer with nobody noticing.
    const totals = computeOrderTotals({
      lines: [line({ manualDiscountPerUnitCentavos: 5_000 }), line({ productId: 2 })],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 2_000 }),
    })
    expect(totals.lines.map((l) => l.discountPerUnitCentavos)).toEqual([5_000, 2_000])
  })

  it('replaces a standing discount even when it is the smaller of the two', () => {
    // Not `Math.max`. A typed ₱10 against a standing ₱200 is a decision, not
    // a mistake to be corrected on her behalf — and silently ignoring it is
    // how the counter and the receipt come to disagree.
    const totals = computeOrderTotals({
      lines: [line({ manualDiscountPerUnitCentavos: 1_000 })],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 20_000 }),
    })
    expect(totals.lines[0].discountPerUnitCentavos).toBe(1_000)
  })

  it('adds to the standing rate when told to stack', () => {
    // The option the counter now offers: "on top of theirs" for the line she
    // typed against. ₱50 typed plus a standing ₱20 is ₱70 off that sack.
    const totals = computeOrderTotals({
      lines: [line({ manualDiscountPerUnitCentavos: 5_000 }), line({ productId: 2 })],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 2_000 }),
      lineMode: 'STACK',
    })
    expect(totals.lines.map((l) => l.discountPerUnitCentavos)).toEqual([7_000, 2_000])
  })

  it('still cannot take a stacked discount past free', () => {
    const totals = computeOrderTotals({
      lines: [line({ priceCentavos: 5_000, manualDiscountPerUnitCentavos: 4_000 })],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 4_000 }),
      lineMode: 'STACK',
    })
    expect(totals.lines[0].discountPerUnitCentavos).toBe(5_000)
    expect(totals.totalCentavos).toBe(0)
  })

  it('leaves lines she typed nothing against alone, whichever mode', () => {
    // Stacking is about the OVERLAP on one line. It must not change what a
    // line with no typed figure gets.
    for (const lineMode of ['REPLACE', 'STACK'] as const) {
      const totals = computeOrderTotals({
        lines: [line({ productId: 2 })],
        customer: customer({ kind: 'AMOUNT', amountCentavos: 2_000 }),
        lineMode,
      })
      expect(totals.lines[0].discountPerUnitCentavos).toBe(2_000)
    }
  })

  it('defaults to replacing, because that is the safe half of the choice', () => {
    // Omitted entirely — the shape every caller written before the option
    // existed still sends.
    const totals = computeOrderTotals({
      lines: [line({ manualDiscountPerUnitCentavos: 5_000 })],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 2_000 }),
    })
    expect(totals.lines[0].discountPerUnitCentavos).toBe(5_000)
  })

  it('spreads a once-per-line figure across the units', () => {
    // How a shopkeeper actually says it: "₱500 off this line", not "₱100 off
    // each of the five".
    const totals = computeOrderTotals({
      lines: [
        line({ quantity: 5, manualDiscountPerUnitCentavos: 50_000, manualDiscountMode: 'ONCE' }),
      ],
    })
    expect(totals.lines[0].discountPerUnitCentavos).toBe(10_000)
    expect(totals.lineDiscountCentavos).toBe(50_000)
  })

  it('rounds a once-per-line figure DOWN, never over what she asked for', () => {
    // ₱500 across three does not divide. Taking ₱166.67 each would remove
    // ₱500.01 — a centavo more than she said. Under, never over.
    const totals = computeOrderTotals({
      lines: [
        line({ quantity: 3, manualDiscountPerUnitCentavos: 50_000, manualDiscountMode: 'ONCE' }),
      ],
    })
    expect(totals.lines[0].discountPerUnitCentavos).toBe(16_666)
    expect(totals.lineDiscountCentavos).toBe(49_998)
    expect(totals.lineDiscountCentavos).toBeLessThanOrEqual(50_000)
  })

  it('treats the figure as per-unit when the mode says EACH or is absent', () => {
    for (const manualDiscountMode of ['EACH', undefined] as const) {
      const totals = computeOrderTotals({
        lines: [line({ quantity: 5, manualDiscountPerUnitCentavos: 5_000, manualDiscountMode })],
      })
      expect(totals.lines[0].discountPerUnitCentavos).toBe(5_000)
      expect(totals.lineDiscountCentavos).toBe(25_000)
    }
  })

  it('does not divide by a quantity of zero', () => {
    // Unreachable from the counter, which never tallies zero — but this is
    // arithmetic on money crossing a Server Action, so it is not left to luck.
    const totals = computeOrderTotals({
      lines: [
        line({ quantity: 0, manualDiscountPerUnitCentavos: 50_000, manualDiscountMode: 'ONCE' }),
      ],
    })
    expect(Number.isFinite(totals.lines[0].discountPerUnitCentavos)).toBe(true)
    expect(totals.totalCentavos).toBe(0)
  })

  it('stacks a once-per-line figure onto a standing rate when told to', () => {
    const totals = computeOrderTotals({
      lines: [
        line({ quantity: 5, manualDiscountPerUnitCentavos: 50_000, manualDiscountMode: 'ONCE' }),
      ],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 2_000 }),
      lineMode: 'STACK',
    })
    // ₱100 a sack from the once-figure, plus their standing ₱20.
    expect(totals.lines[0].discountPerUnitCentavos).toBe(12_000)
  })

  it('applies to a line the standing discount does not even cover', () => {
    const totals = computeOrderTotals({
      lines: [line({ categoryId: MEDICINE, manualDiscountPerUnitCentavos: 5_000 })],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 2_000 }),
    })
    expect(totals.lines[0].discountPerUnitCentavos).toBe(5_000)
  })

  it('never makes a line worth less than nothing', () => {
    const totals = computeOrderTotals({
      lines: [line({ priceCentavos: 5_000, quantity: 2, manualDiscountPerUnitCentavos: 900_000 })],
    })
    expect(totals.lines[0].discountPerUnitCentavos).toBe(5_000)
    expect(totals.totalCentavos).toBe(0)
  })

  it('is ignored when it is zero or missing, which is the ordinary line', () => {
    const zero = computeOrderTotals({
      lines: [line({ manualDiscountPerUnitCentavos: 0 })],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 2_000 }),
    })
    const absent = computeOrderTotals({
      lines: [line()],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 2_000 }),
    })
    expect(zero.lines[0].discountPerUnitCentavos).toBe(2_000)
    expect(absent.lines[0].discountPerUnitCentavos).toBe(2_000)
  })

  it('does not disturb a standing whole-order discount', () => {
    // It replaces only what applied to the LINE. An order-level discount is
    // not per-line and has nothing to do with it.
    const totals = computeOrderTotals({
      lines: [line({ manualDiscountPerUnitCentavos: 10_000 })],
      customer: customer({ kind: 'PERCENT', bps: 1_000, basis: 'ORDER_TOTAL' }),
    })
    expect(totals.lineDiscountCentavos).toBe(10_000)
    // 10% of the ₱900 that survives the line discount.
    expect(totals.customerDiscountCentavos).toBe(9_000)
    expect(totals.totalCentavos).toBe(81_000)
  })

  it('survives an ad-hoc order discount set to REPLACE', () => {
    // REPLACE drops the customer's STANDING discount. A figure she typed
    // against a line seconds ago is not a standing discount, and dropping it
    // would mean the rail and the saved sale disagreed about that line.
    const totals = computeOrderTotals({
      lines: [line({ manualDiscountPerUnitCentavos: 5_000 })],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 2_000 }),
      order: order({ kind: 'AMOUNT', amountCentavos: 1_000, mode: 'REPLACE' }),
    })
    expect(totals.lines[0].discountPerUnitCentavos).toBe(5_000)
    expect(totals.orderDiscountCentavos).toBe(1_000)
    expect(totals.totalCentavos).toBe(94_000)
  })
})

describe('ad-hoc counter discount', () => {
  it('stacks on top of a per-unit customer discount', () => {
    const totals = computeOrderTotals({
      lines: [line()],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 10_000 }),
      order: order({ kind: 'AMOUNT', amountCentavos: 5_000 }),
    })
    expect(totals.lineDiscountCentavos).toBe(10_000)
    expect(totals.orderDiscountCentavos).toBe(5_000)
    expect(totals.totalCentavos).toBe(85_000)
  })

  it('takes its percentage against the already-discounted figure', () => {
    const totals = computeOrderTotals({
      lines: [line()],
      customer: customer({ kind: 'PERCENT', bps: 1_000 }),
      order: order({ kind: 'PERCENT', bps: 1_000 }),
    })
    // 10% off ₱1,000 leaves ₱900; the counter's 10% is ₱90, not ₱100.
    expect(totals.orderDiscountCentavos).toBe(9_000)
    expect(totals.totalCentavos).toBe(81_000)
  })

  it('replaces the standing discount when the mode says so', () => {
    const totals = computeOrderTotals({
      lines: [line()],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 10_000 }),
      order: order({ kind: 'AMOUNT', amountCentavos: 5_000, mode: 'REPLACE' }),
    })
    expect(totals.lineDiscountCentavos).toBe(0)
    expect(totals.orderDiscountCentavos).toBe(5_000)
    expect(totals.totalCentavos).toBe(95_000)
  })

  it('keeps the standing discount when REPLACE is set but nothing was entered', () => {
    // Leaving the toggle on "instead of" with an empty amount must not
    // silently strip a customer of the discount they are owed.
    const totals = computeOrderTotals({
      lines: [line()],
      customer: customer({ kind: 'AMOUNT', amountCentavos: 10_000 }),
      order: order({ mode: 'REPLACE', amountCentavos: 0 }),
    })
    expect(totals.lineDiscountCentavos).toBe(10_000)
    expect(totals.totalCentavos).toBe(90_000)
  })

  it('never drives the total below zero', () => {
    const totals = computeOrderTotals({
      lines: [line({ priceCentavos: 5_000 })],
      order: order({ kind: 'AMOUNT', amountCentavos: 900_000 }),
    })
    expect(totals.orderDiscountCentavos).toBe(5_000)
    expect(totals.totalCentavos).toBe(0)
  })

  it('applies to a walk-in with no customer at all', () => {
    const totals = computeOrderTotals({
      lines: [line()],
      customer: null,
      order: order({ kind: 'PERCENT', bps: 1_000 }),
    })
    expect(totals.totalCentavos).toBe(90_000)
  })
})

describe('invariants', () => {
  const kinds = ['AMOUNT', 'PERCENT'] as const
  const bases = ['PER_UNIT', 'ONCE_PER_ORDER', 'ORDER_TOTAL'] as const
  const modes = ['STACK', 'REPLACE'] as const

  it('always reports a total of subtotal minus every discount, and never a negative', () => {
    for (const customerKind of kinds) {
      for (const basis of bases) {
        for (const orderKind of kinds) {
          for (const mode of modes) {
            for (const quantity of [1, 2.5, 7]) {
              const totals = computeOrderTotals({
                lines: [
                  line({ quantity, priceCentavos: 145_000 }),
                  line({ productId: 2, quantity, priceCentavos: 3_300, categoryId: MEDICINE }),
                ],
                customer: customer({
                  kind: customerKind,
                  basis,
                  amountCentavos: 7_000,
                  bps: 1_250,
                }),
                order: order({ kind: orderKind, mode, amountCentavos: 9_900, bps: 750 }),
              })

              const label = `${customerKind}/${basis} + ${orderKind}/${mode} × ${quantity}`
              expect(totals.totalCentavos, label).toBeGreaterThanOrEqual(0)
              expect(
                totals.subtotalCentavos - totals.totalDiscountCentavos,
                label,
              ).toBe(totals.totalCentavos)
              expect(Number.isInteger(totals.totalCentavos), label).toBe(true)
            }
          }
        }
      }
    }
  })
})

describe('a per-unit discount scoped to a unit', () => {
  it('applies to the named unit and skips the others', () => {
    const customer = { kind: 'AMOUNT' as const, amountCentavos: 2_000, bps: 0, basis: 'PER_UNIT' as const, unit: 'bag', scope: 'CATEGORIES' as const, categoryIds: new Set([FEEDS]), productIds: new Set<number>() }

    const totals = computeOrderTotals({
      lines: [
        line({ productId: 1, quantity: 1, priceCentavos: 205_000, unit: 'bag (50kg)' }),
        line({ productId: 2, quantity: 1, priceCentavos: 11_000, unit: 'kilo' }),
      ],
      customer,
    })

    // ₱20 off the sack, nothing off the kilo pack.
    expect(totals.lines[0].discountPerUnitCentavos).toBe(2_000)
    expect(totals.lines[1].discountPerUnitCentavos).toBe(0)
    expect(totals.totalCentavos).toBe(205_000 - 2_000 + 11_000)
  })

  it('treats every bag size as a bag', () => {
    const customer = { kind: 'AMOUNT' as const, amountCentavos: 2_000, bps: 0, basis: 'PER_UNIT' as const, unit: 'bag', scope: 'CATEGORIES' as const, categoryIds: new Set([FEEDS]), productIds: new Set<number>() }

    const totals = computeOrderTotals({
      lines: [
        line({ productId: 1, unit: 'bag (50kg)' }),
        line({ productId: 2, unit: 'bag (25kg)' }),
        line({ productId: 3, unit: 'bag' }),
      ],
      customer,
    })

    for (const discounted of totals.lines) {
      expect(discounted.discountPerUnitCentavos).toBe(2_000)
    }
  })

  it('still requires the category, so a unit does not widen the scope', () => {
    const customer = { kind: 'AMOUNT' as const, amountCentavos: 2_000, bps: 0, basis: 'PER_UNIT' as const, unit: 'bag', scope: 'CATEGORIES' as const, categoryIds: new Set([FEEDS]), productIds: new Set<number>() }

    const totals = computeOrderTotals({
      lines: [line({ categoryId: 999, unit: 'bag (50kg)' })],
      customer,
    })
    expect(totals.lines[0].discountPerUnitCentavos).toBe(0)
  })

  it('with no unit named, prices exactly as it did before units existed', () => {
    const customer = { kind: 'AMOUNT' as const, amountCentavos: 2_000, bps: 0, basis: 'PER_UNIT' as const, unit: '', scope: 'CATEGORIES' as const, categoryIds: new Set([FEEDS]), productIds: new Set<number>() }

    const totals = computeOrderTotals({
      lines: [line({ productId: 1, unit: 'bag (50kg)' }), line({ productId: 2, unit: 'kilo' })],
      customer,
    })
    expect(totals.lines.map((l) => l.discountPerUnitCentavos)).toEqual([2_000, 2_000])
  })

  it('is ignored entirely by a whole-order discount', () => {
    // ORDER_TOTAL has no per-line scope at all, so naming a unit must not
    // start narrowing one.
    const customer = { kind: 'AMOUNT' as const, amountCentavos: 5_000, bps: 0, basis: 'ORDER_TOTAL' as const, unit: 'bag', scope: 'CATEGORIES' as const, categoryIds: new Set([FEEDS]), productIds: new Set<number>() }

    const totals = computeOrderTotals({
      lines: [line({ priceCentavos: 100_000, unit: 'kilo' })],
      customer,
    })
    expect(totals.totalCentavos).toBe(95_000)
  })
})
