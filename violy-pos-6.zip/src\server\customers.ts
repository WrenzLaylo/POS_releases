'use server'

import type { Customer } from '@prisma/client'
import { prisma } from '@/lib/db'
import { unitKeyword } from '@/lib/unit'
import { parseDayKey, startOfDay } from '@/lib/dates'
import { sumBalance } from '@/lib/ledger-balance'
import type { ActionResult, CategoryCheapest, CustomerWithDiscount } from '@/lib/types'
import { prismaErrorCode } from '@/lib/prisma-errors'
import { ROUTES, bookEntry } from '@/lib/routes'
import {
  isDiscountBasis,
  isDiscountScope,
  type DiscountScope,
  isDiscountKind,
  MAX_BPS,
  type DiscountBasis,
  type DiscountKind,
} from '@/lib/discount'
import { revalidateRoutes, revalidatePathname } from './revalidate'

type CustomerInput = {
  name: string
  phone?: string
  notes?: string
  discountCentavos?: number
  discountKind?: string
  discountBps?: number
  discountBasis?: string
  discountUnit?: string
  discountScope?: string
  discountCategoryIds?: number[]
  discountProductIds?: number[]
}

type ParsedCustomer = {
  name: string
  phone: string | null
  notes: string
  discountCentavos: number
  discountKind: DiscountKind
  discountBps: number
  discountBasis: DiscountBasis
  discountUnit: string
  discountScope: DiscountScope
  discountCategoryIds: number[]
  discountProductIds: number[]
}

function parse(input: CustomerInput): ParsedCustomer | string {
  const name = input.name.trim()
  if (!name) return 'Name is required.'

  const discountCentavos = input.discountCentavos ?? 0
  if (!Number.isInteger(discountCentavos) || discountCentavos < 0) {
    return 'Discount must be zero or more.'
  }

  // Both unions are checked at runtime, not merely typed: they arrive across
  // a Server Action boundary, and SQLite has no enum to refuse a bad value at
  // the column.
  const discountKind = input.discountKind ?? 'AMOUNT'
  if (!isDiscountKind(discountKind)) return 'Unrecognised discount type.'

  const discountBasis = input.discountBasis ?? 'PER_UNIT'
  if (!isDiscountBasis(discountBasis)) return 'Unrecognised discount basis.'

  const discountScope = input.discountScope ?? 'CATEGORIES'
  if (!isDiscountScope(discountScope)) return 'Unrecognised discount scope.'

  const discountBps = input.discountBps ?? 0
  if (!Number.isInteger(discountBps) || discountBps < 0 || discountBps > MAX_BPS) {
    return 'Discount percentage must be between 0 and 100.'
  }

  const phone = (input.phone ?? '').trim()
  return {
    name,
    phone: phone === '' ? null : phone,
    notes: (input.notes ?? '').trim(),
    discountCentavos,
    discountKind,
    discountBps,
    discountBasis,
    // Free text, lowercased to the keyword the pipeline matches on. Not
    // validated against the catalog: a discount naming a unit nothing is sold
    // in yet is inert, not wrong, and refusing it would block setting one up
    // before the first sack arrives.
    discountUnit: unitKeyword(input.discountUnit ?? ''),
    discountScope,
    // The scope a rule is NOT set to is stored empty rather than left alone.
    // Keeping the old list would let switching from brands to products and
    // back silently resurrect ticks she thought she had replaced — the same
    // reason the unused amount/percent column is zeroed.
    discountCategoryIds: discountScope === 'CATEGORIES' ? (input.discountCategoryIds ?? []) : [],
    discountProductIds: discountScope === 'PRODUCTS' ? (input.discountProductIds ?? []) : [],
  }
}

/**
 * Unarchived customers, most recently ordered first. That ordering is the
 * whole point of the picker: the names she used today are the names she is
 * most likely to use next.
 *
 * The sort happens in JavaScript because Prisma cannot order a parent by an
 * aggregate over its children on SQLite.
 */
export async function listCustomers(): Promise<CustomerWithDiscount[]> {
  const customers = await prisma.customer.findMany({
    where: { isArchived: false },
    include: {
      sales: { select: { createdAt: true }, orderBy: { createdAt: 'desc' }, take: 1 },
      discountCategories: { select: { id: true, name: true } },
      discountProducts: { select: { id: true, name: true } },
    },
  })

  return customers
    .map(({ sales, ...customer }) => ({
      customer,
      lastOrderedAt: sales[0]?.createdAt ?? null,
    }))
    .sort((a, b) => {
      if (a.lastOrderedAt && b.lastOrderedAt) {
        return b.lastOrderedAt.getTime() - a.lastOrderedAt.getTime()
      }
      if (a.lastOrderedAt) return -1
      if (b.lastOrderedAt) return 1
      return a.customer.name.localeCompare(b.customer.name)
    })
    .map((row) => row.customer)
}

export async function getCustomer(id: number): Promise<CustomerWithDiscount | null> {
  return prisma.customer.findUnique({
    where: { id },
    include: {
      discountCategories: { select: { id: true, name: true } },
      discountProducts: { select: { id: true, name: true } },
    },
  })
}

/**
 * The account already on file under this name, if there is one.
 *
 * `Customer.name` carries a `@@unique`, and it is not enough. SQLite compares
 * TEXT case-sensitively unless the column is declared `COLLATE NOCASE`, so the
 * database will happily hold MARILOU, Marilou and marilou as three separate
 * people — and `findUnique({ where: { name } })` misses two of them every
 * time. There is a test for exactly that; it failed before this existed.
 *
 * The consequence is worse here than for a duplicate product. Two accounts for
 * one person split her utang across both, so neither balance is what she
 * actually owes, a payment against one leaves the other still showing a debt,
 * and the total on the Book is right only by accident.
 *
 * `contains` narrows in SQL — LIKE is case-insensitive on this provider even
 * though `=` is not — and the exact comparison happens here. Archived accounts
 * count: the answer for one of those is "restore her", not a second file.
 */
async function findCustomerByName(
  name: string,
  excludeId?: number,
): Promise<{ id: number; name: string; isArchived: boolean } | null> {
  const needle = name.trim().toLowerCase()
  if (!needle) return null

  const candidates = await prisma.customer.findMany({
    where: { name: { contains: needle } },
    select: { id: true, name: true, isArchived: true },
  })

  return (
    candidates.find(
      (row) => row.name.trim().toLowerCase() === needle && row.id !== excludeId,
    ) ?? null
  )
}

function duplicateCustomerMessage(existing: { name: string; isArchived: boolean }): string {
  return existing.isArchived
    ? `${existing.name} is already on the list but archived. Restore that account instead of adding a new one — her utang is on it.`
    : `${existing.name} is already on the list.`
}

export async function createCustomer(
  input: CustomerInput,
): Promise<ActionResult<{ customerId: number }>> {
  const parsed = parse(input)
  if (typeof parsed === 'string') return { ok: false, error: parsed }

  const existing = await findCustomerByName(parsed.name)
  if (existing) {
    return { ok: false, error: duplicateCustomerMessage(existing) }
  }

  let customer: Customer
  try {
    customer = await prisma.customer.create({
      data: {
        name: parsed.name,
        phone: parsed.phone,
        notes: parsed.notes,
        discountCentavos: parsed.discountCentavos,
        discountKind: parsed.discountKind,
        discountBps: parsed.discountBps,
        discountBasis: parsed.discountBasis,
        discountUnit: parsed.discountUnit,
        discountScope: parsed.discountScope,
        discountCategories: {
          connect: parsed.discountCategoryIds.map((id) => ({ id })),
        },
        discountProducts: {
          connect: parsed.discountProductIds.map((id) => ({ id })),
        },
      },
    })
  } catch (error) {
    if (prismaErrorCode(error) === 'P2002') {
      return { ok: false, error: `${parsed.name} is already on the list.` }
    }
    return { ok: false, error: 'Could not save the customer.' }
  }

  revalidateRoutes([ROUTES.counter, ROUTES.history, ROUTES.book])
  return { ok: true, data: { customerId: customer.id } }
}

export async function updateCustomer(
  id: number,
  input: CustomerInput,
): Promise<ActionResult> {
  const parsed = parse(input)
  if (typeof parsed === 'string') return { ok: false, error: parsed }

  const existing = await prisma.customer.findUnique({ where: { id } })
  if (!existing) return { ok: false, error: 'Customer not found.' }

  const clash = await findCustomerByName(parsed.name, id)
  if (clash) {
    return { ok: false, error: duplicateCustomerMessage(clash) }
  }

  try {
    await prisma.customer.update({
      where: { id },
      data: {
        name: parsed.name,
        phone: parsed.phone,
        notes: parsed.notes,
        discountCentavos: parsed.discountCentavos,
        discountKind: parsed.discountKind,
        discountBps: parsed.discountBps,
        discountBasis: parsed.discountBasis,
        discountUnit: parsed.discountUnit,
        // `set`, NOT `connect` — this must replace the category list, not add
        // to it. `createCustomer` above uses `connect` because it starts from
        // an empty relation; here the customer already has categories, and
        // `connect` would leave every previously-ticked one attached. She
        // unticks Feeds (Kilo), saves, sees it gone from the form, and keeps
        // granting the discount on it forever. Harmonising these two call
        // sites would compile and pass every unrelated test.
        discountScope: parsed.discountScope,
        discountCategories: {
          set: parsed.discountCategoryIds.map((id) => ({ id })),
        },
        // `set` for the same reason, and it matters more here: an unticked
        // product left connected keeps earning a discount she believes she
        // removed.
        discountProducts: {
          set: parsed.discountProductIds.map((id) => ({ id })),
        },
      },
    })
  } catch (error) {
    const code = prismaErrorCode(error)
    if (code === 'P2002') return { ok: false, error: `${parsed.name} is already on the list.` }
    if (code === 'P2025') return { ok: false, error: 'Customer not found.' }
    return { ok: false, error: 'Could not save the customer.' }
  }

  revalidateRoutes([ROUTES.counter, ROUTES.history, ROUTES.book])
  return { ok: true, data: undefined }
}

/** Archives rather than deletes: sales and ledger entries reference the row. */
export async function archiveCustomer(id: number): Promise<ActionResult> {
  const existing = await prisma.customer.findUnique({ where: { id } })
  if (!existing) return { ok: false, error: 'Customer not found.' }

  try {
    await prisma.customer.update({ where: { id }, data: { isArchived: true } })
  } catch (error) {
    if (prismaErrorCode(error) === 'P2025') return { ok: false, error: 'Customer not found.' }
    return { ok: false, error: 'Could not archive the customer.' }
  }

  revalidateRoutes([ROUTES.counter, ROUTES.history, ROUTES.book])
  return { ok: true, data: undefined }
}

/**
 * The way back from `archiveCustomer`. Archiving is a single click, and it
 * hides the customer from the order picker and the bulk payment grid while
 * their utang stays live on the Customers page — so without this a mis-click
 * strands a debtor somewhere only a direct database edit could reach them.
 * Re-creating them is not a workaround: the unique-name check rejects it.
 */
export async function restoreCustomer(id: number): Promise<ActionResult> {
  const existing = await prisma.customer.findUnique({ where: { id } })
  if (!existing) return { ok: false, error: 'Customer not found.' }

  try {
    await prisma.customer.update({ where: { id }, data: { isArchived: false } })
  } catch (error) {
    if (prismaErrorCode(error) === 'P2025') return { ok: false, error: 'Customer not found.' }
    return { ok: false, error: 'Could not restore the customer.' }
  }

  revalidateRoutes([ROUTES.counter, ROUTES.history, ROUTES.book])
  return { ok: true, data: undefined }
}

/** Extends or corrects the deadline for a live positive balance. */
export async function setCustomerDueDate(id: number, day: string): Promise<ActionResult> {
  if (!Number.isInteger(id) || id <= 0) return { ok: false, error: 'Customer not found.' }

  const dueAt = parseDayKey(day)
  if (!dueAt) return { ok: false, error: 'Enter a valid due date.' }
  if (dueAt < startOfDay(new Date())) {
    return { ok: false, error: 'Due date cannot be in the past.' }
  }

  try {
    await prisma.$transaction(async (tx) => {
      // Validate the live balance and write the deadline under the same SQLite
      // transaction. Otherwise a concurrent payment could clear the balance
      // between this read and update, leaving a settled account with dueAt.
      const customer = await tx.customer.findUnique({
        where: { id },
        select: {
          id: true,
          entries: {
            where: { isVoided: false },
            select: { id: true, type: true, amountCentavos: true, isVoided: true },
          },
        },
      })
      if (!customer) throw new Error('DUE_DATE_CUSTOMER_NOT_FOUND')
      if (sumBalance(customer.entries) <= 0) throw new Error('DUE_DATE_NO_BALANCE')

      await tx.customer.update({ where: { id }, data: { dueAt } })
    })
  } catch (error) {
    if (
      prismaErrorCode(error) === 'P2025' ||
      (error instanceof Error && error.message === 'DUE_DATE_CUSTOMER_NOT_FOUND')
    ) {
      return { ok: false, error: 'Customer not found.' }
    }
    if (error instanceof Error && error.message === 'DUE_DATE_NO_BALANCE') {
      return { ok: false, error: 'This account has no outstanding balance.' }
    }
    return { ok: false, error: 'Could not update the due date.' }
  }

  // The write has committed. Revalidation stays outside the catch so a
  // rendering failure can never make a successful account edit look failed.
  revalidateRoutes([ROUTES.book], { layout: true })
  revalidatePathname(bookEntry(id))
  return { ok: true, data: undefined }
}

/**
 * Every category with its cheapest unarchived product, so the customer form
 * can warn that a discount would price a line at zero. Archived products are
 * excluded — a discontinued item should not trigger a warning about a
 * category she can still sell from.
 */
export async function listCategoriesWithCheapest(): Promise<CategoryCheapest[]> {
  const categories = await prisma.category.findMany({
    orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
    include: {
      products: {
        where: { isArchived: false },
        orderBy: { price: 'asc' },
        take: 1,
        select: { name: true, price: true },
      },
    },
  })

  return categories.map((category) => ({
    id: category.id,
    name: category.name,
    cheapestName: category.products[0]?.name ?? null,
    cheapestCentavos: category.products[0]?.price ?? null,
  }))
}
