'use client'

import { useMemo, useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import type { CustomerWithDiscount, ProductWithCategory } from '@/lib/types'
import { createOrder } from '@/server/orders'
import { computeOrderTotals } from '@/lib/discount'
import {
  deliveryOrderTotal,
  validateDeliveryDetails,
  type DeliveryOrderDetails,
} from '@/lib/delivery-order'
import { parsePesoInput } from '@/lib/money'
import { dayKey, parseDayKey } from '@/lib/dates'
import { deliveryNote, ROUTES } from '@/lib/routes'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { DatePicker } from '@/components/ui/DatePicker'
import { Field } from '@/components/ui/Field'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'
import { Money } from '@/components/ui/Money'
import { ProductPicker } from '@/components/ProductPicker'
import { SegmentedControl } from '@/components/ui/SegmentedControl'
import { Textarea } from '@/components/ui/Textarea'
import { CustomerCombobox } from '../CustomerCombobox'
import type { CustomerPaymentMode, RailSelection } from '../OrderRail'

type Row = {
  /** Stable across inserts and removals so React keeps focus in the right box. */
  key: number
  productId: string
  quantity: string
}

let nextKey = 1
function blankRow(): Row {
  nextKey += 1
  return { key: nextKey, productId: '', quantity: '' }
}

/**
 * Keeps only what can be part of a peso figure, as she types.
 *
 * The same rule the counter's cash box follows, and for the same reason: a
 * keypad cannot type a letter into a till drawer, so refusing the character is
 * better than accepting it, painting the box red and blocking the save.
 */
function digitsOnly(raw: string): string {
  const kept = raw.replace(/[^0-9.]/g, '')
  const firstDot = kept.indexOf('.')
  if (firstDot === -1) return kept
  return kept.slice(0, firstDot + 1) + kept.slice(firstDot + 1).replace(/\./g, '')
}

const PAYMENT_OPTIONS = [
  { value: 'credit', label: 'On utang' },
  { value: 'partial', label: 'Part paid' },
  { value: 'cash', label: 'Paid in full' },
] as const

/**
 * One screen that records a sale AND a delivery.
 *
 * The sale is REAL at save time: stock moves, and the account is charged if it
 * is utang. This is not a booking that becomes a sale later, and the wording on
 * the screen says so — the difference matters to whoever reads the stock figure
 * an hour afterwards.
 *
 * Three things here are deliberate and easy to "tidy" wrongly:
 *
 * · The running total goes through `computeOrderTotals`, the same function
 *   `createOrder` prices with, and the fee is added on top through
 *   `deliveryOrderTotal`. What she reads to the customer is what hits the
 *   books. A second total computed a second way eventually disagrees.
 * · It opens on UTANG, unlike the counter, which opens on cash. A load going
 *   out to a barangay is nearly always charged; a walk-in nearly always pays.
 * · There is no walk-in here. `CustomerCombobox` is reached in "customer" mode
 *   only, because a delivery needs a name and an address to be delivered to.
 */
export function DeliverForm({
  products,
  customers,
}: {
  products: ProductWithCategory[]
  customers: CustomerWithDiscount[]
}) {
  const router = useRouter()
  const [pending, startTransition] = useTransition()

  const [selection, setSelection] = useState<RailSelection | null>(null)
  const [deliverAt, setDeliverAt] = useState(dayKey(new Date()))
  const [deliverTo, setDeliverTo] = useState('')
  const [address, setAddress] = useState('')
  const [instructions, setInstructions] = useState('')
  const [fee, setFee] = useState('')
  const [rows, setRows] = useState<Row[]>([blankRow()])
  const [paymentMode, setPaymentMode] = useState<CustomerPaymentMode>('credit')
  const [cash, setCash] = useState('')
  const [error, setError] = useState<string | null>(null)

  // Generated once per visit, not per attempt: a retry after a failed save has
  // to reuse it, or the retry is what creates the duplicate charge this key
  // exists to prevent.
  const [clientOrderKey] = useState(
    () =>
      globalThis.crypto?.randomUUID?.() ??
      `deliver-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
  )

  const byId = useMemo(
    () => new Map(products.map((product) => [product.id, product])),
    [products],
  )

  const lines = rows
    .filter((row) => row.productId !== '' && Number(row.quantity) > 0)
    .map((row) => ({ productId: Number(row.productId), quantity: Number(row.quantity) }))

  // The same `computeOrderTotals` the Server Action calls. This preview is
  // what she reads out, so it cannot be a second implementation that agrees
  // with the server most of the time.
  const totals = computeOrderTotals({
    lines: lines.flatMap(({ productId, quantity }) => {
      const product = byId.get(productId)
      return product
        ? [
            {
              productId,
              quantity,
              priceCentavos: product.price,
            },
          ]
        : []
    }),
  })
  const totalsByProduct = new Map(totals.lines.map((line) => [line.productId, line]))

  // A blank fee is no fee, not an unparseable one. Anything that will not
  // parse blocks the save rather than silently sending zero.
  const feeBlank = fee.trim() === ''
  const parsedFee = feeBlank ? 0 : parsePesoInput(fee)
  const feeIsValid = parsedFee !== null
  const feeCentavos = parsedFee ?? 0

  const goodsCentavos = totals.totalCentavos
  const totalCentavos = deliveryOrderTotal(goodsCentavos, feeCentavos)

  const cashBlank = cash.trim() === ''
  const parsedCash = cashBlank ? 0 : parsePesoInput(cash)
  const cashIsValid = parsedCash !== null
  const cashCentavos = parsedCash ?? 0

  // Blank means "the exact amount" only when she has said it is paid in full.
  // On utang it means nothing was handed over, which is the opposite default
  // to the counter's and is why this is spelled out rather than shared.
  const tenderedCentavos =
    paymentMode === 'credit'
      ? 0
      : cashBlank && paymentMode === 'cash'
        ? totalCentavos
        : cashCentavos
  const chargeCentavos = Math.max(0, totalCentavos - tenderedCentavos)
  const changeCentavos = Math.max(0, tenderedCentavos - totalCentavos)

  const details: DeliveryOrderDetails = {
    deliverAt: parseDayKey(deliverAt) ?? new Date(Number.NaN),
    deliverTo,
    address,
    instructions,
    feeCentavos,
  }
  // The same check the server will run, so a disabled Save button is never a
  // mystery and a refused save never says something the screen did not.
  const deliveryProblem = feeIsValid ? validateDeliveryDetails(details) : null

  const paymentIsValid = (() => {
    if (!cashIsValid) return false
    if (paymentMode === 'credit') return true
    if (paymentMode === 'cash') return cashBlank || cashCentavos >= totalCentavos
    return !cashBlank && cashCentavos > 0 && cashCentavos < totalCentavos
  })()

  const started = selection !== null || rows.some((row) => row.productId !== '')
  const canSave =
    selection !== null &&
    lines.length > 0 &&
    feeIsValid &&
    deliveryProblem === null &&
    paymentIsValid &&
    !pending

  function setRow(key: number, patch: Partial<Row>) {
    setRows((current) => current.map((row) => (row.key === key ? { ...row, ...patch } : row)))
  }

  function save() {
    if (selection?.kind !== 'customer') return
    setError(null)

    startTransition(async () => {
      const result = await createOrder({
        customerId: selection.id,
        lines,
        // `null` is "exact cash against the server's own total" and is used
        // only when she said paid in full and typed nothing. Utang sends 0,
        // which is a different statement: nothing was handed over.
        cashPaidCentavos:
          paymentMode === 'credit' ? 0 : cashBlank && paymentMode === 'cash' ? null : cashCentavos,
        delivery: details,
        clientOrderKey,
      })
      if (!result.ok) {
        setError(result.error)
        return
      }
      // Straight to the note. "Save and print note" is one action as far as
      // she is concerned, and Print lives on the document.
      router.push(deliveryNote(result.data.saleId))
      router.refresh()
    })
  }

  return (
    <div className="grid gap-6">
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <h2 className="mb-3 text-base font-semibold">Customer</h2>
          <CustomerCombobox
            customers={customers}
            selection={selection}
            onSelect={(next) => {
              setSelection(next)
              setCash('')
            }}
          />

        </Card>

        <Card>
          <h2 className="mb-3 text-base font-semibold">Delivery</h2>
          <div className="grid gap-4">
            <div className="grid min-w-0 gap-4 sm:grid-cols-2">
              <Field label="Delivery date">
                <DatePicker
                  value={deliverAt}
                  onChange={setDeliverAt}
                  aria-label="Delivery date"
                  className="w-full"
                />
              </Field>

              <Field label="Where it is going">
                <Input
                  value={deliverTo}
                  onChange={(event) => setDeliverTo(event.target.value)}
                  placeholder="e.g. Bagac"
                  className="w-full"
                />
              </Field>
            </div>

            {/* On the sale, not on the customer: the same buyer has feeds sent
                to a farm one week and a house the next, and the note has to
                say where THIS load went. */}
            <Field label="Address of the receiver (optional)">
              <Textarea
                value={address}
                onChange={(event) => setAddress(event.target.value)}
                rows={2}
                placeholder="Printed on the delivery note"
                className="w-full"
              />
            </Field>

            <Field label="Note for the driver (optional)">
              <Textarea
                value={instructions}
                onChange={(event) => setInstructions(event.target.value)}
                rows={2}
                placeholder="e.g. Leave with the caretaker if nobody is home"
                className="w-full"
              />
            </Field>
          </div>
        </Card>
      </div>

      <Card>
        <h2 className="mb-3 text-base font-semibold">What is going out</h2>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[40rem] text-sm">
            <thead className="text-left text-xs uppercase tracking-wide text-ink-muted">
              <tr>
                <th className="pb-2 font-medium">Product</th>
                <th className="w-24 pb-2 font-medium">Quantity</th>
                <th className="w-40 pb-2 text-right font-medium">Line total</th>
                <th className="w-12 pb-2" />
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => {
                const product = byId.get(Number(row.productId))
                const priced = totalsByProduct.get(Number(row.productId))
                const stockAfter = product
                  ? product.stockQty - (Number(row.quantity) || 0)
                  : null

                return (
                  <tr key={row.key} className="align-top">
                    <td className="py-1.5 pr-2">
                      {/* The searchable dialog built for the supplier
                          delivery form. Fifty-five products with no search is
                          scrolling for every row. */}
                      <ProductPicker
                        products={products}
                        value={row.productId}
                        onChange={(productId) => setRow(row.key, { productId })}
                      />
                      {product && (
                        <span className="mt-1 block text-xs text-ink-subtle">
                          per {product.unit}
                        </span>
                      )}
                    </td>
                    <td className="py-1.5 pr-2">
                      <Input
                        aria-label="Quantity"
                        inputMode="decimal"
                        value={row.quantity}
                        onChange={(event) =>
                          setRow(row.key, { quantity: digitsOnly(event.target.value) })
                        }
                        placeholder="0"
                        className="w-full tabular-nums"
                      />
                      {/* Said before saving, not discovered afterwards: this
                          sale takes the stock the moment it is written, so a
                          load bigger than the shelf is worth seeing now.

                          Worded as the counter's oversell dialog words it —
                          "would leave N" rather than "only N on hand", which
                          reads as nonsense against a count that is already
                          negative, and plenty of them are. */}
                      {stockAfter !== null && stockAfter < 0 && (
                        <span className="mt-1 block text-xs text-warn">
                          Would leave {stockAfter} in stock
                        </span>
                      )}
                    </td>
                    <td className="py-1.5 pr-2 text-right">
                      <span className="flex h-10 items-center justify-end text-sm tabular-nums">
                        {priced ? <Money centavos={priced.lineTotalCentavos} scale="body" /> : null}
                      </span>
                    </td>
                    <td className="py-1.5">
                      <span className="flex h-10 items-center">
                        <button
                          type="button"
                          aria-label="Remove this line"
                          onClick={() =>
                            setRows((current) =>
                              // Never below one row: an empty list has nothing
                              // to type into and no obvious way back.
                              current.length === 1
                                ? [blankRow()]
                                : current.filter((candidate) => candidate.key !== row.key),
                            )
                          }
                          className="h-8 w-8 shrink-0 rounded-lg border border-line-strong text-base leading-none text-ink-muted transition-colors duration-150 hover:border-owed hover:text-owed focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                        >
                          ×
                        </button>
                      </span>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>

        <div className="mt-3">
          <Button
            variant="secondary"
            size="sm"
            onClick={() => setRows((current) => [...current, blankRow()])}
          >
            Add another line
          </Button>
        </div>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <h2 className="mb-3 text-base font-semibold">Payment</h2>
          <SegmentedControl
            ariaLabel="How this is being paid"
            options={PAYMENT_OPTIONS}
            value={paymentMode}
            onValueChange={(value) => {
              setPaymentMode(value as CustomerPaymentMode)
              setCash('')
            }}
          />

          {paymentMode !== 'credit' && (
            <Field label={paymentMode === 'partial' ? 'Paid now' : 'Cash received'} className="mt-4">
              <Input
                inputMode="decimal"
                value={cash}
                onChange={(event) => setCash(digitsOnly(event.target.value))}
                placeholder={paymentMode === 'cash' ? 'Exact amount' : '0.00'}
                className="w-full tabular-nums"
              />
            </Field>
          )}

          <Field label="Delivery fee (optional)" className="mt-4">
            <Input
              inputMode="decimal"
              value={fee}
              onChange={(event) => setFee(digitsOnly(event.target.value))}
              placeholder="0.00"
              className="w-full tabular-nums"
            />
          </Field>
          <p className="mt-1.5 text-xs text-ink-subtle">
            Charged on top of the goods. A standing discount never comes off it.
          </p>
        </Card>

        <Card>
          <h2 className="mb-3 text-base font-semibold">Total</h2>
          <dl className="grid gap-1 text-sm">
            {totals.totalDiscountCentavos > 0 && (
              <>
                <div className="flex justify-between">
                  <dt className="text-ink-muted">Subtotal</dt>
                  <dd>
                    <Money centavos={totals.subtotalCentavos} scale="body" />
                  </dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-ink-muted">Discount</dt>
                  <dd>
                    −<Money centavos={totals.totalDiscountCentavos} scale="body" />
                  </dd>
                </div>
              </>
            )}
            <div className="flex justify-between">
              <dt className="text-ink-muted">Goods</dt>
              <dd>
                {/* Neutral. Benta is not cash in the drawer. */}
                <Money centavos={goodsCentavos} scale="body" />
              </dd>
            </div>
            {feeCentavos > 0 && (
              <div className="flex justify-between">
                <dt className="text-ink-muted">Delivery fee</dt>
                <dd>
                  <Money centavos={feeCentavos} scale="body" />
                </dd>
              </div>
            )}
            <div className="flex items-baseline justify-between border-t border-line pt-2">
              <dt className="font-semibold text-ink">Total</dt>
              <dd>
                <Money centavos={totalCentavos} scale="strong" />
              </dd>
            </div>
            {tenderedCentavos > 0 && (
              <div className="flex justify-between">
                <dt className="text-ink-muted">Cash received</dt>
                <dd>
                  {/* `in` is only for cash that actually arrived, and this is
                      the one figure on this screen that qualifies. */}
                  <Money centavos={Math.min(tenderedCentavos, totalCentavos)} scale="body" tone="in" />
                </dd>
              </div>
            )}
            {changeCentavos > 0 && (
              <div className="flex justify-between">
                <dt className="text-ink-muted">Change</dt>
                {/* Never green: this is cash LEAVING the drawer. */}
                <dd>
                  <Money centavos={changeCentavos} scale="body" />
                </dd>
              </div>
            )}
            <div className="flex items-baseline justify-between border-t border-line pt-2">
              <dt className="font-medium text-ink">Charged to the account</dt>
              <dd>
                <Money centavos={chargeCentavos} tone="owed" scale="strong" />
              </dd>
            </div>
          </dl>
        </Card>
      </div>

      {/* The server's own complaint, shown before she presses anything, so a
          disabled Save button is never a mystery. */}
      {started && !feeIsValid && (
        <p className="text-sm text-warn">That delivery fee is not a number.</p>
      )}
      {started && feeIsValid && deliveryProblem && (
        <p className="text-sm text-warn">{deliveryProblem}</p>
      )}
      {started && selection !== null && lines.length === 0 && (
        <p className="text-sm text-warn">Add at least one thing to send.</p>
      )}
      {started && !paymentIsValid && (
        <p className="text-sm text-warn">
          {paymentMode === 'partial'
            ? 'A part payment has to be more than nothing and less than the total.'
            : 'That is less than the total. Enter the full amount received.'}
        </p>
      )}
      {error && <FormError>{error}</FormError>}

      <div className="flex flex-wrap justify-end gap-2">
        <Button variant="ghost" onClick={() => router.push(ROUTES.counter)} disabled={pending}>
          Cancel
        </Button>
        {/* `success`: terminal and money-committing. Saving moves the stock
            and writes the charge — it is not a draft. */}
        <Button variant="success" onClick={save} disabled={!canSave}>
          {pending ? 'Saving…' : 'Save and print note'}
        </Button>
      </div>
    </div>
  )
}
