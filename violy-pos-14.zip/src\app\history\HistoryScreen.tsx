'use client'

import { useState } from 'react'
import type { DayOrder, DeliveryOrderRow, Paged, SaleWithItems } from '@/lib/types'
import { Card } from '@/components/ui/Card'
import { Tabs } from '@/components/ui/Tabs'
import { Pagination } from '@/components/Pagination'
import { DayView } from './DayView'
import { GoingOutView } from './GoingOutView'
import { SalesList } from './SalesList'
import { HistoryFilters } from './HistoryFilters'

const HISTORY_TABS = [
  { value: 'today', label: 'Today' },
  { value: 'recent', label: 'Recent' },
  { value: 'going-out', label: 'Going out' },
] as const

type HistoryTab = (typeof HISTORY_TABS)[number]['value']

export function HistoryScreen({
  todayOrders,
  sales,
  deliveries,
  customers,
  categories,
  filters,
  view,
}: {
  todayOrders: DayOrder[]
  sales: Paged<SaleWithItems>
  deliveries: { upcoming: DeliveryOrderRow[]; past: DeliveryOrderRow[] }
  customers: { id: number; name: string; isArchived: boolean }[]
  categories: { id: number; name: string }[]
  filters: {
    from?: string
    to?: string
    customer?: string
    status?: string
    category?: string
    kind?: string
  }
  /** `?view=going-out` from the Dashboard panel or the bell. A tab held only
   *  in component state cannot be linked to, and both of those surfaces exist
   *  to point at this one. */
  view?: string
}) {
  // Starts on "Recent" instead of "Today" whenever the URL already carries a
  // filter or a page beyond the first — otherwise submitting `HistoryFilters`
  // (a plain GET form, so it reloads the page) would land back on "Today"
  // and hide the very results the operator just asked for.
  const hasHistoryQuery =
    Boolean(
      filters.from || filters.to || filters.customer || filters.status || filters.category ||
        filters.kind,
    ) || sales.page > 1

  // An explicit `?view=` wins over the filter heuristic: somebody who followed
  // a link to the booked loads asked for that tab by name.
  const [tab, setTab] = useState<HistoryTab>(
    view === 'going-out' ? 'going-out' : hasHistoryQuery ? 'recent' : 'today',
  )

  // One clock for the whole tab, taken on the client only after mount would be
  // safer still — but this is a plain render-time read passed DOWN as a prop
  // rather than frozen in a `useState` initialiser, so a midnight crossing
  // re-renders correctly instead of sticking on yesterday.
  const today = new Date()

  return (
    <div className="flex flex-col gap-4">
      <Tabs
        ariaLabel="Order history"
        tabs={HISTORY_TABS}
        value={tab}
        onValueChange={(value) => setTab(value as HistoryTab)}
      />

      {tab === 'today' && <DayView orders={todayOrders} />}

      {tab === 'going-out' && (
        <GoingOutView upcoming={deliveries.upcoming} past={deliveries.past} today={today} />
      )}

      {tab === 'recent' && (
        <div className="flex flex-col gap-4">
          <Card>
            <HistoryFilters
              customers={customers}
              categories={categories}
              from={filters.from}
              to={filters.to}
              customer={filters.customer}
              status={filters.status}
              category={filters.category}
              kind={filters.kind}
            />
          </Card>

          <SalesList sales={sales.rows} />

          <Pagination
            page={sales.page}
            pageCount={sales.pageCount}
            params={{
              from: filters.from,
              to: filters.to,
              customer: filters.customer,
              status: filters.status,
              category: filters.category,
              kind: filters.kind,
            }}
          />
        </div>
      )}
    </div>
  )
}
