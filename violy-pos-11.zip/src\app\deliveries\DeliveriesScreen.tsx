'use client'

import { useState, useTransition } from 'react'
import { usePathname, useRouter } from 'next/navigation'
import { useGuardedAction } from '@/lib/use-guarded-action'
import { PasswordPrompt } from '@/components/PasswordPrompt'
import type { DeliveryRow, ConsignmentToSettle } from '@/server/deliveries'
import { getDelivery, payDelivery, voidDelivery } from '@/server/deliveries'
import type { DeliveryDetail } from '@/server/deliveries'
import { parsePesoInput, lineTotal } from '@/lib/money'
import { NEW_DELIVERY } from '@/lib/routes'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Dialog } from '@/components/ui/Dialog'
import { EmptyState } from '@/components/ui/EmptyState'
import { Field } from '@/components/ui/Field'
import { FilterChips } from '@/components/ui/FilterChips'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'
import { Money } from '@/components/ui/Money'
import { ROUTES, delivery as deliveryDocument, settleDelivery } from '@/lib/routes'
import { RowActionMenu } from '@/components/ui/RowActionMenu'
import { Tabs } from '@/components/ui/Tabs'
import { TapeCell, TapeRow } from '@/components/ui/Tape'
import { SupplierDialog } from './SupplierDialog'

export type SupplierOption = {
  id: number
  name: string
  contactNumber: string
  notes: string
  isArchived: boolean
}

/**
 * The settling to-do list: every consignment with stock still on the shelf.
 *
 * A consignment is a relationship, not an event — sacks land, some sell, the
 * agent visits and bills for those, the rest wait for next time. Answering
 * "what does he settle on Tuesday" used to mean reading the whole delivery
 * list and knowing which rows were still open.
 *
 * Oldest first, because the oldest is the stock that has been sitting longest.
 * Deliberately no filters and no paging: it is a list of things to do, and one
 * that hides its tail behind a page control is one that gets half done.
 */
function SettleList({
  rows,
  onSettle,
}: {
  rows: ConsignmentToSettle[]
  onSettle: (row: DeliveryRow) => void
}) {
  if (rows.length === 0) {
    return (
      <EmptyState>
        Nothing waiting to be settled. Consignment stock shows up here until it is sold or sent
        back.
      </EmptyState>
    )
  }

  const buildingUp = rows.reduce((total, row) => total + row.estimatedOwedCentavos, 0)

  return (
    <div className="grid gap-4">
      {/* The figure the Deliveries header cannot show, because the header
          reports what is OWED and this is not owed yet. Stated separately so
          "₱0.00 owed" stops reading as "nothing coming". */}
      {buildingUp > 0 && (
        <div className="rounded-card border border-line bg-surface-sunk px-4 py-3">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <span className="text-sm text-ink">Not owed yet, but building up</span>
            <span className="text-ink">
              ~<Money centavos={buildingUp} scale="strong" />
            </span>
          </div>
          <p className="mt-1 text-xs text-ink-subtle">
            Roughly what has sold since each consignment arrived. Nothing is owed until you settle
            with the supplier — this is only so the total does not surprise you.
          </p>
        </div>
      )}

      {rows.map((row) => (
        <div key={row.id} className="overflow-hidden rounded-card border border-line">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line bg-surface-sunk px-4 py-3">
            <span>
              <span className="text-sm font-medium text-ink">{row.supplierName}</span>
              <span className="ml-2 text-xs text-ink-subtle">
                arrived {shortDate(row.receivedAt)}
              </span>
            </span>
            <Button size="sm" variant="secondary" onClick={() => onSettle(row)}>
              Settle what sold
            </Button>
          </div>

          <table className="w-full text-sm">
            <thead className="text-left text-xs uppercase tracking-wide text-ink-muted">
              <tr>
                <th className="px-4 py-2 font-medium">Item</th>
                <th className="px-4 py-2 text-right font-medium">Arrived</th>
                <th className="px-4 py-2 text-right font-medium">Sold (about)</th>
                <th className="px-4 py-2 text-right font-medium">Still on the shelf</th>
                <th className="px-4 py-2 text-right font-medium">Worth (about)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {row.lines.map((line) => {
                const left = Math.max(
                  0,
                  line.quantity - line.quantitySettled - line.quantityReturned - line.estimatedSoldQuantity,
                )
                return (
                  <tr key={line.productId}>
                    <td className="px-4 py-2">
                      <div className="font-medium text-ink">{line.name}</div>
                      <div className="text-xs text-ink-subtle">{line.unit}</div>
                    </td>
                    <td className="px-4 py-2 text-right font-mono text-ink-muted">
                      {line.quantity}
                    </td>
                    {/* "about", every time it is shown. Stock is fungible and
                        this app has no lot tracking, so a sale cannot be
                        attributed to a particular delivery — see the server. */}
                    <td className="px-4 py-2 text-right font-mono text-ink">
                      {line.estimatedSoldQuantity > 0 ? `~${line.estimatedSoldQuantity}` : '—'}
                    </td>
                    <td className="px-4 py-2 text-right font-mono text-ink-muted">{left}</td>
                    <td className="px-4 py-2 text-right text-ink-muted">
                      {line.estimatedSoldQuantity > 0 ? (
                        <>
                          ~
                          <Money
                            centavos={lineTotal(line.unitCostCentavos, line.estimatedSoldQuantity)}
                            scale="body"
                          />
                        </>
                      ) : (
                        '—'
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      ))}
    </div>
  )
}

function shortDate(date: Date): string {
  return new Intl.DateTimeFormat('en-PH', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(date)
}

/**
 * What the shop bought, and what it still owes for it.
 *
 * The counterpart to the Book. That screen answers "who owes me"; this one
 * answers "who do I owe" — a question the app could not previously ask,
 * because stock only ever left and arrived by somebody editing a number.
 */
export function DeliveriesScreen({
  deliveries,
  suppliers,
  payableCentavos,
  filters,
  toSettle,
  tab,
}: {
  deliveries: DeliveryRow[]
  suppliers: SupplierOption[]
  payableCentavos: number
  filters: { supplier?: string; unpaid?: string }
  /** Consignments with stock still unaccounted for. Unpaged — see the server. */
  toSettle: ConsignmentToSettle[]
  tab: 'list' | 'settle'
}) {
  const router = useRouter()
  const pathname = usePathname()
  const [pending, startTransition] = useTransition()
  // Voiding a delivery unwinds stock and what is owed to a supplier.
  const { asking, guard, confirmed, cancel } = useGuardedAction()

  const [suppliersOpen, setSuppliersOpen] = useState(false)
  const [paying, setPaying] = useState<DeliveryRow | null>(null)
  const [voiding, setVoiding] = useState<DeliveryRow | null>(null)
  const [error, setError] = useState<string | null>(null)

  const [payAmount, setPayAmount] = useState('')
  const [voidReason, setVoidReason] = useState('')

  function apply(patch: { supplier?: string; unpaid?: string }) {
    const params = new URLSearchParams()
    const supplier = patch.supplier ?? filters.supplier ?? ''
    const unpaid = patch.unpaid ?? filters.unpaid ?? ''
    if (supplier) params.set('supplier', supplier)
    if (unpaid === '1') params.set('unpaid', '1')
    params.set('page', '1')
    router.push(`${pathname}?${params.toString()}`)
  }

  function submitPayment() {
    if (!paying) return
    setError(null)
    const centavos = parsePesoInput(payAmount)
    if (centavos === null || centavos <= 0) {
      setError('Enter an amount greater than zero.')
      return
    }
    startTransition(async () => {
      const result = await payDelivery(paying.id, centavos)
      if (!result.ok) {
        setError(result.error)
        return
      }
      setPaying(null)
      setPayAmount('')
      router.refresh()
    })
  }

  function submitVoid() {
    if (!voiding) return
    setError(null)
    startTransition(async () => {
      const id = voiding.id
      await guard(
        () => voidDelivery(id, voidReason),
        (result) => {
          if (!result.ok) {
            setError(result.error ?? 'Could not void the delivery.')
            return
          }
          setVoiding(null)
          setVoidReason('')
          router.refresh()
        },
      )
    })
  }

  const supplierOptions = [
    { value: '', label: 'All suppliers' },
    ...suppliers.map((supplier) => ({ value: String(supplier.id), label: supplier.name })),
  ]

  return (
    <>
      {asking && (
        <PasswordPrompt
          what="void this delivery"
          onConfirmed={() => startTransition(confirmed)}
          onCancel={cancel}
        />
      )}
      {/* Leads the page, mirroring "Total utang" on the Book. Never `money-in`:
          this is money the shop OWES, not cash that has arrived. */}
      <div className="mb-6 rounded-card border border-line-strong bg-surface-raised px-5 py-4 shadow-panel">
        <TapeRow>
          <TapeCell>
            <span className="text-xs font-semibold uppercase tracking-[0.14em] text-ink-muted">
              Owed to suppliers
            </span>
          </TapeCell>
          <TapeCell align="end">
            <Money centavos={payableCentavos} tone="owed" scale="hero" />
          </TapeCell>
        </TapeRow>
      </div>

      {/* `tab` comes from `?tab=` via page.tsx, not local state, so the URL is
          shareable and Back works — the same shape `/book` uses. The count
          rides on the label because it is the whole point of the tab: she can
          see there is settling to do without going to look. */}
      <Tabs
        ariaLabel="Deliveries view"
        tabs={[
          { value: 'list', label: 'Deliveries' },
          {
            value: 'settle',
            label: toSettle.length > 0 ? `To settle (${toSettle.length})` : 'To settle',
          },
        ]}
        value={tab}
        onValueChange={(value) =>
          router.push(value === 'settle' ? `${ROUTES.deliveries}?tab=settle` : ROUTES.deliveries)
        }
        className="mb-6"
      />

      {tab === 'settle' ? (
        <SettleList rows={toSettle} onSettle={(row) => router.push(settleDelivery(row.id))} />
      ) : (
      <>
      <div className="mb-4 flex flex-wrap items-end justify-between gap-4">
        <div className="flex flex-wrap gap-x-8 gap-y-4">
          <FilterChips
            label="Supplier"
            ariaLabel="Filter by supplier"
            options={supplierOptions}
            value={filters.supplier ?? ''}
            onChange={(value) => apply({ supplier: value })}
          />
          <FilterChips
            label="Settled"
            ariaLabel="Filter by whether it is paid"
            options={[
              { value: '', label: 'All' },
              { value: '1', label: 'Still owing' },
            ]}
            value={filters.unpaid === '1' ? '1' : ''}
            onChange={(value) => apply({ unpaid: value })}
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Button variant="secondary" onClick={() => setSuppliersOpen(true)}>
            Suppliers
          </Button>
          {/* Goes to a PAGE now, not a dialog. A delivery can run to a dozen
              lines and deserves the width — squeezed into a dialog the product
              picker was six characters wide and every option read "Ch…". */}
          <Button
            variant="primary"
            onClick={() => router.push(NEW_DELIVERY)}
            disabled={suppliers.length === 0}
          >
            Record delivery
          </Button>
        </div>
      </div>

      {error && !paying && !voiding && <FormError className="mb-4">{error}</FormError>}

      {suppliers.length === 0 && (
        <Card className="mb-4">
          <p className="text-sm text-ink-muted">
            Add a supplier first — a delivery has to have come from somewhere.
          </p>
        </Card>
      )}

      {deliveries.length === 0 ? (
        <EmptyState>
          {filters.supplier || filters.unpaid
            ? 'No deliveries match these filters.'
            : 'Nothing received yet.'}
        </EmptyState>
      ) : (
        <div className="overflow-x-auto rounded-card border border-line bg-surface">
          <table className="w-full text-sm">
            <thead className="bg-surface-sunk text-left text-xs uppercase tracking-wide text-ink-muted">
              <tr>
                <th className="px-3 py-2 font-medium">Received</th>
                <th className="px-3 py-2 font-medium">Supplier</th>
                <th className="px-3 py-2 font-medium">Reference</th>
                <th className="px-3 py-2 text-right font-medium">Items</th>
                <th className="px-3 py-2 text-right font-medium">Cost</th>
                <th className="px-3 py-2 text-right font-medium">Still owing</th>
                <th className="w-10 px-3 py-2" />
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {deliveries.map((delivery) => (
                <tr key={delivery.id} className={delivery.isVoided ? 'opacity-60' : undefined}>
                  <td className="px-3 py-2 tabular-nums">{shortDate(delivery.receivedAt)}</td>
                  <td className="px-3 py-2">
                    <span className="font-medium text-ink">{delivery.supplierName}</span>
                    {delivery.terms === 'CONSIGNMENT' && (
                      <span className="ml-2 align-middle">
                        {/* Neutral: consignment is a fact about the terms, not
                            a warning and not a settled state. */}
                        <Badge tone="neutral">Consignment</Badge>
                      </span>
                    )}
                    {delivery.isVoided && (
                      <span className="ml-2 align-middle">
                        {/* `muted`, not `paid`: this record is dead, not
                            settled. */}
                        <Badge tone="muted">Voided</Badge>
                      </span>
                    )}
                  </td>
                  <td className="px-3 py-2 text-ink-muted">{delivery.reference || '—'}</td>
                  <td className="px-3 py-2 text-right tabular-nums text-ink-muted">
                    {delivery.lineCount}
                  </td>
                  <td className="px-3 py-2 text-right">
                    {/* Neutral. Money leaving is not `money-in`, and it is not
                        a debt on its own either — the debt is the column
                        beside it. */}
                    <Money centavos={delivery.totalCostCentavos} scale="body" />
                  </td>
                  <td className="px-3 py-2 text-right">
                    {delivery.outstandingCentavos > 0 ? (
                      <Money centavos={delivery.outstandingCentavos} tone="owed" scale="body" />
                    ) : delivery.unaccountedCentavos > 0 ? (
                      // Owes nothing YET, which is not the same as settled. A
                      // green "Settled" chip here would say the consignment
                      // was finished when most of it is still on the shelf.
                      //
                      // The DASH is what this column is for, and it has to come
                      // first: the heading says "Still owing", and printing
                      // ₱230,500 under it read as a debt — directly
                      // contradicting the ₱0.00 in "Owed to suppliers" at the
                      // top of the same screen, which was right. The unsold
                      // value is real and worth showing, but it is the
                      // supplier's stock on our shelf, not money we owe, so it
                      // sits underneath as a caption that says so.
                      <span className="block">
                        <span className="block text-ink-subtle">—</span>
                        <span className="block text-xs text-ink-subtle">
                          <Money centavos={delivery.unaccountedCentavos} scale="body" /> unsold,
                          still theirs
                        </span>
                      </span>
                    ) : (
                      <Badge tone="paid">Settled</Badge>
                    )}
                  </td>
                  <td className="px-3 py-2">
                    {!delivery.isVoided && (
                      <RowActionMenu
                        ariaLabel={`Actions for delivery ${delivery.id}`}
                        items={[
                          {
                            // First, because it is the harmless one and the
                            // one asked for while the driver is still standing
                            // there. Everything below it changes money.
                            label: 'Delivery receipt',
                            onSelect: () => router.push(deliveryDocument(delivery.id)),
                          },
                          {
                            label:
                              delivery.terms === 'CONSIGNMENT'
                                ? 'Settle what sold'
                                : 'Return stock',
                            onSelect: () => router.push(settleDelivery(delivery.id)),
                          },
                          ...(delivery.outstandingCentavos > 0
                            ? [
                                {
                                  label: 'Record payment',
                                  onSelect: () => {
                                    setError(null)
                                    setPayAmount('')
                                    setPaying(delivery)
                                  },
                                },
                              ]
                            : []),
                          {
                            label: 'Void this delivery',
                            destructive: true,
                            onSelect: () => {
                              setError(null)
                              setVoidReason('')
                              setVoiding(delivery)
                            },
                          },
                        ]}
                      />
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      </>
      )}

      {suppliersOpen && (
        <SupplierDialog suppliers={suppliers} onClose={() => setSuppliersOpen(false)} />
      )}

      <Dialog
        open={paying !== null}
        onOpenChange={(open) => {
          if (!open) setPaying(null)
        }}
        title="Record a payment to the supplier"
        description={
          paying
            ? `${paying.supplierName} — delivery of ${shortDate(paying.receivedAt)}`
            : undefined
        }
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setPaying(null)}>
              Cancel
            </Button>
            {/* `success`: terminal and money-committing, like Save payment on
                the Book. */}
            <Button variant="success" onClick={submitPayment} disabled={pending}>
              {pending ? 'Saving…' : 'Save payment'}
            </Button>
          </div>
        }
      >
        {paying && (
          <div className="grid gap-4">
            <div className="flex items-baseline justify-between rounded-control bg-surface-sunk px-3 py-2 text-sm">
              <span className="text-ink-muted">Still owing</span>
              <Money centavos={paying.outstandingCentavos} tone="owed" />
            </div>
            <Field label="Amount">
              <Input
                inputMode="decimal"
                value={payAmount}
                onChange={(event) => setPayAmount(event.target.value)}
                placeholder="0.00"
                className="w-full tabular-nums"
                autoFocus
              />
            </Field>
            {error && <FormError>{error}</FormError>}
          </div>
        )}
      </Dialog>

      <Dialog
        open={voiding !== null}
        onOpenChange={(open) => {
          if (!open) setVoiding(null)
        }}
        title="Void this delivery"
        description="The stock it added comes back off, and the amount owed for it goes away."
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setVoiding(null)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={submitVoid} disabled={pending}>
              {pending ? 'Voiding…' : 'Yes, void it'}
            </Button>
          </div>
        }
      >
        <div className="grid gap-4">
          <Field label="Why is it being voided?">
            <Input
              value={voidReason}
              onChange={(event) => setVoidReason(event.target.value)}
              placeholder="e.g. Entered twice"
              className="w-full"
              autoFocus
            />
          </Field>
          <p className="text-xs text-ink-subtle">
            The record stays on this list, marked, with the reason on it. Nothing is deleted.
          </p>
          {error && <FormError>{error}</FormError>}
        </div>
      </Dialog>
    </>
  )
}
