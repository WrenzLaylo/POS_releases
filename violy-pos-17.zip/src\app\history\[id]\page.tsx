import Link from 'next/link'
import { notFound } from 'next/navigation'
import { getSaleReceipt } from '@/server/sales'
import { lineTotal } from '@/lib/money'
import { documentNumber, DOCUMENT_TITLES } from '@/lib/document-number'
import { ROUTES, saleReceipt } from '@/lib/routes'
import { saleStatus } from '@/lib/money-display'
import { Badge } from '@/components/ui/Badge'
import { Card } from '@/components/ui/Card'
import { Money } from '@/components/ui/Money'
import { PageHeader } from '@/components/ui/PageHeader'
import { SaleTabs } from './SaleTabs'

export const dynamic = 'force-dynamic'

/**
 * What a sale was: who, what, and how it was settled.
 *
 * Separate from the receipt on purpose. The receipt is a document — fixed
 * layout, store letterhead, meant for paper and for the customer. This is the
 * working view: the same facts arranged for whoever is looking something up,
 * with the actions that belong to a sale rather than to a piece of paper.
 * Clicking an order used to jump straight to the printable, which is the
 * wrong default for "what was this sale?".
 */
export default async function SalePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const saleId = Number(id)
  if (!Number.isInteger(saleId) || saleId <= 0) notFound()

  const sale = await getSaleReceipt(saleId)
  if (!sale) notFound()

  const subtotalCentavos = sale.items.reduce(
    (total, item) => total + lineTotal(item.priceAtSale, item.quantity),
    0,
  )
  // Against the GOODS, not against `totalAmount`. A delivery fee is part of
  // the total and comes off nothing — subtracting the whole total here would
  // report a ₱300 fee as ₱300 less discount, on both this screen and the
  // receipt beside it.
  const goodsCentavos = sale.totalAmount - sale.deliveryFeeCentavos
  const discountCentavos = subtotalCentavos - goodsCentavos
  const liveCharge = sale.ledgerEntry !== null && !sale.ledgerEntry.isVoided
  const kind = liveCharge ? 'SALES_INVOICE' : 'SALES_RECEIPT'
  const status = saleStatus({
    cashPaidCentavos: sale.cashPaidCentavos,
    totalCentavos: sale.totalAmount,
    hasLiveCharge: liveCharge,
    isVoided: sale.isVoided,
  })
  const utangCentavos = Math.max(0, sale.totalAmount - sale.cashPaidCentavos)

  return (
    <PageHeader
      title={`Sale ${documentNumber(kind, sale.id, sale.createdAt)}`}
      actions={
        <Link
          href={ROUTES.history}
          className="text-sm font-medium text-ink-muted hover:text-ink"
        >
          ← Back to history
        </Link>
      }
    >
      <SaleTabs saleId={sale.id} active="summary" hasDeliveryNote={sale.deliverAt !== null} />

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <h2 className="mb-3 text-base font-semibold">Items</h2>
          <table className="w-full text-sm">
            <thead className="border-b border-line text-left text-xs uppercase tracking-wide text-ink-muted">
              <tr>
                <th className="py-2 pr-3 font-medium">Item</th>
                <th className="px-3 py-2 text-right font-medium">Qty</th>
                <th className="px-3 py-2 text-right font-medium">Unit price</th>
                <th className="py-2 pl-3 text-right font-medium">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {sale.items.map((item) => (
                <tr key={item.id}>
                  <td className="py-2 pr-3">
                    <span className="font-medium text-ink">{item.product.name}</span>{' '}
                    <span className="text-xs text-ink-subtle">{item.product.unit}</span>
                  </td>
                  <td className="px-3 py-2 text-right font-mono tabular-nums">{item.quantity}</td>
                  <td className="px-3 py-2 text-right">
                    <Money centavos={item.priceAtSale} scale="body" />
                  </td>
                  <td className="py-2 pl-3 text-right">
                    <Money
                      centavos={lineTotal(item.priceAtSale - item.discountAtSale, item.quantity)}
                      scale="body"
                      className="font-semibold"
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>

        <div className="grid gap-4">
          <Card>
            <h2 className="mb-3 text-base font-semibold">Payment</h2>
            <dl className="grid gap-2 text-sm">
              <div className="flex items-baseline justify-between">
                <dt className="text-ink-muted">Customer</dt>
                <dd className="font-medium text-ink">
                  {sale.customer?.name ?? 'Walk-in customer'}
                </dd>
              </div>
              <div className="flex items-baseline justify-between">
                <dt className="text-ink-muted">When</dt>
                <dd>{sale.createdAt.toLocaleString('en-PH', { dateStyle: 'medium', timeStyle: 'short' })}</dd>
              </div>
              <div className="flex items-baseline justify-between">
                <dt className="text-ink-muted">Status</dt>
                <dd>
                  {status === 'cash' && <Badge tone="paid">Cash sale</Badge>}
                  {status === 'credit' && <Badge tone="owed">Full credit</Badge>}
                  {status === 'partial' && <Badge tone="owed">Partial</Badge>}
                  {status === 'charge-voided' && <Badge tone="neutral">Charge voided</Badge>}
                  {status === 'voided' && <Badge tone="muted">Sale voided</Badge>}
                </dd>
              </div>

              {sale.deliverAt && (
                <div className="flex items-baseline justify-between gap-3 border-t border-line pt-2">
                  <dt className="text-ink-muted">Deliver</dt>
                  <dd className="text-right font-medium text-ink">
                    {sale.deliverAt.toLocaleDateString('en-PH', { dateStyle: 'medium' })}
                    {sale.deliverTo && `, ${sale.deliverTo}`}
                  </dd>
                </div>
              )}

              {discountCentavos > 0 && (
                <div className="flex items-baseline justify-between border-t border-line pt-2">
                  <dt className="text-ink-muted">Discount</dt>
                  <dd>
                    −<Money centavos={discountCentavos} scale="body" />
                  </dd>
                </div>
              )}
              {sale.deliveryFeeCentavos > 0 && (
                <div className="flex items-baseline justify-between">
                  <dt className="text-ink-muted">Delivery fee</dt>
                  <dd>
                    <Money centavos={sale.deliveryFeeCentavos} scale="body" />
                  </dd>
                </div>
              )}
              <div className="flex items-baseline justify-between border-t border-line pt-2">
                <dt className="font-semibold text-ink">Total</dt>
                <dd>
                  <Money centavos={sale.totalAmount} scale="strong" />
                </dd>
              </div>
              <div className="flex items-baseline justify-between">
                <dt className="text-ink-muted">Cash kept</dt>
                {/* `in` is only for cash that actually arrived. */}
                <dd>
                  <Money centavos={sale.cashPaidCentavos} scale="body" tone="in" />
                </dd>
              </div>
              {utangCentavos > 0 && (
                <div className="flex items-baseline justify-between">
                  <dt className="text-ink-muted">Charged to account</dt>
                  <dd>
                    <Money centavos={utangCentavos} scale="body" tone="owed" />
                  </dd>
                </div>
              )}
              <div className="flex items-baseline justify-between">
                <dt className="text-ink-muted">Change</dt>
                <dd>
                  <Money centavos={sale.changeCentavos} scale="body" />
                </dd>
              </div>
            </dl>
          </Card>

          {sale.isVoided && (
            <Card variant="danger">
              <p className="text-sm font-semibold text-owed">This sale was voided.</p>
              {sale.voidReason && (
                <p className="mt-1 text-sm text-owed">Reason: {sale.voidReason}</p>
              )}
            </Card>
          )}

          <Link
            href={saleReceipt(sale.id)}
            className="inline-flex h-10 items-center justify-center rounded-control border border-line-strong bg-surface-raised px-4 text-sm font-medium text-ink transition-colors duration-150 hover:border-accent hover:bg-accent-soft"
          >
            Open the printable {DOCUMENT_TITLES[kind].toLowerCase()}
          </Link>
        </div>
      </div>
    </PageHeader>
  )
}
