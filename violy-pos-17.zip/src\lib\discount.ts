/**
 * What comes off an order, and in what order.
 *
 * Every discount in this app is now typed at the counter, on a line or against
 * the whole order. There is no standing per-customer rate: a customer used to
 * be able to carry one, and the counter then had to say whether what she typed
 * came on top of it or instead of it — a question about something she could
 * not always see, since the control that asked it read six legacy columns the
 * Discount screen had stopped writing. One place for a discount to come from
 * removes that whole class of problem instead of fixing one instance of it.
 *
 * Sales made while standing rates existed keep theirs: `SaleItem.discountAtSale`
 * and `Sale.customerDiscountCentavos` are snapshots, so every old receipt
 * reprints exactly as it was charged. Nothing here recomputes them.
 *
 * The pipeline, in the order the design fixed:
 *
 *   1. a per-unit figure typed against a line, off each unit of it
 *   2. a whole-line figure typed against a line, off that line once
 *   3. the ad-hoc order discount, off what remains
 *
 * A percentage at step 3 is therefore taken against the already-discounted
 * figure, not the list subtotal. Arbitrary in principle, fixed in practice —
 * otherwise "10% off" means two different pesos depending which code path
 * computed it.
 */

import { lineTotal } from './money'

export type DiscountKind = 'AMOUNT' | 'PERCENT'

/** 100.00%. Nothing may discount more than the thing costs. */
export const MAX_BPS = 10_000

export function isDiscountKind(value: string): value is DiscountKind {
  return value === 'AMOUNT' || value === 'PERCENT'
}

export type OrderDiscount = {
  kind: DiscountKind
  amountCentavos: number
  bps: number
}

export const NO_ORDER_DISCOUNT: OrderDiscount = {
  kind: 'AMOUNT',
  amountCentavos: 0,
  bps: 0,
}

/** The ad-hoc discount as it arrives from the browser, before validation. */
export type OrderDiscountInput = {
  kind: string
  amountCentavos: number
  bps: number
}

/**
 * The write boundary for an ad-hoc discount. `kind` is validated at runtime
 * rather than trusted from the type, for the same reason `isLedgerEntryType`
 * exists: this crosses a Server Action boundary, so the compiler's word for
 * what the client sent is not evidence.
 *
 * A missing discount is not an error — it is the ordinary case.
 */
export function validateOrderDiscount(
  input: OrderDiscountInput | null | undefined,
): { ok: true; value: OrderDiscount } | { ok: false; error: string } {
  if (!input) return { ok: true, value: NO_ORDER_DISCOUNT }

  if (!isDiscountKind(input.kind)) {
    return { ok: false, error: 'Unrecognised discount type.' }
  }
  if (!Number.isInteger(input.amountCentavos) || input.amountCentavos < 0) {
    return { ok: false, error: 'The discount must be a whole, non-negative amount.' }
  }
  if (!Number.isInteger(input.bps) || input.bps < 0 || input.bps > MAX_BPS) {
    return { ok: false, error: 'The discount percentage must be between 0 and 100.' }
  }

  return {
    ok: true,
    value: {
      kind: input.kind,
      amountCentavos: input.amountCentavos,
      bps: input.bps,
    },
  }
}

/**
 * The write boundary for a discount typed against one line.
 *
 * Checked here rather than trusted, for the same reason `validateOrderDiscount`
 * exists: this crosses a Server Action boundary, so the compiler's word for
 * what the client sent is not evidence. Absent is the ordinary case, not an
 * error.
 *
 * Returns an error message, or null when the value is acceptable.
 */
export function validateLineDiscount(value: number | undefined): string | null {
  if (value === undefined) return null
  if (!Number.isInteger(value) || value < 0) {
    return 'A line discount must be a whole, non-negative amount.'
  }
  return null
}

/**
 * Combines the line discounts of two rows for the same product.
 *
 * The counter cannot produce a duplicate — quantities are held in a Map keyed
 * by product id — so this only fires for a caller assembling the payload
 * itself. The larger of the two wins: deterministic, and it errs toward the
 * customer rather than quietly discarding a figure somebody typed.
 */
export function mergeLineDiscounts(a: number | undefined, b: number | undefined): number {
  return Math.max(a ?? 0, b ?? 0)
}

/** Whether a typed line discount is per unit or for the whole line. */
export type LineDiscountMode = 'EACH' | 'ONCE'

export function isLineDiscountMode(value: string): value is LineDiscountMode {
  return value === 'EACH' || value === 'ONCE'
}

export type DiscountLineInput = {
  productId: number
  quantity: number
  priceCentavos: number
  /**
   * A discount typed at the counter against THIS line, in centavos. Absent or
   * zero on an ordinary line. `manualDiscountMode` says whether the figure is
   * meant per unit or for the line as a whole.
   */
  manualDiscountPerUnitCentavos?: number
  manualDiscountMode?: LineDiscountMode
}

/** The typed figure, when it is meant PER UNIT. Zero when it is a once. */
export function manualPerUnitOf(line: {
  manualDiscountPerUnitCentavos?: number
  manualDiscountMode?: LineDiscountMode
}): number {
  const typed = line.manualDiscountPerUnitCentavos ?? 0
  if (typed <= 0) return 0
  return line.manualDiscountMode === 'ONCE' ? 0 : typed
}

/** The typed figure, when it is meant for the WHOLE line. Zero otherwise. */
export function manualPerLineOf(line: {
  manualDiscountPerUnitCentavos?: number
  manualDiscountMode?: LineDiscountMode
}): number {
  const typed = line.manualDiscountPerUnitCentavos ?? 0
  if (typed <= 0) return 0
  return line.manualDiscountMode === 'ONCE' ? typed : 0
}

export type DiscountedLine = DiscountLineInput & {
  /** The per-unit discount actually granted; stored as `discountAtSale`. */
  discountPerUnitCentavos: number
  /** A discount against the whole line; stored as `lineDiscountAtSale`. Never
   *  divided, so "₱500 off this line" is exactly ₱500. */
  lineDiscountCentavos: number
  lineTotalCentavos: number
}

export type OrderTotals = {
  lines: DiscountedLine[]
  /** List price × quantity, summed, before any discount at all. */
  subtotalCentavos: number
  /** Everything taken off the lines, summed — per-unit and whole-line both. */
  lineDiscountCentavos: number
  /** The ad-hoc discount typed against the order as a whole. */
  orderDiscountCentavos: number
  /** Every discount added together — what a receipt prints on one line. */
  totalDiscountCentavos: number
  /** What is actually owed. Never negative. */
  totalCentavos: number
}

/** Rounds half away from zero, like every other money conversion here. */
export function percentOf(centavos: number, bps: number): number {
  return Math.round((centavos * bps) / MAX_BPS)
}

/** Whether a discount would actually take anything off. */
export function hasOrderDiscount(discount: OrderDiscount | null): boolean {
  if (!discount) return false
  return discount.kind === 'PERCENT' ? discount.bps > 0 : discount.amountCentavos > 0
}

export function computeOrderTotals(input: {
  lines: readonly DiscountLineInput[]
  order?: OrderDiscount | null
}): OrderTotals {
  const order = input.order ?? null

  const lines: DiscountedLine[] = input.lines.map((line) => {
    const discountPerUnitCentavos = Math.min(manualPerUnitOf(line), line.priceCentavos)
    const afterUnits = lineTotal(line.priceCentavos - discountPerUnitCentavos, line.quantity)
    // Floored at what the line is worth: a whole-line discount can make it
    // free, never negative — the rule every discount here follows.
    const lineDiscountCentavos = Math.min(manualPerLineOf(line), afterUnits)
    return {
      ...line,
      discountPerUnitCentavos,
      lineDiscountCentavos,
      lineTotalCentavos: afterUnits - lineDiscountCentavos,
    }
  })

  const subtotalCentavos = input.lines.reduce(
    (total, line) => total + lineTotal(line.priceCentavos, line.quantity),
    0,
  )
  const afterLines = lines.reduce((total, line) => total + line.lineTotalCentavos, 0)
  const lineDiscountCentavos = subtotalCentavos - afterLines

  const orderDiscountCentavos =
    order && hasOrderDiscount(order)
      ? clamp(
          order.kind === 'PERCENT' ? percentOf(afterLines, order.bps) : order.amountCentavos,
          afterLines,
        )
      : 0

  return {
    lines,
    subtotalCentavos,
    lineDiscountCentavos,
    orderDiscountCentavos,
    totalDiscountCentavos: lineDiscountCentavos + orderDiscountCentavos,
    totalCentavos: afterLines - orderDiscountCentavos,
  }
}

/** Keeps a discount inside [0, ceiling]. Nothing takes off more than is there. */
function clamp(value: number, ceiling: number): number {
  return Math.min(Math.max(0, value), Math.max(0, ceiling))
}
