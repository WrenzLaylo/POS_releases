import { copyFile, mkdir, readdir, rm, stat } from 'node:fs/promises'
import path from 'node:path'
import { uploadDirectory } from '@/server/uploads'
import { backupFileName, backupTakenAt, selectBackupsToDelete, sortNewestFirst } from './backup-policy'

/**
 * Taking a backup, and reporting on the ones already taken.
 *
 * Deliberately NOT a `'use server'` file and deliberately free of Prisma. Three
 * different callers need this and only one of them is a web request: the button
 * in Settings, the timer in the desktop shell, and `scripts/backup-db.ts`, which
 * the updater runs before it touches anything. That last one has to work when
 * the server is stopped, which is exactly when the updater runs it.
 */

export type BackupFile = {
  name: string
  takenAt: Date
  bytes: number
}

export type BackupStatus = {
  folder: string
  files: BackupFile[]
  /** Bytes across every backup this app wrote. */
  totalBytes: number
  /** Null when nothing has ever been backed up. */
  lastTakenAt: Date | null
}

export type BackupResult =
  | { kind: 'created'; name: string; bytes: number; takenAt: Date; deleted: string[] }
  | { kind: 'skipped'; lastTakenAt: Date }

/** The checkout the app is installed in. */
function projectRoot(root?: string): string {
  return root ?? process.cwd()
}

export function databaseFile(root?: string): string {
  // DATABASE_URL is `file:./dev.db`, resolved by Prisma against the schema's
  // own directory rather than the working directory — so the path is built the
  // same way here instead of against cwd, which would be the project root and
  // would miss by one folder.
  const url = process.env.DATABASE_URL ?? 'file:./dev.db'
  const relative = url.startsWith('file:') ? url.slice('file:'.length) : url
  return path.resolve(projectRoot(root), 'prisma', relative)
}

export function backupFolder(root?: string): string {
  return path.join(projectRoot(root), 'backups')
}

/**
 * Copies the database in a way that survives being run mid-sale.
 *
 * `fs.copyFile` is not good enough. SQLite writes a page at a time, so copying
 * the file while a transaction is part-written yields a snapshot of a database
 * mid-edit, and the rollback journal that would repair it is a separate file
 * the copy does not include. The result looks like a backup and refuses to open
 * when it is finally needed. SQLite's own online backup API exists for this: it
 * reads under a shared lock and restarts if a writer intervenes, so what lands
 * on disk is always a consistent database.
 *
 * The plain copy remains as a fallback for a Node too old to have `node:sqlite`
 * — a stale-risk backup being better than none — and says so to the caller.
 */
async function snapshot(source: string, destination: string): Promise<'sqlite' | 'copy'> {
  try {
    const { DatabaseSync, backup } = await import('node:sqlite')
    const db = new DatabaseSync(source, { readOnly: true })
    try {
      await backup(db, destination)
    } finally {
      db.close()
    }
    return 'sqlite'
  } catch {
    await copyFile(source, destination)
    return 'copy'
  }
}

/**
 * Copies product photos alongside the database.
 *
 * The database stores a photo's PATH, not the photo, so a backup of the .db
 * alone restores forty products pointing at forty files that are not there.
 * Settings calls a backup "a complete, restorable copy of everything", and this
 * is what makes that sentence true.
 *
 * A mirror rather than a snapshot per backup: upload names are v4 UUIDs and a
 * file is never rewritten under the same name, so a name that is already in the
 * mirror is already the right bytes. That makes this cheap enough to run on
 * every backup, and it means the mirror accumulates rather than following the
 * pruning rules — a photo whose product was archived last month is still there
 * for a restore that goes back that far.
 */
async function mirrorUploads(root: string, folder: string): Promise<void> {
  const source = uploadDirectory(root)

  let names: string[]
  try {
    names = await readdir(source)
  } catch {
    return // No photos have ever been uploaded. Nothing to mirror.
  }
  if (names.length === 0) return

  const destination = path.join(folder, 'uploads')
  await mkdir(destination, { recursive: true })

  const existing = new Set(await readdir(destination).catch(() => []))
  for (const name of names) {
    if (existing.has(name)) continue
    try {
      await copyFile(path.join(source, name), path.join(destination, name))
    } catch {
      // One unreadable photo must not fail the backup of the ledger.
    }
  }
}

async function listFiles(folder: string): Promise<BackupFile[]> {
  let names: string[]
  try {
    names = await readdir(folder)
  } catch {
    return []
  }

  const files: BackupFile[] = []
  for (const name of sortNewestFirst(names)) {
    try {
      const info = await stat(path.join(folder, name))
      files.push({ name, takenAt: backupTakenAt(name) as Date, bytes: info.size })
    } catch {
      // Vanished between the listing and the stat. Nothing to report about it.
    }
  }
  return files
}

export async function getBackupStatus(root?: string): Promise<BackupStatus> {
  const folder = backupFolder(root)
  const files = await listFiles(folder)
  return {
    folder,
    files,
    totalBytes: files.reduce((total, file) => total + file.bytes, 0),
    lastTakenAt: files[0]?.takenAt ?? null,
  }
}

/**
 * Writes a backup, then prunes to the policy.
 *
 * Pruning runs after the new file is on disk and never before, so a failed
 * snapshot cannot leave the folder emptier than it found it. The order matters
 * more than it looks: the whole point of the folder is that it is the copy of
 * record when the live database is gone.
 *
 * `skipIfNewerThanMs` is what makes automation safe to run often — the timer
 * asks every so often and is told "there is already a recent one", so the app
 * being opened and closed five times in a morning does not produce five
 * backups.
 */
export async function createBackup(
  options: { root?: string; skipIfNewerThanMs?: number; now?: Date } = {},
): Promise<BackupResult> {
  const root = projectRoot(options.root)
  const now = options.now ?? new Date()
  const source = databaseFile(root)
  const folder = backupFolder(root)

  // Fails loudly rather than writing an empty file: no database is a real
  // problem and must not be reported as a successful backup.
  await stat(source)

  if (options.skipIfNewerThanMs !== undefined) {
    const existing = await listFiles(folder)
    const last = existing[0]?.takenAt
    if (last && now.getTime() - last.getTime() < options.skipIfNewerThanMs) {
      return { kind: 'skipped', lastTakenAt: last }
    }
  }

  await mkdir(folder, { recursive: true })

  const name = backupFileName(now)
  const destination = path.join(folder, name)
  await snapshot(source, destination)
  const info = await stat(destination)

  await mirrorUploads(root, folder)

  const deleted: string[] = []
  for (const old of selectBackupsToDelete(await readdir(folder), now)) {
    try {
      await rm(path.join(folder, old))
      deleted.push(old)
    } catch {
      // A locked or already-removed file is not worth failing a good backup
      // over. It will be offered for pruning again next time.
    }
  }

  return { kind: 'created', name, bytes: info.size, takenAt: now, deleted }
}
