/** All boundaries are local time — the store owner's clock, not UTC. */

export function startOfDay(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate())
}

export function startOfWeek(d: Date): Date {
  const start = startOfDay(d)
  // getDay(): 0 = Sunday. Shift so Monday is 0.
  const offset = (start.getDay() + 6) % 7
  start.setDate(start.getDate() - offset)
  return start
}

export function startOfMonth(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), 1)
}

export function addDays(d: Date, n: number): Date {
  const next = new Date(d)
  next.setDate(next.getDate() + n)
  return next
}

/**
 * Adds whole months, clamping to the last day of the target month.
 *
 * `setMonth` alone overflows: 31 January + 1 month becomes 3 March, because
 * 31 February does not exist and the Date rolls forward. On an instalment
 * schedule that error compounds — every later due date inherits the slip, and
 * a plan started on the 31st drifts a few days further out every month.
 *
 * Returns local midnight, like every other boundary in this file.
 */
export function addMonthsClamped(d: Date, months: number): Date {
  const day = d.getDate()
  // The 1st always exists in every month, so this arithmetic cannot overflow.
  const target = new Date(d.getFullYear(), d.getMonth() + months, 1)
  // Day 0 of the following month is the last day of the target month.
  const lastDay = new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate()
  target.setDate(Math.min(day, lastDay))
  return target
}

export function dayKey(d: Date): string {
  const month = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${d.getFullYear()}-${month}-${day}`
}

/** Strictly parses an HTML date input as local midnight. `new Date(raw)` is
 * deliberately avoided: date-only ISO strings are UTC and can become the
 * previous calendar day in the store's timezone. */
export function parseDayKey(raw: string): Date | null {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(raw)
  if (!match) return null

  const year = Number(match[1])
  const month = Number(match[2])
  const day = Number(match[3])
  const parsed = new Date(year, month - 1, day)

  if (
    parsed.getFullYear() !== year ||
    parsed.getMonth() !== month - 1 ||
    parsed.getDate() !== day
  ) {
    return null
  }
  return parsed
}

/**
 * When something recorded against a chosen DAY actually happened.
 *
 * A date picker gives a day, not a time, and the obvious reading — midnight —
 * is wrong for the commonest case of all. Every sale carries a real timestamp,
 * so a payment taken this afternoon and stamped 00:00 sorts BEFORE every sale
 * made this morning. The ledger is ordered by when things happened, so the
 * running balance then dives negative and reports the shop as owing the
 * customer money it never owed.
 *
 * That is not hypothetical: a customer's ledger showed four payments driving
 * the running balance to -₱14,450 before two same-day charges brought it back
 * to zero. The final balance was right; every line above it was a fiction.
 *
 * So: TODAY means now, and any other day means the start of it. A past date
 * genuinely has no time of day to recover — nobody records at what hour last
 * Tuesday's payment arrived — and the start of the day is the conventional
 * reading. Only today has a real answer, and today is when it matters, because
 * today is the only day that also has new charges landing on it.
 *
 * `now` is injectable so tests can pin the clock rather than racing midnight.
 */
export function occurredAtForDay(dayValue: string, now: Date = new Date()): Date | null {
  const day = parseDayKey(dayValue)
  if (!day) return null
  return dayKey(day) === dayKey(now) ? now : day
}
