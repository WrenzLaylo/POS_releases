import { listOrdersForDay } from '@/server/orders'
import { listSales } from '@/server/sales'
import { listDeliveryOrders } from '@/server/delivery-orders'
import { listCategories } from '@/server/products'
import { listCustomerBalances } from '@/server/ledger'
import { parsePage } from '@/lib/pagination'
import type { SaleKindFilter, SaleStatusFilter, SalesFilters } from '@/lib/types'
import { PageHeader } from '@/components/ui/PageHeader'
import { HistoryScreen } from './HistoryScreen'

export const dynamic = 'force-dynamic'

type Props = {
  searchParams: Promise<{
    page?: string
    from?: string
    to?: string
    customer?: string
    status?: string
    category?: string
    kind?: string
    /** Which tab to open on. The Dashboard panel and the bell link straight
     *  to the booked loads, and a tab held only in component state cannot be
     *  linked to. */
    view?: string
  }>
}

// Moved verbatim from `src/app/counter/page.tsx`, which itself carried these
// over from the old `/history` route before it was folded into the counter.
// `/history` is its own route again, and this parsing moved back with the
// three components that need it.
function parseCustomer(raw: string | undefined): SalesFilters['customerId'] {
  if (raw === 'walkin') return 'walkin'
  const id = Number(raw)
  return Number.isInteger(id) && id > 0 ? id : undefined
}

/** A brand, for "which sales included anything from this supplier". */
function parseCategory(raw: string | undefined): number | undefined {
  const id = Number(raw)
  return Number.isInteger(id) && id > 0 ? id : undefined
}

function parseStatus(raw: string | undefined): SaleStatusFilter {
  return raw === 'cash' || raw === 'credit' || raw === 'partial' || raw === 'voided' ? raw : 'all'
}

/** Counter sale or delivery order. A separate axis from status — see
 *  `SaleKindFilter`. */
function parseKind(raw: string | undefined): SaleKindFilter {
  return raw === 'counter' || raw === 'delivery' ? raw : 'all'
}

export default async function HistoryPage({ searchParams }: Props) {
  const params = await searchParams
  const filters: SalesFilters = {
    from: params.from,
    to: params.to,
    customerId: parseCustomer(params.customer),
    status: parseStatus(params.status),
    kind: parseKind(params.kind),
    categoryId: parseCategory(params.category),
  }

  const [today, sales, deliveries, balances, categories] = await Promise.all([
    listOrdersForDay(new Date()),
    listSales(filters, parsePage(params.page)),
    listDeliveryOrders(),
    listCustomerBalances(),
    listCategories(),
  ])

  // The dropdown must include archived customers: filtering to one still
  // works (the server honors `customer=<id>` regardless of archive status),
  // and without the archived option present the <select> falls back to
  // showing "All customers" even though the results are filtered — a lie.
  // listCustomers() (unarchived only, most-recently-ordered) would not do
  // here; listCustomerBalances() already returns everyone, so this reuses
  // it rather than adding a dedicated query. Sorted by name for the picker
  // — the balance-descending order that page wants is not useful here.
  const customers = [...balances]
    .sort((a, b) => a.name.localeCompare(b.name))
    .map((b) => ({ id: b.customerId, name: b.name, isArchived: b.isArchived }))

  return (
    <PageHeader title="History">
      <HistoryScreen
        todayOrders={today}
        sales={sales}
        deliveries={deliveries}
        customers={customers}
        categories={categories}
        view={params.view}
        filters={{
          from: params.from,
          to: params.to,
          customer: params.customer,
          status: params.status,
          category: params.category,
          kind: params.kind,
        }}
      />
    </PageHeader>
  )
}
