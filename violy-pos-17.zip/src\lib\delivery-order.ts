/**
 * The delivery half of a delivery order: where it is going, when, and what the
 * trip is charged at.
 *
 * Pure, and separate from `src/server/orders.ts`, for the same reason
 * `delivery.ts` is separate from `deliveries.ts`: the screen shows a total
 * while she types and the Server Action computes the authoritative one. One
 * implementation, called from both, or the figure she reads to the customer
 * and the figure that hits the books eventually disagree.
 *
 * Only the delivery half lives here. What is being sold — the lines, the
 * quantities, the discounts, the cash — is already checked by `createOrder`
 * and priced by `computeOrderTotals`, and duplicating either of those would be
 * exactly the second implementation this file exists to avoid.
 *
 * Note which way the date rule runs. An incoming delivery cannot be dated in
 * the future (`validateDelivery`) — sacks either arrived or they did not. An
 * outgoing one usually IS: it is Tuesday and the load goes out Saturday. The
 * two look symmetrical and are opposites.
 */

/** ₱100,000 to send a load out. Anything above is a misplaced decimal. */
export const MAX_DELIVERY_FEE_CENTAVOS = 10_000_000

/** How far ahead a load can be booked. A year out is a typo, not a plan. */
export const MAX_DAYS_AHEAD = 365

/** Long enough for "Sitio Pag-asa, Bagac", short enough to read on one line. */
export const MAX_DESTINATION_LENGTH = 120

export const MAX_ADDRESS_LENGTH = 400
export const MAX_INSTRUCTIONS_LENGTH = 400

/**
 * Everything about the delivery that is not the sale.
 *
 * `deliverTo` is the destination as she says it — "Bagac" — and is required,
 * because a delivery order with nowhere to go is a counter sale. `address` is
 * the receiver's full address for the printed note and is optional: plenty of
 * loads go to a place the driver already knows.
 */
export type DeliveryOrderDetails = {
  deliverAt: Date
  deliverTo: string
  address: string
  instructions: string
  /** In centavos, and zero is the ordinary case — plenty of trips are free. */
  feeCentavos: number
}

/**
 * What the customer owes: the priced order, plus the trip.
 *
 * The fee is added AFTER `computeOrderTotals` has done its work, and the order
 * of those two steps is the whole point of this function existing rather than
 * a `+` at each call site. A customer's standing "10% off" is off feeds. Fold
 * the fee in first and their discount quietly starts paying for the truck.
 */
export function deliveryOrderTotal(goodsCentavos: number, feeCentavos: number): number {
  return goodsCentavos + feeCentavos
}

/**
 * Every condition the delivery half has to meet, in one place.
 *
 * Returns the first problem as a sentence for the operator, or null. `now` is
 * injectable so tests can pin the clock rather than race it.
 */
export function validateDeliveryDetails(
  details: DeliveryOrderDetails,
  now: Date = new Date(),
): string | null {
  if (Number.isNaN(details.deliverAt.getTime())) {
    return 'That is not a date this app can read.'
  }

  // Measured from the END of today, so booking a load for this afternoon is
  // not counted as a day away and next year's date is still refused.
  const endOfToday = new Date(now)
  endOfToday.setHours(23, 59, 59, 999)
  const daysAhead = (details.deliverAt.getTime() - endOfToday.getTime()) / 86_400_000
  if (daysAhead > MAX_DAYS_AHEAD) {
    return 'That delivery date is more than a year away. Check it before saving.'
  }

  // Backdating is allowed and deliberate: a load that went out yesterday gets
  // typed up this morning, and refusing that would push her to date it today
  // — which puts a wrong date on the note somebody signed.

  if (details.deliverTo.trim() === '') {
    return 'Say where this is going.'
  }
  if (details.deliverTo.trim().length > MAX_DESTINATION_LENGTH) {
    return 'That destination is too long. Put the detail in the address instead.'
  }
  if (details.address.length > MAX_ADDRESS_LENGTH) {
    return 'That address is too long.'
  }
  if (details.instructions.length > MAX_INSTRUCTIONS_LENGTH) {
    return 'That note is too long.'
  }

  if (!Number.isInteger(details.feeCentavos) || details.feeCentavos < 0) {
    return 'The delivery fee must be zero or more.'
  }
  if (details.feeCentavos > MAX_DELIVERY_FEE_CENTAVOS) {
    return 'That delivery fee looks wrong. Check it before saving.'
  }

  return null
}
