import { listConsignmentsToSettle, listDeliveries, totalPayable } from '@/server/deliveries'
import { listSuppliers } from '@/server/suppliers'
import { suppliersWithOpeningBalance } from '@/server/supplier-opening'
import { dayKey } from '@/lib/dates'
import { parsePage } from '@/lib/pagination'
import { Pagination } from '@/components/Pagination'
import { PageHeader } from '@/components/ui/PageHeader'
import { DeliveriesScreen } from './DeliveriesScreen'

export const dynamic = 'force-dynamic'

type Props = {
  searchParams: Promise<{ page?: string; supplier?: string; unpaid?: string; tab?: string }>
}

export default async function DeliveriesPage({ searchParams }: Props) {
  const params = await searchParams
  const supplierId = Number(params.supplier)

  // Both tabs' data fetched together rather than branching on which is
  // active — the same choice `/book` makes for Customers/Bulk payments. The
  // open-consignment count is on the tab itself, so it has to be known even
  // while the other tab is showing.
  const [deliveries, suppliers, payable, toSettle, withDebt] = await Promise.all([
    listDeliveries(
      {
        supplierId: Number.isInteger(supplierId) && supplierId > 0 ? supplierId : undefined,
        unpaidOnly: params.unpaid === '1',
      },
      parsePage(params.page),
    ),
    listSuppliers(),
    totalPayable(),
    listConsignmentsToSettle(),
    suppliersWithOpeningBalance(),
  ])

  return (
    <PageHeader
      title="Deliveries"
      actions={<span className="text-sm text-ink-muted">{deliveries.total} recorded</span>}
    >
      <DeliveriesScreen
        deliveries={deliveries.rows}
        suppliers={suppliers}
        payableCentavos={payable}
        filters={{ supplier: params.supplier, unpaid: params.unpaid }}
        toSettle={toSettle}
        tab={params.tab === 'settle' ? 'settle' : 'list'}
        suppliersWithDebt={withDebt}
        todayKey={dayKey(new Date())}
      />

      {params.tab !== 'settle' && <Pagination
        page={deliveries.page}
        pageCount={deliveries.pageCount}
        params={{ supplier: params.supplier, unpaid: params.unpaid }}
      />}
    </PageHeader>
  )
}
