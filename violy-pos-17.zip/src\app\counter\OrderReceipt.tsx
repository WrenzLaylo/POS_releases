'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Money } from '@/components/ui/Money'
import { saleReceipt } from '@/lib/routes'
import type { ReceiptLine } from '@/lib/types'

type OrderReceiptProps = {
  saleId: number
  createdAt: string
  lines: ReceiptLine[]
  totalCentavos: number
  cashPaidCentavos: number
  cashTenderedCentavos: number
  changeCentavos: number
  onDismiss: () => void
} & (
  | {
      kind: 'customer'
      customerName: string
      chargedCentavos: number
      newBalanceCentavos: number
    }
  | {
      kind: 'walkin'
    }
)

export function OrderReceipt(props: OrderReceiptProps) {
  return (
    <Card variant="raised" className="animate-fade-in">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-sm font-medium uppercase tracking-wide text-accent">
            {props.kind === 'walkin' ? 'Cash sale saved' : 'Order saved'}
          </div>
          <div className="mt-1 text-xs text-ink-muted">
            Receipt #{props.saleId} ·{' '}
            {new Date(props.createdAt).toLocaleString('en-PH', {
              dateStyle: 'medium',
              timeStyle: 'short',
            })}
          </div>
        </div>
      </div>

      <div className="mt-2 truncate text-xl font-semibold text-ink">
        {props.kind === 'walkin' ? 'Walk-in' : props.customerName}
      </div>

      <ul className="mt-3 divide-y divide-line">
        {props.lines.map((line) => (
          <li key={line.productId} className="flex items-center justify-between py-2 text-sm text-ink">
            <span className="truncate pr-2">
              × {line.quantity} {line.name}
            </span>
            <Money centavos={line.lineTotalCentavos} />
          </li>
        ))}
      </ul>

      <div className="mt-4 space-y-2 border-t border-line pt-4">
        <div className="flex items-baseline justify-between">
          <span className="text-sm text-ink-muted">Total</span>
          <Money centavos={props.totalCentavos} scale="strong" />
        </div>
        <div className="flex items-baseline justify-between">
          <span className="text-sm text-ink-muted">Cash tendered</span>
          <Money centavos={props.cashTenderedCentavos} tone="neutral" />
        </div>
        <div className="flex items-baseline justify-between">
          <span className="text-sm text-ink-muted">Cash kept</span>
          <Money centavos={props.cashPaidCentavos} tone="in" />
        </div>
        {props.kind === 'customer' && (
          <>
            <div className="flex items-baseline justify-between">
              <span className="text-sm text-ink-muted">Added to credit</span>
              <Money
                centavos={props.chargedCentavos}
                tone={props.chargedCentavos > 0 ? 'owed' : 'zero'}
              />
            </div>
            <div className="flex items-baseline justify-between">
              <span className="text-sm text-ink-muted">New balance</span>
              <Money centavos={props.newBalanceCentavos} tone="balance" scale="strong" />
            </div>
          </>
        )}
        <div className="flex items-baseline justify-between">
          <span className="text-sm text-ink-muted">Change due</span>
          <Money centavos={props.changeCentavos} tone="neutral" />
        </div>
      </div>

      <div className="mt-4 grid gap-2">
        <Link
          href={saleReceipt(props.saleId)}
          className="inline-flex h-10 items-center justify-center rounded-control bg-accent px-4 text-sm font-medium text-canvas shadow-panel hover:bg-accent-strong"
        >
          View or print receipt
        </Link>
        <Button variant="secondary" size="wide" className="w-full" onClick={props.onDismiss}>
          Start next order
        </Button>
      </div>
    </Card>
  )
}
