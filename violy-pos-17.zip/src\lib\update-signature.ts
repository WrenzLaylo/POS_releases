import { createPublicKey, verify } from 'node:crypto'
import { UPDATE_PUBLIC_KEY } from './update-public-key'

/**
 * Verifying that a release manifest came from us.
 *
 * SEPARATE from `update-info.ts` on purpose, and this is load-bearing rather
 * than tidiness: that module also exports `updateHeadline`, which
 * `src/app/settings/UpdatePanel.tsx` imports — and that file is `'use client'`.
 * Putting `node:crypto` beside it invites the bundler to follow it into the
 * browser build, which fails in a way that names the bundler rather than the
 * cause. Nothing here may be imported by a client component.
 *
 * WHAT THIS ADDS OVER THE CHECKSUM, which stays exactly where it is:
 *
 * The SHA-256 in the manifest proves the zip arrived intact. It says nothing
 * about who published it, because one pipeline writes both the zip and its
 * checksum — anybody who can push to the releases repository can replace the
 * pair and the laptop is satisfied. The signature is made with a key held only
 * on the developer's machine, so publishing access alone cannot ship code into
 * the shop. Two different failures, two different checks; neither replaces the
 * other.
 */

/** The exact bytes that get signed and verified. */
export type SignedFields = {
  build: number
  version: string
  zipUrl: string
  sha256: string
}

/**
 * The one canonical form, used by the signer and the verifier alike.
 *
 * Both sides MUST call this rather than assembling their own string. Two
 * implementations that differ by a separator produce a signature that never
 * verifies, and the symptom — everything rejected — looks exactly like a wrong
 * key, which is a long way from the cause.
 *
 * `notes` is deliberately excluded. They are prose for the operator and get
 * reworded; signing them would mean a typo fix required re-signing a release
 * that is otherwise byte-identical. Nothing about the notes can change what
 * gets downloaded or whether it is trusted — the four fields here decide all
 * of that.
 */
export function canonicalManifest(fields: SignedFields): string {
  const NEWLINE = String.fromCharCode(10)
  return [
    `build:${fields.build}`,
    `version:${fields.version}`,
    `zipUrl:${fields.zipUrl}`,
    `sha256:${fields.sha256.toLowerCase()}`,
  ].join(NEWLINE)
}

/**
 * Whether `signature` (base64) is ours, over these fields.
 *
 * Ed25519 is verified with a NULL algorithm — the curve specifies its own
 * hash, and passing 'sha256' here throws rather than checking anything.
 *
 * Returns false rather than throwing on a malformed signature, a corrupt key,
 * or anything else: the caller's question is "may this be trusted", and every
 * answer other than a clean yes is no.
 */
export function verifyManifestSignature(fields: SignedFields, signature: string): boolean {
  if (typeof signature !== 'string' || signature.trim() === '') return false

  try {
    const key = createPublicKey(UPDATE_PUBLIC_KEY)
    return verify(
      null,
      Buffer.from(canonicalManifest(fields), 'utf8'),
      key,
      Buffer.from(signature, 'base64'),
    )
  } catch {
    return false
  }
}
