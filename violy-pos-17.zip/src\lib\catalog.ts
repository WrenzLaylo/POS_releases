import type { ProductWithCategory } from './types'

export type CategoryGroup = {
  categoryName: string
  products: ProductWithCategory[]
}

/** Products arrive ordered by category.sortOrder then name, so preserving
 *  insertion order is all the grouping has to do. Ordering is data, not a
 *  guess about what a category is called. */
export function groupByCategory(products: ProductWithCategory[]): CategoryGroup[] {
  const groups = new Map<string, ProductWithCategory[]>()
  for (const product of products) {
    const name = product.category.name
    const bucket = groups.get(name)
    if (bucket) bucket.push(product)
    else groups.set(name, [product])
  }

  return [...groups.entries()].map(([categoryName, groupProducts]) => ({
    categoryName,
    products: groupProducts,
  }))
}

/** The one search predicate. Previously duplicated at two call sites, which
 *  is how a filtered list and its "no matches" message can disagree. */
export function matchesSearch(product: ProductWithCategory, needle: string): boolean {
  return product.name.toLowerCase().includes(needle.trim().toLowerCase())
}

/**
 * The single matching product, or null. Powers Enter-to-increment: pressing
 * Enter must never guess. An empty needle matches everything and so has no
 * sole match — otherwise Enter on a freshly focused, empty search box would
 * add whichever product happened to be first.
 */
export function soleMatch(
  products: ProductWithCategory[],
  needle: string,
): ProductWithCategory | null {
  if (needle.trim() === '') return null
  const matches = products.filter((product) => matchesSearch(product, needle))
  return matches.length === 1 ? matches[0] : null
}

/**
 * Edit distance, capped.
 *
 * `max` is not an optimisation detail — it is what keeps a suggestion list
 * honest. Without it, "xyz" is within 9 edits of "ADM Broodsow (sako)" and
 * every product becomes a candidate, so a typo that resembles nothing would
 * still produce five confident-looking suggestions. Bailing out at `max`
 * returns Infinity for anything further away, and the caller drops it.
 *
 * Two rolling rows rather than a full matrix: this runs on every keystroke of
 * a failed search, against the whole catalog.
 */
export function editDistance(a: string, b: string, max: number): number {
  if (a === b) return 0
  if (Math.abs(a.length - b.length) > max) return Infinity

  let previous = Array.from({ length: b.length + 1 }, (_, i) => i)
  let current = new Array<number>(b.length + 1)

  for (let i = 1; i <= a.length; i += 1) {
    current[0] = i
    let best = current[0]
    for (let j = 1; j <= b.length; j += 1) {
      const substitution = previous[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)
      current[j] = Math.min(current[j - 1] + 1, previous[j] + 1, substitution)
      if (current[j] < best) best = current[j]
    }
    // Every remaining row can only add to the best score on this one, so once
    // the whole row is past the cap the answer cannot come back under it.
    if (best > max) return Infinity
    const swap = previous
    previous = current
    current = swap
  }

  return previous[b.length] > max ? Infinity : previous[b.length]
}

/**
 * How far a needle is from a product, as the smallest distance to any single
 * word of its name as well as to the whole name.
 *
 * Per-word matters because product names are several words long: typing
 * "brodsow" should reach "ADM Broodsow (sako)", and against the full name that
 * is 13 edits away — far past any sane cap — while against the word
 * "broodsow" it is one.
 */
function needleDistance(needle: string, name: string, max: number): number {
  const lowered = name.toLowerCase()
  let best = editDistance(needle, lowered, max)
  for (const word of lowered.split(/[^a-z0-9]+/)) {
    if (word === '') continue
    best = Math.min(best, editDistance(needle, word, max))
    if (best === 0) return 0
  }
  return best
}

/**
 * Products worth offering when a search matched nothing — the "did you mean".
 *
 * The tolerance grows with the length of what was typed: one edit for a short
 * word, two for a longer one. A fixed tolerance of two turns every three-letter
 * needle into a match for half the catalog, and a fixed tolerance of one makes
 * a single slip in a long name unrecoverable.
 */
export function suggestProducts(
  products: ProductWithCategory[],
  rawNeedle: string,
  limit = 4,
): ProductWithCategory[] {
  const needle = rawNeedle.trim().toLowerCase()
  if (needle.length < 3) return []

  const max = needle.length <= 4 ? 1 : 2

  return products
    .map((product) => ({ product, distance: needleDistance(needle, product.name, max) }))
    .filter((entry) => entry.distance !== Infinity)
    .sort(
      (a, b) =>
        a.distance - b.distance || a.product.name.localeCompare(b.product.name),
    )
    .slice(0, limit)
    .map((entry) => entry.product)
}
