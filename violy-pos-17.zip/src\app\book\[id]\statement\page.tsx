import Link from 'next/link'
import { notFound } from 'next/navigation'
import { getCustomer } from '@/server/customers'
import { getBalance, getLedger } from '@/server/ledger'
import { listPlans } from '@/server/utang'
import { bookEntry } from '@/lib/routes'
import { DocumentShell } from '@/components/DocumentShell'
import {
  DocumentFacts,
  DocumentFooter,
  DocumentHeading,
} from '@/components/DocumentHeading'
import { documentNumber, DOCUMENT_TITLES } from '@/lib/document-number'
import { getStoreProfile } from '@/server/store-profile'
import { Badge } from '@/components/ui/Badge'
import { EmptyState } from '@/components/ui/EmptyState'
import { Money } from '@/components/ui/Money'

export const dynamic = 'force-dynamic'

const ENTRY_LABELS: Record<string, string> = {
  OPENING: 'Opening balance',
  CHARGE: 'Charge',
  PAYMENT: 'Payment',
}

function shortDate(date: Date): string {
  return date.toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' })
}

/**
 * Everything one customer owes, on one page: each borrowing summarised, then
 * the full ledger, then the grand total.
 *
 * The total is `getBalance` — the same sum every other screen reads — and NOT
 * the sum of the plans above it. Those two can legitimately differ: a sale on
 * credit or an account-level payment moves the balance without belonging to
 * any record, and a statement that quietly reported only plan totals would
 * understate what is owed.
 */
export default async function StatementPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const customerId = Number(id)
  if (!Number.isInteger(customerId)) notFound()

  const customer = await getCustomer(customerId)
  if (!customer) notFound()

  const [plans, lines, balanceCentavos] = await Promise.all([
    listPlans(customerId),
    getLedger(customerId),
    getBalance(customerId),
  ])

  const profile = await getStoreProfile()
  const issuedAt = new Date()
  const livePlans = plans.filter((plan) => !plan.isVoided)
  const planOutstanding = livePlans.reduce((total, plan) => total + plan.outstandingCentavos, 0)
  const otherCentavos = balanceCentavos - planOutstanding

  return (
    <DocumentShell
      fileName={`${documentNumber('STATEMENT', customer.id, issuedAt)} ${customer.name}`}
      actions={
        <Link
          href={bookEntry(customerId)}
          className="inline-flex h-10 items-center justify-center rounded-control border border-line-strong bg-surface-raised px-4 text-sm font-medium text-ink hover:border-accent hover:bg-accent-soft"
        >
          Back to {customer.name}
        </Link>
      }
    >
      <DocumentHeading
        profile={profile}
        title={DOCUMENT_TITLES.STATEMENT}
        reference={documentNumber('STATEMENT', customer.id, issuedAt)}
        issuedAt={issuedAt}
      />

      <DocumentFacts
        items={[
          {
            label: 'Customer',
            value: (
              <>
                {customer.name}
                {customer.phone && (
                  <div className="font-normal text-ink-muted">{customer.phone}</div>
                )}
              </>
            ),
          },
          {
            label: 'Total amount due',
            value: <Money centavos={balanceCentavos} tone="balance" scale="strong" />,
            align: 'end',
          },
        ]}
      />

      <section className="py-5">
        <h2 className="mb-3 text-base font-semibold text-ink">Credit accounts</h2>
        {livePlans.length === 0 ? (
          // Says what is true. "No credit accounts" alongside a four-figure
          // total read as though nothing was owed.
          <EmptyState>
            {otherCentavos > 0
              ? 'Nothing on this account is on a payment schedule. The balance below is due in full.'
              : 'No credit accounts on this file.'}
          </EmptyState>
        ) : (
          <table className="doc-table w-full text-sm">
            <thead className="border-b border-line text-left text-xs uppercase tracking-wide text-ink-muted">
              <tr>
                <th className="py-3 pr-3">Started</th>
                <th className="px-3 py-3">Terms</th>
                <th className="px-3 py-3 text-right">Total</th>
                <th className="px-3 py-3 text-right">Paid</th>
                <th className="py-3 pl-3 text-right">Outstanding</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {livePlans.map((plan) => (
                <tr key={plan.id}>
                  <td data-label="Started" className="py-3 pr-3">{shortDate(plan.startedAt)}</td>
                  <td data-label="Terms" className="px-3 py-3">
                    {plan.termsLabel}
                    {plan.overdue.length > 0 && (
                      <Badge tone="owed" className="ml-2">
                        {plan.overdue.length} overdue
                      </Badge>
                    )}
                  </td>
                  <td data-label="Total" className="px-3 py-3 text-right"><Money centavos={plan.totalCentavos} /></td>
                  <td data-label="Paid" className="px-3 py-3 text-right">
                    <Money centavos={plan.paidCentavos} tone="in" />
                  </td>
                  <td data-label="Outstanding" className="py-3 pl-3 text-right">
                    <Money
                      centavos={plan.outstandingCentavos}
                      tone={plan.outstandingCentavos > 0 ? 'owed' : 'zero'}
                      className="font-semibold"
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>

      <section className="border-t border-line py-5">
        <h2 className="mb-3 text-base font-semibold text-ink">Every entry</h2>
        {lines.length === 0 ? (
          <EmptyState>Nothing on this account yet.</EmptyState>
        ) : (
          <table className="doc-table w-full text-sm">
            <thead className="border-b border-line text-left text-xs uppercase tracking-wide text-ink-muted">
              <tr>
                <th className="py-3 pr-3">Date</th>
                <th className="px-3 py-3">Description</th>
                <th className="px-3 py-3 text-right">Charge</th>
                <th className="px-3 py-3 text-right">Payment</th>
                <th className="py-3 pl-3 text-right">Balance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {lines.map((line) => (
                <tr key={line.id} className={line.isVoided ? 'text-ink-subtle line-through' : undefined}>
                  <td data-label="Date" className="py-3 pr-3">{shortDate(line.occurredAt)}</td>
                  <td className="px-3 py-3">
                    {ENTRY_LABELS[line.type] ?? line.type}
                    {line.note && <span className="text-ink-muted"> — {line.note}</span>}
                    {line.saleId && <span className="text-ink-muted"> (sale #{line.saleId})</span>}
                    {line.planId && line.type !== 'PAYMENT' && (
                      <span className="text-ink-muted">
                        {' '}
                        ({documentNumber('CREDIT_AGREEMENT', line.planId, line.occurredAt)})
                      </span>
                    )}
                  </td>
                  <td data-label="Charge" className="px-3 py-3 text-right">
                    {line.type !== 'PAYMENT' ? (
                      <Money centavos={line.amountCentavos} tone={line.isVoided ? 'zero' : 'owed'} />
                    ) : (
                      <span className="text-ink-subtle">—</span>
                    )}
                  </td>
                  <td data-label="Payment" className="px-3 py-3 text-right">
                    {line.type === 'PAYMENT' ? (
                      <Money centavos={line.amountCentavos} tone={line.isVoided ? 'zero' : 'in'} />
                    ) : (
                      <span className="text-ink-subtle">—</span>
                    )}
                  </td>
                  <td data-label="Balance" className="py-3 pl-3 text-right">
                    <Money centavos={line.runningBalanceCentavos} tone="balance" />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>

      <section className="doc-keep-together ml-auto w-full max-w-sm space-y-2 border-t border-line pt-5">
        <div className="flex justify-between text-sm text-ink-muted">
          <span>Outstanding on credit accounts</span>
          <Money centavos={planOutstanding} />
        </div>
        {/* Shown whenever it is non-zero, including negative. A credit balance
            or a plain credit sale belongs to no record, and hiding it would
            make the two figures above look like they should add up when they
            do not. */}
        {otherCentavos !== 0 && (
          <div className="flex justify-between text-sm text-ink-muted">
            <span>Other charges and payments</span>
            <Money centavos={otherCentavos} tone="balance" />
          </div>
        )}
        <div className="flex items-baseline justify-between border-t border-line pt-3">
          <span className="font-semibold text-ink">Total amount due as of {shortDate(issuedAt)}</span>
          <Money centavos={balanceCentavos} tone="balance" scale="strong" />
        </div>
      </section>


      <DocumentFooter>
        This statement reflects the account as at{' '}
        {issuedAt.toLocaleString('en-PH', { dateStyle: 'long', timeStyle: 'short' })}. Please
        report any discrepancy to {profile.name} within seven days of receipt.
      </DocumentFooter>
    </DocumentShell>
  )
}
