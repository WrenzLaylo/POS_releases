import { beforeEach, describe, expect, it } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'
import {
  convertBalanceToPlan,
  createPlan,
  getPlan,
  getUnplannedBalance,
  listPlans,
  voidPlan,
} from './utang'
import { getBalance, getLedger, recordPayment, updateEntry, voidEntry } from './ledger'

const JAN_15 = new Date(2026, 0, 15)

async function customer(name = 'ROMAN'): Promise<number> {
  const row = await prisma.customer.create({ data: { name } })
  return row.id
}

/** ₱3,000 over 3 months at 5% per month, flat: ₱450 interest, ₱3,450 total. */
async function plan(customerId: number, overrides: Record<string, unknown> = {}) {
  const result = await createPlan({
    customerId,
    principalCentavos: 300_000,
    interestMethod: 'FLAT_MONTHLY',
    interestRateBps: 500,
    termMonths: 3,
    startedAt: JAN_15,
    ...overrides,
  })
  if (!result.ok) throw new Error(result.error)
  return result.data.planId
}

beforeEach(async () => {
  await resetDb()
})

describe('createPlan', () => {
  it('posts principal and all interest as one charge on the start date', async () => {
    const customerId = await customer()
    await plan(customerId)

    // The whole obligation is owed immediately; the schedule is a payment
    // plan over a debt that already exists in full.
    expect(await getBalance(customerId)).toBe(345_000)

    const lines = await getLedger(customerId)
    expect(lines).toHaveLength(1)
    expect(lines[0].amountCentavos).toBe(345_000)
    expect(lines[0].occurredAt.getTime()).toBe(JAN_15.getTime())
    expect(lines[0].planId).not.toBeNull()
  })

  it('records the first entry as OPENING and later ones as CHARGE', async () => {
    const customerId = await customer()
    await plan(customerId)
    await plan(customerId, { startedAt: new Date(2026, 2, 1) })

    const lines = await getLedger(customerId)
    expect(lines.map((line) => line.type)).toEqual(['OPENING', 'CHARGE'])
  })

  it('stores the schedule, and snapshots the totals', async () => {
    const customerId = await customer()
    const planId = await plan(customerId)

    const view = await getPlan(planId)
    expect(view).not.toBeNull()
    expect(view!.principalCentavos).toBe(300_000)
    expect(view!.interestCentavos).toBe(45_000)
    expect(view!.totalCentavos).toBe(345_000)
    expect(view!.termsLabel).toBe('3 months at 5% per month, flat')
    expect(view!.installments.map((i) => i.amountCentavos)).toEqual([115_000, 115_000, 115_000])
    expect(view!.installments.map((i) => i.dueAt.getMonth())).toEqual([1, 2, 3])
  })

  it('sets a due date on a customer who had none', async () => {
    const customerId = await customer()
    await plan(customerId)
    const row = await prisma.customer.findUnique({ where: { id: customerId } })
    expect(row!.dueAt).not.toBeNull()
  })

  it.each([
    ['a zero principal', { principalCentavos: 0 }],
    ['a negative principal', { principalCentavos: -100 }],
    ['a term of zero months', { termMonths: 0 }],
    ['a rate above 100%', { interestRateBps: 10_001 }],
    ['an unknown interest method', { interestMethod: 'COMPOUND_DAILY' }],
  ])('refuses %s, and writes nothing', async (_label, override) => {
    const customerId = await customer()
    const result = await createPlan({
      customerId,
      principalCentavos: 300_000,
      interestMethod: 'FLAT_MONTHLY',
      interestRateBps: 500,
      termMonths: 3,
      startedAt: JAN_15,
      ...override,
    })

    expect(result.ok).toBe(false)
    expect(await prisma.utangPlan.count()).toBe(0)
    expect(await getBalance(customerId)).toBe(0)
  })

  it('refuses a customer that does not exist', async () => {
    const result = await createPlan({
      customerId: 9_999,
      principalCentavos: 300_000,
      interestMethod: 'FLAT_MONTHLY',
      interestRateBps: 500,
      termMonths: 3,
      startedAt: JAN_15,
    })
    expect(result).toEqual({ ok: false, error: 'That customer no longer exists.' })
  })
})

describe('paying into a plan', () => {
  it('reduces that plan’s outstanding and settles instalments oldest first', async () => {
    const customerId = await customer()
    const planId = await plan(customerId)

    const paid = await recordPayment({
      customerId,
      amountCentavos: 115_000,
      occurredAt: new Date(2026, 1, 15),
      planId,
    })
    expect(paid.ok).toBe(true)

    const view = await getPlan(planId)
    expect(view!.paidCentavos).toBe(115_000)
    expect(view!.outstandingCentavos).toBe(230_000)
    expect(view!.installments[0].isSettled).toBe(true)
    expect(view!.nextDue?.sequence).toBe(2)
    expect(await getBalance(customerId)).toBe(230_000)
  })

  it('leaves every plan untouched when the payment is account-level', async () => {
    const customerId = await customer()
    const planId = await plan(customerId)

    await recordPayment({ customerId, amountCentavos: 115_000, occurredAt: JAN_15 })

    // The balance falls, but no single borrowing has been settled — otherwise
    // two plans could both claim the same peso.
    expect(await getBalance(customerId)).toBe(230_000)
    const view = await getPlan(planId)
    expect(view!.paidCentavos).toBe(0)
    expect(view!.outstandingCentavos).toBe(345_000)
  })

  it('refuses a plan belonging to a different customer', async () => {
    const mine = await customer('ROMAN')
    const theirs = await customer('MARILOU')
    const planId = await plan(mine)

    const result = await recordPayment({
      customerId: theirs,
      amountCentavos: 5_000,
      occurredAt: JAN_15,
      planId,
    })
    expect(result).toEqual({
      ok: false,
      error: 'That utang record does not belong to this customer.',
    })
    expect(await getBalance(theirs)).toBe(0)
  })

  it('refuses a voided plan', async () => {
    const customerId = await customer()
    const planId = await plan(customerId)
    await voidPlan(planId)

    const result = await recordPayment({
      customerId,
      amountCentavos: 5_000,
      occurredAt: JAN_15,
      planId,
    })
    expect(result.ok).toBe(false)
  })
})

describe('two borrowings on one account', () => {
  it('keeps the records apart while the balance totals them', async () => {
    const customerId = await customer()
    const first = await plan(customerId)
    const second = await plan(customerId, {
      principalCentavos: 100_000,
      interestMethod: 'FLAT_ONCE',
      interestRateBps: 1_000,
      termMonths: 2,
      startedAt: new Date(2026, 2, 1),
    })

    // ₱3,450 + ₱1,100, owed as one balance but tracked as two records.
    expect(await getBalance(customerId)).toBe(455_000)

    await recordPayment({
      customerId,
      amountCentavos: 115_000,
      occurredAt: new Date(2026, 1, 15),
      planId: first,
    })

    const plans = await listPlans(customerId)
    expect(plans).toHaveLength(2)
    // Newest borrowing first.
    expect(plans.map((p) => p.id)).toEqual([second, first])
    expect(plans.find((p) => p.id === first)!.outstandingCentavos).toBe(230_000)
    expect(plans.find((p) => p.id === second)!.outstandingCentavos).toBe(110_000)
    expect(await getBalance(customerId)).toBe(340_000)
  })
})

describe('a plan’s charge is not editable on its own', () => {
  it('refuses updateEntry and voidEntry, pointing at the record instead', async () => {
    const customerId = await customer()
    await plan(customerId)
    const [charge] = await getLedger(customerId)

    const message = 'This charge belongs to an utang record. Void that record instead.'
    expect(await updateEntry(charge.id, { amountCentavos: 1, occurredAt: JAN_15 })).toEqual({
      ok: false,
      error: message,
    })
    expect(await voidEntry(charge.id)).toEqual({ ok: false, error: message })

    // Nothing moved.
    expect(await getBalance(customerId)).toBe(345_000)
  })

  it('still allows a plan-allocated PAYMENT to be corrected', async () => {
    const customerId = await customer()
    const planId = await plan(customerId)
    const paid = await recordPayment({
      customerId,
      amountCentavos: 115_000,
      occurredAt: JAN_15,
      planId,
    })
    if (!paid.ok) throw new Error(paid.error)

    const result = await updateEntry(paid.data.entryId, {
      amountCentavos: 100_000,
      occurredAt: JAN_15,
    })
    expect(result.ok).toBe(true)
    expect((await getPlan(planId))!.paidCentavos).toBe(100_000)
  })
})

describe('voidPlan', () => {
  it('cancels the charge but keeps money that was actually handed over', async () => {
    const customerId = await customer()
    const planId = await plan(customerId)
    await recordPayment({
      customerId,
      amountCentavos: 115_000,
      occurredAt: new Date(2026, 1, 15),
      planId,
    })
    expect(await getBalance(customerId)).toBe(230_000)

    expect(await voidPlan(planId)).toEqual({ ok: true, data: undefined })

    // The ₱3,450 charge is gone; the ₱1,150 payment is not. The customer
    // really did hand that over, so the account is now ₱1,150 in credit.
    expect(await getBalance(customerId)).toBe(-115_000)

    const entries = await prisma.ledgerEntry.findMany({ where: { customerId } })
    const charge = entries.find((entry) => entry.type !== 'PAYMENT')!
    const payment = entries.find((entry) => entry.type === 'PAYMENT')!
    expect(charge.isVoided).toBe(true)
    expect(payment.isVoided).toBe(false)
    // The payment reverts to account-level rather than pointing at a dead plan.
    expect(payment.planId).toBeNull()
  })

  it('snapshots the charge before voiding it', async () => {
    const customerId = await customer()
    const planId = await plan(customerId)
    const [charge] = await getLedger(customerId)

    await voidPlan(planId)

    const revisions = await prisma.ledgerEntryRevision.findMany({
      where: { ledgerEntryId: charge.id },
    })
    expect(revisions).toHaveLength(1)
    expect(revisions[0].amountCentavos).toBe(345_000)
    expect(revisions[0].isVoided).toBe(false)
  })

  it('clears the account due date once nothing is owed', async () => {
    const customerId = await customer()
    const planId = await plan(customerId)
    await voidPlan(planId)

    const row = await prisma.customer.findUnique({ where: { id: customerId } })
    expect(row!.dueAt).toBeNull()
  })

  it('is idempotent, and refuses one that never existed', async () => {
    const customerId = await customer()
    const planId = await plan(customerId)

    expect(await voidPlan(planId)).toEqual({ ok: true, data: undefined })
    expect(await voidPlan(planId)).toEqual({ ok: true, data: undefined })
    expect(await getBalance(customerId)).toBe(0)

    expect(await voidPlan(9_999)).toEqual({ ok: false, error: 'That utang no longer exists.' })
  })

  it('reports nothing overdue on a voided plan', async () => {
    const customerId = await customer()
    const planId = await plan(customerId, { startedAt: new Date(2020, 0, 15) })
    expect((await getPlan(planId))!.overdue.length).toBeGreaterThan(0)

    await voidPlan(planId)
    expect((await getPlan(planId))!.overdue).toEqual([])
  })
})

describe('convertBalanceToPlan', () => {
  /** A notebook carry-over: ₱3,150 owed, on no schedule. */
  async function withOpeningBalance(amountCentavos = 315_000) {
    const customerId = await customer('CARRIED OVER')
    await prisma.ledgerEntry.create({
      data: { customerId, type: 'OPENING', amountCentavos, occurredAt: JAN_15 },
    })
    return customerId
  }

  it('schedules an existing balance WITHOUT charging it again', async () => {
    const customerId = await withOpeningBalance()
    expect(await getBalance(customerId)).toBe(315_000)

    const result = await convertBalanceToPlan({
      customerId,
      interestMethod: 'FLAT_ONCE',
      interestRateBps: 0,
      termMonths: 3,
      startedAt: JAN_15,
    })
    expect(result.ok).toBe(true)

    // The whole point: the money was already on the ledger, so scheduling it
    // must not add a second charge. A doubled balance here would be the most
    // damaging bug this feature could ship.
    expect(await getBalance(customerId)).toBe(315_000)
    expect(await prisma.ledgerEntry.count({ where: { customerId } })).toBe(1)

    const [plan] = await listPlans(customerId)
    expect(plan.principalCentavos).toBe(315_000)
    expect(plan.totalCentavos).toBe(315_000)
    expect(plan.installments.map((i) => i.amountCentavos)).toEqual([105_000, 105_000, 105_000])
  })

  it('posts ONLY the interest when a rate is added', async () => {
    const customerId = await withOpeningBalance(300_000)

    const result = await convertBalanceToPlan({
      customerId,
      interestMethod: 'FLAT_MONTHLY',
      interestRateBps: 500,
      termMonths: 3,
    startedAt: JAN_15,
    })
    if (!result.ok) throw new Error(result.error)

    // ₱3,000 was already owed; only the ₱450 of interest is new money, and it
    // is posted as its own entry so the ledger says where the increase came
    // from rather than a balance quietly growing.
    expect(await getBalance(customerId)).toBe(345_000)
    const entries = await prisma.ledgerEntry.findMany({ where: { customerId } })
    expect(entries).toHaveLength(2)
    const added = entries.find((entry) => entry.planId !== null)!
    expect(added.amountCentavos).toBe(45_000)
    expect(added.type).toBe('CHARGE')
  })

  it('refuses when nothing is unscheduled', async () => {
    const customerId = await customer()
    expect(await convertBalanceToPlan({
      customerId,
      interestMethod: 'FLAT_ONCE',
      interestRateBps: 0,
      termMonths: 3,
      startedAt: JAN_15,
    })).toEqual({
      ok: false,
      error: 'There is no unscheduled balance on this account to put on terms.',
    })
  })

  it('refuses to schedule a balance that is already on a plan', async () => {
    const customerId = await customer()
    await plan(customerId)

    // The plan's own charge is not "unscheduled" money.
    expect(await getUnplannedBalance(customerId)).toBe(0)
    const result = await convertBalanceToPlan({
      customerId,
      interestMethod: 'FLAT_ONCE',
      interestRateBps: 0,
      termMonths: 2,
      startedAt: JAN_15,
    })
    expect(result.ok).toBe(false)
  })

  it('counts only the part of a balance that is not on a plan', async () => {
    const customerId = await customer()
    await plan(customerId) // ₱3,450 on terms
    await prisma.ledgerEntry.create({
      data: { customerId, type: 'CHARGE', amountCentavos: 50_000, occurredAt: JAN_15 },
    })

    expect(await getBalance(customerId)).toBe(395_000)
    expect(await getUnplannedBalance(customerId)).toBe(50_000)

    const result = await convertBalanceToPlan({
      customerId,
      interestMethod: 'FLAT_ONCE',
      interestRateBps: 0,
      termMonths: 2,
      startedAt: JAN_15,
    })
    if (!result.ok) throw new Error(result.error)

    const converted = (await listPlans(customerId)).find((p) => p.id === result.data.planId)!
    expect(converted.principalCentavos).toBe(50_000)
    expect(await getBalance(customerId)).toBe(395_000)
  })

  it('does not treat a credit balance as convertible', async () => {
    const customerId = await customer()
    await prisma.ledgerEntry.create({
      data: { customerId, type: 'PAYMENT', amountCentavos: 10_000, occurredAt: JAN_15 },
    })
    expect(await getUnplannedBalance(customerId)).toBe(-10_000)
    expect(
      (await convertBalanceToPlan({
        customerId,
        interestMethod: 'FLAT_ONCE',
        interestRateBps: 0,
        termMonths: 2,
        startedAt: JAN_15,
      })).ok,
    ).toBe(false)
  })
})
