import { prisma } from '@/lib/db'
import { startOfDay } from '@/lib/dates'
import { sumBalance } from '@/lib/ledger-balance'
import { applyPayments, overdueInstallments } from '@/lib/utang'
import type {
  NotificationSummary,
  OverdueAccountNotification,
  OverdueInstallmentNotification,
} from '@/lib/types'
import { listLowStockProducts } from '@/server/products'
import { listDeliveriesToday } from '@/server/delivery-orders'
import { updateCache } from '@/server/update-cache'

/** Live facts, not an inbox: issues disappear only when the underlying debt or
 * stock state is fixed. `now` is injectable for the local-day boundary tests. */
export async function getNotifications(now: Date = new Date()): Promise<NotificationSummary> {
  // Read, not awaited. This used to be `checkForUpdates()` inside the
  // Promise.all below — a live HTTPS request with an 8-second timeout sitting
  // in the path the root layout awaits, which meant an offline shop waited it
  // out on every page load. Measured at 8.21s, against 0.45s online. See
  // `update-cache.ts`; the count is now whatever the last background check
  // found, and the shell never waits for a socket.
  const updatesAvailable = updateCache.read()

  const [customers, plans, lowStock, deliveriesToday] = await Promise.all([
    prisma.customer.findMany({
      // Archived debtors deliberately remain visible; a non-null deadline is
      // the only customer-level prefilter the bell needs.
      where: { dueAt: { not: null } },
      select: {
        id: true,
        name: true,
        dueAt: true,
        entries: {
          where: { isVoided: false },
          select: { id: true, type: true, amountCentavos: true, isVoided: true },
        },
      },
    }),
    prisma.utangPlan.findMany({
      where: { isVoided: false },
      select: {
        id: true,
        customerId: true,
        customer: { select: { name: true } },
        installments: {
          select: { sequence: true, dueAt: true, amountCentavos: true },
          orderBy: { sequence: 'asc' },
        },
        entries: {
          where: { type: 'PAYMENT', isVoided: false },
          select: { amountCentavos: true },
        },
      },
    }),
    listLowStockProducts(),
    // Same `now` the day-boundary arithmetic below uses, so a test that pins
    // the clock pins this too.
    listDeliveriesToday(now),
  ])
  const today = startOfDay(now)

  // What each customer still owes on live plans. Used to keep the two groups
  // from reporting the same peso twice — see `overdueAccounts` below.
  const planOutstandingByCustomer = new Map<number, number>()
  for (const plan of plans) {
    const paid = plan.entries.reduce((total, entry) => total + entry.amountCentavos, 0)
    const total = plan.installments.reduce(
      (running, installment) => running + installment.amountCentavos,
      0,
    )
    planOutstandingByCustomer.set(
      plan.customerId,
      (planOutstandingByCustomer.get(plan.customerId) ?? 0) + Math.max(0, total - paid),
    )
  }

  // Split once, on the same rules, so a customer cannot appear in both lists
  // or fall between them.
  const dueToday: OverdueAccountNotification[] = []

  const overdueAccounts: OverdueAccountNotification[] = customers
    .flatMap((customer) => {
      const balanceCentavos = sumBalance(customer.entries)
      if (customer.dueAt === null) return []

      const due = startOfDay(customer.dueAt)
      const isToday = due.getTime() === today.getTime()
      if (due > today) return []

      // Only the part of the balance that belongs to no plan. A plan sets
      // `dueAt` when it posts its charge, so without this a customer with one
      // utang would appear in BOTH groups for the same debt — counted twice in
      // the badge and chased twice off the list. The instalment group is the
      // better report for plan money, because it says which months were
      // missed.
      const accountOnlyCentavos =
        balanceCentavos - (planOutstandingByCustomer.get(customer.id) ?? 0)
      if (accountOnlyCentavos <= 0) return []

      const row = {
        customerId: customer.id,
        name: customer.name,
        balanceCentavos: accountOnlyCentavos,
        dueAt: customer.dueAt,
      }
      // Due today is collected today; overdue is chased. Different lists.
      if (isToday) {
        dueToday.push(row)
        return []
      }
      return [row]
    })
    .sort(
      (a, b) =>
        a.dueAt.getTime() - b.dueAt.getTime() ||
        a.name.localeCompare(b.name),
    )

  // One row per plan, not per instalment: a customer three months behind is
  // one collection problem to chase, and three separate bell entries for the
  // same conversation is noise, not information.
  const overdueRows: OverdueInstallmentNotification[] = plans
    .flatMap((plan) => {
      const paidCentavos = plan.entries.reduce(
        (total, entry) => total + entry.amountCentavos,
        0,
      )
      const statuses = applyPayments(
        plan.installments.map((installment) => ({
          sequence: installment.sequence,
          dueAt: installment.dueAt,
          amountCentavos: installment.amountCentavos,
          // The principal/interest split is irrelevant to overdue-ness; the
          // bell only needs what is unpaid and when it was due.
          principalCentavos: 0,
          interestCentavos: 0,
        })),
        paidCentavos,
      )

      const late = overdueInstallments(statuses, today)
      if (late.length === 0) return []

      return [
        {
          customerId: plan.customerId,
          name: plan.customer.name,
          planId: plan.id,
          count: late.length,
          oldestDueAt: late[0].dueAt,
          // What is actually still owed across those months, net of anything
          // part-paid into them — not the sum of their face amounts.
          amountCentavos: late.reduce(
            (total, installment) => total + (installment.amountCentavos - installment.paidCentavos),
            0,
          ),
        },
      ]
    })
    .sort(
      (a, b) =>
        a.oldestDueAt.getTime() - b.oldestDueAt.getTime() || a.name.localeCompare(b.name),
    )

  dueToday.sort((a, b) => b.balanceCentavos - a.balanceCentavos || a.name.localeCompare(b.name))

  return {
    overdueAccounts,
    dueToday,
    overdueInstallments: overdueRows,
    deliveriesToday,
    lowStock,
    updatesAvailable,
    total:
      overdueAccounts.length +
      dueToday.length +
      overdueRows.length +
      deliveriesToday.length +
      lowStock.length +
      (updatesAvailable > 0 ? 1 : 0),
  }
}
