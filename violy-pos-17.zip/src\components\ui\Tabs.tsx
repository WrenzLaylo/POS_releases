'use client'

import { cn } from '@/lib/cn'

export function Tabs({
  tabs,
  value,
  onValueChange,
  ariaLabel,
  className,
}: {
  tabs: readonly { value: string; label: string }[]
  value: string
  onValueChange: (value: string) => void
  ariaLabel: string
  className?: string
}) {
  return (
    <div
      role="tablist"
      aria-label={ariaLabel}
      className={cn('flex items-center gap-1 border-b border-line', className)}
    >
      {tabs.map((tab) => {
        const selected = tab.value === value
        return (
          <button
            key={tab.value}
            type="button"
            role="tab"
            aria-selected={selected}
            onClick={() => onValueChange(tab.value)}
            className={cn(
              'h-10 border-b-2 px-3 text-sm font-medium transition-colors duration-150',
              'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent',
              selected
                ? 'border-accent text-ink'
                : 'border-transparent text-ink-muted hover:text-ink',
            )}
          >
            {tab.label}
          </button>
        )
      })}
    </div>
  )
}
