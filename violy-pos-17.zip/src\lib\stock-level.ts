/**
 * The three states a product's stock can be in.
 *
 * Deliberately a PARTITION — every product is in exactly one of these, and
 * "out" is not a kind of "low". They are different jobs: out of stock means a
 * customer standing at the counter cannot buy it today, low means order more
 * this week. Folding them together, which `stockQty <= lowStockThreshold`
 * alone does, hides the urgent case inside the merely untidy one.
 *
 * Shared between the SQL that filters the table and any code that has to say
 * which state a row is in, so the two can never disagree about where the
 * boundary sits.
 */

export type StockLevel = 'in' | 'low' | 'out'

export const STOCK_LEVEL_OPTIONS = [
  { value: '', label: 'Any stock' },
  { value: 'in', label: 'In stock' },
  { value: 'low', label: 'Low' },
  { value: 'out', label: 'Out of stock' },
] as const

export function parseStockLevel(raw: string | undefined | null): StockLevel | undefined {
  return raw === 'in' || raw === 'low' || raw === 'out' ? raw : undefined
}

export function stockLevelOf(product: {
  stockQty: number
  lowStockThreshold: number
}): StockLevel {
  // Checked first, and with `<=` rather than `=== 0`: a negative count is a
  // real state in this app — the counter lets a sale go through on stock the
  // shop physically has but has not counted in yet — and a product at -3 is
  // emphatically not "in stock".
  if (product.stockQty <= 0) return 'out'
  if (product.stockQty <= product.lowStockThreshold) return 'low'
  return 'in'
}
