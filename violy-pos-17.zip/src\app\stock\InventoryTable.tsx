'use client'

import { useState, useTransition } from 'react'
import { useRouter, usePathname, useSearchParams } from 'next/navigation'
import { archiveProduct, restoreProduct } from '@/server/products'
import type { ProductWithCategory } from '@/lib/types'
import { ProductForm } from './ProductForm'
import { ProductViewModal } from './ProductViewModal'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { EmptyState } from '@/components/ui/EmptyState'
import { Money } from '@/components/ui/Money'
import { ProductImage } from '@/components/ui/ProductImage'
import { FormError } from '@/components/ui/FormError'
import { RowActionMenu } from '@/components/ui/RowActionMenu'
import { openBag } from '@/server/open-bag'
import { SortableHeader } from '@/components/ui/SortableHeader'
import { nextSort, type SortState } from '@/lib/sorting'
import type { ProductSortKey } from '@/lib/product-sort'
import { cn } from '@/lib/cn'

type Props = {
  products: ProductWithCategory[]
  categories: { id: number; name: string }[]
  sort: SortState<ProductSortKey>
}

export function InventoryTable({ products, categories, sort }: Props) {
  const router = useRouter()
  const pathname = usePathname()
  const searchParams = useSearchParams()
  const [editing, setEditing] = useState<ProductWithCategory | null>(null)
  const [formOpen, setFormOpen] = useState(false)
  const [viewing, setViewing] = useState<ProductWithCategory | null>(null)
  const [error, setError] = useState<string | null>(null)
  /** Confirmation after a bag is opened, so the stock drop is explained. */
  const [opened, setOpened] = useState<string | null>(null)
  const [confirmingId, setConfirmingId] = useState<number | null>(null)
  const [pending, startTransition] = useTransition()

  // Sorting is a navigation, not local state: the table is server-paginated,
  // so the ORDER has to reach the query that fetches the page. Sorting the
  // twelve rows already on screen would reorder one page against itself.
  // Paging resets to 1 — staying on page 5 of a freshly reordered list lands
  // on rows that have nothing to do with what was clicked.
  function applySort(key: ProductSortKey, descendingFirst = false) {
    const next = nextSort(sort, key, descendingFirst)
    const query = new URLSearchParams(searchParams.toString())
    query.set('sort', next.key)
    query.set('dir', next.direction)
    query.delete('page')
    router.push(`${pathname}?${query.toString()}`)
  }

  function openEdit(product: ProductWithCategory) {
    setEditing(product)
    setFormOpen(true)
  }

  function handleArchive(product: ProductWithCategory) {
    setError(null)
    startTransition(async () => {
      const result = await archiveProduct(product.id)
      if (!result.ok) {
        setError(result.error)
        return
      }
      setConfirmingId(null)
      router.refresh()
    })
  }

  // No confirmation step, unlike archiving: restoring puts a record back and
  // takes nothing away, so the destructive-confirm pattern would be noise —
  // same call `CustomerList` makes for `restoreCustomer`.
  function handleRestore(product: ProductWithCategory) {
    setError(null)
    startTransition(async () => {
      const result = await restoreProduct(product.id)
      if (!result.ok) {
        setError(result.error)
        return
      }
      router.refresh()
    })
  }

  /**
   * Records that a sealed bag was opened to sell feed by the kilo.
   *
   * Confirmed first, because it moves stock and there is no undo but a stock
   * count. The confirmation names the product and says what the figure will
   * become, so a mis-click on the wrong row is visible before it happens
   * rather than a week later.
   */
  function handleOpenBag(product: ProductWithCategory) {
    setError(null)
    setOpened(null)
    startTransition(async () => {
      const result = await openBag(product.id)
      if (!result.ok) {
        setError(result.error)
        return
      }
      setOpened(`${result.data.productName}: one bag opened, ${result.data.remaining} sealed left.`)
      router.refresh()
    })
  }

  return (
    <div>
      {error && <FormError className="mb-4">{error}</FormError>}
      {opened && (
        <p className="mb-4 rounded-control border border-line bg-surface-sunk px-4 py-3 text-sm text-ink">
          {opened} The loose feed is not counted — sell it by the kilo as usual.
        </p>
      )}

      {products.length === 0 ? (
        <EmptyState>No products match these filters.</EmptyState>
      ) : (
        // No inner scroll. It used to be `max-h-[65vh] overflow-auto`, which
        // meant scrolling a table inside a scrolling page — two scrollbars for
        // one list. A page is now twelve rows, which fits, so paging does the
        // job the scroll box was doing badly. `thead` loses its `sticky` with
        // it: there is no scrolling ancestor left for it to stick to.
        <div className="overflow-hidden rounded-xl border border-line bg-surface">
          <table className="w-full text-sm">
            <thead className="bg-surface-sunk text-left text-xs uppercase tracking-wide text-ink-muted">
              <tr>
                <SortableHeader
                  label="Product"
                  active={sort.key === 'name'}
                  direction={sort.direction}
                  onSort={() => applySort('name')}
                />
                <SortableHeader
                  label="Category"
                  active={sort.key === 'category'}
                  direction={sort.direction}
                  onSort={() => applySort('category')}
                />
                <SortableHeader
                  label="Price"
                  align="end"
                  active={sort.key === 'price'}
                  direction={sort.direction}
                  onSort={() => applySort('price', true)}
                />
                <SortableHeader
                  label="Cost"
                  align="end"
                  active={sort.key === 'cost'}
                  direction={sort.direction}
                  onSort={() => applySort('cost', true)}
                />
                {/* Ascending first here, unlike the money columns: the reason
                    to sort by stock is to find what is running out. */}
                <SortableHeader
                  label="Stock"
                  align="end"
                  active={sort.key === 'stock'}
                  direction={sort.direction}
                  onSort={() => applySort('stock')}
                />
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {products.map((product) => {
                const out = product.stockQty <= 0
                const low = !out && product.stockQty <= product.lowStockThreshold
                const confirming = confirmingId === product.id
                return (
                  <tr
                    key={product.id}
                    // The row is a click target for the MOUSE and nothing more.
                    // It used to carry role="button" and tabIndex, which avoided
                    // a literal <button> but not the problem: role="button" says
                    // "this is a button" to assistive technology just as loudly,
                    // and the row contains an action menu — so AT was told a
                    // button contained buttons, and axe flagged ten of them.
                    // The keyboard path is the product name below, which is a
                    // real button and a sibling of the menu rather than its
                    // ancestor. Same fix, and same reasoning, as the catalog
                    // cards becoming role="group".
                    onClick={() => setViewing(product)}
                    className={cn(
                      'cursor-pointer transition-colors duration-150',
                      // NO row wash. It used to tint the whole row, reasoning
                      // that a wash is visible while scanning the Product
                      // column where the eye actually is. That holds when
                      // out-of-stock is the exception. This shop has 46 of 55
                      // products at zero because stock has not been counted in
                      // yet, so the table came out pink end to end and the
                      // signal vanished — highlighting everything highlights
                      // nothing.
                      //
                      // The stock column carries it instead: a coloured figure
                      // and a chip, which says WHICH product rather than
                      // shouting about the whole row.
                      'hover:bg-surface-sunk',
                      product.isArchived && 'opacity-50',
                    )}
                  >
                    {/* One line, not two. The unit on its own row made every
                        row 65px, so twelve of them overflowed the screen by
                        235px — measured — and paging you cannot see the bottom
                        of is not paging. Inline it is 44px and a page fits. */}
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-3">
                        {/* Only when there is a photo. None of the catalog
                            carries one today, so the placeholder was an empty
                            beige square on every row — the same mistake the
                            counter's product cards already dropped. */}
                        {product.imagePath && (
                          <ProductImage
                            src={product.imagePath}
                            className="h-8 w-8 shrink-0 rounded"
                            fallbackClassName="h-8 w-8 shrink-0 rounded"
                          />
                        )}
                        <div className="flex min-w-0 flex-wrap items-baseline gap-x-2">
                          {/* The keyboard route into the view, and the reason
                              the row no longer claims to be a button. The
                              accessible name carries the verb the row's
                              aria-label used to; it still CONTAINS the visible
                              text, which is what "label in name" requires. */}
                          <button
                            type="button"
                            aria-label={`View ${product.name}`}
                            onClick={(event) => {
                              // The row opens it too. Without this the handler
                              // runs twice on a mouse click.
                              event.stopPropagation()
                              setViewing(product)
                            }}
                            className={cn(
                              'truncate rounded-sm text-left font-medium',
                              'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent',
                            )}
                          >
                            {product.name}
                          </button>
                          <span className="text-xs text-ink-subtle">{product.unit}</span>
                          {product.isArchived && <Badge tone="muted">Archived</Badge>}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-2.5 text-ink-muted">{product.category.name}</td>
                    <td className="px-4 py-2.5 text-right">
                      <Money centavos={product.price} scale="body" />
                    </td>
                    <td className="px-4 py-2.5 text-right">
                      <Money centavos={product.costPrice} scale="body" />
                    </td>
                    <td className="px-4 py-2.5 text-right font-medium">
                      <span
                        className={cn(
                          'font-mono tabular-nums',
                          low && 'font-semibold text-warn',
                          out && 'font-semibold text-owed',
                        )}
                      >
                        {product.stockQty}
                      </span>
                      {/* Low gets a chip too now. Without the row wash a
                          product one sack from running out would otherwise
                          look exactly like a healthy one. */}
                      {(out || low) && (
                        <Badge tone={out ? 'owed' : 'warn'} className="ml-2">
                          {out ? 'Out' : 'Low'}
                        </Badge>
                      )}
                    </td>
                    {/* Stops a click on the menu, or on the archive
                        confirmation, from also opening the view behind it. */}
                    <td
                      className="px-4 py-2.5 text-right"
                      onClick={(event) => event.stopPropagation()}
                    >
                      {confirming ? (
                        <span className="flex flex-wrap items-center justify-end gap-3">
                          <span className="text-sm text-ink">
                            Archive <span className="font-semibold">{product.name}</span>? Past
                            sales keep their record.
                          </span>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleArchive(product)}
                            disabled={pending}
                          >
                            Yes, archive it
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => setConfirmingId(null)}
                            disabled={pending}
                          >
                            Cancel
                          </Button>
                        </span>
                      ) : (
                        <div className="flex justify-end">
                          <RowActionMenu
                            ariaLabel={`Actions for ${product.name}`}
                            items={[
                              { label: 'View', onSelect: () => setViewing(product) },
                              { label: 'Edit', onSelect: () => openEdit(product) },
                              // Only for things that come in bags. A product
                              // already sold by the kilo has no bag to open,
                              // and offering it there would be nonsense.
                              ...(!product.isArchived && /bag|sack|pack/i.test(product.unit)
                                ? [
                                    {
                                      label: 'Open a bag',
                                      disabled: pending,
                                      onSelect: () => handleOpenBag(product),
                                    },
                                  ]
                                : []),
                              product.isArchived
                                ? {
                                    label: 'Restore',
                                    onSelect: () => handleRestore(product),
                                    disabled: pending,
                                  }
                                : {
                                    label: 'Archive',
                                    onSelect: () => setConfirmingId(product.id),
                                    destructive: true,
                                    disabled: pending,
                                  },
                            ]}
                          />
                        </div>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}

      {formOpen && (
        <ProductForm
          categories={categories}
          product={editing}
          onClose={() => setFormOpen(false)}
        />
      )}

      {viewing && (
        <ProductViewModal
          product={viewing}
          onClose={() => setViewing(null)}
          onEdit={() => {
            setEditing(viewing)
            setViewing(null)
            setFormOpen(true)
          }}
        />
      )}
    </div>
  )
}
