import { describe, it, expect, beforeEach } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'

beforeEach(resetDb)

describe('accounts and ledger schema', () => {
  it('creates a customer with defaults', async () => {
    const customer = await prisma.customer.create({ data: { name: 'ROMAN' } })

    expect(customer.phone).toBeNull()
    expect(customer.notes).toBe('')
    expect(customer.isArchived).toBe(false)
    expect(customer.createdAt).toBeInstanceOf(Date)
  })

  it('rejects a duplicate customer name', async () => {
    await prisma.customer.create({ data: { name: 'ROMAN' } })

    await expect(
      prisma.customer.create({ data: { name: 'ROMAN' } }),
    ).rejects.toThrow()
  })

  it('stores a ledger entry with a positive amount and a string type', async () => {
    const customer = await prisma.customer.create({ data: { name: 'BALDO' } })

    const entry = await prisma.ledgerEntry.create({
      data: {
        customerId: customer.id,
        type: 'CHARGE',
        amountCentavos: 157500,
        occurredAt: new Date('2026-07-28T00:00:00'),
      },
    })

    expect(entry.type).toBe('CHARGE')
    expect(entry.amountCentavos).toBe(157500)
    expect(entry.isVoided).toBe(false)
    expect(entry.note).toBe('')
    expect(entry.saleId).toBeNull()
  })

  it('keeps revisions after their entry is edited', async () => {
    const customer = await prisma.customer.create({ data: { name: 'NENA' } })
    const entry = await prisma.ledgerEntry.create({
      data: {
        customerId: customer.id,
        type: 'PAYMENT',
        amountCentavos: 50000,
        occurredAt: new Date('2026-07-28T00:00:00'),
      },
    })

    await prisma.ledgerEntryRevision.create({
      data: {
        ledgerEntryId: entry.id,
        type: entry.type,
        amountCentavos: entry.amountCentavos,
        occurredAt: entry.occurredAt,
        note: entry.note,
        isVoided: entry.isVoided,
      },
    })
    await prisma.ledgerEntry.update({
      where: { id: entry.id },
      data: { amountCentavos: 60000 },
    })

    const revisions = await prisma.ledgerEntryRevision.findMany({
      where: { ledgerEntryId: entry.id },
    })
    expect(revisions).toHaveLength(1)
    expect(revisions[0].amountCentavos).toBe(50000)
  })

  it('allows at most one ledger entry per sale', async () => {
    const customer = await prisma.customer.create({ data: { name: 'TASYO' } })
    const sale = await prisma.sale.create({
      data: { totalAmount: 100000, customerId: customer.id, cashPaidCentavos: 0 },
    })

    await prisma.ledgerEntry.create({
      data: {
        customerId: customer.id,
        type: 'CHARGE',
        amountCentavos: 100000,
        occurredAt: new Date(),
        saleId: sale.id,
      },
    })

    await expect(
      prisma.ledgerEntry.create({
        data: {
          customerId: customer.id,
          type: 'CHARGE',
          amountCentavos: 1,
          occurredAt: new Date(),
          saleId: sale.id,
        },
      }),
    ).rejects.toThrow()
  })

  it('defaults an existing-style sale to no customer and no cash', async () => {
    const sale = await prisma.sale.create({ data: { totalAmount: 42000 } })

    expect(sale.customerId).toBeNull()
    expect(sale.cashPaidCentavos).toBe(0)
  })
})
