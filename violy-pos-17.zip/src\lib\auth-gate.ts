/**
 * The sentinel a guarded action returns when it needs the password again.
 *
 * A plain string on `ActionResult.error` rather than a thrown exception or a
 * new result shape, so every existing call site keeps compiling and keeps
 * working: an action that gates now fails the same way it already failed for
 * any other reason. Screens that have not been taught to prompt simply show
 * this as the error, which is honest — not a silent success.
 *
 * Lives in `lib`, not `server`, because both halves need it: the actions
 * return it and the client component recognises it.
 */
export const NEEDS_PASSWORD = 'NEEDS_PASSWORD'

/** Whether a failed action is asking for the password rather than refusing. */
export function needsPassword(result: { ok: boolean; error?: string }): boolean {
  return !result.ok && result.error === NEEDS_PASSWORD
}

/**
 * How long one password confirmation covers.
 *
 * Five minutes, so voiding three wrong entries in a row asks once rather than
 * three times — the second and third prompts teach her to type the password
 * without reading what she is agreeing to, which is the opposite of the point.
 * Short enough that walking away from the counter closes the window.
 */
export const CONFIRMATION_MINUTES = 5
