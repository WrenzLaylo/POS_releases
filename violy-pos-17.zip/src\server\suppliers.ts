'use server'

import { prisma } from '@/lib/db'
import type { ActionResult } from '@/lib/types'
import { ROUTES } from '@/lib/routes'
import { revalidateRoutes } from './revalidate'

export type SupplierInput = {
  name: string
  contactNumber?: string
  notes?: string
}

/**
 * The supplier already on file under this name, if there is one.
 *
 * Same rule and same reason as products and customers: `@@unique` on the
 * column is not enough, because SQLite compares TEXT case-sensitively unless
 * declared `COLLATE NOCASE`, so "Bataan Farmers" and "bataan farmers" would
 * both be allowed and then split one supplier's deliveries across two files.
 * LIKE narrows in SQL — it IS case-insensitive here — and the exact
 * comparison happens in JS.
 *
 * Archived suppliers count. The answer for one of those is "restore it", not a
 * second file holding half the history.
 */
async function findByName(
  name: string,
  excludeId?: number,
): Promise<{ id: number; name: string; isArchived: boolean } | null> {
  const needle = name.trim().toLowerCase()
  if (!needle) return null

  const candidates = await prisma.supplier.findMany({
    where: { name: { contains: needle } },
    select: { id: true, name: true, isArchived: true },
  })
  return (
    candidates.find(
      (row) => row.name.trim().toLowerCase() === needle && row.id !== excludeId,
    ) ?? null
  )
}

function duplicateMessage(existing: { name: string; isArchived: boolean }): string {
  return existing.isArchived
    ? `${existing.name} is already on the list but archived. Restore it instead of adding it again — its deliveries are on it.`
    : `${existing.name} is already on the list.`
}

function parse(input: SupplierInput): { name: string; contactNumber: string; notes: string } | string {
  const name = input.name.trim()
  if (!name) return 'Supplier name is required.'
  if (name.length > 120) return 'That name is too long.'
  return {
    name,
    contactNumber: (input.contactNumber ?? '').trim(),
    notes: (input.notes ?? '').trim(),
  }
}

export async function listSuppliers(includeArchived = false): Promise<
  { id: number; name: string; contactNumber: string; notes: string; isArchived: boolean }[]
> {
  return prisma.supplier.findMany({
    where: includeArchived ? {} : { isArchived: false },
    select: { id: true, name: true, contactNumber: true, notes: true, isArchived: true },
    orderBy: [{ isArchived: 'asc' }, { name: 'asc' }],
  })
}

export async function createSupplier(input: SupplierInput): Promise<ActionResult<{ id: number }>> {
  const parsed = parse(input)
  if (typeof parsed === 'string') return { ok: false, error: parsed }

  const clash = await findByName(parsed.name)
  if (clash) return { ok: false, error: duplicateMessage(clash) }

  let id: number
  try {
    const created = await prisma.supplier.create({ data: parsed })
    id = created.id
  } catch {
    return { ok: false, error: 'Could not save that supplier.' }
  }

  revalidateRoutes([ROUTES.deliveries])
  return { ok: true, data: { id } }
}

export async function updateSupplier(id: number, input: SupplierInput): Promise<ActionResult> {
  if (!Number.isInteger(id) || id <= 0) return { ok: false, error: 'Supplier id is required.' }

  const parsed = parse(input)
  if (typeof parsed === 'string') return { ok: false, error: parsed }

  const existing = await prisma.supplier.findUnique({ where: { id } })
  if (!existing) return { ok: false, error: 'Supplier not found.' }

  // Excluding itself, or saving a supplier without touching its name would
  // report it as a duplicate of itself.
  const clash = await findByName(parsed.name, id)
  if (clash) return { ok: false, error: duplicateMessage(clash) }

  try {
    await prisma.supplier.update({ where: { id }, data: parsed })
  } catch {
    return { ok: false, error: 'Could not save that supplier.' }
  }

  revalidateRoutes([ROUTES.deliveries])
  return { ok: true, data: undefined }
}

/**
 * Archived, never deleted.
 *
 * Deliveries point at a supplier and are the record of what was bought and
 * what it cost. Deleting the row would either orphan that history or take it
 * with it, and the reason to stop using a supplier is that they stopped
 * supplying — not that the last two years did not happen.
 */
export async function archiveSupplier(id: number): Promise<ActionResult> {
  if (!Number.isInteger(id) || id <= 0) return { ok: false, error: 'Supplier id is required.' }

  const existing = await prisma.supplier.findUnique({ where: { id } })
  if (!existing) return { ok: false, error: 'Supplier not found.' }

  // Refused while money is still owed. Archiving hides it from the payables
  // list, and a debt that disappears because somebody tidied up is the kind of
  // error nobody finds until the supplier asks.
  const unpaid = await prisma.delivery.findFirst({
    where: { supplierId: id, isVoided: false, amountPaidCentavos: { lt: prisma.delivery.fields.totalCostCentavos } },
    select: { id: true },
  })
  if (unpaid) {
    return {
      ok: false,
      error: 'This supplier still has unpaid deliveries. Settle those first, or leave it active.',
    }
  }

  try {
    await prisma.supplier.update({ where: { id }, data: { isArchived: true } })
  } catch {
    return { ok: false, error: 'Could not archive that supplier.' }
  }

  revalidateRoutes([ROUTES.deliveries])
  return { ok: true, data: undefined }
}

export async function restoreSupplier(id: number): Promise<ActionResult> {
  if (!Number.isInteger(id) || id <= 0) return { ok: false, error: 'Supplier id is required.' }

  const existing = await prisma.supplier.findUnique({ where: { id } })
  if (!existing) return { ok: false, error: 'Supplier not found.' }

  try {
    await prisma.supplier.update({ where: { id }, data: { isArchived: false } })
  } catch {
    return { ok: false, error: 'Could not restore that supplier.' }
  }

  revalidateRoutes([ROUTES.deliveries])
  return { ok: true, data: undefined }
}
