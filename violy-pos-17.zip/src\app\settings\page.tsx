import { getStoreProfile } from '@/server/store-profile'
import { countRecoveryCodes, currentUser } from '@/server/auth'
import { getBackupStatus } from '@/lib/backup-run'
import { PageHeader } from '@/components/ui/PageHeader'
import { StoreProfileForm } from './StoreProfileForm'
import { BackupPanel } from './BackupPanel'
import { CounterPanel } from './CounterPanel'
import { DataTransfer } from './DataTransfer'
import { SecurityPanel } from './SecurityPanel'
import { UpdatePanel } from './UpdatePanel'

export const dynamic = 'force-dynamic'

export default async function SettingsPage() {
  // Read on the server so the panel arrives already knowing when the last
  // backup was. A client fetch on mount would show "no backups yet" for a beat
  // first, which is the single most alarming thing this panel could say.
  const [profile, backups, user, codesRemaining] = await Promise.all([
    getStoreProfile(),
    getBackupStatus(),
    currentUser(),
    countRecoveryCodes(),
  ])

  return (
    <PageHeader title="Settings">
      <div className="grid gap-6">
        <StoreProfileForm profile={profile} />
        <CounterPanel />
        {/* Above the backup and data panels on purpose: it is the one that
            decides whether anybody else can reach them. */}
        <SecurityPanel username={user?.username ?? null} codesRemaining={codesRemaining} />
        <BackupPanel status={backups} />
        <DataTransfer />
        <UpdatePanel />
      </div>
    </PageHeader>
  )
}
