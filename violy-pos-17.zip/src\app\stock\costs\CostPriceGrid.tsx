'use client'

import { useMemo, useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import type { ProductWithCategory } from '@/lib/types'
import { recordCostPrices } from '@/server/cost-prices'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { EmptyState } from '@/components/ui/EmptyState'
import { Field } from '@/components/ui/Field'
import { FilterChips } from '@/components/ui/FilterChips'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'
import { Money } from '@/components/ui/Money'
import { formatPeso, parsePesoInput, toPesos } from '@/lib/money'
import { cn } from '@/lib/cn'

/** Only products still missing a cost — the reason this screen exists. */
const MISSING = 'missing'

/**
 * Typing what the shop pays, so the Dashboard stops inventing profit.
 *
 * Every profit figure is `price - cost`, and cost sat at zero on 52 of 55
 * products — so a ₱2,060 sack reported ₱2,060 profit. The only way to fix one
 * was the product's edit dialog, which also holds its name, brand, photo and
 * stock; fifty-two of those is not a thing anybody does, and eight releases went
 * by with nobody doing it.
 *
 * Deliberately the same shape as `StockCountGrid` — one screen, one column of
 * boxes, one Save, blank means untouched. That convention is already learned,
 * and a third pattern for the third bulk-entry screen would be the expensive
 * kind of novelty.
 *
 * What this screen adds over that one is the MARGIN, live, beside every box.
 * A cost is not a figure anyone can sanity-check on its own — ₱1,900 is either
 * fine or ruinous depending on a selling price sitting in another column — and
 * the whole point of collecting these is to find out which. Typing a cost above
 * the shelf price is saved, not blocked, but it goes red and says so.
 */
export function CostPriceGrid({ products }: { products: ProductWithCategory[] }) {
  const router = useRouter()
  const [filter, setFilter] = useState('')
  const [category, setCategory] = useState(MISSING)
  /** productId → what she typed. Absent means this product was left alone. */
  const [costs, setCosts] = useState<Map<number, string>>(new Map())
  const [error, setError] = useState<string | null>(null)
  const [summary, setSummary] = useState<string | null>(null)
  const [pending, startTransition] = useTransition()

  const missingCount = useMemo(
    () => products.filter((product) => product.costPrice === 0).length,
    [products],
  )

  const categories = useMemo(() => {
    const names = new Map<number, string>()
    for (const product of products) names.set(product.categoryId, product.category.name)
    return [
      // First and default, because on a first pass it IS the job. It stops
      // being the default the moment it empties, which is the point.
      ...(missingCount > 0 ? [{ value: MISSING, label: `No cost yet (${missingCount})` }] : []),
      { value: '', label: 'All brands' },
      ...[...names].map(([id, name]) => ({ value: String(id), label: name })),
    ]
  }, [products, missingCount])

  const visible = useMemo(() => {
    const needle = filter.trim().toLowerCase()
    return products.filter((product) => {
      if (category === MISSING && product.costPrice !== 0) return false
      if (category !== '' && category !== MISSING && String(product.categoryId) !== category) {
        return false
      }
      if (needle !== '' && !product.name.toLowerCase().includes(needle)) return false
      return true
    })
  }, [products, filter, category])

  // Counted across the WHOLE catalogue, not just what the filter is showing.
  // She works through one brand, moves to the next, and the tally must not
  // appear to reset — it is one pass, not one per screen.
  const entered = [...costs.entries()]
    .map(([productId, raw]) => ({ productId, value: parsePesoInput(raw) }))
    .filter((row) => row.value !== null)
  const invalid = [...costs.values()].some(
    (raw) => raw.trim() !== '' && parsePesoInput(raw) === null,
  )

  function setCost(productId: number, raw: string) {
    setSummary(null)
    setCosts((previous) => {
      const next = new Map(previous)
      // An emptied box means "leave this one alone", not "costs nothing" — so
      // it is removed rather than kept as a blank string.
      if (raw.trim() === '') next.delete(productId)
      else next.set(productId, raw)
      return next
    })
  }

  function save() {
    setError(null)
    setSummary(null)

    if (invalid) {
      setError('One of the costs is not an amount. Check the boxes outlined in red.')
      return
    }
    if (entered.length === 0) {
      setError('Type at least one cost before saving.')
      return
    }

    startTransition(async () => {
      const result = await recordCostPrices(
        entered.map((row) => ({ productId: row.productId, costCentavos: row.value as number })),
      )
      if (!result.ok) {
        setError(result.error)
        return
      }
      // The boxes clear only on success. After a failure everything she typed
      // is still on screen to try again.
      setCosts(new Map())

      const { changed, belowCost } = result.data
      const saved =
        changed === 0
          ? 'Everything you typed already matched. Nothing changed.'
          : `Saved. ${changed} product${changed === 1 ? '' : 's'} updated.`
      // Named, not counted. "2 products sell below cost" sends her looking;
      // naming them means she already knows where to look.
      setSummary(
        belowCost.length === 0
          ? saved
          : `${saved} Careful: ${belowCost.join(', ')} now sell${
              belowCost.length === 1 ? 's' : ''
            } for less than ${belowCost.length === 1 ? 'it costs' : 'they cost'}.`,
      )
      router.refresh()
    })
  }

  return (
    <Card>
      <div className="mb-4 flex flex-wrap items-end justify-between gap-4">
        <div className="flex flex-wrap items-end gap-4">
          <FilterChips
            label="Show"
            ariaLabel="Filter products"
            options={categories}
            value={category}
            onChange={setCategory}
          />
          <Field label="Find a product">
            <Input
              type="search"
              value={filter}
              onChange={(event) => setFilter(event.target.value)}
              placeholder="Product name"
              className="w-56"
            />
          </Field>
        </div>

        <div className="flex items-end gap-4">
          <div className="text-right">
            <div className="text-xs font-semibold uppercase tracking-wide text-ink-muted">
              Typed
            </div>
            <div className="font-mono text-base font-medium text-ink">
              {entered.length}
              <span className="text-sm text-ink-subtle"> of {products.length}</span>
            </div>
          </div>
          {/* Disabled only when nothing at all has been typed — NOT when what
              was typed fails to parse. A junk value would otherwise leave a
              dead button and no explanation; `save` refuses it in words. */}
          <Button variant="success" onClick={save} disabled={pending || costs.size === 0}>
            {pending ? 'Saving…' : 'Save costs'}
          </Button>
        </div>
      </div>

      {error && <FormError className="mb-3">{error}</FormError>}
      {summary && (
        <p className="mb-3 rounded-control border border-line bg-surface-sunk px-4 py-3 text-sm text-ink">
          {summary}
        </p>
      )}

      {visible.length === 0 ? (
        <EmptyState>
          {category === MISSING
            ? 'Every product has a cost. Nothing left to fill in.'
            : 'No products match that filter.'}
        </EmptyState>
      ) : (
        <div className="overflow-hidden rounded-card border border-line">
          <table className="w-full text-sm">
            <thead className="bg-surface-sunk text-left text-xs uppercase tracking-wide text-ink-muted">
              <tr>
                <th className="px-4 py-3 font-medium">Product</th>
                <th className="px-4 py-3 font-medium">Brand</th>
                <th className="px-4 py-3 text-right font-medium">Sells for</th>
                <th className="px-4 py-3 text-right font-medium">Cost now</th>
                <th className="px-4 py-3 text-right font-medium">New cost</th>
                <th className="px-4 py-3 text-right font-medium">Margin</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {visible.map((product) => {
                const raw = costs.get(product.id) ?? ''
                const typed = parsePesoInput(raw)
                const bad = raw.trim() !== '' && typed === null
                // The margin follows what she is typing, falling back to the
                // stored cost so a row she has not touched still shows where
                // it stands. Zero cost means unknown, so it shows nothing
                // rather than a margin of the whole selling price.
                const effective = typed ?? (product.costPrice > 0 ? product.costPrice : null)
                const margin = effective === null ? null : product.price - effective
                const losing = margin !== null && margin <= 0

                return (
                  <tr key={product.id} className={cn(raw.trim() !== '' && 'bg-accent-soft/40')}>
                    <td className="px-4 py-2">
                      <div className="font-medium text-ink">{product.name}</div>
                      <div className="text-xs text-ink-subtle">{product.unit}</div>
                    </td>
                    <td className="px-4 py-2 text-ink-muted">{product.category.name}</td>
                    <td className="px-4 py-2 text-right">
                      <Money centavos={product.price} scale="body" />
                    </td>
                    <td className="px-4 py-2 text-right font-mono">
                      {product.costPrice > 0 ? (
                        <span className="text-ink-muted">{formatPeso(product.costPrice)}</span>
                      ) : (
                        // The thing she is here to fix, called out rather than
                        // shown as a confident ₱0.00 — which is what made this
                        // look like real data for eight releases.
                        <span className="text-warn">not set</span>
                      )}
                    </td>
                    <td className="px-4 py-2 text-right">
                      <Input
                        inputMode="decimal"
                        value={raw}
                        onChange={(event) => setCost(product.id, event.target.value)}
                        placeholder={product.costPrice > 0 ? String(toPesos(product.costPrice)) : '—'}
                        aria-label={`Cost price for ${product.name}`}
                        aria-invalid={bad || undefined}
                        disabled={pending}
                        className={cn('w-32 text-right tabular-nums', bad && 'border-owed')}
                      />
                    </td>
                    <td className="px-4 py-2 text-right font-mono text-sm">
                      {margin === null ? (
                        <span className="text-ink-subtle">—</span>
                      ) : (
                        // Neutral when healthy: a margin is a computed figure,
                        // not cash that has arrived, so it never goes green.
                        // Red when it is a loss, which is the one thing here
                        // worth interrupting for.
                        <span className={losing ? 'font-medium text-owed' : 'text-ink'}>
                          {formatPeso(margin)}
                        </span>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}

      <p className="mt-4 text-xs text-ink-subtle">
        Leave a box empty for anything you are unsure of — it stays exactly as it is. This changes
        what future sales count as profit; sales already rung up keep the cost they were sold at.
      </p>
    </Card>
  )
}
