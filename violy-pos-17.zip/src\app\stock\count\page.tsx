import Link from 'next/link'
import { listProducts } from '@/server/products'
import { ROUTES } from '@/lib/routes'
import { PageHeader } from '@/components/ui/PageHeader'
import { StockCountGrid } from './StockCountGrid'

export const dynamic = 'force-dynamic'

/**
 * The first thing a shop has to do, and the thing this app never let it do.
 *
 * `listProducts`, not `listAllProducts`: unarchived only, and deliberately
 * unpaged. A stock take is one pass down the shelves, and a grid that dropped
 * what she typed when it turned to page two would be worse than no grid.
 * Fifty-five rows in one table is nothing to render and everything to her.
 */
export default async function StockCountPage() {
  const products = await listProducts()

  return (
    <PageHeader
      title="Count stock"
      actions={
        <Link href={ROUTES.stock} className="text-sm font-medium text-ink-muted hover:text-ink">
          ← Back to stock
        </Link>
      }
    >
      <StockCountGrid products={products} />
    </PageHeader>
  )
}
