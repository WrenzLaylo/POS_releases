import { createHash, randomInt, timingSafeEqual } from 'node:crypto'

/**
 * The one-time codes that get her back in when the password is forgotten.
 *
 * These are read aloud down a phone and printed on paper, which drives every
 * decision here: the alphabet has no characters that can be misheard or
 * misread, the codes are short enough to say in one breath, and they are
 * compared after normalising whatever she actually typed.
 */

/**
 * No 0/O, no 1/I/L, no 5/S, no 8/B, no 2/Z.
 *
 * Every one of those pairs is a code dictated over a bad line and typed back
 * wrong, and a wrong code at that moment reads as "the code does not work" —
 * exactly when nobody has patience for a puzzle.
 */
const ALPHABET = '34679ACDEFGHJKMNPQRTUVWXY'

const GROUP = 4
const GROUPS = 2

/** How many live codes a user holds. Using one mints a replacement. */
export const RECOVERY_CODE_COUNT = 10

/** One code, like `7QK2-4M91`. */
export function generateRecoveryCode(): string {
  const groups: string[] = []
  for (let g = 0; g < GROUPS; g += 1) {
    let group = ''
    // randomInt, not Math.random: this is a credential, and Math.random is
    // predictable enough to enumerate given a couple of known outputs.
    for (let i = 0; i < GROUP; i += 1) group += ALPHABET[randomInt(ALPHABET.length)]
    groups.push(group)
  }
  return groups.join('-')
}

/** A fresh set, for setup or for "generate new codes". */
export function generateRecoveryCodes(count = RECOVERY_CODE_COUNT): string[] {
  return Array.from({ length: count }, generateRecoveryCode)
}

/**
 * What she typed, reduced to what it means.
 *
 * Case, spaces and dashes are all noise — she may type `7qk2 4m91` or
 * `7QK24M91`, and refusing those would be refusing the right code. The letters
 * that were excluded from the alphabet are also mapped in from their
 * lookalikes, so a `0` typed for `O` still lands.
 */
export function normaliseRecoveryCode(raw: string): string {
  return raw
    .toUpperCase()
    .replace(/[^0-9A-Z]/g, '')
    .replace(/0/g, 'O')
    .replace(/[1IL]/g, 'J')
    .replace(/5/g, 'S')
    .replace(/8/g, 'B')
    .replace(/2/g, 'Z')
}

/**
 * Hashed, not stored.
 *
 * A plain SHA-256 rather than scrypt, unlike a password: these are 8 characters
 * from a 25-character alphabet chosen at random, so there is no dictionary to
 * try and no human pattern to exploit — the search space is the whole space.
 * The reason to hash at all is that a code readable out of the database file
 * would be a plaintext credential sitting beside the password we took care not
 * to store.
 */
export function hashRecoveryCode(raw: string): string {
  return createHash('sha256').update(normaliseRecoveryCode(raw), 'utf8').digest('hex')
}

/** Constant-time, for the same reason password checks are. */
export function recoveryCodeMatches(raw: string, storedHash: string): boolean {
  try {
    const a = Buffer.from(hashRecoveryCode(raw), 'hex')
    const b = Buffer.from(storedHash, 'hex')
    if (a.length !== b.length || a.length === 0) return false
    return timingSafeEqual(a, b)
  } catch {
    return false
  }
}
