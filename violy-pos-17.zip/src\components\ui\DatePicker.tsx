'use client'

import { useEffect, useId, useLayoutEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { addMonthsClamped, dayKey, parseDayKey } from '@/lib/dates'
import { Icon } from '@/components/ui/Icon'
import { CONTROL } from '@/components/ui/Input'
import { cn } from '@/lib/cn'

const WEEKDAYS = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'] as const

const MONTH_LABEL = new Intl.DateTimeFormat('en-PH', { month: 'long', year: 'numeric' })
const FULL_DATE = new Intl.DateTimeFormat('en-PH', {
  weekday: 'long',
  month: 'long',
  day: 'numeric',
  year: 'numeric',
})

/** The days shown for a month, padded to whole weeks with the neighbouring
 *  months' days so the grid never has holes in it. */
function monthGrid(month: Date): { date: Date; inMonth: boolean }[] {
  const first = new Date(month.getFullYear(), month.getMonth(), 1)
  const start = new Date(first)
  start.setDate(1 - first.getDay())

  return Array.from({ length: 42 }, (_, index) => {
    const date = new Date(start.getFullYear(), start.getMonth(), start.getDate() + index)
    return { date, inMonth: date.getMonth() === month.getMonth() }
  })
}

/**
 * A date field styled like the rest of the app.
 *
 * Replaces `<input type="date">`, whose popup is drawn by the operating system
 * and cannot be themed — on this warm palette it arrived as a stark blue-and-
 * white panel that belonged to a different application.
 *
 * The VALUE is still a `yyyy-mm-dd` string, identical to the native control,
 * so every caller keeps working and `parseDayKey`/`dayKey` remain the only
 * date parsing in the app.
 *
 * The text box stays typable, and that is not only a convenience. The calendar
 * is portalled to `document.body` to escape the scroll containers it opens
 * inside, which puts it outside `Overlay`'s focus trap when this field sits in
 * a Dialog — Tab will not reach the day buttons there. Typing the date is the
 * complete keyboard path, and Escape closes the calendar either way. Worth
 * knowing before anyone removes the text input in favour of the calendar
 * alone.
 */
export function DatePicker({
  value,
  onChange,
  className,
  disabled,
  'aria-label': ariaLabel,
  id,
}: {
  /** `yyyy-mm-dd`, the same shape `<input type="date">` produces. */
  value: string
  onChange: (value: string) => void
  className?: string
  disabled?: boolean
  'aria-label'?: string
  id?: string
}) {
  const [open, setOpen] = useState(false)
  // Where to draw the calendar, in viewport coordinates.
  const [anchor, setAnchor] = useState<{ left: number; top: number } | null>(null)
  const rootRef = useRef<HTMLDivElement>(null)
  const panelRef = useRef<HTMLDivElement>(null)
  const triggerRef = useRef<HTMLButtonElement>(null)
  const generatedId = useId()
  const dialogId = `${id ?? generatedId}-calendar`

  const selected = parseDayKey(value)
  const [month, setMonth] = useState<Date>(() => selected ?? new Date())

  // Reopening on a different value should land on that value's month, not on
  // whatever month was last browsed to.
  useEffect(() => {
    if (open && selected) setMonth(new Date(selected.getFullYear(), selected.getMonth(), 1))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open])

  // Positioned against the trigger in VIEWPORT coordinates and portalled to
  // `document.body`, rather than absolutely positioned inside this component.
  //
  // Every place this field appears is inside something that scrolls or clips:
  // a Dialog body, a table with `overflow-x-auto`. An absolutely-positioned
  // popup is clipped by the nearest such ancestor, which is exactly how the
  // bulk-payment customer dropdown ended up as a 40px window with its own
  // scrollbar. A portal has no clipping ancestor to be trapped by.
  //
  // `useLayoutEffect` so the position is set before the browser paints; with a
  // plain effect the panel flashes at the top-left corner first.
  useLayoutEffect(() => {
    if (!open) return

    function place() {
      const trigger = rootRef.current
      if (!trigger) return
      const rect = trigger.getBoundingClientRect()
      const height = panelRef.current?.offsetHeight ?? 340
      const width = panelRef.current?.offsetWidth ?? 288

      // Flip above when there is not room below, and pull back inside the
      // right edge rather than opening off-screen.
      const below = window.innerHeight - rect.bottom
      const top =
        below < height + 8 && rect.top > height + 8 ? rect.top - height - 4 : rect.bottom + 4
      const left = Math.max(8, Math.min(rect.left, window.innerWidth - width - 8))
      setAnchor({ left, top })
    }

    place()
    // A scroll or resize while it is open must not leave it behind.
    window.addEventListener('scroll', place, true)
    window.addEventListener('resize', place)
    return () => {
      window.removeEventListener('scroll', place, true)
      window.removeEventListener('resize', place)
    }
  }, [open])

  // `pointerdown`, not `click` — it fires before a click lands on whatever is
  // underneath, which is what `RowActionMenu` and `Select` already do.
  useEffect(() => {
    if (!open) return
    function onPointerDown(event: PointerEvent) {
      const target = event.target as Node
      // The panel is portalled, so it is NOT inside `rootRef` any more and
      // has to be checked separately — otherwise clicking a date would count
      // as clicking outside and close the calendar before it registered.
      if (rootRef.current?.contains(target)) return
      if (panelRef.current?.contains(target)) return
      setOpen(false)
    }
    function onKeyDown(event: KeyboardEvent) {
      if (event.key !== 'Escape') return
      event.preventDefault()
      setOpen(false)
      triggerRef.current?.focus()
    }
    document.addEventListener('pointerdown', onPointerDown)
    document.addEventListener('keydown', onKeyDown)
    return () => {
      document.removeEventListener('pointerdown', onPointerDown)
      document.removeEventListener('keydown', onKeyDown)
    }
  }, [open])

  function choose(date: Date) {
    onChange(dayKey(date))
    setOpen(false)
    triggerRef.current?.focus()
  }

  const todayKey = dayKey(new Date())
  const days = monthGrid(month)

  return (
    // `min-w-[12rem]`, measured rather than estimated. The field holds a
    // ten-character date AND a 2rem button; at `w-40` the input's content box
    // was 106px against the 115px the text needs, and it rendered as
    // "2026-09-". 11rem was still 9px short. 12rem leaves headroom, which
    // matters because the glyph width depends on the font that actually loads.
    // A control that silently truncates the value it exists to show is worse
    // than one that pushes its container.
    <div ref={rootRef} className={cn('relative min-w-[12rem]', className)}>
      <div className={cn(CONTROL, 'flex w-full items-center gap-2 p-0')}>
        {/* Still typable. A calendar you have to click through is slower than
            typing a date you already know, and this is the field she fills in
            while a customer waits. */}
        <input
          id={id}
          type="text"
          inputMode="numeric"
          value={value}
          disabled={disabled}
          aria-label={ariaLabel}
          placeholder="yyyy-mm-dd"
          onChange={(event) => onChange(event.target.value)}
          className="h-full min-w-0 flex-1 bg-transparent px-3 text-sm tabular-nums text-ink outline-none placeholder:text-ink-subtle"
        />
        <button
          ref={triggerRef}
          type="button"
          disabled={disabled}
          aria-label="Choose a date"
          aria-haspopup="dialog"
          aria-expanded={open}
          aria-controls={dialogId}
          onClick={() => setOpen((current) => !current)}
          className="mr-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-control text-ink-muted transition-colors duration-150 hover:bg-surface-sunk hover:text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
        >
          <Icon name="calendar" className="h-4 w-4" />
        </button>
      </div>

      {open &&
        typeof document !== 'undefined' &&
        createPortal(
        <div
          ref={panelRef}
          id={dialogId}
          role="dialog"
          aria-label="Choose a date"
          style={{ left: anchor?.left ?? -9999, top: anchor?.top ?? -9999 }}
          // z-[60]: above `Overlay`'s z-50, since this opens from inside a
          // Dialog and would otherwise render behind the very form that owns
          // it.
          className="fixed z-[60] w-72 rounded-control border border-line bg-surface-raised p-3 shadow-raised"
        >
          <div className="mb-2 flex items-center justify-between">
            <button
              type="button"
              aria-label="Previous month"
              onClick={() => setMonth(addMonthsClamped(month, -1))}
              className="flex h-8 w-8 items-center justify-center rounded-control text-ink-muted hover:bg-surface-sunk hover:text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
            >
              <Icon name="chevron" className="h-4 w-4 rotate-180" />
            </button>
            <span className="text-sm font-semibold text-ink">{MONTH_LABEL.format(month)}</span>
            <button
              type="button"
              aria-label="Next month"
              onClick={() => setMonth(addMonthsClamped(month, 1))}
              className="flex h-8 w-8 items-center justify-center rounded-control text-ink-muted hover:bg-surface-sunk hover:text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
            >
              <Icon name="chevron" className="h-4 w-4" />
            </button>
          </div>

          <div className="grid grid-cols-7 gap-0.5">
            {WEEKDAYS.map((weekday) => (
              <div
                key={weekday}
                aria-hidden="true"
                className="py-1 text-center text-xs font-medium text-ink-subtle"
              >
                {weekday}
              </div>
            ))}

            {days.map(({ date, inMonth }) => {
              const key = dayKey(date)
              const isSelected = key === value
              const isToday = key === todayKey
              return (
                <button
                  key={key}
                  type="button"
                  // The full date, not just the number: "13" read on its own
                  // says nothing about which month is on screen.
                  aria-label={FULL_DATE.format(date)}
                  aria-current={isToday ? 'date' : undefined}
                  aria-pressed={isSelected}
                  onClick={() => choose(date)}
                  className={cn(
                    'flex h-8 items-center justify-center rounded-control text-sm tabular-nums transition-colors duration-150',
                    'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent',
                    isSelected
                      ? 'bg-accent font-semibold text-canvas'
                      : inMonth
                        ? 'text-ink hover:bg-accent-soft hover:text-accent'
                        : 'text-ink-subtle hover:bg-surface-sunk',
                    // Today is outlined rather than filled, so it cannot be
                    // mistaken for the selection.
                    isToday && !isSelected && 'ring-1 ring-inset ring-accent',
                  )}
                >
                  {date.getDate()}
                </button>
              )
            })}
          </div>

          <div className="mt-2 flex items-center justify-between border-t border-line pt-2">
            <button
              type="button"
              onClick={() => choose(new Date())}
              className="rounded-control px-2 py-1 text-sm font-medium text-accent hover:bg-accent-soft focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
            >
              Today
            </button>
            <button
              type="button"
              onClick={() => {
                setOpen(false)
                triggerRef.current?.focus()
              }}
              className="rounded-control px-2 py-1 text-sm text-ink-muted hover:bg-surface-sunk hover:text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
            >
              Close
            </button>
          </div>
        </div>,
        document.body,
      )}
    </div>
  )
}
