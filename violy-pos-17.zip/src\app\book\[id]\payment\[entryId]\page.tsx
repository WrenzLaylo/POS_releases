import Link from 'next/link'
import { notFound } from 'next/navigation'
import { getPaymentReceipt } from '@/server/ledger'
import { getPlan } from '@/server/utang'
import { bookEntry, planInvoice } from '@/lib/routes'
import { DocumentShell } from '@/components/DocumentShell'
import {
  DocumentFacts,
  DocumentFooter,
  DocumentHeading,
} from '@/components/DocumentHeading'
import { documentNumber, DOCUMENT_TITLES } from '@/lib/document-number'
import { getStoreProfile } from '@/server/store-profile'
import { Badge } from '@/components/ui/Badge'
import { Money } from '@/components/ui/Money'

export const dynamic = 'force-dynamic'

/** Proof that a specific payment was received, and what it left owing. */
export default async function PaymentReceiptPage({
  params,
}: {
  params: Promise<{ id: string; entryId: string }>
}) {
  const { id, entryId } = await params
  const customerId = Number(id)
  const paymentId = Number(entryId)
  if (!Number.isInteger(customerId) || !Number.isInteger(paymentId)) notFound()

  const receipt = await getPaymentReceipt(paymentId)
  if (!receipt) notFound()
  if (receipt.customer.id !== customerId) notFound()

  const plan = receipt.planId ? await getPlan(receipt.planId) : null
  const profile = await getStoreProfile()

  return (
    <DocumentShell
      fileName={`${documentNumber('PAYMENT_RECEIPT', receipt.entry.id, receipt.entry.occurredAt)} ${receipt.customer.name}`}
      actions={
        <>
          <Link
            href={bookEntry(customerId)}
            className="inline-flex h-10 items-center justify-center rounded-control border border-line-strong bg-surface-raised px-4 text-sm font-medium text-ink hover:border-accent hover:bg-accent-soft"
          >
            Back to {receipt.customer.name}
          </Link>
          {plan && (
            <Link
              href={planInvoice(customerId, plan.id)}
              className="inline-flex h-10 items-center justify-center rounded-control px-3 text-sm font-medium text-accent hover:bg-accent-soft"
            >
              Open the credit agreement
            </Link>
          )}
          {receipt.entry.isVoided && <Badge tone="muted">VOIDED</Badge>}
        </>
      }
    >
      <DocumentHeading
        profile={profile}
        title={DOCUMENT_TITLES.PAYMENT_RECEIPT}
        reference={documentNumber('PAYMENT_RECEIPT', receipt.entry.id, receipt.entry.occurredAt)}
        issuedAt={receipt.entry.occurredAt}
      />

      <DocumentFacts
        items={[
          {
            label: 'Received from',
            value: (
              <>
                {receipt.customer.name}
                {receipt.customer.phone && (
                  <div className="font-normal text-ink-muted">{receipt.customer.phone}</div>
                )}
              </>
            ),
          },
          {
            label: 'Applied to',
            value: plan
              ? `${documentNumber('CREDIT_AGREEMENT', plan.id, plan.startedAt)} — ${plan.termsLabel}`
              : 'The account balance',
            align: 'end',
          },
        ]}
      />

      <section className="doc-keep-together py-6">
        <div className="flex items-baseline justify-between border-b border-line pb-4">
          <span className="font-semibold text-ink">Amount received</span>
          {/* `in` — the one tone reserved for cash that actually arrived, and
              this document exists precisely because it did. */}
          <Money centavos={receipt.entry.amountCentavos} tone="in" scale="hero" />
        </div>

        <dl className="mt-4 grid gap-2 text-sm">
          <div className="flex justify-between">
            <dt className="text-ink-muted">Balance before this payment</dt>
            <dd><Money centavos={receipt.balanceBeforeCentavos} tone="balance" /></dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-ink-muted">Balance after this payment</dt>
            <dd>
              <Money centavos={receipt.balanceAfterCentavos} tone="balance" scale="strong" />
            </dd>
          </div>
          {plan && (
            <div className="flex justify-between border-t border-line pt-2">
              <dt className="text-ink-muted">Balance on this credit account</dt>
              <dd>
                <Money
                  centavos={plan.outstandingCentavos}
                  tone={plan.outstandingCentavos > 0 ? 'owed' : 'zero'}
                />
              </dd>
            </div>
          )}
          {plan?.nextDue && (
            <div className="flex justify-between">
              <dt className="text-ink-muted">Next instalment</dt>
              <dd>
                <Money centavos={plan.nextDue.amountCentavos} /> due{' '}
                {plan.nextDue.dueAt.toLocaleDateString('en-PH', {
                  month: 'long',
                  day: 'numeric',
                  year: 'numeric',
                })}
              </dd>
            </div>
          )}
        </dl>
      </section>

      {receipt.entry.note && (
        <p className="text-sm text-ink-muted">Note: {receipt.entry.note}</p>
      )}

      {receipt.entry.isVoided && (
        <section className="mt-6 rounded-control border border-owed/40 bg-owed/10 p-4 text-sm text-owed">
          <div className="font-semibold">This payment was voided.</div>
          <div className="mt-1">It no longer counts towards the balance.</div>
        </section>
      )}


      <DocumentFooter>
        This receipt acknowledges the amount stated above as received in full.
      </DocumentFooter>
    </DocumentShell>
  )
}
