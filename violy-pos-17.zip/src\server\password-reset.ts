'use server'

import { randomInt } from 'node:crypto'
import { readFileSync } from 'node:fs'
import path from 'node:path'
import { prisma } from '@/lib/db'
import type { ActionResult } from '@/lib/types'
import { hashPassword, passwordProblem } from '@/lib/password'
import { verifyResetSignature } from '@/lib/reset-signature'
import { ROUTES } from '@/lib/routes'
import { revalidateRoutes } from './revalidate'

/**
 * The way back in that has no list to run out and nothing to keep track of.
 *
 * She asks the app for a code, sends that code to Wrenz, and Wrenz signs it and
 * publishes it to the same public channel the app already fetches updates from.
 * The laptop checks the signature against the public key baked into its own
 * build, exactly as it does for a release.
 *
 * Why routing a password reset through a PUBLIC file is safe: the token names
 * one machine's one-time code, so reading it buys nothing, and forging a token
 * for a different code needs the private key — which is on Wrenz's machine and
 * never on GitHub. Publishing access alone cannot unlock the till.
 *
 * This is the unlimited path. Recovery codes are the offline one, for when the
 * internet is down or the key is not to hand. They fail in different
 * situations, which is the entire reason both exist.
 */

/** No characters that can be misheard down a phone. Same set as the codes. */
const ALPHABET = '34679ACDEFGHJKMNPQRTUVWXY'

/** Short enough to read aloud, long enough not to be guessed inside an hour. */
const CODE_LENGTH = 6

/**
 * How long a request stays open.
 *
 * Long enough for Wrenz to be somewhere with a laptop, short enough that a
 * token scraped off the public repo is worthless by the time anybody could
 * reach the shop with it.
 */
const REQUEST_HOURS = 6

function newCode(): string {
  let code = ''
  for (let i = 0; i < CODE_LENGTH; i += 1) code += ALPHABET[randomInt(ALPHABET.length)]
  return `${code.slice(0, 3)}-${code.slice(3)}`
}

/**
 * Where to look for the signed reset, freshest source first.
 *
 * The API endpoint leads, and that ordering is the whole difference between a
 * feature that works and one nobody trusts. `raw.githubusercontent.com` is
 * edge-cached for about five minutes, and `?t=` busts only the LOCAL cache —
 * so she would press "Check now", be told nothing had arrived, and be looking
 * at a stale copy while Wrenz is on the phone insisting he has sent it. The
 * contents API serves the current file.
 *
 * `raw` stays as a fallback because the API is rate-limited without a token
 * (60 requests an hour), and a reset that fails because of somebody else's
 * traffic would be worse than one that is five minutes late.
 */
function resetUrls(): string[] {
  const channel = JSON.parse(
    readFileSync(path.join(process.cwd(), 'release-channel.json'), 'utf8'),
  ) as { baseUrl: string }
  // https://raw.githubusercontent.com/<owner>/<repo>/<branch>
  const parts = new URL(channel.baseUrl).pathname.split('/').filter(Boolean)
  const api =
    parts.length >= 2
      ? `https://api.github.com/repos/${parts[0]}/${parts[1]}/contents/reset.json`
      : null
  return [...(api ? [api] : []), `${channel.baseUrl}/reset.json`]
}

/**
 * Starts a request and returns the code to read out to Wrenz.
 *
 * Any earlier open request is discarded first. Two live codes would mean a
 * signed token for the older one still works, and she would have no way to tell
 * which of the two she was looking at.
 */
export async function requestReset(): Promise<ActionResult<{ code: string }>> {
  const user = await prisma.appUser.findFirst({ orderBy: { id: 'asc' } })
  if (!user) return { ok: false, error: 'This shop has no login set up yet.' }

  const code = newCode()
  try {
    await prisma.$transaction(async (tx) => {
      await tx.resetRequest.deleteMany({ where: { consumedAt: null } })
      await tx.resetRequest.create({
        data: { code, expiresAt: new Date(Date.now() + REQUEST_HOURS * 60 * 60 * 1000) },
      })
    })
  } catch {
    return { ok: false, error: 'Could not start the request. Try again.' }
  }
  return { ok: true, data: { code } }
}

/**
 * Looks for a signed reset for the open request, and applies it.
 *
 * Every check is a refusal, in this order: there must be an open request, it
 * must not have expired, the published token must be FOR THIS CODE, it must
 * carry its own unexpired deadline, and the signature must verify. A token that
 * fails any of them is treated identically to no token at all.
 *
 * The cache is bypassed with a timestamp because raw.githubusercontent.com
 * serves a five-minute-old copy otherwise, and five minutes of "Wrenz has not
 * sent it yet" while he is on the phone saying he has is the difference between
 * a feature that works and one nobody trusts.
 */
export async function checkForReset(
  newPassword: string,
): Promise<ActionResult<{ applied: boolean }>> {
  const user = await prisma.appUser.findFirst({ orderBy: { id: 'asc' } })
  if (!user) return { ok: false, error: 'This shop has no login set up yet.' }

  const request = await prisma.resetRequest.findFirst({
    where: { consumedAt: null },
    orderBy: { id: 'desc' },
  })
  if (!request) return { ok: false, error: 'Ask for a code first.' }
  if (request.expiresAt.getTime() <= Date.now()) {
    return { ok: false, error: 'That code has expired. Ask for a new one.' }
  }

  // Checked BEFORE the network call: a password the app would refuse anyway is
  // not worth a round trip, and finding out afterwards would consume the token.
  const problem = passwordProblem(newPassword)
  if (problem) return { ok: false, error: problem }

  let token: { code?: unknown; expiresAt?: unknown; signature?: unknown } | null = null
  let reached = false

  for (const url of resetUrls()) {
    try {
      const response = await fetch(`${url}?t=${Date.now()}`, {
        cache: 'no-store',
        // Asks the contents API for the file itself rather than its metadata
        // envelope. Harmless on the raw URL, which ignores it.
        headers: { Accept: 'application/vnd.github.raw' },
        signal: AbortSignal.timeout(15_000),
      })
      // A 404 is the NORMAL state: it is what "Wrenz has not sent one yet"
      // looks like, and it is not an error worth alarming her with.
      if (response.status === 404) {
        reached = true
        break
      }
      if (!response.ok) continue
      token = await response.json()
      reached = true
      break
    } catch {
      // Try the next source rather than giving up on the first hiccup.
    }
  }

  if (!reached) return { ok: false, error: 'Could not reach the internet. Try again.' }
  if (!token) return { ok: true, data: { applied: false } }

  const code = typeof token.code === 'string' ? token.code : ''
  const expiresAt = typeof token.expiresAt === 'string' ? token.expiresAt : ''
  const signature = typeof token.signature === 'string' ? token.signature : ''

  // Not this machine's request. Someone else's reset, or an old one still
  // sitting in the repository.
  if (code.toUpperCase() !== request.code.toUpperCase()) {
    return { ok: true, data: { applied: false } }
  }
  // The token carries its own deadline, so a signed one cannot be replayed
  // forever even if the request it names were somehow still open.
  const deadline = Date.parse(expiresAt)
  if (!Number.isFinite(deadline) || deadline <= Date.now()) {
    return { ok: false, error: 'That reset has expired. Ask Wrenz for a new one.' }
  }
  if (!verifyResetSignature({ code, expiresAt }, signature)) {
    return {
      ok: false,
      error: 'That reset could not be verified as genuine and was NOT used.',
    }
  }

  try {
    await prisma.$transaction(async (tx) => {
      await tx.resetRequest.update({
        where: { id: request.id },
        data: { consumedAt: new Date() },
      })
      await tx.appUser.update({
        where: { id: user.id },
        data: { passwordHash: hashPassword(newPassword) },
      })
      // Whoever knew the old password should not still be inside.
      await tx.appSession.deleteMany({ where: { userId: user.id } })
    })
  } catch {
    return { ok: false, error: 'Could not set the new password. Nothing was changed.' }
  }

  revalidateRoutes([ROUTES.settings], { layout: true })
  return { ok: true, data: { applied: true } }
}
