import type { ReactNode } from 'react'
import { cn } from '@/lib/cn'

/** A row on the ledger tape. Hairline-separated, no card chrome. */
export function TapeRow({
  children,
  className,
}: {
  children: ReactNode
  className?: string
}) {
  return (
    <div
      className={cn(
        'grid grid-cols-[1fr_auto] items-baseline gap-3 border-b border-line py-2 last:border-b-0',
        className,
      )}
    >
      {children}
    </div>
  )
}

/** A cell on the tape. `end` alignment uses tabular numerals so columns of
 *  figures line up down the page. */
export function TapeCell({
  children,
  align = 'start',
  className,
}: {
  children: ReactNode
  align?: 'start' | 'end'
  className?: string
}) {
  return (
    <div
      className={cn(
        'min-w-0 text-sm',
        align === 'end' ? 'text-right font-mono tabular-nums' : 'text-ink',
        className,
      )}
    >
      {children}
    </div>
  )
}
