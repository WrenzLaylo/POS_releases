'use client'

import {
  Children,
  isValidElement,
  useEffect,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type KeyboardEvent as ReactKeyboardEvent,
  type OptionHTMLAttributes,
  type ReactNode,
  type Ref,
} from 'react'
import { createPortal } from 'react-dom'
import { cn } from '@/lib/cn'
import { CONTROL } from './Input'
import { Icon } from './Icon'

/** What every caller's `onChange` actually reads — see the five callers
 *  (`HistoryFilters`, `ProductForm`, `BulkPaymentGrid`; `InventoryFilters`
 *  and `CustomerForm` don't use `Select` today) for the contract this has
 *  to satisfy: `event.target.value`, a string, and nothing more. */
export type SelectChangeEvent = {
  target: { value: string; name?: string }
}

export type SelectProps = {
  /** `<option value="...">Label</option>` children — read directly, same as
   *  a native select, rather than a separate `options` prop. An `<option>`
   *  with no `value` attribute falls back to its text, matching the browser. */
  children: ReactNode
  value?: string | number
  defaultValue?: string | number
  onChange?: (event: SelectChangeEvent) => void
  name?: string
  id?: string
  className?: string
  disabled?: boolean
  'aria-label'?: string
  ref?: Ref<HTMLButtonElement>
}

type OptionData = { value: string; label: string; disabled: boolean }

function textOf(node: ReactNode): string {
  if (node === null || node === undefined || typeof node === 'boolean') return ''
  if (typeof node === 'string' || typeof node === 'number') return String(node)
  if (Array.isArray(node)) return node.map(textOf).join('')
  if (isValidElement(node)) return textOf((node.props as { children?: ReactNode }).children)
  return ''
}

/** Mirrors how a browser reads a native `<select>`'s children: only
 *  `<option>` elements count, and a missing `value` attribute falls back to
 *  the option's own text (see `primitives.test.tsx`'s bare `<option>All</option>`). */
function readOptions(children: ReactNode): OptionData[] {
  const options: OptionData[] = []
  Children.forEach(children, (child) => {
    if (!isValidElement(child) || child.type !== 'option') return
    const optionProps = child.props as OptionHTMLAttributes<HTMLOptionElement>
    const label = textOf(optionProps.children)
    const value = optionProps.value !== undefined ? String(optionProps.value) : label
    options.push({ value, label, disabled: !!optionProps.disabled })
  })
  return options
}

/**
 * A themed replacement for the native `<select>`, whose OS-drawn popup
 * cannot be styled and shows up as a white list with a blue highlight on
 * this dark theme — see the "Custom dropdown" section of the counter/stock
 * design doc. The public API is unchanged: children are `<option>`s, and
 * `value`/`defaultValue`/`onChange` behave the same as before, so every
 * existing caller works without modification.
 *
 * The trigger is `role="combobox"` (matching a native select's implicit
 * role, which `primitives.test.tsx` depends on) with `aria-haspopup`,
 * `aria-expanded`, `aria-controls`, and `aria-activedescendant` — the
 * ARIA "select-only combobox" pattern. Focus never leaves the trigger:
 * arrow keys move the *active* (highlighted) option via
 * `aria-activedescendant`, distinct from the *selected* (committed) option
 * marked by `aria-selected` and the check icon, until Enter/Space commits
 * the active option. This is also why `role="listbox"` genuinely lands on
 * an element in the document while open, which is what lets
 * `CatalogColumn`'s overlay guard (`[role="dialog"], [role="listbox"]`)
 * suppress catalog shortcuts without any change on that side.
 *
 * A caller that passes `name` gets a hidden native `<input type="hidden">`
 * mirroring the current value, so plain native form submission
 * (`HistoryFilters`) and React 19 form actions (`ProductForm`'s
 * `action={handleSubmit}`) keep collecting it via `FormData` exactly as a
 * real `<select>` would. `BulkPaymentGrid` never passes `name`, so no
 * hidden input is rendered there.
 */
export function Select({
  children,
  value,
  defaultValue,
  onChange,
  name,
  id,
  className,
  disabled,
  ref,
  ...rest
}: SelectProps) {
  const ariaLabel = rest['aria-label']
  const options = readOptions(children)
  const isControlled = value !== undefined

  const [uncontrolledValue, setUncontrolledValue] = useState<string>(() =>
    defaultValue !== undefined ? String(defaultValue) : (options[0]?.value ?? ''),
  )
  const currentValue = isControlled ? String(value) : uncontrolledValue

  const [open, setOpen] = useState(false)
  const [activeIndex, setActiveIndex] = useState(0)

  const rootRef = useRef<HTMLDivElement>(null)
  const triggerRef = useRef<HTMLButtonElement>(null)
  const panelRef = useRef<HTMLUListElement>(null)
  // Where to draw the list, in viewport coordinates.
  const [anchor, setAnchor] = useState<{ left: number; top: number; width: number } | null>(null)
  const optionRefs = useRef<Array<HTMLLIElement | null>>([])
  const typeaheadRef = useRef({ query: '', lastTime: 0 })

  const generatedId = useId()
  const listboxId = `${id ?? generatedId}-listbox`

  const selectedIndex = options.findIndex((option) => option.value === currentValue)
  const selectedOption = selectedIndex >= 0 ? options[selectedIndex] : undefined

  function setTriggerRef(element: HTMLButtonElement | null) {
    triggerRef.current = element
    if (typeof ref === 'function') ref(element)
    else if (ref) (ref as { current: HTMLButtonElement | null }).current = element
  }

  // Positioned against the trigger in VIEWPORT coordinates and portalled to
  // `document.body`, rather than absolutely positioned inside this component.
  //
  // An absolutely-positioned popup is clipped by the nearest ancestor that
  // scrolls, and this control lives inside such ancestors everywhere: a Dialog
  // body, the delivery form's `overflow-x-auto` line table — where a list of
  // 55 products rendered as a single-row window with its own scrollbar, which
  // is not a list anybody can choose from. `DatePicker` was moved to a portal
  // for exactly this, and the bulk-payment dropdown before it. This is the
  // third time; fixing the primitive is what stops a fourth.
  //
  // Note `overflow-x-auto` alone is enough to cause it: CSS computes the other
  // axis from `visible` to `auto` when one axis is not visible, so a
  // horizontally-scrolling table clips vertically too.
  //
  // `useLayoutEffect` so the position is set before the browser paints; with a
  // plain effect the list flashes at the top-left corner first.
  useLayoutEffect(() => {
    if (!open) return

    function place() {
      const trigger = rootRef.current
      if (!trigger) return
      const rect = trigger.getBoundingClientRect()
      const height = panelRef.current?.offsetHeight ?? 240

      // Flip above when there is not room below, so a control near the bottom
      // of the screen still shows its options.
      const below = window.innerHeight - rect.bottom
      const top =
        below < height + 8 && rect.top > height + 8 ? rect.top - height - 4 : rect.bottom + 4
      // Matches the trigger's width, as a select should — and pulled back
      // inside the right edge rather than opening off-screen.
      const left = Math.max(8, Math.min(rect.left, window.innerWidth - rect.width - 8))
      setAnchor({ left, top, width: rect.width })
    }

    place()
    // A scroll or resize while it is open must not leave it behind.
    window.addEventListener('scroll', place, true)
    window.addEventListener('resize', place)
    return () => {
      window.removeEventListener('scroll', place, true)
      window.removeEventListener('resize', place)
    }
  }, [open])

  // Outside pointer-down closes, same as RowActionMenu/Popover — pointerdown
  // rather than click, so it fires before an option's own onClick.
  //
  // The panel is checked SEPARATELY from the root now that it is portalled: it
  // is no longer a DOM descendant of the wrapper, so `rootRef.contains` alone
  // would read every click on an option as a click outside and close the list
  // before the option's own handler ever ran.
  useEffect(() => {
    if (!open) return
    function handlePointerDown(event: PointerEvent) {
      const target = event.target as Node
      if (rootRef.current?.contains(target)) return
      if (panelRef.current?.contains(target)) return
      setOpen(false)
    }
    document.addEventListener('pointerdown', handlePointerDown)
    return () => document.removeEventListener('pointerdown', handlePointerDown)
  }, [open])

  useEffect(() => {
    if (!open) return
    // Guarded with `?.()`, not just `?.` — jsdom doesn't implement
    // scrollIntoView at all, so the method itself is undefined there.
    optionRefs.current[activeIndex]?.scrollIntoView?.({ block: 'nearest' })
  }, [open, activeIndex])

  function commit(option: OptionData) {
    if (!isControlled) setUncontrolledValue(option.value)
    onChange?.({ target: { value: option.value, name } })
  }

  function openAt(index: number) {
    setActiveIndex(Math.max(0, index))
    setOpen(true)
  }

  function moveActive(delta: number) {
    setActiveIndex((current) => Math.min(Math.max(current + delta, 0), options.length - 1))
  }

  function jumpToEdge(edge: 'first' | 'last') {
    const enabled = options
      .map((option, index) => ({ option, index }))
      .filter(({ option }) => !option.disabled)
    if (enabled.length === 0) return
    setActiveIndex(edge === 'first' ? enabled[0].index : enabled[enabled.length - 1].index)
  }

  // Typing a letter jumps to the next option starting with it — this is a
  // real requirement, not a nicety: HistoryFilters' "Customer" select is a
  // long alphabetical list, and typing "M" to reach "MANG KIKO" is how an
  // operator actually uses it. Repeating the same character cycles through
  // every option starting with that letter, matching a native select.
  function typeahead(char: string) {
    if (options.length === 0) return
    const now = Date.now()
    const state = typeaheadRef.current
    const continued = now - state.lastTime < 500
    const query = continued ? state.query + char : char
    state.query = query
    state.lastTime = now

    const normalized = query.toLowerCase()
    const repeatingChar = normalized.length > 1 && normalized.split('').every((c) => c === normalized[0])
    const needle = repeatingChar ? normalized[0] : normalized
    const startAt = query.length === 1 || repeatingChar ? (activeIndex + 1) % options.length : 0

    for (let offset = 0; offset < options.length; offset++) {
      const index = (startAt + offset) % options.length
      const option = options[index]
      if (option.disabled) continue
      if (option.label.toLowerCase().startsWith(needle)) {
        setActiveIndex(index)
        if (!open) setOpen(true)
        return
      }
    }
  }

  function handleTriggerKeyDown(event: ReactKeyboardEvent<HTMLButtonElement>) {
    if (disabled) return

    if (!open) {
      if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
        event.preventDefault()
        openAt(selectedIndex >= 0 ? selectedIndex : 0)
        return
      }
    } else {
      switch (event.key) {
        case 'ArrowDown':
          event.preventDefault()
          moveActive(1)
          return
        case 'ArrowUp':
          event.preventDefault()
          moveActive(-1)
          return
        case 'Home':
          event.preventDefault()
          jumpToEdge('first')
          return
        case 'End':
          event.preventDefault()
          jumpToEdge('last')
          return
        case 'Enter':
        case ' ': {
          event.preventDefault()
          const option = options[activeIndex]
          if (option && !option.disabled) commit(option)
          setOpen(false)
          return
        }
        case 'Escape':
          event.preventDefault()
          setOpen(false)
          triggerRef.current?.focus()
          return
        case 'Tab':
          setOpen(false)
          return
        default:
          break
      }
    }

    if (event.key.length === 1 && !event.ctrlKey && !event.altKey && !event.metaKey) {
      event.preventDefault()
      typeahead(event.key)
    }
  }

  const activeOptionId = options[activeIndex] ? `${listboxId}-option-${activeIndex}` : undefined

  return (
    <div ref={rootRef} className="relative">
      <button
        ref={setTriggerRef}
        type="button"
        id={id}
        role="combobox"
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-controls={listboxId}
        aria-activedescendant={open ? activeOptionId : undefined}
        aria-label={ariaLabel}
        disabled={disabled}
        className={cn(CONTROL, 'flex w-full items-center justify-between gap-2 text-left', className)}
        onClick={() => {
          if (disabled) return
          setOpen((current) => {
            const next = !current
            if (next) setActiveIndex(selectedIndex >= 0 ? selectedIndex : 0)
            return next
          })
        }}
        onKeyDown={handleTriggerKeyDown}
      >
        <span className="truncate">{selectedOption?.label ?? ''}</span>
        <Icon name="chevron-down" className="h-4 w-4 shrink-0 text-ink-muted" />
      </button>

      {/* Native form participation: a controlled caller (BulkPaymentGrid)
          never passes `name`, so nothing renders here for it. A caller that
          does — HistoryFilters' plain GET form, ProductForm's
          `action={handleSubmit}` — gets a hidden input `FormData` picks up
          exactly like it would a real select. */}
      {name && <input type="hidden" name={name} value={currentValue} readOnly />}

      {open &&
        typeof document !== 'undefined' &&
        createPortal(
        <ul
          ref={panelRef}
          id={listboxId}
          role="listbox"
          aria-label={ariaLabel}
          style={{
            left: anchor?.left ?? -9999,
            top: anchor?.top ?? -9999,
            width: anchor?.width,
          }}
          // z-[60]: above `Overlay`'s z-50, since this opens from inside a
          // Dialog and would otherwise render behind the very form that owns
          // it. Same reasoning as `DatePicker`.
          className="fixed z-[60] max-h-60 overflow-y-auto rounded-control border border-line bg-surface-raised p-1 shadow-raised"
        >
          {options.map((option, index) => {
            const active = index === activeIndex
            const selected = option.value === currentValue
            return (
              <li
                key={option.value}
                id={`${listboxId}-option-${index}`}
                ref={(element) => {
                  optionRefs.current[index] = element
                }}
                role="option"
                aria-selected={selected}
                aria-disabled={option.disabled || undefined}
                onMouseEnter={() => !option.disabled && setActiveIndex(index)}
                onClick={() => {
                  if (option.disabled) return
                  commit(option)
                  setOpen(false)
                  triggerRef.current?.focus()
                }}
                className={cn(
                  'flex h-10 items-center gap-2 rounded-control px-3 text-sm',
                  option.disabled
                    ? 'cursor-not-allowed opacity-50'
                    : 'cursor-pointer hover:bg-accent-soft hover:text-accent',
                  active ? 'bg-accent-soft text-accent' : 'text-ink',
                )}
              >
                <Icon name="check" className={cn('h-4 w-4 shrink-0', selected ? 'opacity-100' : 'opacity-0')} />
                <span className="truncate">{option.label}</span>
              </li>
            )
          })}
        </ul>,
        document.body,
      )}
    </div>
  )
}
