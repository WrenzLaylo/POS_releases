import { describe, expect, it } from 'vitest'
import { addMonthsClamped, dayKey } from './dates'
import {
  applyPayments,
  buildSchedule,
  describeTerms,
  nextDue,
  overdueInstallments,
  validateTerms,
  type InterestMethod,
  type PlanTerms,
} from './utang'

const JAN_15 = new Date(2026, 0, 15)

function terms(overrides: Partial<PlanTerms> = {}): PlanTerms {
  return {
    principalCentavos: 300_000, // ₱3,000
    interestMethod: 'FLAT_MONTHLY',
    interestRateBps: 500, // 5%
    termMonths: 3,
    startedAt: JAN_15,
    ...overrides,
  }
}

describe('addMonthsClamped', () => {
  it('clamps to the last day of a shorter month', () => {
    // The bug this exists to prevent: setMonth alone rolls 31 Jan into 3 Mar.
    expect(dayKey(addMonthsClamped(new Date(2026, 0, 31), 1))).toBe('2026-02-28')
    expect(dayKey(addMonthsClamped(new Date(2026, 0, 31), 3))).toBe('2026-04-30')
    expect(dayKey(addMonthsClamped(new Date(2026, 4, 31), 1))).toBe('2026-06-30')
  })

  it('handles leap years', () => {
    expect(dayKey(addMonthsClamped(new Date(2028, 0, 31), 1))).toBe('2028-02-29')
    expect(dayKey(addMonthsClamped(new Date(2027, 0, 31), 1))).toBe('2027-02-28')
  })

  it('leaves a day that exists in the target month alone', () => {
    expect(dayKey(addMonthsClamped(new Date(2026, 0, 15), 1))).toBe('2026-02-15')
    expect(dayKey(addMonthsClamped(new Date(2026, 11, 15), 1))).toBe('2027-01-15')
  })
})

describe('the three interest methods, worked', () => {
  it('FLAT_MONTHLY multiplies the rate by the term', () => {
    const schedule = buildSchedule(terms())
    expect(schedule.interestCentavos).toBe(45_000) // ₱450
    expect(schedule.totalCentavos).toBe(345_000) // ₱3,450
    expect(schedule.installments.map((i) => i.amountCentavos)).toEqual([
      115_000, 115_000, 115_000, // ₱1,150 each
    ])
  })

  it('FLAT_ONCE charges the rate once regardless of term', () => {
    const schedule = buildSchedule(terms({ interestMethod: 'FLAT_ONCE' }))
    expect(schedule.interestCentavos).toBe(15_000) // ₱150
    expect(schedule.totalCentavos).toBe(315_000) // ₱3,150
    expect(schedule.installments.map((i) => i.amountCentavos)).toEqual([
      105_000, 105_000, 105_000, // ₱1,050 each
    ])
  })

  it('REDUCING charges interest only on what is still outstanding', () => {
    const schedule = buildSchedule(terms({ interestMethod: 'REDUCING' }))
    // Payment = 3000 × 0.05 / (1 − 1.05⁻³) = ₱1,101.6257, so ₱1,101.63.
    // The final instalment is a centavo lighter because it clears the exact
    // remaining balance instead of charging the rounded payment again.
    expect(schedule.installments.map((i) => i.amountCentavos)).toEqual([
      110_163, 110_163, 110_162,
    ])
    expect(schedule.totalCentavos).toBe(330_488) // ₱3,304.88
    expect(schedule.interestCentavos).toBe(30_488) // ₱304.88

    // Interest falls every month as the balance does; principal rises.
    const interest = schedule.installments.map((i) => i.interestCentavos)
    expect(interest[0]).toBeGreaterThan(interest[1])
    expect(interest[1]).toBeGreaterThan(interest[2])
    expect(schedule.installments[0].interestCentavos).toBe(15_000) // 5% of ₱3,000
  })

  it('charges nothing at a zero rate, whichever method is chosen', () => {
    for (const method of ['FLAT_MONTHLY', 'FLAT_ONCE', 'REDUCING'] as InterestMethod[]) {
      const schedule = buildSchedule(terms({ interestMethod: method, interestRateBps: 0 }))
      expect(schedule.interestCentavos, method).toBe(0)
      expect(schedule.totalCentavos, method).toBe(300_000)
      expect(schedule.installments.map((i) => i.amountCentavos), method).toEqual([
        100_000, 100_000, 100_000,
      ])
    }
  })

  it('treats a one-month term as the whole thing at one due date', () => {
    const schedule = buildSchedule(terms({ termMonths: 1 }))
    expect(schedule.installments).toHaveLength(1)
    expect(schedule.installments[0].amountCentavos).toBe(schedule.totalCentavos)
    expect(dayKey(schedule.installments[0].dueAt)).toBe('2026-02-15')
  })
})

describe('due dates', () => {
  it('puts the first instalment one month after the start', () => {
    const schedule = buildSchedule(terms())
    expect(schedule.installments.map((i) => dayKey(i.dueAt))).toEqual([
      '2026-02-15',
      '2026-03-15',
      '2026-04-15',
    ])
  })

  it('does not let a short month push every later date out', () => {
    // Each due date is computed from the START, not from the previous due
    // date, so February's clamp cannot compound into March and April.
    const schedule = buildSchedule(terms({ startedAt: new Date(2026, 0, 31) }))
    expect(schedule.installments.map((i) => dayKey(i.dueAt))).toEqual([
      '2026-02-28',
      '2026-03-31',
      '2026-04-30',
    ])
  })
})

describe('the rounding invariants', () => {
  const methods: InterestMethod[] = ['FLAT_MONTHLY', 'FLAT_ONCE', 'REDUCING']

  it('always splits into instalments that sum exactly to the total', () => {
    for (const interestMethod of methods) {
      // Principals chosen to divide badly: 1000.01, 333.33, 7.77, 99999.99.
      for (const principalCentavos of [100_001, 33_333, 777, 9_999_999, 1, 100_000]) {
        for (const interestRateBps of [0, 1, 175, 500, 1_250, 10_000]) {
          for (const termMonths of [1, 2, 3, 7, 12, 13, 60]) {
            const schedule = buildSchedule(
              terms({ principalCentavos, interestMethod, interestRateBps, termMonths }),
            )
            const label = `${interestMethod} ₱${principalCentavos} @${interestRateBps}bps × ${termMonths}`

            const summed = schedule.installments.reduce((t, i) => t + i.amountCentavos, 0)
            expect(summed, label).toBe(schedule.totalCentavos)

            const principalSum = schedule.installments.reduce(
              (t, i) => t + i.principalCentavos,
              0,
            )
            expect(principalSum, label).toBe(principalCentavos)

            const interestSum = schedule.installments.reduce(
              (t, i) => t + i.interestCentavos,
              0,
            )
            expect(interestSum, label).toBe(schedule.interestCentavos)

            expect(schedule.installments, label).toHaveLength(termMonths)
            for (const installment of schedule.installments) {
              expect(Number.isInteger(installment.amountCentavos), label).toBe(true)
              expect(installment.amountCentavos, label).toBeGreaterThanOrEqual(0)
              expect(
                installment.principalCentavos + installment.interestCentavos,
                label,
              ).toBe(installment.amountCentavos)
            }
          }
        }
      }
    }
  })

  it('never charges less than the principal borrowed', () => {
    for (const interestMethod of methods) {
      for (const interestRateBps of [0, 250, 10_000]) {
        const schedule = buildSchedule(terms({ interestMethod, interestRateBps }))
        expect(schedule.totalCentavos).toBeGreaterThanOrEqual(schedule.principalCentavos)
        expect(schedule.interestCentavos).toBeGreaterThanOrEqual(0)
      }
    }
  })
})

describe('validateTerms', () => {
  it('accepts sane terms', () => {
    expect(validateTerms(terms())).toBeNull()
  })

  it.each([
    ['zero principal', { principalCentavos: 0 }],
    ['negative principal', { principalCentavos: -1 }],
    ['fractional principal', { principalCentavos: 10.5 }],
    ['a rate over 100%', { interestRateBps: 10_001 }],
    ['a negative rate', { interestRateBps: -1 }],
    ['a zero term', { termMonths: 0 }],
    ['a term past the ceiling', { termMonths: 61 }],
  ])('rejects %s', (_label, override) => {
    expect(validateTerms(terms(override))).not.toBeNull()
  })
})

describe('describeTerms', () => {
  it('says how the interest works, in words', () => {
    expect(describeTerms({ interestMethod: 'FLAT_MONTHLY', interestRateBps: 500, termMonths: 3 }))
      .toBe('3 months at 5% per month, flat')
    expect(describeTerms({ interestMethod: 'FLAT_ONCE', interestRateBps: 1_000, termMonths: 6 }))
      .toBe('6 months at 10% one-time')
    expect(describeTerms({ interestMethod: 'REDUCING', interestRateBps: 250, termMonths: 12 }))
      .toBe('12 months at 2.5% per month on the balance')
  })

  it('says "no interest" rather than "at 0%"', () => {
    expect(describeTerms({ interestMethod: 'FLAT_MONTHLY', interestRateBps: 0, termMonths: 1 }))
      .toBe('1 month, no interest')
  })
})

describe('applying payments to a schedule', () => {
  const schedule = buildSchedule(terms()) // 3 × ₱1,150

  it('fills instalments oldest first', () => {
    const statuses = applyPayments(schedule.installments, 150_000) // ₱1,500
    expect(statuses[0].isSettled).toBe(true)
    expect(statuses[0].paidCentavos).toBe(115_000)
    expect(statuses[1].isSettled).toBe(false)
    expect(statuses[1].paidCentavos).toBe(35_000) // the ₱350 spillover
    expect(statuses[2].paidCentavos).toBe(0)
  })

  it('settles everything when the plan is paid off', () => {
    const statuses = applyPayments(schedule.installments, 345_000)
    expect(statuses.every((s) => s.isSettled)).toBe(true)
    expect(nextDue(statuses)).toBeNull()
  })

  it('does not let an overpayment settle more than exists', () => {
    const statuses = applyPayments(schedule.installments, 999_999)
    expect(statuses.reduce((t, s) => t + s.paidCentavos, 0)).toBe(345_000)
  })

  it('names the first unsettled instalment as next due', () => {
    const statuses = applyPayments(schedule.installments, 115_000)
    expect(nextDue(statuses)?.sequence).toBe(2)
  })
})

describe('overdue instalments', () => {
  const schedule = buildSchedule(terms()) // due 15 Feb, 15 Mar, 15 Apr

  it('counts only unpaid instalments whose date has passed', () => {
    const statuses = applyPayments(schedule.installments, 0)
    expect(overdueInstallments(statuses, new Date(2026, 2, 20)).map((i) => i.sequence)).toEqual([
      1, 2,
    ])
  })

  it('ignores instalments already covered', () => {
    const statuses = applyPayments(schedule.installments, 115_000)
    expect(overdueInstallments(statuses, new Date(2026, 2, 20)).map((i) => i.sequence)).toEqual([2])
  })

  it('reports nothing before the first due date', () => {
    const statuses = applyPayments(schedule.installments, 0)
    expect(overdueInstallments(statuses, new Date(2026, 0, 20))).toEqual([])
  })
})
