import { generateKeyPairSync, sign, verify } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { describe, expect, it } from 'vitest'
import { canonicalReset, type SignedReset } from './reset-signature'

/**
 * A throwaway key per run. The production public key is compiled into
 * `update-public-key.ts`, so nothing here can sign something the app would
 * accept — which is the point. What is under test is the arithmetic: that a
 * signature over the canonical form verifies, and that changing any signed
 * field breaks it.
 */
const KEYS = generateKeyPairSync('ed25519')

const FIELDS: SignedReset = {
  code: '4K7-Q92',
  expiresAt: '2026-08-21T20:00:00.000Z',
}

function signWith(fields: SignedReset): string {
  // Ed25519 takes a NULL algorithm. Passing 'sha256' throws — the curve
  // carries its own hash — and it is the usual way to get this wrong.
  return sign(null, Buffer.from(canonicalReset(fields), 'utf8'), KEYS.privateKey).toString('base64')
}

function verifyWith(fields: SignedReset, signature: string): boolean {
  try {
    return verify(
      null,
      Buffer.from(canonicalReset(fields), 'utf8'),
      KEYS.publicKey,
      Buffer.from(signature, 'base64'),
    )
  } catch {
    return false
  }
}

describe('the canonical form', () => {
  it('is exactly two lines, code then expiry', () => {
    const NEWLINE = String.fromCharCode(10)
    expect(canonicalReset(FIELDS)).toBe(
      ['reset:4K7-Q92', 'expires:2026-08-21T20:00:00.000Z'].join(NEWLINE),
    )
  })

  it('upper-cases the code, so casing cannot break a good signature', () => {
    // Wrenz types whatever she read out. The script upper-cases too.
    expect(canonicalReset({ ...FIELDS, code: '4k7-q92' })).toBe(canonicalReset(FIELDS))
  })

  it('is the shape the shipped script still signs', () => {
    // `scripts/send-reset.mjs` cannot import this — it runs under plain Node
    // before anything is compiled — so it carries its own copy. If the two
    // drift, every reset verifies as forged and the symptom looks exactly
    // like a wrong key.
    const source = readFileSync('scripts/send-reset.mjs', 'utf8')
    expect(source).toContain('`reset:${String(code).toUpperCase()}`')
    expect(source).toContain('`expires:${expiresAt}`')
  })
})

describe('verifying a reset', () => {
  it('accepts one signed over these exact fields', () => {
    expect(verifyWith(FIELDS, signWith(FIELDS))).toBe(true)
  })

  it.each([
    ['code', { code: '9ZZ-Z99' }],
    ['expiry', { expiresAt: '2027-01-01T00:00:00.000Z' }],
  ])('rejects a reset whose %s was changed after signing', (_field, patch) => {
    // The whole purpose. Someone with push access to the public repo can
    // rewrite the file; the signature is the only thing that notices — and
    // retargeting a reset at a DIFFERENT machine's code is exactly what they
    // would change.
    const signature = signWith(FIELDS)
    expect(verifyWith({ ...FIELDS, ...patch }, signature)).toBe(false)
  })

  it('rejects one signed with a different key', () => {
    const other = generateKeyPairSync('ed25519')
    const forged = sign(
      null,
      Buffer.from(canonicalReset(FIELDS), 'utf8'),
      other.privateKey,
    ).toString('base64')
    expect(verifyWith(FIELDS, forged)).toBe(false)
  })

  it.each([
    ['empty', ''],
    ['whitespace', '   '],
    ['not base64', '!!!!'],
    ['truncated', 'AAAA'],
  ])('rejects a %s signature rather than throwing', (_label, signature) => {
    expect(verifyWith(FIELDS, signature)).toBe(false)
  })
})
