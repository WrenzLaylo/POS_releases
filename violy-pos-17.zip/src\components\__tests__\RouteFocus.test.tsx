// @vitest-environment jsdom

import { render, screen, waitFor } from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { RouteFocus } from '../RouteFocus'
import { FormError } from '@/components/ui/FormError'

/** Drives `usePathname` the way a client-side navigation would. */
let pathname = '/counter'
vi.mock('next/navigation', () => ({ usePathname: () => pathname }))

function shell(heading = 'Book') {
  return (
    <>
      <RouteFocus />
      <a href="/book">Book</a>
      <main id="main" tabIndex={-1}>
        <h1>{heading}</h1>
        <input aria-label="Search products" />
      </main>
    </>
  )
}

afterEach(() => {
  pathname = '/counter'
})

describe('RouteFocus', () => {
  /**
   * The whole point. Without this, clicking Book in the rail changes the screen
   * and leaves focus on the rail link — the next Tab carries on from the
   * navigation rather than from the page that just arrived.
   */
  it('moves focus to the new page heading after a navigation', async () => {
    const view = render(shell())
    const link = screen.getByRole('link', { name: 'Book' })
    link.focus()
    expect(document.activeElement).toBe(link)

    pathname = '/book'
    view.rerender(shell())

    await waitFor(() => {
      expect(document.activeElement).toBe(screen.getByRole('heading', { name: 'Book' }))
    })
  })

  /**
   * Never on first paint. The app opening is not a navigation, and taking focus
   * before she has done anything is the behaviour that gets this removed again.
   */
  it('leaves focus alone on the first render', async () => {
    render(shell())
    await new Promise((resolve) => setTimeout(resolve, 50))
    expect(document.activeElement).toBe(document.body)
  })

  /**
   * The counter focuses its product search on mount, deliberately — she arrives
   * there to start typing a product. This component runs first, so without the
   * deferred check it would take focus and immediately lose it: a flicker, and
   * two announcements where one was wanted.
   */
  it('yields to a page that claims focus itself', async () => {
    const view = render(shell())
    pathname = '/counter/deliver'
    view.rerender(shell())

    // Stand in for the counter's own mount effect.
    const search = screen.getByLabelText('Search products')
    search.focus()

    await new Promise((resolve) => setTimeout(resolve, 50))
    expect(document.activeElement).toBe(search)
    expect(screen.getByRole('heading', { name: 'Book' })).not.toHaveAttribute('tabindex')
  })

  /** A permanent tabindex would leave a heading swallowing a Tab stop. */
  it('takes the tabindex back off when focus leaves', async () => {
    const view = render(shell())
    pathname = '/book'
    view.rerender(shell())

    const heading = screen.getByRole('heading', { name: 'Book' })
    await waitFor(() => expect(document.activeElement).toBe(heading))
    expect(heading).toHaveAttribute('tabindex', '-1')

    heading.blur()
    expect(heading).not.toHaveAttribute('tabindex')
  })
})

/**
 * 38 of the 40 uses of `FormError` are a sale, payment or void that has just
 * failed, and none of them was announced to anybody. The two that are inline
 * validation must NOT interrupt, because they render while she is typing.
 */
describe('FormError announcements', () => {
  it('is assertive by default, for something that has just failed', () => {
    render(<FormError>Could not save that sale.</FormError>)
    expect(screen.getByRole('alert')).toHaveTextContent('Could not save that sale.')
  })

  it('is polite when it is validation typed into a field', () => {
    render(<FormError live="polite">Enter an amount like 50 or 1,000</FormError>)
    expect(screen.getByRole('status')).toBeInTheDocument()
    expect(screen.queryByRole('alert')).toBeNull()
  })
})
