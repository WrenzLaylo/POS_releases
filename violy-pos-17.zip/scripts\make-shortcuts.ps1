# Creates the Desktop and Start-menu shortcuts for Violy Store POS.
#
# The shortcut points at `run-pos.vbs` rather than at a .cmd file. A .cmd
# shortcut flashes a black console window every launch and leaves it sitting in
# the taskbar for as long as the app runs, which looks broken to anyone who did
# not build it. The .vbs starts the same command with no window at all.
#
# Rewriting an existing shortcut is deliberate: setup can be run again after a
# move or a rename and the icons simply become correct.

$ErrorActionPreference = 'Stop'

$root      = Split-Path -Parent $PSScriptRoot
$launcher  = Join-Path $root 'run-pos.vbs'
$iconFile  = Join-Path $root 'electron\icon.ico'

# Electron's own binary carries an icon, so a missing custom one is not a
# failure — the shortcut just inherits Electron's.
$icon = if (Test-Path $iconFile) { $iconFile } else { Join-Path $root 'node_modules\electron\dist\electron.exe' }

$shell = New-Object -ComObject WScript.Shell

function New-PosShortcut([string]$path) {
    $dir = Split-Path -Parent $path
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }

    $link = $shell.CreateShortcut($path)
    $link.TargetPath       = $launcher
    $link.WorkingDirectory = $root
    $link.IconLocation     = $icon
    $link.Description      = 'Violy Store - Point of Sale'
    $link.Save()
    Write-Host "      created: $path"
}

New-PosShortcut (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Violy Store POS.lnk')
New-PosShortcut (Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs\Violy Store POS.lnk')

Write-Host '      done.'
