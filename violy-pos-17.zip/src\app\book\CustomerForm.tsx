'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createCustomer, updateCustomer } from '@/server/customers'
import type { CustomerWithDiscount } from '@/lib/types'
import { Button } from '@/components/ui/Button'
import { Dialog } from '@/components/ui/Dialog'
import { Field } from '@/components/ui/Field'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'
import { Textarea } from '@/components/ui/Textarea'

const DISCOUNT_BASIS_OPTIONS = [
  { value: 'PER_UNIT', label: 'Per unit' },
  { value: 'ONCE_PER_ORDER', label: 'Once an order' },
  { value: 'ORDER_TOTAL', label: 'Whole order' },
] as const

/** Kept identical to `Field`'s own label, which these sit alongside. */
const FIELD_LABEL = 'text-xs font-medium uppercase tracking-[0.08em] text-ink-muted'

type Props = {
  customer: CustomerWithDiscount | null
  onClose: () => void
}

/**
 * The caller (`CustomerList`) only mounts this component while it should be
 * open, so `Dialog`'s own `open` is always `true` here — closing means the
 * parent stops rendering this component, not `open` flipping to `false` on
 * a persistent instance. That is deliberate: a fresh mount means every field
 * below re-initialises from the current `customer` prop instead of carrying
 * over whatever was typed the previous time the form was open.
 *
 * All Escape-to-close, focus-trapping, body-scroll-locking, and
 * focus-restoration behaviour comes from `Dialog`/`Overlay` — this component
 * adds none of its own, and must not.
 */
export function CustomerForm({ customer, onClose }: Props) {
  const router = useRouter()
  const [name, setName] = useState(customer?.name ?? '')
  const [phone, setPhone] = useState(customer?.phone ?? '')
  const [notes, setNotes] = useState(customer?.notes ?? '')
  const [error, setError] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  // A customer record is a name, a number and a note. Discounts are typed at
  // the counter now — there is no standing rate to set up here, and so no
  // "would this discount make a line free" warning left to give.
  const warnings: { id: string; message: string }[] = []

  async function handleSubmit() {
    setError(null)

    setSaving(true)
    const input = {
      name,
      phone,
      notes,
    }

    const result = customer
      ? await updateCustomer(customer.id, input)
      : await createCustomer(input)

    setSaving(false)
    if (!result.ok) {
      setError(result.error)
      return
    }
    router.refresh()
    onClose()
  }

  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title={customer ? 'Edit customer' : 'New customer'}
      footer={
        <div className="flex justify-end gap-2">
          <Button type="button" variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" form="customer-form" variant="primary" disabled={saving}>
            {saving ? 'Saving…' : 'Save'}
          </Button>
        </div>
      }
    >
      <form
        id="customer-form"
        onSubmit={(e) => {
          e.preventDefault()
          handleSubmit()
        }}
        className="grid gap-4"
      >
        <Field label="Name">
          <Input
            name="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            className="w-full"
            placeholder="Juan Dela Cruz"
          />
        </Field>

        <Field label="Phone">
          <Input
            name="phone"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="w-full"
            placeholder="09XX XXX XXXX"
          />
        </Field>

        <Field label="Notes">
          <Textarea
            name="notes"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={2}
            className="w-full"
          />
        </Field>

        {/* Not a `Field`: that renders a <label> wrapping its children, and a
            radiogroup nested inside a label is the wrong element for the job.
            The label styling is copied from `Field` so the form still reads as
            one set of controls. */}
        {warnings.map((warning) => (
          <p key={warning.id} className="animate-fade-in text-sm text-warn">
            {warning.message}
          </p>
        ))}

        {error && <FormError>{error}</FormError>}
      </form>
    </Dialog>
  )
}
