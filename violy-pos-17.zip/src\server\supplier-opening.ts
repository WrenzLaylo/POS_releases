'use server'

import { randomUUID } from 'node:crypto'
import { prisma } from '@/lib/db'
import type { ActionResult } from '@/lib/types'
import { ROUTES } from '@/lib/routes'
import { CARRY_OVER_NOTE } from '@/lib/supplier-debt'
import { revalidateRoutes } from './revalidate'


/**
 * What the shop already owed a supplier before any of this existed.
 *
 * Recorded as a DELIVERY WITH NO LINES rather than a new supplier ledger, and
 * that is deliberate. `Delivery.amountPaidCentavos` carries a comment saying it
 * is "a single figure rather than a supplier ledger… without inventing a second
 * ledger to keep in step with the customer one" — adding one here would undo a
 * decision the schema already records.
 *
 * Reusing the delivery gets the whole thing for free and correct: it appears in
 * payables, `outstandingOf` counts it, `payDelivery` pays it down, voiding
 * removes it. A separate table would have needed all four rewritten and kept in
 * step.
 *
 * No lines means no stock movement and no cost price rewritten, which is right:
 * this is money owed, not sacks arriving. The sacks arrived before the app
 * could see them.
 */
export async function recordSupplierOpeningBalance(
  supplierId: number,
  amountCentavos: number,
  occurredAt: Date,
  note = '',
): Promise<ActionResult<{ deliveryId: number }>> {
  if (!Number.isInteger(supplierId) || supplierId <= 0) {
    return { ok: false, error: 'That supplier no longer exists.' }
  }
  if (!Number.isInteger(amountCentavos) || amountCentavos <= 0) {
    return { ok: false, error: 'The amount owed must be more than zero.' }
  }

  const supplier = await prisma.supplier.findUnique({ where: { id: supplierId } })
  if (!supplier) return { ok: false, error: 'That supplier no longer exists.' }
  if (supplier.isArchived) {
    return { ok: false, error: `${supplier.name} is archived. Restore it first.` }
  }

  // One carry-over per supplier. A second is always a mistake — the first is
  // still there to correct — and two would quietly double what the payables
  // screen says is owed.
  const existing = await prisma.delivery.count({
    where: { supplierId, isVoided: false, note: CARRY_OVER_NOTE },
  })
  if (existing > 0) {
    return {
      ok: false,
      error: `${supplier.name} already has a carried-over debt. Edit or void that one instead.`,
    }
  }

  let deliveryId: number
  try {
    const created = await prisma.delivery.create({
      data: {
        supplierId,
        receivedAt: occurredAt,
        reference: '',
        note: CARRY_OVER_NOTE,
        // OUTRIGHT, not CONSIGNMENT: this is owed now. A consignment owes
        // nothing until it sells, which is the opposite of a debt already run
        // up.
        terms: 'OUTRIGHT',
        totalCostCentavos: amountCentavos,
        chargeableCentavos: amountCentavos,
        amountPaidCentavos: 0,
        // Same retry guard every delivery gets. A double-submit here would
        // double what the shop believes it owes.
        clientKey: randomUUID(),
      },
      select: { id: true },
    })
    deliveryId = created.id
  } catch {
    return { ok: false, error: 'Could not record the debt. Nothing was changed.' }
  }

  revalidateRoutes([ROUTES.deliveries, ROUTES.dashboard], { layout: true })
  return { ok: true, data: { deliveryId } }
}

/** Which suppliers already have a carry-over, so the form can say so. */
export async function suppliersWithOpeningBalance(): Promise<number[]> {
  const rows = await prisma.delivery.findMany({
    where: { isVoided: false, note: CARRY_OVER_NOTE },
    select: { supplierId: true },
    distinct: ['supplierId'],
  })
  return rows.map((row) => row.supplierId)
}
