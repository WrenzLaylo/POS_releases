'use client'

import { useEffect, useId, useRef, useState, type MouseEventHandler, type ReactNode, type RefCallback } from 'react'
import { cn } from '@/lib/cn'

export type PopoverTriggerProps = {
  ref: RefCallback<HTMLButtonElement>
  type: 'button'
  'aria-haspopup': 'dialog'
  'aria-expanded': boolean
  'aria-controls': string
  onClick: MouseEventHandler<HTMLButtonElement>
}

export type PopoverProps = {
  label: string
  trigger: (props: PopoverTriggerProps) => ReactNode
  children: ReactNode
  align?: 'start' | 'end'
}

export function Popover({ label, trigger, children, align = 'end' }: PopoverProps) {
  const [open, setOpen] = useState(false)
  const panelId = useId()
  const rootRef = useRef<HTMLDivElement>(null)
  const triggerRef = useRef<HTMLButtonElement | null>(null)
  const panelRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!open) return
    const firstFocusable = panelRef.current?.querySelector<HTMLElement>(
      'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
    )
    ;(firstFocusable ?? panelRef.current)?.focus()

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return
      event.preventDefault()
      setOpen(false)
      queueMicrotask(() => triggerRef.current?.focus())
    }
    const handlePointerDown = (event: PointerEvent) => {
      if (!rootRef.current?.contains(event.target as Node)) setOpen(false)
    }
    document.addEventListener('keydown', handleKeyDown)
    document.addEventListener('pointerdown', handlePointerDown)
    return () => {
      document.removeEventListener('keydown', handleKeyDown)
      document.removeEventListener('pointerdown', handlePointerDown)
    }
  }, [open])

  return (
    <div ref={rootRef} className="relative inline-flex">
      {trigger({
        ref: (element) => { triggerRef.current = element },
        type: 'button',
        'aria-haspopup': 'dialog',
        'aria-expanded': open,
        'aria-controls': panelId,
        onClick: () => setOpen((current) => !current),
      })}
      {open ? (
        <div
          ref={panelRef}
          id={panelId}
          role="dialog"
          aria-label={label}
          tabIndex={-1}
          className={cn(
            'absolute top-full z-40 mt-1 rounded-control border border-line bg-surface-raised p-3 shadow-raised',
            align === 'start' ? 'left-0' : 'right-0',
          )}
        >
          {children}
        </div>
      ) : null}
    </div>
  )
}
