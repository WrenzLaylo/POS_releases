'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import Link from 'next/link'
import type { NotificationSummary } from '@/lib/types'
import { formatPeso } from '@/lib/money'
import { NOTIFICATIONS_SEEN_KEY, notificationSignature } from '@/lib/notification-seen'
import { Icon } from '@/components/ui/Icon'
import { cn } from '@/lib/cn'
import { ROUTES, bookEntry, deliveryNote, planInvoice } from '@/lib/routes'

function shortDate(date: Date): string {
  return new Intl.DateTimeFormat('en-PH', { month: 'short', day: 'numeric' }).format(date)
}

export function NotificationBell({
  notifications,
}: {
  notifications: NotificationSummary
}) {
  const [open, setOpen] = useState(false)
  const rootRef = useRef<HTMLDivElement>(null)
  const buttonRef = useRef<HTMLButtonElement>(null)

  const signature = useMemo(() => notificationSignature(notifications), [notifications])

  // What she has already read. `null` until the effect below runs, which is
  // also how "not mounted yet" is spelled — see `showBadge`.
  const [seen, setSeen] = useState<string | null>(null)
  const [mounted, setMounted] = useState(false)

  // Read AFTER mount, never in the useState initialiser: the initialiser runs
  // on the server pass too, where localStorage does not exist. Same reason
  // `AppRail` and the catalog's view toggle do it this way.
  useEffect(() => {
    setSeen(window.localStorage.getItem(NOTIFICATIONS_SEEN_KEY))
    setMounted(true)
  }, [])

  /**
   * Marks everything currently listed as read.
   *
   * Called on OPEN rather than on close, and deliberately not on a timer or a
   * scroll position. Opening the panel is the act of looking; anything cleverer
   * would leave her tapping the bell twice wondering why the red dot is still
   * there.
   */
  function markSeen() {
    window.localStorage.setItem(NOTIFICATIONS_SEEN_KEY, signature)
    setSeen(signature)
  }

  // Gated on `mounted` so the badge is never rendered on the server and then
  // removed a frame later. The wrong way round — server renders it, client
  // decides it was already read — is a red count that flashes on every single
  // page load, which is worse than the badge appearing one frame late.
  const showBadge = mounted && notifications.total > 0 && seen !== signature

  useEffect(() => {
    if (!open) return

    function onPointerDown(event: MouseEvent) {
      if (!rootRef.current?.contains(event.target as Node)) setOpen(false)
    }
    function onKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        setOpen(false)
        buttonRef.current?.focus()
      }
    }

    document.addEventListener('mousedown', onPointerDown)
    document.addEventListener('keydown', onKeyDown)
    return () => {
      document.removeEventListener('mousedown', onPointerDown)
      document.removeEventListener('keydown', onKeyDown)
    }
  }, [open])

  const countLabel = notifications.total > 99 ? '99+' : String(notifications.total)

  return (
    <div ref={rootRef} className="relative">
      <button
        ref={buttonRef}
        type="button"
        aria-label={notifications.total === 0 ? 'Notifications' : `${notifications.total} notifications`}
        aria-expanded={open}
        aria-controls="notification-panel"
        title="Notifications"
        onClick={() => {
          setOpen((value) => {
            if (!value) markSeen()
            return !value
          })
        }}
        className={cn(
          'relative flex h-10 w-10 items-center justify-center rounded-control text-ink-muted',
          'transition-colors duration-150 hover:bg-surface-sunk hover:text-ink',
          'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-surface',
          open && 'bg-surface-sunk text-ink',
        )}
      >
        <Icon name="bell" className="h-4 w-4 shrink-0" />
        {showBadge && (
          <span
            className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-owed px-1.5 text-xs font-semibold text-canvas"
          >
            {countLabel}
          </span>
        )}
      </button>

      {open && (
        <div
          id="notification-panel"
          role="region"
          aria-label="Notifications"
          className="absolute right-0 top-full z-50 mt-2 max-h-[70vh] w-96 overflow-y-auto rounded-control border border-line bg-surface-raised p-3 shadow-raised"
        >
          <div className="mb-2 flex items-center justify-between px-2 py-1">
            <h2 className="text-base font-semibold text-ink">Needs attention</h2>
            <span className="text-xs text-ink-subtle">{notifications.total} total</span>
          </div>

          {notifications.total === 0 ? (
            <p className="rounded-control bg-surface-sunk px-3 py-4 text-sm text-ink-muted">
              Nothing needs attention.
            </p>
          ) : (
            <div className="space-y-4">
              {/* First, and its own colour: an update is not a money problem
                  and must not be read as one. Everything else in this panel is
                  something a customer owes or a shelf is missing. */}
              {notifications.updatesAvailable > 0 && (
                <section aria-labelledby="updates-heading">
                  <h3
                    id="updates-heading"
                    className="mb-1 px-2 text-xs font-semibold uppercase tracking-wide text-accent"
                  >
                    App update
                  </h3>
                  <Link
                    href={ROUTES.settings}
                    onClick={() => setOpen(false)}
                    className="block rounded-control px-3 py-2 hover:bg-surface-sunk focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                  >
                    <span className="block text-sm font-semibold text-ink">
                      {notifications.updatesAvailable === 1
                        ? '1 update is ready to install'
                        : `${notifications.updatesAvailable} updates are ready to install`}
                    </span>
                    <span className="mt-0.5 block text-xs text-ink-subtle">
                      Open Settings to install it
                    </span>
                  </Link>
                </section>
              )}

              {/* Above the money, below an update. This is the only entry in
                  the panel that is a job to DO today rather than a debt to
                  chase, and it has a deadline the others do not: the truck
                  leaves. `accent`, not `warn` — nothing is wrong, there is
                  simply something to load. */}
              {notifications.deliveriesToday.length > 0 && (
                <section aria-labelledby="deliveries-heading">
                  <h3
                    id="deliveries-heading"
                    className="mb-1 px-2 text-xs font-semibold uppercase tracking-wide text-accent"
                  >
                    Going out today
                  </h3>
                  <ul className="space-y-1">
                    {notifications.deliveriesToday.map((row) => (
                      <li key={row.saleId}>
                        <Link
                          href={deliveryNote(row.saleId)}
                          onClick={() => setOpen(false)}
                          className="block rounded-control px-3 py-2 hover:bg-surface-sunk focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                        >
                          <span className="flex items-center justify-between gap-3 text-sm font-semibold text-ink">
                            <span className="truncate">{row.customerName}</span>
                            {/* Neutral: a booked load is benta, not cash that
                                has arrived. */}
                            <span className="shrink-0 font-mono text-ink">
                              {formatPeso(row.totalCentavos)}
                            </span>
                          </span>
                          <span className="mt-0.5 block truncate text-xs text-ink-subtle">
                            {row.deliverTo} · {row.lines.length} item
                            {row.lines.length === 1 ? '' : 's'} · open the note
                          </span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </section>
              )}

              {/* Ahead of Overdue: today's round is the one still worth
                  walking, and burying it under accounts that are already late
                  inverts the urgency. */}
              {notifications.dueToday.length > 0 && (
                <section aria-labelledby="due-today-heading">
                  <h3
                    id="due-today-heading"
                    className="mb-1 px-2 text-xs font-semibold uppercase tracking-wide text-warn"
                  >
                    Due today
                  </h3>
                  <ul className="space-y-1">
                    {notifications.dueToday.map((row) => (
                      <li key={row.customerId}>
                        <Link
                          href={bookEntry(row.customerId)}
                          onClick={() => setOpen(false)}
                          className="block rounded-control px-3 py-2 hover:bg-surface-sunk focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                        >
                          <span className="flex items-center justify-between gap-3 text-sm font-semibold text-ink">
                            <span className="truncate">{row.name}</span>
                            <span className="shrink-0 font-mono text-warn">
                              {formatPeso(row.balanceCentavos)}
                            </span>
                          </span>
                          <span className="mt-0.5 block text-xs text-ink-subtle">
                            Collect today
                          </span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </section>
              )}

              {notifications.overdueAccounts.length > 0 && (
                <section aria-labelledby="overdue-heading">
                  <h3 id="overdue-heading" className="mb-1 px-2 text-xs font-semibold uppercase tracking-wide text-owed">
                    Overdue accounts
                  </h3>
                  <ul className="space-y-1">
                    {notifications.overdueAccounts.map((row) => (
                      <li key={row.customerId}>
                        <Link
                          href={bookEntry(row.customerId)}
                          onClick={() => setOpen(false)}
                          className="block rounded-control px-3 py-2 hover:bg-surface-sunk focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                        >
                          <span className="flex items-center justify-between gap-3 text-sm font-semibold text-ink">
                            <span className="truncate">{row.name}</span>
                            <span className="shrink-0 font-mono text-owed">{formatPeso(row.balanceCentavos)}</span>
                          </span>
                          <span className="mt-0.5 block text-xs text-ink-subtle">Due {shortDate(row.dueAt)}</span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </section>
              )}

              {/* Its own group, listed before low stock and after plain
                  overdue balances. A missed instalment on an agreed schedule
                  is a different conversation from an old balance drifting
                  past its deadline, so they are never merged. */}
              {notifications.overdueInstallments.length > 0 && (
                <section aria-labelledby="installments-heading">
                  <h3
                    id="installments-heading"
                    className="mb-1 px-2 text-xs font-semibold uppercase tracking-wide text-owed"
                  >
                    Missed instalments
                  </h3>
                  <ul className="space-y-1">
                    {notifications.overdueInstallments.map((row) => (
                      <li key={row.planId}>
                        <Link
                          href={planInvoice(row.customerId, row.planId)}
                          onClick={() => setOpen(false)}
                          className="block rounded-control px-3 py-2 hover:bg-surface-sunk focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                        >
                          <span className="flex items-center justify-between gap-3 text-sm font-semibold text-ink">
                            <span className="truncate">{row.name}</span>
                            <span className="shrink-0 font-mono text-owed">
                              {formatPeso(row.amountCentavos)}
                            </span>
                          </span>
                          <span className="mt-0.5 block text-xs text-ink-subtle">
                            {row.count} month{row.count === 1 ? '' : 's'} behind · oldest due{' '}
                            {shortDate(row.oldestDueAt)}
                          </span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </section>
              )}

              {notifications.lowStock.length > 0 && (
                <section aria-labelledby="stock-heading">
                  <h3 id="stock-heading" className="mb-1 px-2 text-xs font-semibold uppercase tracking-wide text-warn">
                    Low stock
                  </h3>
                  <ul className="space-y-1">
                    {notifications.lowStock.map((row) => (
                      <li key={row.id}>
                        <Link
                          href={`${ROUTES.stock}?q=${encodeURIComponent(row.name)}`}
                          onClick={() => setOpen(false)}
                          className="block rounded-control px-3 py-2 hover:bg-surface-sunk focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                        >
                          <span className="block truncate text-sm font-semibold text-ink">{row.name}</span>
                          <span className="mt-0.5 block text-xs text-ink-subtle">
                            {row.stockQty} {row.unit} left · threshold {row.lowStockThreshold}
                          </span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </section>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
