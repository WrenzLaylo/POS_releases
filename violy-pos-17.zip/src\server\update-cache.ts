import { checkForUpdates } from '@/server/updates'

/**
 * The update count, readable without waiting for a socket.
 *
 * The root layout awaits `getNotifications()`, which used to await
 * `checkForUpdates()` — a live HTTPS request with an 8-second timeout, no
 * cache, and `cache: 'no-store'`. On an installed copy with no internet that
 * held the ENTIRE application shell for the full timeout, on every page load,
 * because every page is `force-dynamic` and re-renders the layout. Measured
 * before this existed: 0.22s on a dev checkout (which never fetches),
 * 0.45s installed and online, 8.21s installed and offline.
 *
 * So the check moved off the critical path rather than being made faster. A
 * shorter timeout would only have chosen a smaller number to stall by; the
 * shell has no business waiting on the internet at all.
 *
 * Read returns the last known answer immediately and refreshes in the
 * background when it has gone stale. First read after the server starts
 * therefore says "no updates", and the next one a few seconds later says the
 * truth. That is the right way round: being told about an update slightly late
 * costs nothing, and Electron tells her independently four seconds after the
 * window opens (`electron/main.js`), which is the mechanism that actually
 * matters on the shop laptop.
 *
 * Module-level state is deliberate and safe here: this app is one Next process
 * beside one SQLite file on one counter. It is a cache, not a source of truth —
 * losing it costs one extra HTTPS request.
 */

/** Long enough that a closed shop is not re-asking all morning, short enough
 *  that an update published at lunch is noticed the same afternoon. */
const DEFAULT_TTL_MS = 5 * 60_000

export type UpdateCache = {
  /**
   * The last known number of waiting updates. Synchronous by design: the
   * moment this returns a promise, something will await it, and the stall is
   * back.
   */
  read: () => number
}

export function createUpdateCache(
  load: () => Promise<number>,
  options: { ttlMs?: number; now?: () => number } = {},
): UpdateCache {
  const ttlMs = options.ttlMs ?? DEFAULT_TTL_MS
  const now = options.now ?? Date.now

  let value = 0
  let loadedAt = Number.NEGATIVE_INFINITY
  let inFlight: Promise<void> | null = null

  function refresh(): void {
    // One at a time. Twenty page loads against a host that is not answering
    // must not become twenty sockets waiting eight seconds each.
    if (inFlight) return

    inFlight = load()
      .then((next) => {
        value = next
        loadedAt = now()
      })
      .catch(() => {
        // An unreachable host is not evidence that the update went away, so
        // the previous answer stands. `loadedAt` is left alone so the next
        // read tries again rather than waiting out the whole TTL.
        //
        // Swallowed rather than rethrown: nothing is awaiting this, so a
        // rejection here would be an unhandled one, logged on every page load
        // of an offline shop.
      })
      .finally(() => {
        inFlight = null
      })
  }

  return {
    read() {
      if (now() - loadedAt >= ttlMs) refresh()
      return value
    },
  }
}

/**
 * The instance the app reads. One release, not a count of commits: a release
 * is a single thing to install however many changes went into it.
 */
export const updateCache = createUpdateCache(async () => {
  const status = await checkForUpdates()
  return status.kind === 'available' ? 1 : 0
})
