import type { ReactNode } from 'react'
import { Money } from './Money'
import type { MoneyTone } from '@/lib/money-display'

/** A labelled money figure. `secondary` carries subordinate figures (week,
 *  month) beneath a hero today-figure. */
export function Stat({
  label,
  centavos,
  scale = 'strong',
  tone = 'neutral',
  secondary,
}: {
  label: string
  centavos: number
  scale?: 'hero' | 'strong' | 'body'
  tone?: MoneyTone | 'balance'
  secondary?: ReactNode
}) {
  return (
    <div>
      <div className="text-xs font-semibold uppercase tracking-[0.14em] text-ink-muted font-display">
        {label}
      </div>
      <div className="mt-1">
        <Money centavos={centavos} scale={scale} tone={tone} />
      </div>
      {secondary && <div className="mt-2 space-y-1">{secondary}</div>}
    </div>
  )
}
