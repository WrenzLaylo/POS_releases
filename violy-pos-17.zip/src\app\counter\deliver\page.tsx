import Link from 'next/link'
import { listProducts } from '@/server/products'
import { listCustomers } from '@/server/customers'
import { ROUTES } from '@/lib/routes'
import { PageHeader } from '@/components/ui/PageHeader'
import { DeliverForm } from './DeliverForm'

export const dynamic = 'force-dynamic'

/**
 * Selling something and sending it somewhere, recorded as one act.
 *
 * A page rather than a dialog, for the same reason `deliveries/new` is one:
 * the number of lines is unbounded, and a dialog is sized for a question. It
 * also carries an address and a note, which a rail has no room for.
 *
 * Under `/counter` rather than under `/deliveries`, which is stock arriving
 * from a supplier. Two opposite directions sharing a word is exactly how a
 * person ends up on the wrong screen.
 */
export default async function DeliverPage() {
  const [products, customers] = await Promise.all([listProducts(), listCustomers()])

  return (
    <PageHeader
      title="New delivery order"
      description="Records the sale and the delivery together. Stock moves and the account is charged when you save."
      actions={
        <Link href={ROUTES.counter} className="text-sm font-medium text-ink-muted hover:text-ink">
          ← Back to the counter
        </Link>
      }
    >
      <DeliverForm products={products} customers={customers} />
    </PageHeader>
  )
}
