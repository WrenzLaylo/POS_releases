import { readFileSync } from 'node:fs'
import { join } from 'node:path'
import { DatabaseSync } from 'node:sqlite'
import { afterAll, beforeAll, describe, expect, it } from 'vitest'

const originalTimezone = process.env.TZ

const migrationPaths = [
  '20260803013500_backfill_customer_due_dates',
]

function applyBackfillChain(utcNow: string): {
  debtLocalDueAt: string
  settledDueAt: number | null
} {
  const db = new DatabaseSync(':memory:')
  db.exec(`
    CREATE TABLE "Customer" (
      "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
      "name" TEXT NOT NULL,
      "dueAt" DATETIME
    );
    CREATE TABLE "LedgerEntry" (
      "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
      "customerId" INTEGER NOT NULL,
      "type" TEXT NOT NULL,
      "amountCentavos" INTEGER NOT NULL,
      "isVoided" BOOLEAN NOT NULL DEFAULT false
    );
    INSERT INTO "Customer" ("id", "name", "dueAt") VALUES
      (1, 'DEBT', NULL),
      (2, 'SETTLED', NULL);
    INSERT INTO "LedgerEntry" ("customerId", "type", "amountCentavos", "isVoided") VALUES
      (1, 'CHARGE', 50000, false),
      (2, 'OPENING', 10000, false),
      (2, 'PAYMENT', 10000, false);
  `)

  for (const directory of migrationPaths) {
    const sql = readFileSync(
      join(process.cwd(), 'prisma', 'migrations', directory, 'migration.sql'),
      'utf8',
    ).replaceAll("'now'", `'${utcNow}'`)
    db.exec(sql)
  }

  const debt = db.prepare(`
    SELECT datetime("dueAt" / 1000, 'unixepoch', 'localtime') AS "localDueAt"
    FROM "Customer" WHERE "id" = 1
  `).get() as { localDueAt: string }
  const settled = db.prepare(`
    SELECT "dueAt" FROM "Customer" WHERE "id" = 2
  `).get() as { dueAt: number | null }
  db.close()
  return { debtLocalDueAt: debt.localDueAt, settledDueAt: settled.dueAt }
}

describe('existing-debt due-date migration chain', () => {
  beforeAll(() => {
    process.env.TZ = 'Asia/Manila'
  })

  afterAll(() => {
    if (originalTimezone === undefined) delete process.env.TZ
    else process.env.TZ = originalTimezone
  })

  it('grants 30 local calendar days when run before 08:00 in UTC+8', () => {
    // 18:00 UTC on August 2 is 02:00 local on August 3.
    const result = applyBackfillChain('2026-08-02 18:00:00')
    expect(result.debtLocalDueAt).toBe('2026-09-02 00:00:00')
    expect(result.settledDueAt).toBeNull()
  })

  it('grants the same local deadline when run after 08:00 in UTC+8', () => {
    // 02:00 UTC on August 3 is 10:00 local on August 3.
    const result = applyBackfillChain('2026-08-03 02:00:00')
    expect(result.debtLocalDueAt).toBe('2026-09-02 00:00:00')
    expect(result.settledDueAt).toBeNull()
  })
})
