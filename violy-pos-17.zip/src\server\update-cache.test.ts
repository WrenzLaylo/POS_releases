import { describe, expect, it, vi } from 'vitest'
import { createUpdateCache } from '@/server/update-cache'

/** A loader whose completion the test controls. */
function deferred() {
  let resolve!: (value: number) => void
  const promise = new Promise<number>((res) => {
    resolve = res
  })
  return { promise, resolve }
}

describe('createUpdateCache', () => {
  /**
   * The whole point. The root layout awaits notification aggregation, which
   * awaited the update check — so an unreachable update host held the entire
   * application shell for the full 8-second fetch timeout. Measured at 8.2s
   * per page load on an installed build. Reading must never wait on a socket.
   */
  it('answers immediately while the check is still in flight', () => {
    const pending = deferred()
    const cache = createUpdateCache(() => pending.promise)

    // No await anywhere. If `read` ever becomes something you have to wait
    // for, the stall is back.
    expect(cache.read()).toBe(0)
    expect(cache.read()).toBe(0)
  })

  it('serves the answer once the check has landed', async () => {
    const pending = deferred()
    const cache = createUpdateCache(() => pending.promise)

    expect(cache.read()).toBe(0)
    pending.resolve(1)
    await vi.waitFor(() => expect(cache.read()).toBe(1))
  })

  /** One check in flight at a time. Twenty page loads must not become twenty
   *  sockets to a host that is already not answering. */
  it('does not start a second check while one is running', () => {
    const load = vi.fn(() => deferred().promise)
    const cache = createUpdateCache(load)

    cache.read()
    cache.read()
    cache.read()

    expect(load).toHaveBeenCalledTimes(1)
  })

  it('re-checks once the answer has gone stale', async () => {
    let clock = 1_000
    const load = vi.fn(() => Promise.resolve(1))
    const cache = createUpdateCache(load, { ttlMs: 60_000, now: () => clock })

    cache.read()
    await vi.waitFor(() => expect(cache.read()).toBe(1))
    expect(load).toHaveBeenCalledTimes(1)

    // Inside the window: still one check.
    clock += 59_000
    cache.read()
    expect(load).toHaveBeenCalledTimes(1)

    // Past it: refreshed, and the previous answer is served meanwhile.
    clock += 2_000
    expect(cache.read()).toBe(1)
    await vi.waitFor(() => expect(load).toHaveBeenCalledTimes(2))
  })

  /**
   * A shop with no internet is an ordinary Tuesday. A failing check has to
   * leave the cache usable, and must never surface as an unhandled rejection —
   * which in Next would be logged on every single page load.
   */
  it('survives a check that rejects, and tries again later', async () => {
    let clock = 1_000
    const load = vi
      .fn<() => Promise<number>>()
      .mockRejectedValueOnce(new Error('offline'))
      .mockResolvedValueOnce(2)
    const cache = createUpdateCache(load, { ttlMs: 1_000, now: () => clock })

    expect(cache.read()).toBe(0)
    await vi.waitFor(() => expect(load).toHaveBeenCalledTimes(1))
    expect(cache.read()).toBe(0)

    clock += 2_000
    cache.read()
    await vi.waitFor(() => expect(cache.read()).toBe(2))
  })

  it('keeps the last good answer when a later check fails', async () => {
    let clock = 1_000
    const load = vi
      .fn<() => Promise<number>>()
      .mockResolvedValueOnce(1)
      .mockRejectedValueOnce(new Error('offline'))
    const cache = createUpdateCache(load, { ttlMs: 1_000, now: () => clock })

    cache.read()
    await vi.waitFor(() => expect(cache.read()).toBe(1))

    clock += 2_000
    cache.read()
    await vi.waitFor(() => expect(load).toHaveBeenCalledTimes(2))
    // Still 1. An unreachable host is not evidence the update went away.
    expect(cache.read()).toBe(1)
  })
})
