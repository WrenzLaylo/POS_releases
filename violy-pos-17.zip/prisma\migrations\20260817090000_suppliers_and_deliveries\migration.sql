-- Suppliers and deliveries: the buying half of the business.
--
-- Until now stock only ever went DOWN, through sales, and went up by somebody
-- editing a number on a product form. That left cost prices as a hand-kept
-- figure — which is why every one of them is 0 — and made margin unknowable
-- rather than merely unentered.
--
-- Purely additive: three new tables and one nullable column on StockMovement.
-- Nothing existing changes shape, so every row already on file keeps its
-- meaning and no backfill is needed.
--
-- Written by hand and applied with `migrate deploy`. `migrate dev` is never run
-- against this database: it can decide the schema has drifted and offer to
-- RESET, which here means deleting the ledger.

CREATE TABLE "Supplier" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "name" TEXT NOT NULL,
    "contactNumber" TEXT NOT NULL DEFAULT '',
    "notes" TEXT NOT NULL DEFAULT '',
    "isArchived" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX "Supplier_name_key" ON "Supplier"("name");

CREATE TABLE "Delivery" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "supplierId" INTEGER NOT NULL,
    "receivedAt" DATETIME NOT NULL,
    "reference" TEXT NOT NULL DEFAULT '',
    "note" TEXT NOT NULL DEFAULT '',
    "totalCostCentavos" INTEGER NOT NULL DEFAULT 0,
    "amountPaidCentavos" INTEGER NOT NULL DEFAULT 0,
    "isVoided" BOOLEAN NOT NULL DEFAULT false,
    "voidReason" TEXT NOT NULL DEFAULT '',
    "clientKey" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "Delivery_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES "Supplier" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
CREATE UNIQUE INDEX "Delivery_clientKey_key" ON "Delivery"("clientKey");
CREATE INDEX "Delivery_supplierId_idx" ON "Delivery"("supplierId");
CREATE INDEX "Delivery_receivedAt_idx" ON "Delivery"("receivedAt");

CREATE TABLE "DeliveryItem" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "deliveryId" INTEGER NOT NULL,
    "productId" INTEGER NOT NULL,
    "quantity" REAL NOT NULL,
    "unitCostCentavos" INTEGER NOT NULL,
    CONSTRAINT "DeliveryItem_deliveryId_fkey" FOREIGN KEY ("deliveryId") REFERENCES "Delivery" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "DeliveryItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES "Product" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
CREATE INDEX "DeliveryItem_deliveryId_idx" ON "DeliveryItem"("deliveryId");
CREATE INDEX "DeliveryItem_productId_idx" ON "DeliveryItem"("productId");

-- Nullable, so every StockMovement already written keeps its meaning.
ALTER TABLE "StockMovement" ADD COLUMN "deliveryId" INTEGER;
