'use client'

import { useEffect, useLayoutEffect, useRef, useState, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import { cn } from '@/lib/cn'
import { Icon } from './Icon'

export type RowActionMenuItem = {
  label: string
  onSelect: () => void
  destructive?: boolean
  disabled?: boolean
}

export type RowActionMenuProps = {
  items: RowActionMenuItem[]
  ariaLabel?: string
  className?: string
  /**
   * What the trigger looks like. Defaults to the row-action dots.
   *
   * Optional so the account menu in the topbar can wear an avatar instead of
   * borrowing a table's visual language, without a FOURTH hand-rolled
   * outside-click-and-Escape appearing in this codebase — there are already
   * three, and AGENTS.md records that they have drifted apart. The behaviour
   * is the part worth sharing; the glyph is not.
   */
  trigger?: ReactNode
  /** Static block above the items, e.g. who is signed in. Not focusable. */
  header?: ReactNode
  /** Where the panel sits relative to the trigger. */
  align?: 'start' | 'end'
}

export function RowActionMenu({
  items,
  ariaLabel = 'Row actions',
  className,
  trigger,
  header,
}: RowActionMenuProps) {
  const [open, setOpen] = useState(false)
  const rootRef = useRef<HTMLDivElement>(null)
  const triggerRef = useRef<HTMLButtonElement>(null)
  const panelRef = useRef<HTMLDivElement>(null)
  const itemRefs = useRef<Array<HTMLButtonElement | null>>([])
  /** Where to draw the menu, in viewport coordinates. */
  const [anchor, setAnchor] = useState<{ left: number; top: number } | null>(null)

  /**
   * Positioned against the trigger and portalled to `document.body`.
   *
   * This menu lives in the last column of a table, and every table in this app
   * sits in `overflow-x-auto` so a narrow screen can scroll it sideways. An
   * absolutely-positioned menu is clipped by that container — and because CSS
   * computes the OTHER axis from `visible` to `auto` when one axis is not
   * visible, it is clipped vertically too. The result was a menu showing one
   * and a half items with its own scrollbar, hard against the right edge.
   *
   * This is the FOURTH component to need this: the bulk-payment dropdown,
   * `DatePicker`, `Select`, and now this one. The pattern is the same each
   * time, and so is the fix.
   */
  useLayoutEffect(() => {
    if (!open) return

    function place() {
      const trigger = rootRef.current
      if (!trigger) return
      const rect = trigger.getBoundingClientRect()
      const panel = panelRef.current
      const width = panel?.offsetWidth ?? 160
      const height = panel?.offsetHeight ?? 96

      // Right-aligned to the trigger, as a row menu should be, then pulled
      // back inside the viewport rather than opening off the edge — which is
      // exactly what it did in the last column of a wide table.
      const preferredLeft = rect.right - width
      const left = Math.max(8, Math.min(preferredLeft, window.innerWidth - width - 8))

      // Flip above when there is no room below, so the last row of a long
      // table still shows its actions.
      const below = window.innerHeight - rect.bottom
      const top =
        below < height + 8 && rect.top > height + 8 ? rect.top - height - 4 : rect.bottom + 4

      setAnchor({ left, top })
    }

    place()
    window.addEventListener('scroll', place, true)
    window.addEventListener('resize', place)
    return () => {
      window.removeEventListener('scroll', place, true)
      window.removeEventListener('resize', place)
    }
  }, [open])

  const enabledIndexes = () => items.flatMap((item, index) => item.disabled ? [] : [index])

  useEffect(() => {
    if (!open) return
    itemRefs.current[enabledIndexes()[0]]?.focus()

    const handlePointerDown = (event: PointerEvent) => {
      const target = event.target as Node
      // The panel is checked SEPARATELY now that it is portalled: it is no
      // longer a DOM descendant of this wrapper, so `rootRef.contains` alone
      // would read every click on a menu item as a click outside and close the
      // menu before the item's own handler ran.
      if (rootRef.current?.contains(target)) return
      if (panelRef.current?.contains(target)) return
      setOpen(false)
    }
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return
      event.preventDefault()
      setOpen(false)
      queueMicrotask(() => triggerRef.current?.focus())
    }
    document.addEventListener('pointerdown', handlePointerDown)
    document.addEventListener('keydown', handleEscape)
    return () => {
      document.removeEventListener('pointerdown', handlePointerDown)
      document.removeEventListener('keydown', handleEscape)
    }
  }, [open])

  return (
    <div ref={rootRef} className={cn('relative inline-flex', className)}>
      <button
        ref={triggerRef}
        type="button"
        aria-label={ariaLabel}
        aria-haspopup="menu"
        aria-expanded={open}
        // `h-8`, the row-action size AGENTS.md sets, not `h-10`. At h-10 this
        // trigger was the tallest thing in a stock row and set the row height
        // on its own — 40px of it against 20px of text — so compacting every
        // other cell moved the row by four pixels and no further. The menu
        // ITEMS stay h-10: they are a normal control surface, not a row action.
        className={cn(
          'inline-flex items-center justify-center rounded-control transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-canvas',
          trigger
            // `min-w-10`, not `w-10`. A fixed 40px square is right for an
            // avatar — which is what the first custom trigger was — and wrong
            // for a label: "Stock tools" was folded onto two lines inside it.
            // An avatar is already 40 wide so the minimum leaves it untouched,
            // and a text trigger brings its own padding.
            ? 'h-10 min-w-10 text-ink-muted hover:bg-surface-sunk hover:text-ink'
            : 'h-8 w-8 text-ink-muted hover:bg-surface-sunk hover:text-ink',
        )}
        onClick={() => setOpen((current) => !current)}
      >
        {trigger ?? <Icon name="more-horizontal" className="h-4 w-4" />}
      </button>
      {open && typeof document !== 'undefined' ? (
        createPortal(
        <div
          ref={panelRef}
          role="menu"
          style={{ left: anchor?.left ?? -9999, top: anchor?.top ?? -9999 }}
          // `z-[60]`: above `Overlay`'s z-50, so a row menu inside a dialog is
          // not drawn behind the dialog that owns it. Same as `Select`.
          className="fixed z-[60] min-w-40 rounded-control border border-line bg-surface-raised p-1 shadow-raised"
          onKeyDown={(event) => {
            if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') return
            event.preventDefault()
            const enabled = enabledIndexes()
            if (enabled.length === 0) return
            const current = itemRefs.current.findIndex((item) => item === document.activeElement)
            const currentPosition = enabled.indexOf(current)
            const direction = event.key === 'ArrowDown' ? 1 : -1
            const nextPosition = (currentPosition + direction + enabled.length) % enabled.length
            itemRefs.current[enabled[nextPosition]]?.focus()
          }}
        >
          {header && (
            <div className="border-b border-line px-3 py-2">{header}</div>
          )}
          {items.map((item, index) => (
            <button
              key={item.label}
              ref={(element) => { itemRefs.current[index] = element }}
              type="button"
              role="menuitem"
              disabled={item.disabled}
              className={cn(
                'flex h-10 w-full items-center rounded-control px-3 text-left text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent disabled:opacity-50',
                item.destructive ? 'text-owed hover:bg-accent-soft' : 'text-ink hover:bg-surface-sunk',
              )}
              onClick={() => {
                if (item.disabled) return
                setOpen(false)
                item.onSelect()
              }}
            >
              {item.label}
            </button>
          ))}
        </div>,
        document.body,
      )
      ) : null}
    </div>
  )
}
