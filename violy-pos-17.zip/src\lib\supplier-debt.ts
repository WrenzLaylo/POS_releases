/**
 * The note that marks a delivery as a carry-over rather than goods arriving.
 *
 * Lives in `lib` and not beside the action that writes it, because a
 * `'use server'` module may export ONLY async functions. Exporting this string
 * from there killed every export in the file at once — `tsc` was happy, the
 * tests were happy, and the Deliveries page returned a 500 saying the module
 * "has no exports at all". The constant has to sit somewhere that is not an
 * action boundary.
 */
export const CARRY_OVER_NOTE = 'Carried over: owed before this app'
