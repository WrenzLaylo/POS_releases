import type { ReactNode } from 'react'
import { cn } from '@/lib/cn'

/** The page shell. One responsive padding value and one title treatment for
 * every route. Optional context stays attached to the semantic h1 while
 * actions stack at narrow widths and return to the title row on larger ones. */
export function PageHeader({
  title,
  eyebrow,
  description,
  actions,
  dense,
  fill,
  hideOnPrint,
  children,
}: {
  title: string
  eyebrow?: string
  description?: string
  actions?: ReactNode
  /** Working screens (the counter) trade the visible title for screen height. */
  dense?: boolean
  /**
   * The page fills the viewport and does its own scrolling inside.
   *
   * Without this the shell's `main` is the only scroller, so a long catalog
   * scrolls the whole page — carrying the running total, the cash field and
   * "Save order" off the top with it. A till cannot do that: the total has to
   * stay on screen while she is still adding sacks. A page opting in becomes a
   * full-height flex column and takes responsibility for bounding whatever
   * inside it is long.
   */
  fill?: boolean
  /** Keeps the title row off the paper on a page that prints a document.
   *  The frame is navigation; the document below it is the thing being
   *  printed. */
  hideOnPrint?: boolean
  children: ReactNode
}) {
  // `dense` is for a working screen rather than a reading screen. On the
  // counter, the standard header spent ~84px on `lg:p-8` plus a title that
  // only repeated what the rail already highlights — against roughly 510px of
  // usable height on a shop laptop, that is most of a row of products. The
  // `h1` stays in the document for screen readers and the page outline; it
  // just stops taking space.
  const bare = dense && !actions && !description && !eyebrow

  return (
    <div
      className={cn(
        dense ? 'p-4 lg:px-6 lg:py-4' : 'p-4 sm:p-6 lg:p-8',
        // `min-h-0` matters as much as `h-full`: a flex child defaults to
        // min-height:auto, which refuses to shrink below its content and
        // hands the overflow back to the page — the exact thing `fill` is
        // here to stop.
        fill && 'flex h-full min-h-0 flex-col',
      )}
    >
      {bare ? (
        <h1 className="sr-only">{title}</h1>
      ) : (
        <div
          data-print={hideOnPrint ? 'hide' : undefined}
          className={cn(
            'flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between',
            dense ? 'mb-4' : 'mb-6',
          )}
        >
          <div className="min-w-0">
            {eyebrow && (
              <p className="mb-1 text-xs font-semibold uppercase tracking-[0.12em] text-accent">
                {eyebrow}
              </p>
            )}
            <h1
              className={cn(
                'text-xl font-semibold tracking-tight text-ink',
                dense && 'sr-only',
              )}
            >
              {title}
            </h1>
            {description && <p className="mt-1 max-w-2xl text-sm text-ink-muted">{description}</p>}
          </div>
          {actions && <div className="w-full shrink-0 sm:w-auto">{actions}</div>}
        </div>
      )}
      {fill ? <div className="min-h-0 flex-1">{children}</div> : children}
    </div>
  )
}
