import { describe, it, expect, beforeEach } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'

describe('database schema', () => {
  beforeEach(resetDb)

  it('stores a product with centavo prices and fractional stock', async () => {
    const category = await prisma.category.create({ data: { name: 'Feeds' } })

    const product = await prisma.product.create({
      data: {
        categoryId: category.id,
        name: 'Hog Grower (kilo)',
        unit: 'kilo',
        price: 3250,
        costPrice: 2800,
        stockQty: 12.5,
        lowStockThreshold: 5,
      },
    })

    expect(product.price).toBe(3250)
    expect(product.stockQty).toBe(12.5)
    expect(product.isArchived).toBe(false)
    expect(product.imagePath).toBeNull()
  })

  it('cascades sale items when a sale is deleted', async () => {
    const category = await prisma.category.create({ data: { name: 'Feeds' } })
    const product = await prisma.product.create({
      data: {
        categoryId: category.id,
        name: 'Hog Grower (sako)',
        unit: 'sako',
        price: 140000,
        costPrice: 128000,
        stockQty: 10,
      },
    })
    const sale = await prisma.sale.create({
      data: {
        totalAmount: 140000,
        items: {
          create: [
            { productId: product.id, quantity: 1, priceAtSale: 140000, costAtSale: 128000 },
          ],
        },
      },
    })

    await prisma.sale.delete({ where: { id: sale.id } })

    expect(await prisma.saleItem.count()).toBe(0)
  })
})
