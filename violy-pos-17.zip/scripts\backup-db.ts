/**
 * Backs up the database from the command line.
 *
 * Three things call this: `npm run backup`, the updater in `update.mjs` before
 * it changes anything, and the timer in the desktop shell. The shell passes
 * `--if-older-than` so that opening and closing the app all morning does not
 * fill the folder with copies of the same data.
 *
 * Run with tsx rather than plain node so it shares one implementation with the
 * button in Settings. A second copy of "where the database is, what a backup is
 * called, which ones to delete" is exactly the kind of duplication that drifts
 * until the two disagree about what to prune.
 */

import { AUTO_BACKUP_HOURS } from '@/lib/backup-policy'
import { createBackup, getBackupStatus } from '@/lib/backup-run'

// `node:sqlite` is still flagged experimental, and the warning it prints on
// every run would be the loudest thing in the updater's console — where the
// whole point of the window is that a real failure is readable.
process.removeAllListeners('warning')
process.on('warning', (warning) => {
  if (warning.name !== 'ExperimentalWarning') console.warn(warning)
})

function megabytes(bytes: number): string {
  return `${(bytes / 1_000_000).toFixed(1)} MB`
}

// Wrapped in a function rather than written at the top level: this project's
// tsconfig has tsx emitting CommonJS, which has no top-level await.
async function main(): Promise<void> {
  // `--auto` is what the desktop shell's timer passes. Without it every run
  // takes a backup, which is what somebody typing `npm run backup` means and
  // what the updater needs before it changes anything.
  const auto = process.argv.includes('--auto')

  const result = await createBackup({
    skipIfNewerThanMs: auto ? AUTO_BACKUP_HOURS * 60 * 60 * 1000 : undefined,
  })

  if (result.kind === 'skipped') {
    console.log(`Backup skipped — the last one is from ${result.lastTakenAt.toLocaleString()}.`)
    return
  }

  const status = await getBackupStatus()
  console.log(`Backup created: ${result.name} (${megabytes(result.bytes)})`)
  if (result.deleted.length > 0) {
    console.log(`Removed ${result.deleted.length} older backup(s) beyond what is kept.`)
  }
  console.log(
    `${status.files.length} backups in ${status.folder}, ${megabytes(status.totalBytes)} total.`,
  )
}

main().catch((error: unknown) => {
  // A non-zero exit is what the updater checks: it refuses to touch anything
  // when the backup did not happen.
  console.error(`Backup FAILED: ${error instanceof Error ? error.message : String(error)}`)
  process.exit(1)
})
