// @vitest-environment jsdom

import { render } from '@testing-library/react'
import { describe, expect, it } from 'vitest'
import { Icon } from '../Icon'

const existingNames = [
  'orders',
  'customers',
  'inventory',
  'dashboard',
  'history',
  'chevron',
  'hamburger',
  'bell',
] as const

const utilityNames = [
  'menu',
  'receipt',
  'package',
  'chart',
  'search',
  'filter',
  'chevron-down',
  'close',
  'more-horizontal',
  'more',
  'plus',
  'minus',
  'arrow-right',
  'alert',
  'stock',
  'calendar',
] as const

function renderIcon(name: Parameters<typeof Icon>[0]['name']) {
  const { container } = render(<Icon name={name} />)
  return container.querySelector('svg') as SVGSVGElement
}

describe('Icon', () => {
  it.each(existingNames)('keeps the existing %s icon available', (name) => {
    expect(renderIcon(name).querySelector('path')).toBeInTheDocument()
  })

  it.each(utilityNames)('renders the new %s operational icon', (name) => {
    expect(renderIcon(name).querySelector('path')).toHaveAttribute('d')
  })

  it('gives menu and orders structurally different geometry', () => {
    const menuGeometry = renderIcon('menu').querySelector('path')?.getAttribute('d')
    const ordersGeometry = renderIcon('orders').querySelector('path')?.getAttribute('d')

    expect(menuGeometry).toBeTruthy()
    expect(ordersGeometry).toBeTruthy()
    expect(menuGeometry).not.toBe(ordersGeometry)
  })

  it('draws Orders with a closed container silhouette and internal details', () => {
    const path = renderIcon('orders').querySelector('path')
    const geometry = path?.getAttribute('d') ?? ''
    const horizontalSegments = geometry.match(/[Mm]\d+\s+\d+h\d+/g) ?? []

    expect(geometry).toMatch(/[zZ]/)
    expect(geometry).toMatch(/[vV]/)
    expect(horizontalSegments).not.toHaveLength(3)
  })

  it.each([...existingNames, ...utilityNames])(
    'keeps %s decorative and in the shared 24px, 2px round-stroke system',
    (name) => {
      const icon = renderIcon(name)

      expect(icon).toHaveAttribute('aria-hidden', 'true')
      expect(icon).toHaveAttribute('focusable', 'false')
      expect(icon).toHaveAttribute('viewBox', '0 0 24 24')
      expect(icon).toHaveAttribute('stroke-width', '2')
      expect(icon).toHaveAttribute('stroke-linecap', 'round')
      expect(icon).toHaveAttribute('stroke-linejoin', 'round')
    },
  )

  it('passes size and className through to the svg', () => {
    const { container } = render(<Icon name="plus" size={20} className="custom-icon" />)
    const icon = container.querySelector('svg')

    expect(icon).toHaveAttribute('width', '20')
    expect(icon).toHaveAttribute('height', '20')
    expect(icon).toHaveClass('custom-icon')
  })
})
