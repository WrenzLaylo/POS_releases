-- Selling something and sending it somewhere, recorded as one act.
--
-- A delivery order IS a sale: stock leaves, the ledger is charged if it is
-- utang, and it appears in History like any other. What it carries in addition
-- is where the sacks are going, when, and what the trip cost. So these live on
-- Sale rather than in a table of their own — the alternative is a second row
-- that has to be written in the same breath as the sale and can therefore fail
-- separately from it, which is how a sale ends up existing with nowhere to go.
--
-- Note also that "Delivery" already means something else here: a consignment
-- arriving FROM a supplier. Naming a second table after the opposite direction
-- would have made every future reader check which one they were looking at.
--
-- `deliverAt` is the flag. Null — which is every sale written before today —
-- means an ordinary counter sale, and nothing else in the app changes
-- behaviour for one. Non-null means this sale is going somewhere, and that is
-- what the Delivery Note tab and document key off.
ALTER TABLE "Sale" ADD COLUMN "deliverAt" DATETIME;

-- The destination as she says it: "Bagac". Short enough to read on a summary
-- line beside the date, which is the form the request arrives in.
ALTER TABLE "Sale" ADD COLUMN "deliverTo" TEXT NOT NULL DEFAULT '';

-- The receiver's full address, for the paper. Kept apart from `deliverTo`
-- because they are read in different places and neither substitutes for the
-- other: a printed note needs a street, and a screen summary needs a town.
--
-- On the sale rather than on Customer deliberately. Customer has no address
-- column, and adding one would assert that a customer has ONE address — but
-- the same buyer has feeds sent to a farm one week and to a house the next,
-- and a delivery note has to say where THIS load went.
ALTER TABLE "Sale" ADD COLUMN "deliverAddress" TEXT NOT NULL DEFAULT '';

-- Anything the driver needs told. Named `deliveryInstructions`, not
-- `deliveryNote`: the printable document is called the delivery note, and one
-- of the two had to not be.
ALTER TABLE "Sale" ADD COLUMN "deliveryInstructions" TEXT NOT NULL DEFAULT '';

-- What the trip is being charged for, in centavos.
--
-- Part of `totalAmount` and therefore part of what is owed, but NOT a
-- SaleItem: nothing left a shelf, it has no cost price, and it must not appear
-- in what a product sold. Stored separately for the same reason
-- `orderDiscountCentavos` is — so a figure folded into the total can still be
-- taken back out and named on a receipt.
--
-- Held apart from the goods for one more reason that bites: a customer's
-- standing "10% off" discounts feeds, not transport. The fee is added after
-- the order is priced, so no discount can ever reach it.
ALTER TABLE "Sale" ADD COLUMN "deliveryFeeCentavos" INTEGER NOT NULL DEFAULT 0;

-- "What is going out on Saturday" is the question this exists to answer.
CREATE INDEX "Sale_deliverAt_idx" ON "Sale"("deliverAt");
