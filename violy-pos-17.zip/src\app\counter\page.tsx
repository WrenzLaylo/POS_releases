import Link from 'next/link'
import { listProducts } from '@/server/products'
import { listCustomers } from '@/server/customers'
import { listCustomerCredit } from '@/server/ledger'
import { DELIVER } from '@/lib/routes'
import { OrderScreen } from './OrderScreen'
import { PageHeader } from '@/components/ui/PageHeader'

export const dynamic = 'force-dynamic'

export default async function CounterPage() {
  // Only what the counter needs: who is in credit, and how much. A negative
  // balance is money the shop is holding for somebody, reported here as the
  // positive figure she is offered back.
  //
  // The narrowing is the point. This used to call `listCustomerBalances()` and
  // discard almost all of it — that loads every customer row, every ledger
  // entry with its `occurredAt`, and a correlated "newest sale" subquery per
  // customer, to produce a last-ordered date the counter never reads.
  const [products, customers, creditByCustomer] = await Promise.all([
    listProducts(),
    listCustomers(),
    listCustomerCredit(),
  ])

  return (
    // `dense`: the counter is the one screen she works in continuously, and a
    // visible "Counter" title only repeats what the rail already highlights.
    //
    // The one action here costs the header row `dense` had otherwise removed
    // entirely — an `h-8` link plus `mb-4`, about 48px of the ~510px a 768px
    // laptop has to work in. Paid deliberately: a delivery order is a whole
    // way of selling, and the counter is where she starts. It is a link
    // rather than a Button so it cannot be reached by the catalog's keyboard
    // shortcuts, none of which should be able to leave a half-built order.
    <PageHeader
      title="Counter"
      dense
      fill
      actions={
        <Link
          href={DELIVER}
          className="inline-flex h-8 items-center justify-center rounded-control border border-line-strong bg-surface-raised px-3 text-sm font-medium text-ink transition-colors duration-150 hover:border-accent hover:bg-accent-soft focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
        >
          Deliver to a customer
        </Link>
      }
    >
      <OrderScreen
        products={products}
        customers={customers}
        creditByCustomer={creditByCustomer}
      />
    </PageHeader>
  )
}
