// @vitest-environment jsdom

import { render, screen } from '@testing-library/react'
import { describe, expect, it } from 'vitest'
import { Badge } from '../Badge'
import { Button } from '../Button'
import { Card } from '../Card'
import { Input } from '../Input'
import { PageHeader } from '../PageHeader'
import { SectionHeader } from '../SectionHeader'
import { Select } from '../Select'
import { Toolbar } from '../Toolbar'

describe('Card', () => {
  it.each([
    ['default', 'bg-surface'],
    ['raised', 'bg-surface-raised'],
    ['muted', 'bg-surface-sunk'],
    ['danger', 'border-owed'],
  ] as const)('applies the %s variant intent', (variant, expectedClass) => {
    render(
      <Card variant={variant} className="custom-card" data-testid="card">
        Stock summary
      </Card>,
    )

    const card = screen.getByTestId('card')
    expect(card).toHaveClass(expectedClass)
    expect(card).toHaveClass('custom-card')
    expect(card).toHaveTextContent('Stock summary')
  })
})

describe('Button', () => {
  it.each([
    ['primary', 'bg-accent'],
    ['secondary', 'border-line-strong'],
    ['ghost', 'text-ink-muted'],
    ['danger', 'text-owed'],
    ['success', 'bg-money-in'],
    ['destructive', 'bg-owed'],
  ] as const)(
    'keeps the %s variant on the shared default size and focus treatment',
    (variant, expectedClass) => {
      render(<Button variant={variant}>{variant}</Button>)

      expect(screen.getByRole('button', { name: variant })).toHaveClass(
        expectedClass,
        'h-10',
        'text-sm',
        'focus-visible:outline-none',
        'focus-visible:ring-2',
        'focus-visible:ring-accent',
      )
    },
  )

  it('provides a typed icon-only size without caller size overrides', () => {
    render(
      <Button size="icon" aria-label="Open filters">
        ×
      </Button>,
    )

    expect(screen.getByRole('button', { name: 'Open filters' })).toHaveClass('h-10', 'w-10', 'p-0')
  })
})

describe('form controls', () => {
  it('gives Input a fully opaque keyboard focus ring', () => {
    render(<Input aria-label="Search products" />)

    expect(screen.getByRole('textbox', { name: 'Search products' })).toHaveClass(
      'focus:ring-2',
      'focus:ring-accent',
      'focus:ring-offset-2',
    )
  })

  it('keeps the opaque focus indicator when Input is invalid', () => {
    render(<Input aria-label="Product name" aria-invalid="true" />)

    expect(screen.getByRole('textbox', { name: 'Product name' })).toHaveClass('focus:ring-accent')
    expect(screen.getByRole('textbox', { name: 'Product name' })).not.toHaveClass('aria-invalid:ring-owed/15')
  })

  it('gives Select the same keyboard focus treatment', () => {
    render(
      <Select aria-label="Category">
        <option>All</option>
      </Select>,
    )

    expect(screen.getByRole('combobox', { name: 'Category' })).toHaveClass(
      'focus:ring-2',
      'focus:ring-accent',
      'focus:ring-offset-2',
    )
  })
})

describe('Badge', () => {
  it.each([
    ['neutral', 'bg-accent-soft'],
    ['warn', 'text-warn'],
    ['owed', 'text-owed'],
    ['muted', 'text-ink-subtle'],
    ['paid', 'text-money-in'],
  ] as const)('keeps the %s business-semantic tone', (tone, expectedClass) => {
    render(<Badge tone={tone}>{tone}</Badge>)
    expect(screen.getByText(tone)).toHaveClass(expectedClass)
  })
})

describe('PageHeader', () => {
  it('renders optional context around a semantic page title', () => {
    render(
      <PageHeader
        title="Inventory"
        eyebrow="Store operations"
        description="Review stock levels and pricing."
        actions={<button type="button">Add product</button>}
      >
        <p>Inventory table</p>
      </PageHeader>,
    )

    expect(screen.getByRole('heading', { level: 1, name: 'Inventory' })).toBeInTheDocument()
    expect(screen.getByText('Store operations')).toHaveClass('text-accent')
    expect(screen.getByText('Review stock levels and pricing.')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Add product' }).parentElement).toHaveClass('w-full', 'sm:w-auto')
    expect(screen.getByText('Inventory table')).toBeInTheDocument()
  })
})

describe('SectionHeader', () => {
  it('uses an h2 by default and renders optional supporting content', () => {
    render(
      <SectionHeader
        title="Low stock"
        description="Products that need attention."
        action={<button type="button">View all</button>}
      />,
    )

    expect(screen.getByRole('heading', { level: 2, name: 'Low stock' })).toBeInTheDocument()
    expect(screen.getByText('Products that need attention.')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'View all' })).toBeInTheDocument()
  })
})

describe('Toolbar', () => {
  it('renders children and passes div attributes and classes through', () => {
    render(
      <Toolbar className="custom-toolbar" data-testid="toolbar" aria-label="Inventory filters">
        <button type="button">Filter</button>
      </Toolbar>,
    )

    const toolbar = screen.getByTestId('toolbar')
    expect(toolbar).toHaveClass('custom-toolbar')
    expect(toolbar).toHaveAttribute('aria-label', 'Inventory filters')
    expect(screen.getByRole('button', { name: 'Filter' })).toBeInTheDocument()
  })
})
