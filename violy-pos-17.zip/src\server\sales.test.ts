import { describe, it, expect, beforeEach } from 'vitest'
import { prisma } from '@/lib/db'
import { PAGE_SIZE } from '@/lib/pagination'
import { resetDb } from '@/test/reset-db'
import { lineTotal } from '@/lib/money'
import { createSale, listSales, voidSale } from '@/server/sales'
import { getDashboard } from '@/server/dashboard'
import { createOrder } from '@/server/orders'
import { recordPayment } from '@/server/ledger'

beforeEach(resetDb)

async function makeProduct(overrides: Partial<{
  name: string
  price: number
  costPrice: number
  stockQty: number
  isArchived: boolean
}> = {}) {
  const category = await prisma.category.upsert({
    where: { name: 'Pig Feeds' },
    create: { name: 'Pig Feeds' },
    update: {},
  })
  return prisma.product.create({
    data: {
      categoryId: category.id,
      name: overrides.name ?? 'Hog Grower (sako)',
      unit: 'sako (50kg)',
      price: overrides.price ?? 140000,
      costPrice: overrides.costPrice ?? 128000,
      stockQty: overrides.stockQty ?? 10,
      lowStockThreshold: 5,
      isArchived: overrides.isArchived ?? false,
    },
  })
}

describe('createSale', () => {
  it('writes the sale, its items, and the stock deduction together', async () => {
    const product = await makeProduct()

    const result = await createSale([{ productId: product.id, quantity: 2 }])

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.totalCentavos).toBe(280000)

    const sale = await prisma.sale.findUniqueOrThrow({
      where: { id: result.data.saleId },
      include: { items: true },
    })
    expect(sale.totalAmount).toBe(280000)
    expect(sale.items).toHaveLength(1)

    const after = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
    expect(after.stockQty).toBe(8)
  })

  it('snapshots price and cost at the time of sale', async () => {
    const product = await makeProduct({ price: 140000, costPrice: 128000 })

    const result = await createSale([{ productId: product.id, quantity: 1 }])
    if (!result.ok) throw new Error(result.error)

    // The store later raises both price and cost.
    await prisma.product.update({
      where: { id: product.id },
      data: { price: 148000, costPrice: 136000 },
    })

    const item = await prisma.saleItem.findFirstOrThrow()
    expect(item.priceAtSale).toBe(140000)
    expect(item.costAtSale).toBe(128000)
  })

  it('prices from the database, ignoring any stale client price', async () => {
    const product = await makeProduct({ price: 140000 })

    const result = await createSale([{ productId: product.id, quantity: 1 }])
    if (!result.ok) throw new Error(result.error)

    expect(result.data.totalCentavos).toBe(140000)
  })

  it('handles fractional kilo quantities', async () => {
    const product = await makeProduct({ name: 'Hog Grower (kilo)', price: 3250, stockQty: 20 })

    const result = await createSale([{ productId: product.id, quantity: 2.5 }])

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.totalCentavos).toBe(8125)

    const after = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
    expect(after.stockQty).toBe(17.5)
  })

  it('sums multiple lines', async () => {
    const sako = await makeProduct({ name: 'Hog Grower (sako)', price: 140000 })
    const kilo = await makeProduct({ name: 'Hog Grower (kilo)', price: 3250, stockQty: 30 })

    const result = await createSale([
      { productId: sako.id, quantity: 1 },
      { productId: kilo.id, quantity: 1 },
    ])

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.totalCentavos).toBe(143250)
  })

  it('allows stock to go negative when over-selling', async () => {
    const product = await makeProduct({ stockQty: 3 })

    const result = await createSale([{ productId: product.id, quantity: 5 }])

    expect(result.ok).toBe(true)
    const after = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
    expect(after.stockQty).toBe(-2)
  })

  it('rejects an empty cart', async () => {
    const result = await createSale([])

    expect(result).toEqual({ ok: false, error: 'Cart is empty.' })
    expect(await prisma.sale.count()).toBe(0)
  })

  it('rejects a non-positive quantity', async () => {
    const product = await makeProduct()

    const result = await createSale([{ productId: product.id, quantity: 0 }])

    expect(result.ok).toBe(false)
    expect(await prisma.sale.count()).toBe(0)
  })

  it('rejects a product archived in another tab, leaving no orphan sale', async () => {
    const product = await makeProduct({ isArchived: true })

    const result = await createSale([{ productId: product.id, quantity: 1 }])

    expect(result.ok).toBe(false)
    if (result.ok) return
    expect(result.error).toContain('no longer available')
    expect(await prisma.sale.count()).toBe(0)
    expect(await prisma.saleItem.count()).toBe(0)
  })

  it('rolls back completely when one product in the cart is missing', async () => {
    const product = await makeProduct()

    const result = await createSale([
      { productId: product.id, quantity: 1 },
      { productId: 9999, quantity: 1 },
    ])

    expect(result.ok).toBe(false)
    expect(await prisma.sale.count()).toBe(0)
    expect(await prisma.saleItem.count()).toBe(0)

    const after = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
    expect(after.stockQty).toBe(10) // untouched
  })

  it('rolls back the written sale and items when the stock decrement fails', async () => {
    const product = await makeProduct({ stockQty: 10 })

    // Force a failure during the stock-decrement phase — after tx.sale.create
    // has already written the Sale and its SaleItem rows. If the transaction
    // boundary is wrong, those rows survive and this test catches it.
    await prisma.$executeRawUnsafe(
      `CREATE TRIGGER reject_extreme_stock BEFORE UPDATE ON "Product"
       WHEN NEW."stockQty" < -100
       BEGIN SELECT RAISE(ABORT, 'stock floor breached'); END;`,
    )

    try {
      const result = await createSale([{ productId: product.id, quantity: 200 }])

      expect(result.ok).toBe(false)
      expect(await prisma.sale.count()).toBe(0)
      expect(await prisma.saleItem.count()).toBe(0)

      const after = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
      expect(after.stockQty).toBe(10)
    } finally {
      await prisma.$executeRawUnsafe('DROP TRIGGER IF EXISTS reject_extreme_stock')
    }
  })

  it('merges three lines for the same product into a single decrement and item', async () => {
    const product = await makeProduct({ price: 140000, stockQty: 10 })

    const result = await createSale([
      { productId: product.id, quantity: 1 },
      { productId: product.id, quantity: 1.5 },
      { productId: product.id, quantity: 1 },
    ])

    expect(result.ok).toBe(true)
    if (!result.ok) return

    const summedQuantity = 3.5
    const sale = await prisma.sale.findUniqueOrThrow({
      where: { id: result.data.saleId },
      include: { items: true },
    })
    expect(sale.items).toHaveLength(1)
    expect(sale.items[0].quantity).toBe(summedQuantity)
    expect(sale.totalAmount).toBe(lineTotal(140000, summedQuantity))
    expect(result.data.totalCentavos).toBe(lineTotal(140000, summedQuantity))

    const after = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
    expect(after.stockQty).toBe(10 - summedQuantity)
  })
})


describe('createSale, a discount typed against one line', () => {
  it('takes the typed figure off each unit of that line', async () => {
    const product = await makeProduct({ price: 157500 })

    const result = await createSale({
      items: [{ productId: product.id, quantity: 2, discountPerUnitCentavos: 7500 }],
      cashTenderedCentavos: null,
      clientOrderKey: 'line-discount-walkin-1',
    })

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.totalCentavos).toBe(300000)

    const sale = await prisma.sale.findUniqueOrThrow({
      where: { id: result.data.saleId },
      include: { items: true },
    })
    expect(sale.items[0].discountAtSale).toBe(7500)
  })

  it('never makes a line worth less than nothing', async () => {
    const product = await makeProduct({ price: 5000 })

    const result = await createSale({
      items: [{ productId: product.id, quantity: 2, discountPerUnitCentavos: 900000 }],
      cashTenderedCentavos: null,
      clientOrderKey: 'line-discount-walkin-2',
    })

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.totalCentavos).toBe(0)
  })

  it('refuses a line discount that is not a whole, non-negative amount', async () => {
    const product = await makeProduct()

    const result = await createSale({
      items: [{ productId: product.id, quantity: 1, discountPerUnitCentavos: -1 }],
      cashTenderedCentavos: null,
      clientOrderKey: 'line-discount-walkin-3',
    })

    expect(result.ok).toBe(false)
    expect(await prisma.sale.count()).toBe(0)
  })
})

describe('createSale checkout safety', () => {
  it('stores cash tendered and change', async () => {
    const product = await makeProduct({ price: 75000 })
    const result = await createSale({
      items: [{ productId: product.id, quantity: 1 }],
      cashTenderedCentavos: 100000,
      clientOrderKey: 'walkin-tender-test',
    })

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.cashTenderedCentavos).toBe(100000)
    expect(result.data.cashPaidCentavos).toBe(75000)
    expect(result.data.changeCentavos).toBe(25000)

    const sale = await prisma.sale.findUniqueOrThrow({ where: { id: result.data.saleId } })
    expect(sale.cashTenderedCentavos).toBe(100000)
    expect(sale.changeCentavos).toBe(25000)
  })

  it('refuses an explicit short walk-in tender', async () => {
    const product = await makeProduct({ price: 75000 })
    const result = await createSale({
      items: [{ productId: product.id, quantity: 1 }],
      cashTenderedCentavos: 50000,
      clientOrderKey: 'walkin-short-test',
    })

    expect(result.ok).toBe(false)
    expect(await prisma.sale.count()).toBe(0)
  })

  it('returns the original sale when the same checkout key is retried', async () => {
    const product = await makeProduct({ price: 75000, stockQty: 10 })
    const input = {
      items: [{ productId: product.id, quantity: 2 }],
      cashTenderedCentavos: 150000,
      clientOrderKey: 'walkin-idempotency-test',
    }

    const first = await createSale(input)
    const second = await createSale(input)

    expect(first.ok && second.ok).toBe(true)
    if (!first.ok || !second.ok) return
    expect(second.data.saleId).toBe(first.data.saleId)
    expect(await prisma.sale.count()).toBe(1)
    expect((await prisma.product.findUniqueOrThrow({ where: { id: product.id } })).stockQty).toBe(8)
  })
})

describe('voidSale', () => {
  it('restores stock, voids the linked charge and keeps an audit record', async () => {
    const product = await makeProduct({ price: 100000, stockQty: 10 })
    const customer = await prisma.customer.create({ data: { name: 'VOID CUSTOMER' } })
    const order = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 2 }],
      cashPaidCentavos: 0,
      clientOrderKey: 'void-order-test',
    })
    if (!order.ok) throw new Error(order.error)

    const result = await voidSale(order.data.saleId, 'Duplicate checkout')
    expect(result.ok).toBe(true)

    const sale = await prisma.sale.findUniqueOrThrow({
      where: { id: order.data.saleId },
      include: { ledgerEntry: true },
    })
    expect(sale.isVoided).toBe(true)
    expect(sale.voidReason).toBe('Duplicate checkout')
    expect(sale.ledgerEntry?.isVoided).toBe(true)
    expect((await prisma.product.findUniqueOrThrow({ where: { id: product.id } })).stockQty).toBe(10)
    expect(await prisma.stockMovement.count({ where: { saleId: sale.id, type: 'VOID' } })).toBe(1)
  })
})

describe('listSales', () => {
  it('returns newest first with line items and product names', async () => {
    const product = await makeProduct()
    await createSale([{ productId: product.id, quantity: 1 }])
    await createSale([{ productId: product.id, quantity: 2 }])

    const sales = (await listSales()).rows

    expect(sales).toHaveLength(2)
    expect(sales[0].totalAmount).toBe(280000)
    expect(sales[0].items[0].product.name).toBe('Hog Grower (sako)')
  })

  it('filters to an inclusive date range', async () => {
    const product = await makeProduct()
    await prisma.sale.create({
      data: { createdAt: new Date(2026, 5, 10, 9, 0), totalAmount: 1000 },
    })
    await prisma.sale.create({
      data: { createdAt: new Date(2026, 6, 25, 23, 30), totalAmount: 2000 },
    })
    await prisma.sale.create({
      data: { createdAt: new Date(2026, 7, 1, 9, 0), totalAmount: 3000 },
    })

    const sales = (await listSales({ from: '2026-06-10', to: '2026-07-25' })).rows

    expect(sales.map((s) => s.totalAmount).sort()).toEqual([1000, 2000])
  })
})

describe('cross-module agreement', () => {
  it('createSale, getDashboard, and listSales agree on the total for a fractional sale', async () => {
    const product = await makeProduct({ name: 'Hog Grower (kilo)', price: 3250, stockQty: 20 })
    const now = new Date()

    const result = await createSale([{ productId: product.id, quantity: 2.5 }])
    expect(result.ok).toBe(true)
    if (!result.ok) return

    const dashboard = await getDashboard(now)
    expect(dashboard.todayCentavos).toBe(result.data.totalCentavos)

    const sales = (await listSales()).rows
    const sale = sales.find((s) => s.id === result.data.saleId)
    expect(sale).toBeDefined()
    if (!sale) return

    const summedFromItems = sale.items.reduce(
      (acc, item) => acc + lineTotal(item.priceAtSale, item.quantity),
      0,
    )
    expect(summedFromItems).toBe(sale.totalAmount)
  })
})

describe('listSales paging and filters', () => {
  async function makeSales(count: number, customerId?: number) {
    const product = await makeProduct()
    for (let i = 0; i < count; i++) {
      await prisma.sale.create({
        data: {
          totalAmount: 1000 + i,
          customerId: customerId ?? null,
          cashPaidCentavos: 1000 + i,
          createdAt: new Date(2026, 6, 1 + i, 9, 0),
          items: {
            create: [{ productId: product.id, quantity: 1, priceAtSale: 1000 + i, costAtSale: 900 }],
          },
        },
      })
    }
  }

/**
 * Paging assertions are expressed in terms of `PAGE_SIZE`, never as the number
 * it happens to hold. They were written against a literal 20/25 and every one
 * of them broke the day the page size changed — which told us nothing about
 * paging, only that a constant had moved.
 */
  it('returns the first page and the true total', async () => {
    const total = PAGE_SIZE + 5
    await makeSales(total)

    const result = await listSales({}, 1)

    expect(result.rows).toHaveLength(PAGE_SIZE)
    expect(result.total).toBe(total)
    expect(result.page).toBe(1)
    expect(result.pageCount).toBe(2)
  })

  it('returns the remainder on the last page', async () => {
    await makeSales(PAGE_SIZE + 5)

    const result = await listSales({}, 2)

    expect(result.rows).toHaveLength(5)
    expect(result.page).toBe(2)
  })

  it('page 2 continues where page 1 stopped — no gap, no overlap', async () => {
    const total = PAGE_SIZE + 5
    await makeSales(total)

    const firstIds = (await listSales({}, 1)).rows.map((s) => s.id)
    const secondIds = (await listSales({}, 2)).rows.map((s) => s.id)

    const overlap = firstIds.filter((id) => secondIds.includes(id))
    expect(overlap).toEqual([])

    const combined = [...firstIds, ...secondIds]
    expect(new Set(combined).size).toBe(total)
    expect(combined).toHaveLength(total)
  })

  it('clamps a page past the end to the last page', async () => {
    await makeSales(PAGE_SIZE + 5)

    const result = await listSales({}, 99)

    expect(result.page).toBe(2)
    expect(result.rows).toHaveLength(5)
  })

  it('reports page 1 of 1 for an empty list', async () => {
    const result = await listSales({}, 1)

    expect(result.rows).toEqual([])
    expect(result.total).toBe(0)
    expect(result.pageCount).toBe(1)
  })

  it('counts the filtered set, not the whole table', async () => {
    const customer = await prisma.customer.create({ data: { name: 'ROMAN' } })
    await makeSales(PAGE_SIZE + 5)
    await makeSales(3, customer.id)

    const result = await listSales({ customerId: customer.id }, 1)

    expect(result.total).toBe(3)
    expect(result.pageCount).toBe(1)
    expect(result.rows).toHaveLength(3)
  })

  it('filters to walk-in sales', async () => {
    const customer = await prisma.customer.create({ data: { name: 'ROMAN' } })
    await makeSales(2)
    await makeSales(3, customer.id)

    const result = await listSales({ customerId: 'walkin' }, 1)

    expect(result.total).toBe(2)
    expect(result.rows.every((s) => s.customerId === null)).toBe(true)
  })

  it('composes a customer filter with a date range and a page', async () => {
    const customer = await prisma.customer.create({ data: { name: 'ROMAN' } })
    await makeSales(25, customer.id) // 2026-07-01 .. 2026-07-25

    // 5 July to 24 July inclusive is 20 sales — a fixed window, deliberately
    // independent of PAGE_SIZE, so this asserts the filter composes with
    // paging rather than re-asserting the page size.
    const result = await listSales(
      { customerId: customer.id, from: '2026-07-05', to: '2026-07-24' },
      2,
    )

    expect(result.total).toBe(20)
    expect(result.pageCount).toBe(Math.ceil(20 / PAGE_SIZE))
    expect(result.rows.length).toBeLessThanOrEqual(PAGE_SIZE)
  })

  it('separates cash, credit and partial transactions', async () => {
    const product = await makeProduct({ price: 100000, stockQty: 10 })
    const customer = await prisma.customer.create({ data: { name: 'ROMAN' } })

    const credit = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 1 }],
      cashPaidCentavos: 0,
    })
    const cash = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 1 }],
      cashPaidCentavos: 100000,
    })
    const partial = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 1 }],
      cashPaidCentavos: 40000,
    })
    if (!credit.ok || !cash.ok || !partial.ok) throw new Error('setup failed')

    expect((await listSales({ status: 'credit' }, 1)).rows.map((sale) => sale.id)).toEqual([
      credit.data.saleId,
    ])
    expect((await listSales({ status: 'cash' }, 1)).rows.map((sale) => sale.id)).toEqual([
      cash.data.saleId,
    ])
    expect((await listSales({ status: 'partial' }, 1)).rows.map((sale) => sale.id)).toEqual([
      partial.data.saleId,
    ])
  })

  it('moves a sale to the voided filter through the sale correction workflow', async () => {
    const product = await makeProduct({ price: 100000 })
    const customer = await prisma.customer.create({ data: { name: 'ROMAN' } })
    const credit = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 1 }],
      cashPaidCentavos: 0,
    })
    if (!credit.ok) throw new Error('setup failed')

    const result = await voidSale(credit.data.saleId, 'Duplicate order')
    expect(result.ok).toBe(true)

    expect((await listSales({ status: 'credit' }, 1)).total).toBe(0)
    expect((await listSales({ status: 'voided' }, 1)).total).toBe(1)
  })

  it('keeps a later account payment from rewriting the original sale type', async () => {
    const product = await makeProduct({ price: 100000 })
    const customer = await prisma.customer.create({ data: { name: 'ROMAN' } })
    await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 1 }],
      cashPaidCentavos: 0,
    })

    await recordPayment({
      customerId: customer.id,
      amountCentavos: 100000,
      occurredAt: new Date(),
    })

    expect((await listSales({ status: 'credit' }, 1)).total).toBe(1)
  })
})

describe('listSales, filtered by brand', () => {
  async function categoryNamed(name: string) {
    return prisma.category.upsert({ where: { name }, create: { name }, update: {} })
  }

  async function productIn(categoryName: string, name: string) {
    const category = await categoryNamed(categoryName)
    return prisma.product.create({
      data: {
        categoryId: category.id,
        name,
        unit: 'sako',
        price: 100_000,
        costPrice: 90_000,
        stockQty: 100,
        lowStockThreshold: 5,
      },
    })
  }

  it('finds sales that INCLUDED the brand, not sales made up only of it', async () => {
    // `some`, not `every`. A sale of two Atlas sacks and one Pigrolac is an
    // Atlas sale as well as a Pigrolac one, and answering otherwise would make
    // the filter useless on exactly the mixed baskets it is meant to find.
    const atlas = await productIn('Atlas', 'Atlas Grower')
    const pigrolac = await productIn('Pigrolac', 'Pigrolac Booster')
    const atlasCategoryId = atlas.categoryId

    const mixed = await createSale({
      items: [
        { productId: atlas.id, quantity: 2 },
        { productId: pigrolac.id, quantity: 1 },
      ],
      cashTenderedCentavos: null,
      clientOrderKey: 'brand-mixed',
    })
    const pigrolacOnly = await createSale({
      items: [{ productId: pigrolac.id, quantity: 3 }],
      cashTenderedCentavos: null,
      clientOrderKey: 'brand-pigrolac-only',
    })
    expect(mixed.ok && pigrolacOnly.ok).toBe(true)

    const page = await listSales({ categoryId: atlasCategoryId }, 1)
    expect(page.total).toBe(1)
    expect(page.rows).toHaveLength(1)
    expect(page.rows[0].items.some((item) => item.product.name === 'Atlas Grower')).toBe(true)
  })

  it('returns nothing for a brand that has never been sold', async () => {
    const atlas = await productIn('Atlas', 'Atlas Grower')
    const unsold = await categoryNamed('Ace Feeds')
    await createSale({
      items: [{ productId: atlas.id, quantity: 1 }],
      cashTenderedCentavos: null,
      clientOrderKey: 'brand-unsold',
    })

    const page = await listSales({ categoryId: unsold.id }, 1)
    expect(page.total).toBe(0)
    expect(page.rows).toEqual([])
  })

  it('combines with the other filters rather than replacing them', async () => {
    const atlas = await productIn('Atlas', 'Atlas Grower')
    const ace = await productIn('Ace Feeds', 'Ace Grower')

    const atlasSale = await createSale({
      items: [{ productId: atlas.id, quantity: 1 }],
      cashTenderedCentavos: null,
      clientOrderKey: 'brand-combined-atlas',
    })
    const aceSale = await createSale({
      items: [{ productId: ace.id, quantity: 1 }],
      cashTenderedCentavos: null,
      clientOrderKey: 'brand-combined-ace',
    })
    expect(atlasSale.ok && aceSale.ok).toBe(true)
    if (!atlasSale.ok) return

    // Brand narrows within a status rather than replacing it.
    const cashAtlas = await listSales({ categoryId: atlas.categoryId, status: 'cash' }, 1)
    expect(cashAtlas.total).toBe(1)

    // And a brand filter cannot resurrect a sale another filter excluded.
    await voidSale(atlasSale.data.saleId, 'Wrong brand rung up')
    expect((await listSales({ categoryId: atlas.categoryId, status: 'cash' }, 1)).total).toBe(0)
    expect((await listSales({ categoryId: atlas.categoryId, status: 'voided' }, 1)).total).toBe(1)
  })
})
