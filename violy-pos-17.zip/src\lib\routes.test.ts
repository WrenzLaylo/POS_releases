import { existsSync, readdirSync } from 'node:fs'
import { join } from 'node:path'
import { describe, expect, it } from 'vitest'
import {
  ROUTES,
  accountStatement,
  bookEntry,
  BOOK_BULK,
  DELIVER,
  HISTORY_GOING_OUT,
  NEW_DELIVERY,
  STOCK_COUNT,
  delivery,
  deliveryNote,
  settleDelivery,
  paymentReceipt,
  planInvoice,
  sale,
  saleReceipt,
} from './routes'

describe('ROUTES', () => {
  it('every route is absolute and has no trailing slash', () => {
    for (const route of Object.values(ROUTES)) {
      expect(route.startsWith('/')).toBe(true)
      expect(route.endsWith('/')).toBe(false)
    }
  })

  it('names every destination and nothing else', () => {
    // Settings is a route but not a rail destination — it is a utility,
    // reached from the topbar. The rail carries the six workspaces.
    expect(Object.keys(ROUTES).sort()).toEqual([
      'book',
      'counter',
      'dashboard',
      'deliveries',
      'history',
      'settings',
      'stock',
    ])
  })

  it('builds customer ledger, bulk and receipt paths', () => {
    expect(bookEntry(42)).toBe('/book/42')
    expect(BOOK_BULK).toBe('/book/bulk')
    expect(NEW_DELIVERY).toBe('/deliveries/new')
    expect(STOCK_COUNT).toBe('/stock/count')
    expect(sale(42)).toBe('/history/42')
    expect(saleReceipt(42)).toBe('/history/42/receipt')
  })

  it('keeps the two directions of "delivery" apart', () => {
    // Stock arriving from a supplier, and stock leaving for a customer. They
    // share a word and nothing else, and the paths say so.
    expect(DELIVER).toBe('/counter/deliver')
    expect(NEW_DELIVERY).toBe('/deliveries/new')
    expect(deliveryNote(42)).toBe('/history/42/delivery-note')
    expect(delivery(42)).toBe('/deliveries/42')
  })

  it('points the going-out tab at the history page it is a tab of', () => {
    // A query string, not a route: it IS the History screen. What matters is
    // that it still resolves to that page, so the tab cannot drift onto a
    // path that does not exist.
    expect(HISTORY_GOING_OUT.startsWith(`${ROUTES.history}?`)).toBe(true)
    expect(HISTORY_GOING_OUT).toBe('/history?view=going-out')
  })

  it('nests the three utang documents under the customer they concern', () => {
    expect(planInvoice(42, 7)).toBe('/book/42/plan/7')
    expect(paymentReceipt(42, 9)).toBe('/book/42/payment/9')
    expect(accountStatement(42)).toBe('/book/42/statement')
  })
})

/**
 * A test file colocated under `src/app/` takes every nested route with it.
 *
 * Observed on Next 16.2.11: one `SaleTabs.test.tsx` beside the component it
 * tests, and `/history/[id]/receipt`, `/history/[id]/delivery-note` and
 * `/book/[id]/statement` all began returning 404 — every printable document
 * in the app, gone. `/history/[id]` itself still rendered, which is what made
 * it look like a data problem rather than a routing one.
 *
 * Nothing caught it. `tsc` passed, all 1099 tests passed, and `next build`
 * passed AND printed each of those routes in its route table. Only loading
 * the page showed it.
 *
 * So the rule is mechanical: component tests live in
 * `src/components/__tests__/`, never under `src/app/`, whatever they test.
 */
describe('nothing under src/app/ is a test file', () => {
  it('keeps tests out of the route tree', () => {
    const appDir = join(process.cwd(), 'src', 'app')
    const offenders: string[] = []

    function walk(dir: string) {
      for (const entry of readdirSync(dir, { withFileTypes: true })) {
        const full = join(dir, entry.name)
        if (entry.isDirectory()) walk(full)
        else if (/\.(test|spec)\.[cm]?[jt]sx?$/.test(entry.name)) offenders.push(full)
      }
    }
    walk(appDir)

    expect(offenders).toEqual([])
  })
})

/**
 * `revalidatePath` pointing at a route that does not exist has shipped as a
 * bug in this repo twice (`revalidatePath('/pos')` in both products.ts and
 * sales.ts, after /pos was deleted). `vitest.config.ts` stubs `next/cache`,
 * so revalidation itself is unobservable in tests — but a route constant that
 * resolves to nothing is observable, and that is the actual defect.
 */
describe('ROUTES resolve to real pages', () => {
  it.each(Object.entries(ROUTES))('%s (%s) has a page.tsx', (_name, route) => {
    const dir = join(process.cwd(), 'src', 'app', route.replace(/^\//, ''))
    expect(existsSync(join(dir, 'page.tsx'))).toBe(true)
  })
})


describe('dynamic route builders resolve to real pages', () => {
  it('saleReceipt points at the history receipt page', () => {
    const page = join(process.cwd(), 'src', 'app', 'history', '[id]', 'receipt', 'page.tsx')
    expect(existsSync(page)).toBe(true)
  })

  it.each([
    ['planInvoice', ['book', '[id]', 'plan', '[planId]']],
    ['paymentReceipt', ['book', '[id]', 'payment', '[entryId]']],
    ['accountStatement', ['book', '[id]', 'statement']],
    ['sale', ['history', '[id]']],
    ['bookEntry', ['book', '[id]']],
    ['BOOK_BULK', ['book', 'bulk']],
    ['NEW_DELIVERY', ['deliveries', 'new']],
    ['STOCK_COUNT', ['stock', 'count']],
    // Guarded now because it was NOT: this helper existed for weeks pointing
    // at a page nobody had built, and nothing failed. Every route constant
    // belongs on this list or the check is only as good as who remembers it.
    ['delivery', ['deliveries', '[id]']],
    ['settleDelivery', ['deliveries', '[id]', 'settle']],
    ['DELIVER', ['counter', 'deliver']],
    ['deliveryNote', ['history', '[id]', 'delivery-note']],
  ])('%s points at a real page', (_name, segments) => {
    expect(existsSync(join(process.cwd(), 'src', 'app', ...segments, 'page.tsx'))).toBe(true)
  })
})
