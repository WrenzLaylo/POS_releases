import { dayKey, startOfDay, addDays } from './dates'

/**
 * What a backup is called, and which ones survive.
 *
 * Split out from the code that writes files so the part with actual reasoning
 * in it — what to delete — can be tested without a disk.
 */

const NAME_PATTERN = /^violy-pos-(\d{4})-(\d{2})-(\d{2})_(\d{2})-(\d{2})-(\d{2})-(\d{3})\.db$/

/**
 * Newest backups kept whatever their age.
 *
 * This number exists because backups became automatic. A plain "keep the last
 * 30" was right while every backup was a deliberate act, but a timer running
 * every six hours fills 30 slots in just over a week — so the moment automation
 * was added, that policy would have quietly shortened the history to seven days
 * and then started eating the oldest copy of the ledger every morning. The two
 * rules together mean a busy day cannot evict last month.
 */
export const KEEP_RECENT = 10

/** Plus the newest backup of each of the last N days. */
export const KEEP_DAYS = 30

/**
 * How stale the newest backup must be before an automatic one is taken.
 *
 * The single definition of the schedule. The desktop shell does not hold a copy
 * of this number — it asks every hour and lets `scripts/backup-db.ts` decide,
 * so the interval cannot drift between the timer that runs backups and the
 * sentence in Settings that tells her how often they run.
 */
export const AUTO_BACKUP_HOURS = 6

/** The file a backup taken now would be written to. */
export function backupFileName(at: Date): string {
  const stamp = at.toISOString().replace(/[:.]/g, '-').replace('T', '_').replace('Z', '')
  return `violy-pos-${stamp}.db`
}

/**
 * When a backup was taken, read back out of its name.
 *
 * Returns null for anything this app did not write — including
 * `dev-backup-before-pos-fixes.db`, a hand-named copy sitting in the folder
 * today. That null is load-bearing: an unrecognised file is never counted and
 * never deleted, so somebody can drop a copy in there by hand and pruning will
 * leave it alone rather than treating it as the oldest thing to discard.
 */
export function backupTakenAt(name: string): Date | null {
  const match = NAME_PATTERN.exec(name)
  if (!match) return null

  const [, year, month, day, hour, minute, second, ms] = match
  const at = new Date(`${year}-${month}-${day}T${hour}:${minute}:${second}.${ms}Z`)
  return Number.isNaN(at.getTime()) ? null : at
}

export function isBackupName(name: string): boolean {
  return backupTakenAt(name) !== null
}

/** Backup file names, newest first, ignoring anything not written by this app. */
export function sortNewestFirst(names: readonly string[]): string[] {
  return names
    .filter(isBackupName)
    .sort()
    .reverse()
}

/**
 * Which backups to delete, given everything in the folder.
 *
 * Keeps the newest {@link KEEP_RECENT}, plus the newest backup of each of the
 * last {@link KEEP_DAYS} days. Days are LOCAL days — the file name is stamped
 * in UTC, and in the Philippines that is eight hours off, so grouping by the
 * text of the name would put an evening backup on the following day and let two
 * of them survive one calendar date while some other date kept none.
 */
export function selectBackupsToDelete(
  names: readonly string[],
  now: Date,
  options: { keepRecent?: number; keepDays?: number } = {},
): string[] {
  const keepRecent = options.keepRecent ?? KEEP_RECENT
  const keepDays = options.keepDays ?? KEEP_DAYS

  const dated = sortNewestFirst(names).map((name) => ({
    name,
    at: backupTakenAt(name) as Date,
  }))

  const keep = new Set(dated.slice(0, Math.max(0, keepRecent)).map((row) => row.name))

  // The daily rule looks back from the start of today, so "30 days" means 30
  // calendar dates including today rather than a rolling 720 hours — otherwise
  // whether a month-old backup survives would depend on the time of day it is
  // being asked.
  const oldestDay = addDays(startOfDay(now), -(Math.max(1, keepDays) - 1)).getTime()
  const daysSeen = new Set<string>()

  for (const row of dated) {
    if (row.at.getTime() < oldestDay) continue
    const day = dayKey(row.at)
    if (daysSeen.has(day)) continue
    daysSeen.add(day)
    keep.add(row.name)
  }

  return dated.filter((row) => !keep.has(row.name)).map((row) => row.name)
}
