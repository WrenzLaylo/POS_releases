'use client'

import { useState } from 'react'
import { cn } from '@/lib/cn'

/**
 * A product photo that degrades to a plain well when the file is not there.
 *
 * `imagePath` is a path stored on the row, and a stored path can always go
 * stale — the file is deleted, the uploads folder is not carried across a
 * restore, the disk moves. Guarding only on "is a path recorded" is what put a
 * browser's broken-image icon in the middle of the product dialog: the record
 * said there was a photo, so the `<img>` rendered, and the file was gone.
 *
 * `onError` is the only reliable signal here. There is no way to know from the
 * path alone whether it resolves, and checking on the server would cost a
 * filesystem hit per product on every render of the catalog.
 */
export function ProductImage({
  src,
  alt = '',
  className,
  /** Rendered instead when there is no usable image. */
  fallbackClassName,
}: {
  src: string | null
  alt?: string
  className?: string
  fallbackClassName?: string
}) {
  const [failed, setFailed] = useState(false)

  if (!src || failed) {
    return <div aria-hidden="true" className={cn('bg-surface-sunk', fallbackClassName ?? className)} />
  }

  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={src}
      alt={alt}
      onError={() => setFailed(true)}
      className={cn('object-cover', className)}
    />
  )
}
