import { beforeEach, describe, expect, it } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'
import { recordStockCount } from '@/server/stock-count'

beforeEach(resetDb)

async function makeProduct(name: string, stockQty: number, isArchived = false) {
  const category = await prisma.category.upsert({
    where: { name: 'Pig Feeds' },
    create: { name: 'Pig Feeds' },
    update: {},
  })
  return prisma.product.create({
    data: {
      categoryId: category.id,
      name,
      unit: 'bag (50kg)',
      price: 200_000,
      costPrice: 190_000,
      stockQty,
      lowStockThreshold: 5,
      isArchived,
    },
  })
}

const stockOf = async (id: number) =>
  (await prisma.product.findUniqueOrThrow({ where: { id } })).stockQty

describe('recording a shelf count', () => {
  it('sets stock to what was counted, from zero', async () => {
    // The case the shop actually hit: everything reads 0 because nothing was
    // ever counted in.
    const product = await makeProduct('Atlas Grower', 0)

    const result = await recordStockCount([{ productId: product.id, countedQty: 40 }])

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data).toEqual({ changed: 1, netQuantity: 40 })
    expect(await stockOf(product.id)).toBe(40)
  })

  it('sets, never adds — so saving the same count twice is safe', async () => {
    // The whole reason a count is absolute. A delivery increments and needs an
    // idempotency key; this does not, because the second save is a no-op.
    const product = await makeProduct('Atlas Grower', 0)

    await recordStockCount([{ productId: product.id, countedQty: 40 }])
    const second = await recordStockCount([{ productId: product.id, countedQty: 40 }])

    expect(await stockOf(product.id)).toBe(40)
    expect(second.ok).toBe(true)
    if (!second.ok) return
    // Nothing moved, so nothing is reported as having moved.
    expect(second.data.changed).toBe(0)
  })

  it('brings a product back from negative', async () => {
    // Selling against an uncounted product drove five of them below zero. A
    // count is how that gets corrected.
    const product = await makeProduct('Gestation', -2)

    const result = await recordStockCount([{ productId: product.id, countedQty: 12 }])

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.netQuantity).toBe(14)
    expect(await stockOf(product.id)).toBe(12)
  })

  it('counts a fractional quantity, because some stock is sold by the kilo', async () => {
    const product = await makeProduct('Broodsow (kilo)', 0)
    expect((await recordStockCount([{ productId: product.id, countedQty: 18.5 }])).ok).toBe(true)
    expect(await stockOf(product.id)).toBe(18.5)
  })

  it('writes one movement per changed row, and none for a row that already matched', async () => {
    // A stock figure that moves with no record of who moved it is how an
    // inventory stops being believed — but fifty-five movements of zero on the
    // first count would bury the ones that mean something.
    const moved = await makeProduct('Atlas Grower', 0)
    const same = await makeProduct('Atlas Starter', 30)

    await recordStockCount([
      { productId: moved.id, countedQty: 40 },
      { productId: same.id, countedQty: 30 },
    ])

    const movements = await prisma.stockMovement.findMany()
    expect(movements).toHaveLength(1)
    expect(movements[0].productId).toBe(moved.id)
    expect(movements[0].type).toBe('MANUAL')
    // The DELTA, not the count: a movement records what changed.
    expect(movements[0].quantity).toBe(40)
  })

  it('records the shortfall as a negative movement', async () => {
    const product = await makeProduct('Atlas Grower', 50)

    await recordStockCount([{ productId: product.id, countedQty: 44 }])

    const movement = await prisma.stockMovement.findFirstOrThrow()
    expect(movement.quantity).toBe(-6)
    expect(await stockOf(product.id)).toBe(44)
  })

  it('applies every row or none of them', async () => {
    // A half-applied count is worse than no count: she would have no way to
    // tell which shelves saved, and the only way back is counting again.
    const good = await makeProduct('Atlas Grower', 0)

    const result = await recordStockCount([
      { productId: good.id, countedQty: 40 },
      { productId: 999_999, countedQty: 10 },
    ])

    expect(result.ok).toBe(false)
    expect(await stockOf(good.id)).toBe(0)
    expect(await prisma.stockMovement.count()).toBe(0)
  })

  it('refuses an archived product rather than quietly reviving it', async () => {
    const product = await makeProduct('Withdrawn', 0, true)

    const result = await recordStockCount([{ productId: product.id, countedQty: 5 }])

    expect(result.ok).toBe(false)
    if (result.ok) return
    expect(result.error).toMatch(/archived/i)
    expect(await stockOf(product.id)).toBe(0)
  })

  it.each([-1, Number.NaN, Number.POSITIVE_INFINITY])('refuses a count of %s', async (bad) => {
    // A shelf cannot hold less than nothing. The counter may go negative
    // deliberately, with a confirmation; there is no reading of "I counted
    // minus two".
    const product = await makeProduct('Atlas Grower', 7)

    expect((await recordStockCount([{ productId: product.id, countedQty: bad }])).ok).toBe(false)
    expect(await stockOf(product.id)).toBe(7)
  })

  it('refuses the same product counted twice', async () => {
    // Two rows would apply in an order nobody chose and the last would
    // silently win.
    const product = await makeProduct('Atlas Grower', 0)

    const result = await recordStockCount([
      { productId: product.id, countedQty: 40 },
      { productId: product.id, countedQty: 12 },
    ])

    expect(result.ok).toBe(false)
    expect(await stockOf(product.id)).toBe(0)
  })

  it('refuses an empty count', async () => {
    expect((await recordStockCount([])).ok).toBe(false)
  })

  it('leaves every product that was not counted exactly as it was', async () => {
    // Blank means "I never got to that shelf", and the grid sends nothing for
    // it. It must not be read as a count of zero.
    const counted = await makeProduct('Atlas Grower', 0)
    const untouched = await makeProduct('Atlas Starter', 17)

    await recordStockCount([{ productId: counted.id, countedQty: 40 }])

    expect(await stockOf(untouched.id)).toBe(17)
  })
})
