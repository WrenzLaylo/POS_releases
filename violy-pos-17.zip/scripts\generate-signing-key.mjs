#!/usr/bin/env node
/**
 * Makes the key pair that signs releases. Run ONCE, ever.
 *
 *   node scripts/generate-signing-key.mjs
 *
 * The private key is written to `.release-signing-key.pem`, which is
 * gitignored and must stay that way. The public key is printed for pasting
 * into `src/lib/update-public-key.ts`, where it ships inside every build.
 *
 * WHY A SIGNATURE, when the manifest already carries a SHA-256:
 *
 * The checksum proves the zip arrived intact. It proves nothing about who put
 * it there, because the same pipeline produces the zip AND its checksum — an
 * attacker with the publishing account replaces both and the laptop is
 * satisfied. The signature is made with a key that never touches GitHub, so
 * publishing access alone is not enough to ship code to the shop.
 *
 * Ed25519 because Node has it built in. No dependency, nothing to keep patched
 * in a codebase that has to run untouched on a shop laptop for years.
 *
 * LOSING THIS KEY IS SERIOUS. Once laptops are running a build that verifies,
 * a manifest signed with any other key is rejected — so losing it means no
 * further update can ever reach the shop, and the recovery is reinstalling by
 * hand on the machine. Keep a copy somewhere off this computer.
 */

import { generateKeyPairSync } from 'node:crypto'
import { existsSync, writeFileSync } from 'node:fs'
import path from 'node:path'
import readline from 'node:readline/promises'

const ROOT = process.cwd()
const KEY_FILE = path.join(ROOT, '.release-signing-key.pem')
const NEWLINE = String.fromCharCode(10)

async function main() {
  // Overwriting it silently would orphan every laptop already running a build
  // that trusts the old public key.
  if (existsSync(KEY_FILE)) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
    console.log(`\nA signing key already exists at ${KEY_FILE}`)
    console.log('Replacing it means every laptop running a build that trusts the OLD')
    console.log('public key will refuse every future update until it is reinstalled.')
    const answer = await rl.question('\nType REPLACE to overwrite it, or anything else to stop: ')
    rl.close()
    if (answer.trim() !== 'REPLACE') {
      console.log('\nStopped. Nothing was changed.')
      process.exit(0)
    }
  }

  const { publicKey, privateKey } = generateKeyPairSync('ed25519')

  const privatePem = privateKey.export({ type: 'pkcs8', format: 'pem' })
  const publicPem = publicKey.export({ type: 'spki', format: 'pem' })

  // 0o600: readable by this account only. Advisory on Windows, and set anyway
  // — the file is also copied to backups and other machines by hand.
  writeFileSync(KEY_FILE, privatePem, { encoding: 'utf8', mode: 0o600 })

  console.log(`\nPrivate key written to ${KEY_FILE}`)
  console.log('  · It is gitignored. Never commit it, never put it in the releases repo.')
  console.log('  · Copy it somewhere off this computer. Losing it means no more updates.')
  console.log('\nPaste this into src/lib/update-public-key.ts:\n')
  console.log(
    `export const UPDATE_PUBLIC_KEY = \`${NEWLINE}${String(publicPem).trim()}${NEWLINE}\``,
  )
  console.log('')
}

main().catch((error) => {
  console.error(`\nCould not generate a key: ${error instanceof Error ? error.message : error}\n`)
  process.exit(1)
})
