/**
 * How to write the command-palette shortcut on the key the person actually has.
 *
 * The topbar said "Search ⌘K" on every platform. This shop runs Windows, where
 * there is no ⌘ key on the keyboard at all — the label named a key that does
 * not exist, for a shortcut that has always answered Ctrl+K as well.
 *
 * Both chords keep working everywhere regardless of what is printed. This
 * decides the LABEL only; `CommandPalette` listens for Meta and Control alike,
 * because a Mac keyboard plugged into the shop laptop should not stop working
 * over a string.
 */

export const CTRL_LABEL = 'Ctrl+K'
export const MAC_LABEL = '⌘K'

/**
 * `platform` is `navigator.platform` or equivalent. Deliberately takes it as an
 * argument rather than reading `navigator` itself, so this is testable and so
 * the caller decides WHEN to read it — which matters, because reading it during
 * render is a hydration mismatch waiting to happen.
 */
export function shortcutLabel(platform: string | undefined): string {
  if (!platform) return CTRL_LABEL
  // iPhone/iPad included: the app is desktop-only, but a label is cheap to get
  // right and `MacIntel` is what an iPad reports in desktop mode anyway.
  return /mac|iphone|ipad|ipod/i.test(platform) ? MAC_LABEL : CTRL_LABEL
}
