import { beforeEach, describe, expect, it } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'
import { createOrder } from '@/server/orders'
import { getBalance, recordPayment } from '@/server/ledger'

beforeEach(resetDb)

async function customer(name = 'MARILOU') {
  return prisma.customer.create({ data: { name } })
}

async function product(price = 200_000, stockQty = 100) {
  const category = await prisma.category.upsert({
    where: { name: 'Pig Feeds' },
    create: { name: 'Pig Feeds' },
    update: {},
  })
  return prisma.product.create({
    data: {
      categoryId: category.id,
      name: 'Hog Grower',
      unit: 'bag (50kg)',
      price,
      costPrice: 180_000,
      stockQty,
      lowStockThreshold: 5,
    },
  })
}

/** Overpays, which is how a customer comes to be in credit at all. */
async function giveCredit(customerId: number, centavos: number) {
  const result = await recordPayment({
    customerId,
    amountCentavos: centavos,
    occurredAt: new Date(2026, 7, 1),
  })
  if (!result.ok) throw new Error(result.error)
}

let keyCounter = 0
async function order(
  customerId: number,
  productId: number,
  quantity: number,
  overrides: Partial<{ cashPaidCentavos: number | null; creditAppliedCentavos: number }> = {},
) {
  keyCounter += 1
  return createOrder({
    customerId,
    lines: [{ productId, quantity }],
    cashPaidCentavos:
      overrides.cashPaidCentavos === undefined ? null : overrides.cashPaidCentavos,
    creditAppliedCentavos: overrides.creditAppliedCentavos,
    clientOrderKey: `credit-test-key-${keyCounter}`,
  })
}

describe('a customer the shop owes', () => {
  it('is in credit, which is a negative balance', async () => {
    const her = await customer()
    await giveCredit(her.id, 100_000)
    expect(await getBalance(her.id)).toBe(-100_000)
  })

  it('spends her credit instead of cash when she asks to', async () => {
    // ₱1,000 in credit, a ₱2,000 order. She should hand over ₱1,000, not
    // ₱2,000, and walk away owing nothing.
    const her = await customer()
    const sack = await product(200_000)
    await giveCredit(her.id, 100_000)

    const result = await order(her.id, sack.id, 1, { creditAppliedCentavos: 100_000 })
    expect(result.ok).toBe(true)
    if (!result.ok) return

    expect(await getBalance(her.id)).toBe(0)

    const sale = await prisma.sale.findUnique({ where: { id: result.data.saleId } })
    expect(sale!.totalAmount).toBe(200_000)
    // Only the cash that actually entered the drawer.
    expect(sale!.cashPaidCentavos).toBe(100_000)
    expect(sale!.creditAppliedCentavos).toBe(100_000)
    expect(sale!.changeCentavos).toBe(0)
  })

  it('records only real cash as cash, so the day’s takings are not inflated', async () => {
    // The money rule this protects: `cashPaidCentavos` feeds "cash na
    // pumasok" on the dashboard. Counting the credit half would report money
    // that never entered the drawer.
    const her = await customer()
    const sack = await product(200_000)
    await giveCredit(her.id, 100_000)

    const result = await order(her.id, sack.id, 1, { creditAppliedCentavos: 100_000 })
    if (!result.ok) throw new Error(result.error)

    const sale = await prisma.sale.findUnique({ where: { id: result.data.saleId } })
    expect(sale!.cashPaidCentavos).toBe(100_000)
    expect(sale!.cashPaidCentavos + sale!.creditAppliedCentavos).toBe(sale!.totalAmount)
  })

  it('posts one charge, not two, so the credit is not consumed twice', async () => {
    const her = await customer()
    const sack = await product(200_000)
    await giveCredit(her.id, 100_000)

    const result = await order(her.id, sack.id, 1, { creditAppliedCentavos: 100_000 })
    if (!result.ok) throw new Error(result.error)

    const entries = await prisma.ledgerEntry.findMany({
      where: { customerId: her.id, isVoided: false },
      orderBy: { id: 'asc' },
    })
    // The opening payment, and exactly one charge for this order.
    expect(entries.map((entry) => entry.type)).toEqual(['PAYMENT', 'CHARGE'])
    expect(entries[1].amountCentavos).toBe(100_000)
  })

  it('takes part in credit, part in cash, and part on utang', async () => {
    // ₱1,000 credit, ₱2,000 order, ₱500 cash: she should still owe ₱500.
    const her = await customer()
    const sack = await product(200_000)
    await giveCredit(her.id, 100_000)

    const result = await order(her.id, sack.id, 1, {
      creditAppliedCentavos: 100_000,
      cashPaidCentavos: 50_000,
    })
    expect(result.ok).toBe(true)

    expect(await getBalance(her.id)).toBe(50_000)
  })

  it('leaves the credit alone when she pays the whole thing in cash', async () => {
    const her = await customer()
    const sack = await product(200_000)
    await giveCredit(her.id, 100_000)

    const result = await order(her.id, sack.id, 1, { cashPaidCentavos: 200_000 })
    expect(result.ok).toBe(true)

    // Still hers. Nothing spends a credit without being asked to.
    expect(await getBalance(her.id)).toBe(-100_000)
  })

  it('refuses to spend more credit than she has', async () => {
    const her = await customer()
    const sack = await product(200_000)
    await giveCredit(her.id, 100_000)

    const result = await order(her.id, sack.id, 1, { creditAppliedCentavos: 150_000 })
    expect(result.ok).toBe(false)
    if (result.ok) return
    expect(result.error).toMatch(/more credit than/i)
    expect(await prisma.sale.count()).toBe(0)
  })

  it('refuses credit from a customer who has none', async () => {
    const her = await customer()
    const sack = await product(200_000)

    const result = await order(her.id, sack.id, 1, { creditAppliedCentavos: 1 })
    expect(result.ok).toBe(false)
    if (result.ok) return
    expect(result.error).toMatch(/no credit/i)
  })

  it('refuses credit from a customer who is already in debt', async () => {
    const her = await customer()
    const sack = await product(200_000)
    // An unpaid order puts her in debt, which is not credit.
    await order(her.id, sack.id, 1, { cashPaidCentavos: 0 })

    const result = await order(her.id, sack.id, 1, { creditAppliedCentavos: 1 })
    expect(result.ok).toBe(false)
  })

  it('reads the credit as it stands now, not as the browser last saw it', async () => {
    // She had ₱1,000 credit when the screen loaded. It was spent on another
    // screen in between. The order must refuse rather than spend it twice.
    const her = await customer()
    const sack = await product(200_000)
    await giveCredit(her.id, 100_000)

    const first = await order(her.id, sack.id, 1, { creditAppliedCentavos: 100_000 })
    expect(first.ok).toBe(true)

    const second = await order(her.id, sack.id, 1, { creditAppliedCentavos: 100_000 })
    expect(second.ok).toBe(false)
  })

  it('never applies more credit than the order is worth', async () => {
    // ₱5,000 credit against a ₱2,000 order takes ₱2,000, not ₱5,000 — the
    // rest stays hers rather than being handed back as cash the shop never
    // received.
    const her = await customer()
    const sack = await product(200_000)
    await giveCredit(her.id, 500_000)

    const result = await order(her.id, sack.id, 1, { creditAppliedCentavos: 500_000 })
    expect(result.ok).toBe(true)
    if (!result.ok) return

    const sale = await prisma.sale.findUnique({ where: { id: result.data.saleId } })
    expect(sale!.creditAppliedCentavos).toBe(200_000)
    expect(sale!.cashPaidCentavos).toBe(0)
    expect(sale!.changeCentavos).toBe(0)
    // ₱3,000 of credit left.
    expect(await getBalance(her.id)).toBe(-300_000)
  })

  it.each([-1, 100.5])('refuses an amount of %s', async (amount) => {
    const her = await customer()
    const sack = await product(200_000)
    await giveCredit(her.id, 100_000)

    const result = await order(her.id, sack.id, 1, { creditAppliedCentavos: amount })
    expect(result.ok).toBe(false)
  })

  it('gives change against what is left after credit, not against the whole total', async () => {
    // ₱1,000 credit on a ₱2,000 order leaves ₱1,000 to pay. Handing over
    // ₱1,500 is ₱500 change — not ₱0, which is what comparing against the
    // full total would produce.
    const her = await customer()
    const sack = await product(200_000)
    await giveCredit(her.id, 100_000)

    const result = await order(her.id, sack.id, 1, {
      creditAppliedCentavos: 100_000,
      cashPaidCentavos: 150_000,
    })
    if (!result.ok) throw new Error(result.error)

    const sale = await prisma.sale.findUnique({ where: { id: result.data.saleId } })
    expect(sale!.changeCentavos).toBe(50_000)
    expect(sale!.cashPaidCentavos).toBe(100_000)
    expect(await getBalance(her.id)).toBe(0)
  })
})
