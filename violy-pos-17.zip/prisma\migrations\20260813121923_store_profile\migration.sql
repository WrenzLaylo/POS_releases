-- CreateTable
CREATE TABLE "StoreProfile" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT DEFAULT 1,
    "name" TEXT NOT NULL DEFAULT 'Violy Store',
    "tagline" TEXT NOT NULL DEFAULT 'Pig feeds and store supplies',
    "registeredName" TEXT NOT NULL DEFAULT '',
    "addressLine1" TEXT NOT NULL DEFAULT '',
    "addressLine2" TEXT NOT NULL DEFAULT '',
    "contactNumber" TEXT NOT NULL DEFAULT '',
    "email" TEXT NOT NULL DEFAULT '',
    "tin" TEXT NOT NULL DEFAULT '',
    "businessRegistrationNo" TEXT NOT NULL DEFAULT '',
    "updatedAt" DATETIME NOT NULL
);
