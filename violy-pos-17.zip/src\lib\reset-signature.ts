import { createPublicKey, verify } from 'node:crypto'
import { UPDATE_PUBLIC_KEY } from './update-public-key'

/**
 * Proving a password reset came from Wrenz and nobody else.
 *
 * Same Ed25519 key that signs releases, and for the same reason: the app ships
 * as readable source in a PUBLIC repository, so anything symmetric — a shared
 * secret, an API key, an HMAC — is a secret printed on the internet. Only the
 * private half can sign, and it never leaves Wrenz's machine.
 *
 * That is what makes this path safe to route through a public file. The reset
 * token sits in the open where anyone can read it, and reading it buys nothing:
 * it names ONE machine's one-time code, and forging a different one requires a
 * key that is not there.
 *
 * Separate from `update-signature.ts` on purpose. That module is imported by
 * the release scripts under plain Node; this one is only ever reached from
 * server code, and keeping them apart stops a reset token ever being mistaken
 * for a manifest by either verifier.
 */

export type SignedReset = {
  /** The code the shop laptop generated and showed on screen. */
  code: string
  /** ISO timestamp after which this is refused. */
  expiresAt: string
}

/**
 * The exact bytes that get signed.
 *
 * MUST match `canonicalReset` in `scripts/send-reset.mjs`, which cannot import
 * this — it runs under plain Node before any TypeScript exists. The test
 * asserts both produce this shape, because a separator that drifts in one of
 * them rejects every reset and looks exactly like a wrong key.
 */
export function canonicalReset({ code, expiresAt }: SignedReset): string {
  const NEWLINE = String.fromCharCode(10)
  return [`reset:${code.toUpperCase()}`, `expires:${expiresAt}`].join(NEWLINE)
}

/**
 * Whether this reset was signed by us.
 *
 * Ed25519 verifies with a NULL algorithm — the curve carries its own hash, and
 * passing a digest name here throws instead of verifying. Every malformed
 * input is a clean `false`: the question is "may this unlock the till", and
 * every answer other than a confident yes is no.
 */
export function verifyResetSignature(fields: SignedReset, signature: string): boolean {
  try {
    return verify(
      null,
      Buffer.from(canonicalReset(fields), 'utf8'),
      createPublicKey(UPDATE_PUBLIC_KEY),
      Buffer.from(signature, 'base64'),
    )
  } catch {
    return false
  }
}
