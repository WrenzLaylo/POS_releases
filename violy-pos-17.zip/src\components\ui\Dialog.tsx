'use client'

import type { ReactNode } from 'react'
import { Overlay } from './Overlay'

export type DialogProps = {
  open: boolean
  onOpenChange: (open: boolean) => void
  title: ReactNode
  description?: ReactNode
  children?: ReactNode
  footer?: ReactNode
  className?: string
}

export function Dialog(props: DialogProps) {
  return (
    <Overlay
      {...props}
      surfaceClassName="m-auto w-[calc(100%_-_2rem)] max-w-lg rounded-card border border-line"
      backdropTestId="dialog-backdrop"
    />
  )
}
