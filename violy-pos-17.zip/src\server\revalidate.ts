import { revalidatePath } from 'next/cache'
import type { AppRoute } from '@/lib/routes'

/**
 * Revalidate app routes by constant rather than by string literal.
 *
 * MUST be called AFTER the try/catch around a write closes, never inside it.
 * A revalidation error thrown inside the try would be caught and reported to
 * the operator as a failed sale, and the retry would write a SECOND row for
 * money that already left the drawer. That double-write is the most damaging
 * bug this app can ship, and `vitest.config.ts` stubs `next/cache`, so no
 * test can catch a misplaced call — only review can.
 *
 * `layout: true` revalidates the root layout, which the header/rail reads for
 * its live notification counts.
 */
export function revalidateRoutes(
  routes: readonly AppRoute[],
  { layout = false }: { layout?: boolean } = {},
): void {
  if (layout) revalidatePath('/', 'layout')
  for (const route of routes) revalidatePath(route)
}

/** For dynamic segments built by a helper, e.g. `bookEntry(id)`. */
export function revalidatePathname(pathname: string): void {
  revalidatePath(pathname)
}
