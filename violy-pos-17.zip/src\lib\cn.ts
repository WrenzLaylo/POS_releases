/** Joins class names, dropping falsy entries.
 *
 *  Deliberately not a Tailwind-aware merger: consumers must not pass a
 *  conflicting size utility (e.g. `h-14`) to a primitive that already bakes
 *  one in — `Button`'s height is fixed by its `size` prop, for instance —
 *  because two competing utilities in one class attribute are resolved by
 *  stylesheet order, not by argument order. `Input`/`Select` do not bake in
 *  a width, so passing a `w-*` className to them is safe and is how callers
 *  are expected to size them. */
export function cn(...parts: (string | false | null | undefined)[]): string {
  return parts.filter(Boolean).join(' ')
}
