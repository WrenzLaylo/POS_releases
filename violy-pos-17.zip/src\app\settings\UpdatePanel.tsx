'use client'

import { useState, useTransition } from 'react'
import { checkForUpdates, startUpdate } from '@/server/updates'
import { updateHeadline, type UpdateStatus } from '@/lib/update-info'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { FormError } from '@/components/ui/FormError'
import { Icon } from '@/components/ui/Icon'

function longDate(iso: string): string {
  if (!iso) return 'unknown'
  return new Date(iso).toLocaleDateString('en-PH', {
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  })
}

/**
 * Checking for and installing updates.
 *
 * Written for the person who actually runs the shop, not for whoever wrote the
 * code. The headline is "You have the latest version" or "There is 1 update
 * ready to install" — never a commit count or a sha. Those appear underneath,
 * as plain sentences describing what changed, because knowing WHAT is arriving
 * is reasonable and reading a hash is not.
 *
 * Installing is two presses, not one. The first says what is about to happen —
 * the app closes, a window appears, it comes back — because an app that
 * vanishes without warning reads as broken, and the natural response is to
 * start clicking things while it is mid-update.
 */
export function UpdatePanel() {
  const [status, setStatus] = useState<UpdateStatus | null>(null)
  const [confirming, setConfirming] = useState(false)
  const [installing, setInstalling] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [pending, startTransition] = useTransition()

  function check() {
    setError(null)
    setConfirming(false)
    startTransition(async () => {
      setStatus(await checkForUpdates())
    })
  }

  function install() {
    setError(null)
    startTransition(async () => {
      const result = await startUpdate()
      if (!result.ok) {
        setError(result.error)
        return
      }
      // The updater is about to kill this server, so there is no "finished"
      // to wait for. What is left is telling the person what they are about
      // to see, so a closing app reads as expected rather than as a crash.
      setInstalling(true)
    })
  }

  if (installing) {
    return (
      <Card>
        <h2 className="mb-2 text-base font-semibold">Installing the update</h2>
        <p className="text-sm text-ink-muted">
          A black window has opened and is doing the work. This page will stop responding for a
          minute or two — that is normal.
        </p>
        <p className="mt-2 text-sm text-ink-muted">
          When it says it has finished, the app opens again by itself. Please do not close the
          black window until then.
        </p>
      </Card>
    )
  }

  return (
    <Card>
      <div className="mb-3 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-base font-semibold">Updates</h2>
          <p className="text-sm text-ink-muted">
            {status && (status.kind === 'up-to-date' || status.kind === 'available')
              ? `You have version ${status.installed.version}${
                  status.installed.installedAt
                    ? `, installed ${longDate(status.installed.installedAt)}`
                    : ''
                }.`
              : 'Check whether a newer version of this app is available.'}
          </p>
        </div>
        <Button variant="secondary" onClick={check} disabled={pending}>
          {pending ? 'Checking…' : 'Check for updates'}
        </Button>
      </div>

      {error && <FormError className="mb-3">{error}</FormError>}

      {status && (
        <div
          className={
            status.kind === 'available'
              ? 'rounded-control border border-accent/40 bg-accent-soft p-4'
              : 'rounded-control border border-line bg-surface-sunk p-4'
          }
        >
          <p className="flex items-center gap-2 text-sm font-semibold text-ink">
            {status.kind === 'up-to-date' && (
              <Icon name="check" className="h-4 w-4 shrink-0 text-money-in" />
            )}
            {status.kind === 'available' && (
              <Icon name="arrow-right" className="h-4 w-4 shrink-0 text-accent" />
            )}
            {status.kind === 'offline' && (
              <Icon name="alert" className="h-4 w-4 shrink-0 text-warn" />
            )}
            {updateHeadline(status)}
          </p>

          {(status.kind === 'offline' || status.kind === 'unknown') && (
            <p className="mt-1 text-sm text-ink-muted">{status.reason}</p>
          )}

          {status.kind === 'available' && (
            <>
              <p className="mt-1 text-sm text-ink-muted">
                Version {status.latest.version} — you have {status.installed.version}.
              </p>

              {status.latest.notes.length > 0 && (
                <ul className="mt-3 space-y-1 text-sm text-ink-muted">
                  {status.latest.notes.slice(0, 8).map((note, index) => (
                    <li key={index} className="flex gap-2">
                      <span aria-hidden="true" className="select-none text-ink-subtle">
                        •
                      </span>
                      <span>{note}</span>
                    </li>
                  ))}
                  {status.latest.notes.length > 8 && (
                    <li className="text-ink-subtle">
                      …and {status.latest.notes.length - 8} more change
                      {status.latest.notes.length - 8 === 1 ? '' : 's'}.
                    </li>
                  )}
                </ul>
              )}

              {confirming ? (
                <div className="mt-3 rounded-control border border-warn/40 bg-warn/10 p-3">
                  <p className="text-sm font-semibold text-warn">
                    The app will close while it installs.
                  </p>
                  <ul className="mt-1 list-disc space-y-0.5 pl-5 text-sm text-warn">
                    <li>Your data is backed up first, automatically.</li>
                    <li>A black window shows what it is doing.</li>
                    <li>The app opens again by itself when it finishes.</li>
                  </ul>
                  <p className="mt-2 text-sm text-warn">
                    Do not do this in the middle of serving a customer.
                  </p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <Button variant="destructive" onClick={install} disabled={pending}>
                      {pending ? 'Starting…' : 'Yes, install it now'}
                    </Button>
                    <Button variant="ghost" onClick={() => setConfirming(false)} disabled={pending}>
                      Not now
                    </Button>
                  </div>
                </div>
              ) : (
                <Button variant="primary" className="mt-3" onClick={() => setConfirming(true)}>
                  Install the update
                </Button>
              )}
            </>
          )}
        </div>
      )}
    </Card>
  )
}
