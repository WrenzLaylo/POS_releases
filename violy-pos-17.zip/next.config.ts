import { realpathSync } from 'node:fs'
import type { NextConfig } from 'next'

/**
 * Pin the Turbopack workspace root to this directory.
 *
 * There is an unrelated `package-lock.json` in the user's home directory, so
 * more than one lockfile sits in this project's ancestry. Left to itself Next
 * infers a workspace root, picks the home directory, and warns on every build
 * and every `next dev`. Setting the root explicitly is the documented fix.
 *
 * `realpathSync.native` rather than `import.meta.dirname` so the root is the
 * true on-disk path — Windows will happily resolve a differently-cased path
 * to the same folder, and the root should not depend on how the shell
 * addressed it.
 */
const projectRoot = realpathSync.native(import.meta.dirname)

const nextConfig: NextConfig = {
  turbopack: {
    root: projectRoot,
  },
  // Five flat routes became four tabbed workspaces. Bookmarks, browser
  // autocomplete, and muscle memory should land on the replacement rather
  // than a 404. `/pos` was absorbed into the walk-in mode of the order
  // screen, which now lives at /counter.
  async redirects() {
    return [
      { source: '/pos', destination: '/counter', permanent: true },
      { source: '/orders', destination: '/counter', permanent: true },
      { source: '/inventory', destination: '/stock', permanent: true },
      { source: '/pulse', destination: '/dashboard', permanent: true },
      { source: '/customers', destination: '/book', permanent: true },
      { source: '/customers/:path*', destination: '/book/:path*', permanent: true },
    ]
  },
}

export default nextConfig
