'use client'

import { useEffect, useRef, useState, useTransition, type KeyboardEvent } from 'react'
import type { Customer } from '@prisma/client'
import { createCustomer } from '@/server/customers'
import { Button } from '@/components/ui/Button'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'
import { cn } from '@/lib/cn'
import type { RailSelection } from './OrderRail'

type Option = { kind: 'customer'; id: number; name: string } | { kind: 'new' }

/**
 * Replaces the old picker, which laid every customer out as an `h-12` button
 * and did not scale past ~20 names. This is a filterable combobox:
 * `+ New name` is always first, and once a selection is made it collapses to
 * the chosen name — the largest text in the rail — so it stays visible for
 * the rest of the order instead of scrolling off after step 1.
 *
 * Walk-in used to be the first row in this list. It now lives one level up,
 * as the other half of `OrderRail`'s `SegmentedControl` — this component is
 * reached only in "Customer" mode, so it only ever has to resolve a name.
 */
export function CustomerCombobox({
  customers,
  selection,
  onSelect,
}: {
  customers: Customer[]
  selection: RailSelection | null
  onSelect: (selection: RailSelection) => void
}) {
  // Closed until she asks for it. It used to open on mount, and that one
  // `true` cost more than it looked:
  //
  //   · An open `role="listbox"` is what `CatalogColumn`'s overlay guard
  //     watches for, so every catalog shortcut — `/`, the arrows, `+`/`-` —
  //     was dead from page load until a customer was picked. The guard is
  //     right: Escape must close this dropdown without also wiping the
  //     product search behind it. The dropdown was wrong to be open.
  //   · The effect below focuses the input whenever `open` is true, so on
  //     mount it also took the focus `CatalogColumn` asks for on its product
  //     search — she would start typing a sack name into the customer box.
  //   · At 224px tall it pushed the running total and "Save order" toward the
  //     fold on a 768px laptop, which is why the list is capped at `max-h-56`
  //     rather than something roomier.
  //
  // Closing it fixes all three. Nothing is lost: the input still says
  // "Search or pick a customer", and `onFocus` opens the list the moment she
  // touches it — at which point suspending the catalog shortcuts is exactly
  // right, because she is choosing a customer, not adding products.
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState('')
  const [activeIndex, setActiveIndex] = useState(0)
  const [adding, setAdding] = useState(false)
  const [name, setName] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [pending, startTransition] = useTransition()
  const inputRef = useRef<HTMLInputElement>(null)

  // "Change" flips `open` to true, which swaps this component from the
  // collapsed-label branch to the input-rendering branch — so the input
  // does not exist in the DOM yet when the click handler runs, and
  // `inputRef.current` is still null there. Focusing here, once the input
  // has mounted, is what actually moves focus.
  useEffect(() => {
    if (open) inputRef.current?.focus()
  }, [open])

  const needle = query.trim().toLowerCase()
  const filtered =
    needle === '' ? customers : customers.filter((c) => c.name.toLowerCase().includes(needle))

  // `+ New name` leads the list. Last put it below every customer and below
  // the scroll, so adding a walk-up name meant scrolling past everyone first —
  // and the longer the book gets, the further away it drifts.
  const options: Option[] = [
    { kind: 'new' },
    ...filtered.map((c) => ({ kind: 'customer' as const, id: c.id, name: c.name })),
  ]

  // `+ New name` occupies index 0, so the first matching customer is index 1.
  // The highlight has to start THERE, not on the new-name row: typing "MAR"
  // and pressing Enter must pick MARILOU, not open the add-a-customer form.
  // Re-runs on every keystroke, which also re-homes the highlight after the
  // filter changes what is on screen.
  useEffect(() => {
    setActiveIndex(filtered.length > 0 ? 1 : 0)
  }, [query, filtered.length])

  function choose(option: Option) {
    if (option.kind === 'new') {
      setAdding(true)
      return
    }
    onSelect({ kind: 'customer', id: option.id, name: option.name })
    setOpen(false)
    setQuery('')
  }

  function submitNewCustomer() {
    setError(null)
    startTransition(async () => {
      const result = await createCustomer({ name })
      if (!result.ok) {
        setError(result.error)
        return
      }
      onSelect({ kind: 'customer', id: result.data.customerId, name })
      setName('')
      setAdding(false)
      setOpen(false)
      setQuery('')
    })
  }

  function onKeyDown(event: KeyboardEvent<HTMLInputElement>) {
    if (event.key === 'ArrowDown') {
      event.preventDefault()
      setOpen(true)
      setActiveIndex((i) => Math.min(i + 1, options.length - 1))
    } else if (event.key === 'ArrowUp') {
      event.preventDefault()
      setOpen(true)
      setActiveIndex((i) => Math.max(i - 1, 0))
    } else if (event.key === 'Enter') {
      event.preventDefault()
      const option = options[activeIndex]
      if (option) choose(option)
    } else if (event.key === 'Escape') {
      // `stopPropagation`, and it is load-bearing. `CatalogColumn` listens for
      // Escape on `window` to clear the product search, and guards itself by
      // checking whether any listbox is open — but that guard cannot help
      // here. React's root listener sits below `window`, so this handler runs
      // first, `setOpen(false)` flushes synchronously for a discrete event
      // like keydown, and by the time the event reaches `window` the listbox
      // is already gone from the DOM. The guard looks, sees nothing open, and
      // wipes a search she had typed while dismissing an unrelated dropdown.
      //
      // Only when it actually closed something, so Escape on a closed
      // combobox still reaches the catalog it was meant for.
      if (open) event.stopPropagation()
      setOpen(false)
    }
  }

  // Once chosen, the name is the largest text in the rail and stays put —
  // this is the fix for the wrong-account risk: the operator can scroll the
  // whole catalog without the customer she is charging ever leaving view.
  // Only a `customer` selection collapses here — a `walkin` selection means
  // the segmented control above switched away from this component entirely,
  // so it is never this component's job to render that label.
  if (selection?.kind === 'customer' && !open) {
    return (
      <div className="flex items-baseline justify-between gap-2">
        <span className="truncate text-xl font-semibold text-ink">{selection.name}</span>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => {
            setOpen(true)
            setActiveIndex(0)
          }}
        >
          Change
        </Button>
      </div>
    )
  }

  return (
    <div>
      <Input
        ref={inputRef}
        value={query}
        onChange={(e) => {
          setQuery(e.target.value)
          setActiveIndex(0)
          setOpen(true)
        }}
        onFocus={() => setOpen(true)}
        onKeyDown={onKeyDown}
        placeholder="Search or pick a customer"
        className="w-full"
      />

      {open && (
        <ul
          role="listbox"
          aria-label="Customers"
          // `max-h-56`, not `max-h-72`. At 18rem this pushed the running total
          // and "Save order" below the fold on a 768px-tall shop laptop — the
          // two things the rail exists to show. It scrolls, so nothing is
          // lost; the money just stays on screen. Still capped now that the
          // list no longer opens on mount, because it is at its tallest
          // exactly when she is picking a name and the totals still matter.
          className="mt-2 max-h-56 overflow-y-auto rounded-lg border border-line"
        >
          {options.map((option, index) => {
            const active = index === activeIndex
            if (option.kind === 'new') {
              return (
                <li
                  key="new"
                  role="option"
                  aria-selected={false}
                  onMouseEnter={() => setActiveIndex(index)}
                  onClick={() => choose(option)}
                  className={cn(
                    'flex h-12 cursor-pointer items-center border-b border-line px-3 text-sm font-semibold text-accent',
                    active && 'bg-surface-sunk',
                  )}
                >
                  + New name
                </li>
              )
            }
            return (
              <li
                key={option.id}
                role="option"
                aria-selected={selection?.kind === 'customer' && selection.id === option.id}
                onMouseEnter={() => setActiveIndex(index)}
                onClick={() => choose(option)}
                className={cn(
                  'flex h-12 cursor-pointer items-center px-3 text-sm text-ink',
                  active && 'bg-surface-sunk',
                )}
              >
                {option.name}
              </li>
            )
          })}
        </ul>
      )}

      {adding && (
        <div className="mt-2 flex flex-wrap items-center gap-2">
          <Input
            autoFocus
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Name"
            className="flex-1"
          />
          <Button variant="primary" size="sm" onClick={submitNewCustomer} disabled={pending}>
            Save
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              setAdding(false)
              setError(null)
            }}
          >
            Cancel
          </Button>
        </div>
      )}

      {error && <FormError className="mt-2">{error}</FormError>}
    </div>
  )
}
