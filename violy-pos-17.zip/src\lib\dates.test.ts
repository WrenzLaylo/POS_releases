import { describe, it, expect } from 'vitest'
import {
  startOfDay,
  startOfWeek,
  startOfMonth,
  addDays,
  dayKey,
  parseDayKey,
  occurredAtForDay,
} from '@/lib/dates'

describe('startOfDay', () => {
  it('zeroes the time portion', () => {
    const result = startOfDay(new Date(2026, 6, 25, 14, 30, 45, 123))
    expect(result.getFullYear()).toBe(2026)
    expect(result.getMonth()).toBe(6)
    expect(result.getDate()).toBe(25)
    expect(result.getHours()).toBe(0)
    expect(result.getMinutes()).toBe(0)
    expect(result.getSeconds()).toBe(0)
    expect(result.getMilliseconds()).toBe(0)
  })
})

describe('startOfWeek', () => {
  it('returns Monday for a mid-week date', () => {
    // 2026-07-25 is a Saturday
    const result = startOfWeek(new Date(2026, 6, 25, 12, 0, 0))
    expect(result.getDate()).toBe(20) // Monday
    expect(result.getHours()).toBe(0)
  })

  it('returns the same day when given a Monday', () => {
    const result = startOfWeek(new Date(2026, 6, 20, 12, 0, 0))
    expect(result.getDate()).toBe(20)
  })

  it('returns the previous Monday when given a Sunday', () => {
    // 2026-07-26 is a Sunday
    const result = startOfWeek(new Date(2026, 6, 26, 12, 0, 0))
    expect(result.getDate()).toBe(20)
  })
})

describe('startOfMonth', () => {
  it('returns the first of the month at midnight', () => {
    const result = startOfMonth(new Date(2026, 6, 25, 12, 0, 0))
    expect(result.getDate()).toBe(1)
    expect(result.getMonth()).toBe(6)
    expect(result.getHours()).toBe(0)
  })
})

describe('addDays', () => {
  it('moves forward across a month boundary', () => {
    const result = addDays(new Date(2026, 6, 30), 3)
    expect(result.getMonth()).toBe(7)
    expect(result.getDate()).toBe(2)
  })

  it('moves backward with a negative count', () => {
    const result = addDays(new Date(2026, 6, 2), -3)
    expect(result.getMonth()).toBe(5)
    expect(result.getDate()).toBe(29)
  })
})

describe('dayKey', () => {
  it('formats a local date as YYYY-MM-DD', () => {
    expect(dayKey(new Date(2026, 6, 5, 23, 59))).toBe('2026-07-05')
  })
})

describe('parseDayKey', () => {
  it('parses a YYYY-MM-DD value as local midnight', () => {
    const result = parseDayKey('2026-08-03')

    expect(result).not.toBeNull()
    expect(result?.getFullYear()).toBe(2026)
    expect(result?.getMonth()).toBe(7)
    expect(result?.getDate()).toBe(3)
    expect(result?.getHours()).toBe(0)
  })

  it('rejects invalid formats and calendar rollovers', () => {
    for (const raw of ['', '2026-8-03', '03-08-2026', '2026-02-29', '2026-13-01', '2026-04-31']) {
      expect(parseDayKey(raw)).toBeNull()
    }
  })
})

describe('occurredAtForDay', () => {
  const NOW = new Date(2026, 7, 18, 14, 32, 5)

  it('uses the actual time when the day is today', () => {
    // The whole point. Stamped midnight, a payment taken this afternoon sorts
    // before every sale made this morning, and the running balance in the
    // ledger dives negative — reporting the shop as owing money it never owed.
    expect(occurredAtForDay('2026-08-18', NOW)).toEqual(NOW)
  })

  it('uses the start of the day for any other day', () => {
    // A past date has no time of day to recover: nobody records at what hour
    // last Tuesday's payment arrived.
    expect(occurredAtForDay('2026-08-17', NOW)).toEqual(new Date(2026, 7, 17))
    expect(occurredAtForDay('2026-01-01', NOW)).toEqual(new Date(2026, 0, 1))
  })

  it('sorts a payment made today AFTER a charge made earlier today', () => {
    // The ordering that was wrong, stated as the property it has to hold.
    const chargeThisMorning = new Date(2026, 7, 18, 7, 9)
    const paymentToday = occurredAtForDay('2026-08-18', NOW)!
    expect(paymentToday.getTime()).toBeGreaterThan(chargeThisMorning.getTime())
  })

  it('still sorts a genuinely older payment before today', () => {
    const yesterday = occurredAtForDay('2026-08-17', NOW)!
    expect(yesterday.getTime()).toBeLessThan(NOW.getTime())
  })

  it('refuses a date it cannot read', () => {
    for (const bad of ['', 'today', '2026-13-01', '2026-02-30', '18-08-2026']) {
      expect(occurredAtForDay(bad, NOW), bad).toBeNull()
    }
  })
})
