import { describe, expect, it } from 'vitest'
import type { ProductWithCategory } from './types'
import { editDistance, groupByCategory, matchesSearch, soleMatch, suggestProducts } from './catalog'

// Every field of Product, so this typechecks with no `as` cast and would
// break loudly if the model gained a required column. Note Product has no
// createdAt, and ProductWithCategory's `category` is only { id, name }.
function product(id: number, name: string, categoryName: string): ProductWithCategory {
  return {
    id,
    categoryId: 1,
    name,
    unit: 'sako',
    price: 100000,
    costPrice: 90000,
    stockQty: 10,
    lowStockThreshold: 3,
    imagePath: null,
    description: '',
    isArchived: false,
    category: { id: 1, name: categoryName },
  }
}

// Deliberately NOT in alphabetical order, so we can tell if groupByCategory
// sorts alphabetically (a bug) vs preserving arrival order (correct).
const catalog = [
  product(3, 'Iron Dextran', 'Medicine'),
  product(1, 'Starter Mash', 'Feeds (Sako)'),
  product(2, 'Grower Pellet', 'Feeds (Sako)'),
]

describe('groupByCategory', () => {
  it('preserves the order products arrive in, since the query already sorts them', () => {
    const groups = groupByCategory(catalog)
    expect(groups.map((g) => g.categoryName)).toEqual(['Medicine', 'Feeds (Sako)'])
  })

  it('collects every product of a category into one group', () => {
    const groups = groupByCategory(catalog)
    expect(groups[1].products.map((p) => p.id)).toEqual([1, 2])
  })

  it('returns an empty array for an empty catalog', () => {
    expect(groupByCategory([])).toEqual([])
  })
})

describe('matchesSearch', () => {
  it('matches case-insensitively on a substring of the name', () => {
    expect(matchesSearch(catalog[1], 'mash')).toBe(true)
  })

  it('does not match an unrelated needle', () => {
    expect(matchesSearch(catalog[1], 'dextran')).toBe(false)
  })

  it('matches everything on an empty needle', () => {
    expect(matchesSearch(catalog[1], '')).toBe(true)
  })

  it('trims the needle before matching', () => {
    expect(matchesSearch(catalog[1], '  mash  ')).toBe(true)
  })
})

describe('soleMatch', () => {
  it('returns the product when exactly one matches, for Enter-to-add', () => {
    expect(soleMatch(catalog, 'dextran')?.id).toBe(3)
  })

  it('returns null when several match, so Enter cannot add the wrong sack', () => {
    expect(soleMatch(catalog, 'e')).toBeNull()
  })

  it('returns null when nothing matches', () => {
    expect(soleMatch(catalog, 'zzz')).toBeNull()
  })

  it('returns null on an empty needle, where every product matches', () => {
    expect(soleMatch(catalog, '')).toBeNull()
  })
})

describe('suggestProducts', () => {
  const catalog = [
    product(1, 'ADM Broodsow (sako)', 'Feeds (Sako)'),
    product(2, 'AMO Broodsow (sako)', 'Feeds (Sako)'),
    product(3, 'ADM Gold Mix (sako)', 'Feeds (Sako)'),
    product(4, 'Dewormer', 'Medicine and Vitamins'),
    product(5, 'Nylon Rope', 'Equipment'),
  ]

  it('finds a product through a typo in one word of its name', () => {
    // "brodsow" is one edit from "broodsow" but thirteen from the whole name,
    // which is why matching has to consider words as well as the full string.
    expect(suggestProducts(catalog, 'brodsow').map((p) => p.name)).toEqual([
      'ADM Broodsow (sako)',
      'AMO Broodsow (sako)',
    ])
  })

  it('suggests nothing for a needle that resembles nothing', () => {
    // Uncapped edit distance would rank every product here, and five
    // confident-looking suggestions for "zzzzzzz" are worse than none.
    expect(suggestProducts(catalog, 'zzzzzzz')).toEqual([])
  })

  it('stays quiet until enough has been typed to mean anything', () => {
    expect(suggestProducts(catalog, 'de')).toEqual([])
    expect(suggestProducts(catalog, '')).toEqual([])
  })

  it('allows one edit on a short word and two on a longer one', () => {
    expect(suggestProducts(catalog, 'ropf').map((p) => p.name)).toEqual(['Nylon Rope'])
    expect(suggestProducts(catalog, 'dewormr').map((p) => p.name)).toEqual(['Dewormer'])
    // Three edits on a seven-letter needle is past the cap.
    expect(suggestProducts(catalog, 'dwrmerx')).toEqual([])
  })

  it('orders closer matches first', () => {
    const [first] = suggestProducts(catalog, 'dewormer')
    expect(first.name).toBe('Dewormer')
  })

  it('caps how many it offers', () => {
    expect(suggestProducts(catalog, 'sako', 2).length).toBeLessThanOrEqual(2)
  })
})

describe('editDistance', () => {
  it('counts single-character edits', () => {
    expect(editDistance('kitten', 'sitting', 5)).toBe(3)
    expect(editDistance('same', 'same', 2)).toBe(0)
  })

  it('gives up past the cap rather than returning a large number', () => {
    expect(editDistance('abc', 'xyz', 2)).toBe(Infinity)
    expect(editDistance('short', 'a-very-much-longer-string', 2)).toBe(Infinity)
  })
})
