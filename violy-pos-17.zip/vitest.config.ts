import path from 'node:path'
import { defineConfig } from 'vitest/config'
import tsconfigPaths from 'vite-tsconfig-paths'

export default defineConfig({
  plugins: [tsconfigPaths()],
  resolve: {
    alias: {
      // Server actions call revalidatePath/revalidateTag as a fire-and-forget
      // side effect. Outside a real Next.js request context (i.e. under
      // Vitest) those throw, so route the module to test-only no-ops.
      'next/cache': path.resolve(__dirname, 'src/test/next-cache-stub.ts'),
    },
  },
  test: {
    environment: 'node',
    env: { DATABASE_URL: 'file:./test.db' },
    globalSetup: ['./src/test/global-setup.ts'],
    setupFiles: ['./src/test/setup-dom.ts'],
    pool: 'forks',
    poolOptions: { forks: { singleFork: true } },
    // prisma/seed.test.ts writes ~500 sales / ~1500 sale items one row at a
    // time. Since the accounts/ledger migration rebuilt Sale with an added
    // FK + index, seed() now runs ~2x slower (~11s), past both vitest
    // defaults (5s test / 10s hook). Raised with headroom rather than
    // trimmed against, since seed.ts itself is out of scope here.
    testTimeout: 20000,
    hookTimeout: 20000,
  },
})
