/**
 * Page geometry for every PDF this app produces, in ONE place.
 *
 * Required by two callers that must not drift: `main.js`, which prints the
 * window the operator is looking at, and `print-pdf.js`, which renders a page
 * headlessly for the browser. Same numbers, same output, whichever asked.
 *
 * Plain CommonJS with no imports on purpose — `print-pdf.js` runs under
 * Electron's own binary before anything else is available.
 */

/** A4 and the 80mm receipt roll, in inches — what `printToPDF` measures in. */
const A4 = { width: 8.27, height: 11.69 }
const ROLL_WIDTH = 80 / 25.4

/**
 * How long one 80mm page is.
 *
 * There is no "as long as it needs to be" here. `printToPDF` wants a fixed
 * height, Chromium does not resolve `@page { size: 80mm auto }` to the content
 * height, and measuring the page on screen does not answer it either — the
 * print stylesheet reflows the whole document, so the on-screen height is not
 * the printed one. Measured, that guess was short and spilled onto a second
 * page.
 *
 * A fixed 12in page is the honest answer instead. On a thermal roll a page
 * break is just where the paper is cut.
 */
const ROLL_PAGE_HEIGHT = 12

/** The exact options both renderers pass to `printToPDF`. */
function printOptions(paper) {
  const roll = paper === 'roll'
  return {
    pageSize: roll ? { width: ROLL_WIDTH, height: ROLL_PAGE_HEIGHT } : A4,
    margins: roll ? { top: 0.16, bottom: 0.16, left: 0.16, right: 0.16 } : undefined,
    printBackground: true,
  }
}

module.exports = { A4, ROLL_WIDTH, ROLL_PAGE_HEIGHT, printOptions }
