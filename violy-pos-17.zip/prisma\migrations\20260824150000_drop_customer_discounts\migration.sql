-- Discounts are typed at the counter now, and nowhere else.
--
-- A standing per-customer rate was a second place for a discount to come from,
-- and the counter could not reliably see it: the "on top of theirs / instead of
-- theirs" control read six legacy Customer.discount* columns that the Discount
-- screen stopped writing at the rules migration, so for any customer set up
-- after that the control never appeared and an ad-hoc discount silently stacked
-- on a rate nobody was offered the chance to replace. One place to type a
-- discount removes the whole class of problem rather than fixing that instance.
--
-- WRITTEN DOWN BEFORE IT IS DROPPED. These are arrangements the shop agreed
-- with real people — "P500 off a sack of Broodsow" is a promise, not a setting.
-- Dropping the table silently would leave nobody able to say what the
-- arrangement was, so each live rule is appended to the customer's notes first,
-- where she already looks. The wording matches `describeRule`'s as closely as
-- SQL can manage.
UPDATE "Customer"
SET "notes" = TRIM(
  CASE WHEN COALESCE("notes", '') = '' THEN '' ELSE "notes" || CHAR(10) || CHAR(10) END
  || 'Standing discount, removed ' || DATE('now') || ' when discounts moved to the counter:'
  || CHAR(10)
  || (
    SELECT GROUP_CONCAT(line, CHAR(10))
    FROM (
      SELECT
        '  - '
        || CASE
             WHEN r."kind" = 'PERCENT' THEN (CAST(r."bps" AS REAL) / 100.0) || '%'
             ELSE 'P' || PRINTF('%.2f', CAST(r."amountCentavos" AS REAL) / 100.0)
           END
        || CASE r."basis"
             WHEN 'PER_UNIT' THEN ' off each unit'
             WHEN 'ONCE_PER_ORDER' THEN ' off the order, once'
             ELSE ' off the whole order'
           END
        || CASE
             WHEN r."basis" = 'ORDER_TOTAL' OR r."scope" = 'ALL' THEN ''
             WHEN r."scope" = 'PRODUCTS' THEN
               COALESCE(
                 ' of ' || (
                   SELECT GROUP_CONCAT(p."name", ', ')
                   FROM "_RuleDiscountProducts" rp
                   JOIN "Product" p ON p."id" = rp."B"
                   WHERE rp."A" = r."id"
                 ),
                 ''
               )
             ELSE
               COALESCE(
                 ' of ' || (
                   SELECT GROUP_CONCAT(c."name", ', ')
                   FROM "_RuleDiscountCategories" rc
                   JOIN "Category" c ON c."id" = rc."A"
                   WHERE rc."B" = r."id"
                 ),
                 ''
               )
           END
        || CASE WHEN r."unit" = '' THEN '' ELSE ' (per ' || r."unit" || ')' END
        AS line
      FROM "CustomerDiscountRule" r
      WHERE r."customerId" = "Customer"."id"
        -- Inert rules are not arrangements: a rule saved before an amount was
        -- typed took nothing off anything, and writing it down would record a
        -- promise that was never made.
        AND (
          (r."kind" = 'PERCENT' AND r."bps" > 0)
          OR (r."kind" <> 'PERCENT' AND r."amountCentavos" > 0)
        )
      ORDER BY r."id"
    )
  )
)
WHERE EXISTS (
  SELECT 1 FROM "CustomerDiscountRule" r
  WHERE r."customerId" = "Customer"."id"
    AND (
      (r."kind" = 'PERCENT' AND r."bps" > 0)
      OR (r."kind" <> 'PERCENT' AND r."amountCentavos" > 0)
    )
);

-- The rules themselves, and the two scope tables that hang off them.
DROP TABLE IF EXISTS "_RuleDiscountProducts";
DROP TABLE IF EXISTS "_RuleDiscountCategories";
DROP TABLE IF EXISTS "CustomerDiscountRule";

-- The scope tables of the SINGLE rule that `CustomerDiscountRule` replaced.
-- Already dead before today: they belong to the six Customer.discount* columns
-- that were backfilled into the rules and that nothing has read since.
DROP TABLE IF EXISTS "_CustomerDiscountProducts";
DROP TABLE IF EXISTS "_CustomerDiscountCategories";

-- The six columns themselves STAY, and that is deliberate. Dropping a column in
-- SQLite means rebuilding the table, and rebuilding Customer — every name,
-- balance and due date in the shop — is not worth it for six integers nothing
-- reads. They were already inert before this migration and they are inert
-- after it. Same reasoning the schema records for leaving them at the rules
-- migration.
