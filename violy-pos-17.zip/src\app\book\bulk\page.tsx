import Link from 'next/link'
import { listCustomerBalances } from '@/server/ledger'
import { dayKey } from '@/lib/dates'
import { PageHeader } from '@/components/ui/PageHeader'
import { ROUTES } from '@/lib/routes'
import { BulkPaymentGrid } from './BulkPaymentGrid'

export const dynamic = 'force-dynamic'

// This route stays reachable on its own — `/book` also reaches the same
// grid via its "Bulk payments" tab (`?tab=bulk`), but this standalone page
// is kept working for anything that links straight to it.
export default async function BulkPaymentPage() {
  // Balances, not the discount-bearing customer list: the grid lists who owes
  // what, so what it needs from each name is the figure beside it.
  const customers = await listCustomerBalances()

  return (
    <PageHeader
      title="Record payments"
      actions={
        <Link href={ROUTES.book} className="text-sm font-medium text-ink-muted hover:text-ink">
          ← Back to customers
        </Link>
      }
    >
      <BulkPaymentGrid customers={customers} todayKey={dayKey(new Date())} />
    </PageHeader>
  )
}
