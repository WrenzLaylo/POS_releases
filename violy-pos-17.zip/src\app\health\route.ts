import { installedRelease } from '@/server/updates'

/**
 * Says what is answering on this port, so the desktop shell can tell THIS app
 * from anything else that happens to be listening.
 *
 * `electron/main.js` used to decide a server was usable by opening a TCP
 * socket to port 3000 and seeing whether anything answered. Anything did:
 * a `next dev` left running from a previous session, a stray process, another
 * program entirely. The shell would then load it and present whatever came
 * back as the till — a development build with a different database, or a page
 * belonging to some other application.
 *
 * Deliberately cheap. It reads one small file and returns; no notification
 * aggregation, no ledger or stock queries, nothing that touches Prisma. The
 * shell calls this in a loop while it waits for the server to come up, and a
 * readiness probe that is expensive to answer is a readiness probe that
 * changes what it is measuring.
 *
 * Nothing here is a secret: the app's own name, whether it is a development or
 * production build, and which build it is. It is served on localhost to a
 * process running as the same user.
 */
export const dynamic = 'force-dynamic'

/** What a caller must see to believe this is the POS. */
export const HEALTH_APP_ID = 'violy-pos'

export async function GET() {
  // `installedRelease()` returns null on a copy run from source — a developer's
  // clone — which is exactly the distinction the shell needs to refuse an
  // accidental attachment to `next dev`.
  const installed = await installedRelease()

  return Response.json(
    {
      app: HEALTH_APP_ID,
      mode: process.env.NODE_ENV === 'production' ? 'production' : 'development',
      build: installed?.build ?? null,
      version: installed?.version ?? null,
      ready: true,
    },
    {
      // Never cached, anywhere. A cached readiness answer is a stale one, and
      // this exists to be asked repeatedly during startup.
      headers: { 'cache-control': 'no-store' },
    },
  )
}
