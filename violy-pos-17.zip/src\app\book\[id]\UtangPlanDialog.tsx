'use client'

import { useMemo, useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { parsePesoInput } from '@/lib/money'
import { dayKey, parseDayKey } from '@/lib/dates'
import {
  buildSchedule,
  describeTerms,
  MAX_TERM_MONTHS,
  validateTerms,
  type InterestMethod,
} from '@/lib/utang'
import { convertBalanceToPlan, createPlan } from '@/server/utang'
import { Button } from '@/components/ui/Button'
import { Dialog } from '@/components/ui/Dialog'
import { Field } from '@/components/ui/Field'
import { FormError } from '@/components/ui/FormError'
import { DatePicker } from '@/components/ui/DatePicker'
import { Input } from '@/components/ui/Input'
import { Money } from '@/components/ui/Money'
import { Select } from '@/components/ui/Select'
import { Textarea } from '@/components/ui/Textarea'

/** `NONE` is not an interest method — it is the absence of one, and it maps to
 *  a rate of zero on save. It exists as its own choice because "no interest"
 *  was previously expressed by leaving the rate field blank, which is a thing
 *  you have to be told rather than something the form offers. */
const NO_INTEREST = 'NONE' as const
type MethodChoice = InterestMethod | typeof NO_INTEREST

const METHODS: readonly { value: MethodChoice; label: string; blurb: string }[] = [
  {
    value: NO_INTEREST,
    label: 'No interest',
    blurb: 'The customer repays exactly what was borrowed, split evenly across the term.',
  },
  {
    value: 'FLAT_MONTHLY',
    label: 'Flat, per month',
    blurb: 'The rate is charged for every month of the term. 5% for 3 months means 15% in total.',
  },
  {
    value: 'FLAT_ONCE',
    label: 'Flat, one time',
    blurb: 'The rate is charged once, no matter how long the term runs.',
  },
  {
    value: 'REDUCING',
    label: 'On the remaining balance',
    blurb:
      'Equal monthly payments, with interest charged only on what is still unpaid. Costs less than flat over the same rate.',
  },
]

/**
 * Records a borrowing on terms — the notebook carry-over and the "she borrowed
 * again today" path are the same act, so they are the same dialog.
 *
 * Everything is previewed before it is saved. The preview calls the same
 * `buildSchedule` the Server Action will call, so what she reads to the
 * customer is what gets written, down to the centavo.
 */
export function UtangPlanDialog({
  customerId,
  onClose,
  /**
   * When set, this puts an EXISTING balance on terms instead of recording a
   * new borrowing. The principal is fixed at that balance and the amount field
   * disappears, because the money is already on the ledger — re-entering it
   * would be an invitation to charge it twice.
   */
  convertCentavos,
}: {
  customerId: number
  onClose: () => void
  convertCentavos?: number
}) {
  const converting = convertCentavos !== undefined
  const router = useRouter()
  const [principal, setPrincipal] = useState(
    convertCentavos !== undefined ? String(convertCentavos / 100) : '',
  )
  const [date, setDate] = useState(dayKey(new Date()))
  const [termMonths, setTermMonths] = useState('1')
  const [method, setMethod] = useState<MethodChoice>(NO_INTEREST)
  const [rate, setRate] = useState('')
  const [note, setNote] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [pending, startTransition] = useTransition()

  // `parsePesoInput` scales by 100, which suits both fields: "3000" is
  // 300000 centavos and "5.5" is 550 basis points. Blank means zero interest,
  // which is an ordinary utang with no charge on top.
  const principalCentavos = parsePesoInput(principal)
  const charging = method !== NO_INTEREST
  // A rate is only read when a method is charging one. Picking "No interest"
  // therefore does not require clearing the field first.
  const rateBps = !charging ? 0 : rate.trim() === '' ? 0 : parsePesoInput(rate)
  const term = Number(termMonths)
  const startedAt = parseDayKey(date)

  const terms = useMemo(
    () =>
      principalCentavos !== null && rateBps !== null && startedAt !== null
        ? {
            principalCentavos,
            interestMethod: charging ? method : ('FLAT_ONCE' as InterestMethod),
            interestRateBps: rateBps,
            termMonths: Number.isInteger(term) ? term : 0,
            startedAt,
          }
        : null,
    // `startedAt` is a fresh Date object each render, so it is keyed on the
    // string it was parsed from rather than on the object identity.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [principalCentavos, rateBps, term, date, method, charging],
  )

  const problem = useMemo(() => (terms ? validateTerms(terms) : null), [terms])
  // Memoised because it is the only expensive thing in this dialog: a 60-month
  // term builds 60 rows, and without this it rebuilt them on every keystroke
  // in the note field too.
  const schedule = useMemo(
    () => (terms && !problem ? buildSchedule(terms) : null),
    [terms, problem],
  )

  function save() {
    setError(null)
    if (principalCentavos === null) {
      setError('Enter an amount like 3,000')
      return
    }
    if (rateBps === null) {
      setError('Enter a rate like 5 or 2.5, or leave it blank for none.')
      return
    }
    if (startedAt === null) {
      setError('Enter a valid start date.')
      return
    }
    if (problem) {
      setError(problem)
      return
    }

    startTransition(async () => {
      const result = converting
        ? await convertBalanceToPlan({
            customerId,
            interestMethod: charging ? method : 'FLAT_ONCE',
            interestRateBps: rateBps,
            termMonths: term,
            startedAt,
            note,
          })
        : await createPlan({
        customerId,
        principalCentavos,
        // A no-interest plan is stored as a real method at a zero rate, so
        // nothing downstream needs to know about a fourth pseudo-method.
        interestMethod: charging ? method : 'FLAT_ONCE',
        interestRateBps: rateBps,
        termMonths: term,
        startedAt,
        note,
      })
      if (!result.ok) {
        setError(result.error)
        return
      }
      router.refresh()
      onClose()
    })
  }

  const blurb = METHODS.find((entry) => entry.value === method)?.blurb

  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title={converting ? 'Put this balance on terms' : 'New utang'}
      description={
        converting
          ? 'The amount is already owed and already on the ledger. This adds a schedule to it, and charges interest only if you set a rate.'
          : 'Record a borrowing, with or without interest. Nothing is saved until you press Save.'
      }
      footer={
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose} disabled={pending}>
            Cancel
          </Button>
          {/* `success`: this is a terminal, money-committing action. */}
          <Button variant="success" onClick={save} disabled={pending || schedule === null}>
            {pending ? 'Saving…' : converting ? 'Save schedule' : 'Save utang'}
          </Button>
        </div>
      }
    >
      <div className="grid gap-4">
        {/* `min-w-0` on the grid AND on its cells. Without it a grid track is
            sized by its content's minimum width, so the date field — which now
            refuses to shrink below its own text — pushed the dialog wider than
            its own frame and the right-hand edge was clipped. */}
        <div className="grid min-w-0 gap-4 sm:grid-cols-2">
          {converting ? (
            <Field label="Balance being scheduled">
              <div className="flex h-10 items-center rounded-control border border-line bg-surface-sunk px-3 tabular-nums">
                <Money centavos={convertCentavos} />
              </div>
            </Field>
          ) : (
            <Field label="Amount borrowed">
              <Input
                inputMode="decimal"
                value={principal}
                onChange={(event) => setPrincipal(event.target.value)}
                placeholder="3,000.00"
                className="w-full tabular-nums"
                autoFocus
              />
            </Field>
          )}

          <Field label="Date">
            <DatePicker
              value={date}
              onChange={setDate}
              aria-label="Start date"
              className="w-full"
            />
          </Field>

          <Field label="Pay over (months)">
            <Input
              inputMode="numeric"
              value={termMonths}
              onChange={(event) => setTermMonths(event.target.value)}
              placeholder="1"
              className="w-full tabular-nums"
            />
          </Field>

          {/* Interest. These controls existed in this component's state,
              constants and save path the whole time — `METHODS`, `method`,
              `rate`, `charging` — but had been dropped from the markup, so
              every utang recorded through this dialog was silently
              interest-free however it was agreed with the customer. Nothing
              said so: the preview below dutifully showed ₱0.00 interest,
              which reads as a correct answer to a question the form never
              asked. */}
          <Field label="Interest">
            <Select
              value={method}
              onChange={(event) => setMethod(event.target.value as MethodChoice)}
              className="w-full"
            >
              {METHODS.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </Select>
          </Field>

          {/* Only when a method actually charges one. A rate box sitting
              beside "No interest" invites a number that is then ignored. */}
          {charging && (
            <Field label={method === 'FLAT_ONCE' ? 'Rate (% one time)' : 'Rate (% per month)'}>
              <Input
                inputMode="decimal"
                value={rate}
                onChange={(event) => setRate(event.target.value)}
                placeholder="5"
                className="w-full tabular-nums"
              />
            </Field>
          )}
        </div>

        {/* The chosen method in plain words, under the controls rather than
            inside the dropdown: "flat, per month" and "on the remaining
            balance" are the difference between ₱450 and ₱304.88 on the same
            ₱3,000, and that is not something to leave to a label. */}
        <p className="-mt-2 text-xs text-ink-muted">
          {METHODS.find((option) => option.value === method)?.blurb}
        </p>


        <Field label="Note (optional)">
          <Textarea
            value={note}
            onChange={(event) => setNote(event.target.value)}
            rows={2}
            placeholder="e.g. Carry-over from notebook"
            className="w-full"
          />
        </Field>

        {/* The whole point of the dialog: the arithmetic and the schedule are
            visible BEFORE anything is written, so an agreement is read off the
            screen rather than worked out afterwards. */}
        {schedule ? (
          <div className="rounded-card border border-line bg-surface-sunk p-4">
            <div className="mb-3 text-xs font-semibold uppercase tracking-wide text-ink-muted">
              What this works out to
            </div>

            <dl className="grid gap-1 text-sm">
              <div className="flex justify-between">
                <dt className="text-ink-muted">Borrowed</dt>
                <dd><Money centavos={schedule.principalCentavos} /></dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-ink-muted">
                  Interest — {describeTerms({
                    interestMethod: charging ? method : 'FLAT_ONCE',
                    interestRateBps: rateBps ?? 0,
                    termMonths: term,
                  })}
                </dt>
                <dd><Money centavos={schedule.interestCentavos} /></dd>
              </div>
              {converting && schedule.interestCentavos > 0 && (
                <div className="flex justify-between text-xs text-ink-subtle">
                  <dt>Added to the balance</dt>
                  <dd><Money centavos={schedule.interestCentavos} /></dd>
                </div>
              )}
              <div className="flex justify-between border-t border-line pt-2">
                <dt className="font-semibold text-ink">Total to repay</dt>
                {/* Neutral, never `money-in`: this is money owed, not
                    cash received. */}
                <dd><Money centavos={schedule.totalCentavos} scale="strong" /></dd>
              </div>
            </dl>

            {/* Bounded and scrolled in place. Unbounded, a 60-month schedule
                pushed the totals above it off the top of the dialog, so the
                figure being agreed was never on screen with the schedule that
                produces it. The header sticks for the same reason. */}
            {/* Scrolls vertically only. `overflow-y-auto` alone still allows a
                horizontal scrollbar to appear when the table cannot fit, which
                is what put one across the bottom of this preview. The schedule
                is made to fit instead: tighter cells and no minimum width. */}
            <div className="mt-4 max-h-64 overflow-y-auto overflow-x-hidden rounded-control border border-line bg-surface">
            <table className="w-full table-fixed text-sm">
              {/* `table-fixed` divides width equally unless told otherwise, so
                  the one-digit sequence column claimed as much room as the
                  date and pushed "Sep 14, 2026" onto two lines. */}
              <colgroup>
                <col className="w-8" />
                <col className="w-28" />
                <col />
                <col />
                <col />
              </colgroup>
              <thead className="sticky top-0 z-10 border-b border-line bg-surface text-left text-xs uppercase tracking-wide text-ink-muted">
                <tr>
                  <th className="py-2 pr-2 font-medium">#</th>
                  <th className="px-2 py-2 font-medium">Due</th>
                  <th className="px-2 py-2 text-right font-medium">Principal</th>
                  <th className="px-2 py-2 text-right font-medium">Interest</th>
                  <th className="py-2 pl-2 text-right font-medium">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {schedule.installments.map((installment) => (
                  <tr key={installment.sequence}>
                    <td className="py-2 pr-2 font-mono tabular-nums text-ink-muted">
                      {installment.sequence}
                    </td>
                    <td className="px-2 py-2">
                      {installment.dueAt.toLocaleDateString('en-PH', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric',
                      })}
                    </td>
                    <td className="px-2 py-2 text-right">
                      <Money centavos={installment.principalCentavos} />
                    </td>
                    <td className="px-2 py-2 text-right">
                      <Money centavos={installment.interestCentavos} />
                    </td>
                    <td className="py-2 pl-2 text-right">
                      <Money centavos={installment.amountCentavos} className="font-semibold" />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            </div>
          </div>
        ) : (
          <p className="rounded-card border border-line bg-surface-sunk p-4 text-sm text-ink-muted">
            {problem ??
              `Enter an amount and a term of 1 to ${MAX_TERM_MONTHS} months to see the schedule.`}
          </p>
        )}

        {error && <FormError>{error}</FormError>}
      </div>
    </Dialog>
  )
}
