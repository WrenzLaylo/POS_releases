import type { HTMLAttributes } from 'react'
import { cn } from '@/lib/cn'

export function Toolbar({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        'flex flex-col gap-3 rounded-card border border-line bg-surface-raised p-3 shadow-panel sm:flex-row sm:items-center sm:justify-between',
        className,
      )}
      {...props}
    />
  )
}
