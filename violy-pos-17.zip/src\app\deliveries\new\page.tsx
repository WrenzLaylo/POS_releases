import { notFound } from 'next/navigation'
import { listProducts } from '@/server/products'
import { listSuppliers } from '@/server/suppliers'
import { PageHeader } from '@/components/ui/PageHeader'
import { DeliveryForm } from '../DeliveryForm'

export const dynamic = 'force-dynamic'

/**
 * Recording a delivery is a PAGE, not a dialog.
 *
 * It began as one and was wrong for the job. A consignment can be a dozen
 * lines, and a dialog is sized for a question — squeezed into one, the product
 * picker was about six characters wide and every option read "Ch…", "Br…",
 * "Gi…", which is not a choice anybody can make. Widening the dialog would
 * have traded one bad fit for another; a form with an unbounded number of rows
 * wants the page.
 */
export default async function NewDeliveryPage() {
  const [suppliers, products] = await Promise.all([
    listSuppliers(),
    // Unarchived only: receiving stock of something withdrawn from sale is
    // refused by the server, so offering it here would only produce an error.
    listProducts(),
  ])

  const active = suppliers.filter((supplier) => !supplier.isArchived)
  // Nothing to record against. `notFound` rather than an empty form, because
  // the Deliveries screen already disables the button that leads here and
  // explains why — this only catches someone arriving by URL.
  if (active.length === 0) notFound()

  return (
    <PageHeader
      title="Record a delivery"
      description="Stock goes up, and each product's cost is set to what you paid this time."
    >
      <DeliveryForm suppliers={active} products={products} />
    </PageHeader>
  )
}
