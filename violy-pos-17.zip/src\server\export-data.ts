'use server'

import { prisma } from '@/lib/db'
import { centavosToCsv, toCsv } from '@/lib/csv'
import { lineTotal } from '@/lib/money'
import { dayKey } from '@/lib/dates'
import { sumBalance } from '@/lib/ledger-balance'
import type { ExportTable } from '@/lib/export-tables'

/**
 * A table as CSV text.
 *
 * Money is written as decimal pesos, not the integer centavos the database
 * holds: this file is going into a spreadsheet where someone will sum a
 * column, and a column of centavos sums to a number a hundred times too big.
 * `products` and `customers` are shaped to match what the importer reads, so
 * an export can be edited and sent straight back.
 */
export async function exportTableCsv(table: ExportTable): Promise<string> {
  switch (table) {
    case 'products': {
      const rows = await prisma.product.findMany({
        include: { category: { select: { name: true } } },
        orderBy: [{ name: 'asc' }],
      })
      return toCsv(
        ['name', 'category', 'unit', 'price', 'cost', 'stock', 'low_stock_at', 'archived'],
        rows.map((product) => [
          product.name,
          product.category.name,
          product.unit,
          centavosToCsv(product.price),
          centavosToCsv(product.costPrice),
          String(product.stockQty),
          String(product.lowStockThreshold),
          product.isArchived ? 'yes' : 'no',
        ]),
      )
    }

    case 'customers': {
      const rows = await prisma.customer.findMany({
        include: {
          entries: {
            where: { isVoided: false },
            select: { id: true, type: true, amountCentavos: true, isVoided: true },
          },
        },
        orderBy: [{ name: 'asc' }],
      })
      return toCsv(
        ['name', 'phone', 'notes', 'discount_kind', 'discount_value', 'discount_basis', 'balance', 'archived'],
        rows.map((customer) => [
          customer.name,
          customer.phone ?? '',
          customer.notes,
          customer.discountKind,
          // The value column follows the kind: pesos for AMOUNT, percent for
          // PERCENT. Two columns, one of which is always blank, is worse to
          // read and worse to edit.
          customer.discountKind === 'PERCENT'
            ? String(customer.discountBps / 100)
            : centavosToCsv(customer.discountCentavos),
          customer.discountBasis,
          centavosToCsv(sumBalance(customer.entries)),
          customer.isArchived ? 'yes' : 'no',
        ]),
      )
    }


    case 'categories': {
      const rows = await prisma.category.findMany({
        select: { name: true, sortOrder: true, _count: { select: { products: true } } },
        orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
      })
      return toCsv(
        ['name', 'sort_order', 'products'],
        rows.map((category) => [
          category.name,
          String(category.sortOrder),
          String(category._count.products),
        ]),
      )
    }

    case 'suppliers': {
      const rows = await prisma.supplier.findMany({ orderBy: [{ name: 'asc' }] })
      return toCsv(
        ['name', 'contact_number', 'notes', 'archived'],
        rows.map((supplier) => [
          supplier.name,
          supplier.contactNumber,
          supplier.notes,
          supplier.isArchived ? 'yes' : 'no',
        ]),
      )
    }

    case 'sale_items': {
      // One row per LINE, not per sale. The `sales` export answers "what did
      // the day take"; this answers "what actually left the shelf", which is
      // the question stock and margin are both asked from.
      const rows = await prisma.saleItem.findMany({
        include: {
          product: { select: { name: true, unit: true } },
          sale: { select: { id: true, createdAt: true, isVoided: true, customer: { select: { name: true } } } },
        },
        orderBy: [{ saleId: 'desc' }, { id: 'asc' }],
      })
      return toCsv(
        ['date', 'reference', 'customer', 'product', 'unit', 'quantity', 'price', 'discount', 'cost', 'line_total', 'voided'],
        rows.map((item) => [
          dayKey(item.sale.createdAt),
          String(item.sale.id),
          item.sale.customer?.name ?? 'Walk-in',
          item.product.name,
          item.product.unit,
          String(item.quantity),
          centavosToCsv(item.priceAtSale),
          centavosToCsv(item.discountAtSale),
          centavosToCsv(item.costAtSale),
          centavosToCsv(lineTotal(item.priceAtSale - item.discountAtSale, item.quantity)),
          item.sale.isVoided ? 'yes' : 'no',
        ]),
      )
    }

    case 'deliveries': {
      // Flattened to one row per line, with the delivery's own fields repeated
      // across its lines. Two files that have to be joined on an id is not
      // something anybody does in a spreadsheet.
      const rows = await prisma.deliveryItem.findMany({
        include: {
          product: { select: { name: true, unit: true } },
          delivery: {
            select: {
              id: true,
              receivedAt: true,
              terms: true,
              reference: true,
              totalCostCentavos: true,
              amountPaidCentavos: true,
              isVoided: true,
              supplier: { select: { name: true } },
            },
          },
        },
        orderBy: [{ deliveryId: 'desc' }, { id: 'asc' }],
      })
      return toCsv(
        ['date', 'delivery_id', 'supplier', 'terms', 'reference', 'product', 'unit', 'quantity', 'unit_cost', 'line_total', 'delivery_total', 'paid', 'voided'],
        rows.map((item) => [
          dayKey(item.delivery.receivedAt),
          String(item.delivery.id),
          item.delivery.supplier.name,
          item.delivery.terms,
          item.delivery.reference,
          item.product.name,
          item.product.unit,
          String(item.quantity),
          centavosToCsv(item.unitCostCentavos),
          centavosToCsv(lineTotal(item.unitCostCentavos, item.quantity)),
          centavosToCsv(item.delivery.totalCostCentavos),
          centavosToCsv(item.delivery.amountPaidCentavos),
          item.delivery.isVoided ? 'yes' : 'no',
        ]),
      )
    }

    case 'stock_movements': {
      const rows = await prisma.stockMovement.findMany({
        include: { product: { select: { name: true, unit: true } } },
        orderBy: [{ createdAt: 'asc' }, { id: 'asc' }],
      })
      return toCsv(
        ['date', 'product', 'unit', 'type', 'quantity', 'note', 'sale_id', 'delivery_id'],
        rows.map((movement) => [
          dayKey(movement.createdAt),
          movement.product.name,
          movement.product.unit,
          movement.type,
          String(movement.quantity),
          movement.note,
          movement.saleId === null ? '' : String(movement.saleId),
          movement.deliveryId === null ? '' : String(movement.deliveryId),
        ]),
      )
    }

    case 'sales': {
      const rows = await prisma.sale.findMany({
        include: { customer: { select: { name: true } } },
        orderBy: [{ createdAt: 'desc' }],
      })
      return toCsv(
        ['date', 'reference', 'customer', 'total', 'cash_kept', 'change', 'discount', 'voided'],
        rows.map((sale) => [
          dayKey(sale.createdAt),
          String(sale.id),
          sale.customer?.name ?? 'Walk-in',
          centavosToCsv(sale.totalAmount),
          centavosToCsv(sale.cashPaidCentavos),
          centavosToCsv(sale.changeCentavos),
          centavosToCsv(sale.customerDiscountCentavos + sale.orderDiscountCentavos),
          sale.isVoided ? 'yes' : 'no',
        ]),
      )
    }

    case 'ledger': {
      const rows = await prisma.ledgerEntry.findMany({
        include: { customer: { select: { name: true } } },
        orderBy: [{ occurredAt: 'asc' }, { id: 'asc' }],
      })
      return toCsv(
        ['date', 'customer', 'type', 'amount', 'note', 'sale_id', 'plan_id', 'voided'],
        rows.map((entry) => [
          dayKey(entry.occurredAt),
          entry.customer.name,
          entry.type,
          centavosToCsv(entry.amountCentavos),
          entry.note,
          entry.saleId === null ? '' : String(entry.saleId),
          entry.planId === null ? '' : String(entry.planId),
          entry.isVoided ? 'yes' : 'no',
        ]),
      )
    }
  }
}
