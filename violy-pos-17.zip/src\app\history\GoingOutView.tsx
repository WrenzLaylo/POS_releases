'use client'

import Link from 'next/link'
import type { DeliveryOrderRow } from '@/lib/types'
import { dayKey } from '@/lib/dates'
import { deliveryNote, sale as saleRoute, DELIVER } from '@/lib/routes'
import { Badge } from '@/components/ui/Badge'
import { Card } from '@/components/ui/Card'
import { EmptyState } from '@/components/ui/EmptyState'
import { Money } from '@/components/ui/Money'
import { SectionHeader } from '@/components/ui/SectionHeader'
import { cn } from '@/lib/cn'

/**
 * What is booked to go out, and what already went.
 *
 * Grouped by day rather than listed flat: the question is "what goes on the
 * truck on Saturday", and a flat list makes somebody read dates off every row
 * to answer it. The day heading is the answer; the rows under it are the load.
 *
 * Every row carries a direct link to its note, because the reason to open this
 * screen at all is usually to print one. Reaching the note through the sale
 * would be two more clicks on the one journey this tab exists to shorten.
 */
function dayLabel(date: Date, today: Date): string {
  const key = dayKey(date)
  const todayKey = dayKey(today)
  if (key === todayKey) return 'Today'

  const tomorrow = new Date(today)
  tomorrow.setDate(tomorrow.getDate() + 1)
  if (key === dayKey(tomorrow)) return 'Tomorrow'

  const yesterday = new Date(today)
  yesterday.setDate(yesterday.getDate() - 1)
  if (key === dayKey(yesterday)) return 'Yesterday'

  return date.toLocaleDateString('en-PH', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  })
}

function groupByDay(rows: readonly DeliveryOrderRow[]): { key: string; date: Date; rows: DeliveryOrderRow[] }[] {
  const groups = new Map<string, { key: string; date: Date; rows: DeliveryOrderRow[] }>()
  for (const row of rows) {
    const key = dayKey(row.deliverAt)
    const existing = groups.get(key)
    if (existing) existing.rows.push(row)
    else groups.set(key, { key, date: row.deliverAt, rows: [row] })
  }
  return [...groups.values()]
}

function DeliveryRow({ row }: { row: DeliveryOrderRow }) {
  return (
    <li className="flex flex-wrap items-start justify-between gap-3 py-3">
      <div className="min-w-0">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-sm font-medium text-ink">{row.customerName}</span>
          <span className="text-sm text-ink-muted">{row.deliverTo}</span>
          {/* Owing reads `owed`, settled reads `paid`. `paid` is a bordered
              green chip meaning closed-out clean — never `muted`, which means
              a dead record.

              The chip carries no peso figure. `Badge` is the `text-xs` meta
              tier and `Money`'s smallest scale is `text-sm`, so a figure
              inside one sets its own size and fights the tier it sits in. The
              amount belongs in the money column on the right, which is where
              every other figure on this row already is. */}
          {row.owedCentavos > 0 ? (
            <Badge tone="owed">Owing</Badge>
          ) : (
            <Badge tone="paid">Paid</Badge>
          )}
        </div>

        {row.deliverAddress && (
          <div className="mt-0.5 text-xs text-ink-subtle">{row.deliverAddress}</div>
        )}

        <div className="mt-1 text-xs text-ink-muted">
          {row.lines
            .map((line) => `${line.quantity} × ${line.name}`)
            .join(', ')}
        </div>

        {row.instructions && (
          <div className="mt-1 text-xs text-warn">{row.instructions}</div>
        )}
      </div>

      <div className="flex shrink-0 items-center gap-3">
        <div className="text-right">
          {/* Neutral. Benta is not cash in the drawer. */}
          <Money centavos={row.totalCentavos} scale="body" className="font-semibold" />
          {row.deliveryFeeCentavos > 0 && (
            <div className="text-xs text-ink-subtle">
              incl. <Money centavos={row.deliveryFeeCentavos} scale="body" /> delivery
            </div>
          )}
          {/* Only when it differs from the total. On a load nothing has been
              paid against, the total IS what is owed, and printing the same
              figure twice under itself reads as two different numbers that
              happen to match. */}
          {row.owedCentavos > 0 && row.owedCentavos !== row.totalCentavos && (
            <div className="text-xs">
              <Money centavos={row.owedCentavos} scale="body" tone="owed" /> owing
            </div>
          )}
        </div>
        <Link
          href={deliveryNote(row.saleId)}
          className="inline-flex h-8 items-center rounded-control border border-line-strong px-3 text-sm font-medium text-ink hover:border-accent hover:bg-accent-soft"
        >
          Note
        </Link>
        <Link
          href={saleRoute(row.saleId)}
          className="inline-flex h-8 items-center rounded-control px-3 text-sm font-medium text-accent hover:bg-accent-soft"
        >
          Open
        </Link>
      </div>
    </li>
  )
}

export function GoingOutView({
  upcoming,
  past,
  today,
}: {
  upcoming: DeliveryOrderRow[]
  past: DeliveryOrderRow[]
  /** Passed in rather than read here, so "Today" cannot mean one thing on the
   *  server pass and another on the client's — the hydration trap
   *  `dayKey(new Date())` in a useState initialiser already caused twice in
   *  this app. */
  today: Date
}) {
  const upcomingDays = groupByDay(upcoming)
  const pastDays = groupByDay(past)

  if (upcoming.length === 0 && past.length === 0) {
    return (
      <EmptyState>
        Nothing has been booked to go out yet.{' '}
        <Link href={DELIVER} className="font-medium text-accent hover:underline">
          Deliver to a customer
        </Link>
        .
      </EmptyState>
    )
  }

  return (
    <div className="flex flex-col gap-4">
      <Card>
        <SectionHeader title="Coming up" className="mb-3" />
        {upcomingDays.length === 0 ? (
          <EmptyState>Nothing booked from today onward.</EmptyState>
        ) : (
          <div className="flex flex-col gap-5">
            {upcomingDays.map((group) => (
              <section key={group.key}>
                <h3
                  className={cn(
                    'text-xs font-semibold uppercase tracking-wide',
                    dayKey(group.date) === dayKey(today) ? 'text-accent' : 'text-ink-muted',
                  )}
                >
                  {dayLabel(group.date, today)}
                </h3>
                <ul className="divide-y divide-line">
                  {group.rows.map((row) => (
                    <DeliveryRow key={row.saleId} row={row} />
                  ))}
                </ul>
              </section>
            ))}
          </div>
        )}
      </Card>

      {pastDays.length > 0 && (
        <Card>
          <SectionHeader
            title="Already gone out"
            description="The most recent 30. Older ones are under Recent, filtered to Deliveries."
            className="mb-3"
          />
          <div className="flex flex-col gap-5">
            {pastDays.map((group) => (
              <section key={group.key}>
                <h3 className="text-xs font-semibold uppercase tracking-wide text-ink-muted">
                  {dayLabel(group.date, today)}
                </h3>
                <ul className="divide-y divide-line">
                  {group.rows.map((row) => (
                    <DeliveryRow key={row.saleId} row={row} />
                  ))}
                </ul>
              </section>
            ))}
          </div>
        </Card>
      )}
    </div>
  )
}
