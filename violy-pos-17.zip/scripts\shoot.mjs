/**
 * Screenshot the running dev server at a given viewport.
 *
 * A development aid, not a test: this project deliberately has no component or
 * E2E suite, and nothing here asserts anything. It exists because the visual
 * result of a theme or layout change cannot be verified by reading code, and
 * the alternative was guessing.
 *
 *   node scripts/shoot.mjs [width] [height] [route...]
 */
import { chromium } from 'playwright'
import { mkdirSync } from 'node:fs'

const [, , w = '1366', h = '768', ...routes] = process.argv
const paths = routes.length ? routes : ['/counter', '/book', '/stock', '/pulse', '/history']
const base = process.env.BASE_URL ?? 'http://localhost:3000'
const outDir = '.screens'

mkdirSync(outDir, { recursive: true })

const browser = await chromium.launch()
const page = await browser.newPage({
  viewport: { width: Number(w), height: Number(h) },
  deviceScaleFactor: 1,
})

for (const route of paths) {
  const url = `${base}${route}`
  const response = await page.goto(url, { waitUntil: 'networkidle', timeout: 60_000 })
  // Fonts land after first paint; without this the shot can catch fallback
  // metrics and misreport spacing.
  await page.waitForLoadState('domcontentloaded')
  await page.evaluate(() => document.fonts.ready)
  const name = route.replace(/[^a-z0-9]+/gi, '-').replace(/^-|-$/g, '') || 'root'
  const file = `${outDir}/${name}-${w}x${h}.png`
  await page.screenshot({ path: file })
  console.log(`${response?.status() ?? '???'}  ${route}  -> ${file}`)
}

await browser.close()
