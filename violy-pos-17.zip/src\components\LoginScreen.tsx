'use client'

import { useEffect, useRef, useState, useTransition } from 'react'
import Image from 'next/image'
import { useRouter } from 'next/navigation'
import { resetPasswordWithCode, signIn } from '@/server/auth'
import { checkForReset, requestReset } from '@/server/password-reset'
import { Button } from '@/components/ui/Button'
import { Field } from '@/components/ui/Field'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'
import { Icon } from '@/components/ui/Icon'

type Mode = 'signin' | 'forgot' | 'online' | 'done'

/**
 * The first thing the shop sees each morning.
 *
 * Three things shape this screen, none of them decoration:
 *
 * ONE FIELD. There is exactly one account, so a username box would be an email
 * address retyped every morning for no benefit — the account is stated, not
 * asked for. A phone lock screen, not a web sign-in.
 *
 * THE PASSWORD IS VISIBLE ON REQUEST, and Caps Lock is called out before it
 * costs her an attempt. Between them those two cover almost every failed
 * sign-in that is not actually a forgotten password, and both matter more for
 * an operator who is not a fast typist.
 *
 * NOTHING DEAD-ENDS. Every error says what to do next, and the way back in is
 * on this screen rather than somewhere she would have to be told about.
 */
export function LoginScreen({ username }: { username: string }) {
  const router = useRouter()
  const [mode, setMode] = useState<Mode>('signin')

  const [password, setPassword] = useState('')
  const [remember, setRemember] = useState(true)
  const [reveal, setReveal] = useState(false)
  const [capsLock, setCapsLock] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [pending, startTransition] = useTransition()

  // Recovery
  const [code, setCode] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [replacement, setReplacement] = useState<{ code: string; remaining: number } | null>(null)

  // The online path: a code this laptop generated, which Wrenz signs.
  const [machineCode, setMachineCode] = useState<string | null>(null)
  const [waiting, setWaiting] = useState(false)

  const passwordRef = useRef<HTMLInputElement>(null)

  // She opens the laptop and types. Focus follows the mode so the cursor is
  // always already where the next keystroke belongs.
  useEffect(() => {
    passwordRef.current?.focus()
  }, [mode])

  function capsFrom(event: React.KeyboardEvent<HTMLInputElement>) {
    // `getModifierState` is undefined on some synthetic events; treating that
    // as "no warning" is right, since a false warning is worse than none.
    setCapsLock(event.getModifierState?.('CapsLock') ?? false)
  }

  function submitSignIn() {
    setError(null)
    if (password === '') {
      setError('Type your password.')
      passwordRef.current?.focus()
      return
    }
    startTransition(async () => {
      const result = await signIn(password, remember)
      if (!result.ok) {
        setError(result.error)
        setPassword('')
        passwordRef.current?.focus()
        return
      }
      // `refresh`, not a push: the layout re-renders with a session and the
      // screen she was heading for appears underneath. There is no login URL
      // to navigate away from.
      router.refresh()
    })
  }

  function submitRecovery() {
    setError(null)
    startTransition(async () => {
      const result = await resetPasswordWithCode(code, newPassword)
      if (!result.ok) {
        setError(result.error)
        return
      }
      setReplacement({ code: result.data.replacementCode, remaining: result.data.remaining })
      setMode('done')
    })
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-canvas px-6 py-10">
      {/* Not a 320px SaaS box. The panel is wide enough to hold a sentence of
          plain explanation without it wrapping into a column of fragments. */}
      <div className="w-full max-w-md">
        <div className="mb-8 flex flex-col items-center text-center">
          <Image
            src="/brand/violy-store-mark.png"
            alt=""
            width={72}
            height={72}
            className="mb-4 h-16 w-16"
            priority
          />
          <h1 className="font-display text-xl font-semibold uppercase tracking-[0.14em] text-accent">
            Violy Store
          </h1>
          <p className="mt-1 text-sm text-ink-muted">
            {mode === 'signin' ? 'Sign in to open the counter' : 'Get back into the counter'}
          </p>
        </div>

        <div className="rounded-card border border-line bg-surface p-6 shadow-raised">
          {mode === 'signin' && (
            <form
              onSubmit={(event) => {
                event.preventDefault()
                submitSignIn()
              }}
              className="grid gap-5"
            >
              {/* Stated, not asked for. */}
              <div className="flex items-center gap-3 rounded-control border border-line bg-surface-sunk px-3 py-2">
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-accent-soft font-display text-sm font-semibold uppercase text-accent">
                  {username.slice(0, 1)}
                </span>
                <div className="min-w-0">
                  <div className="text-xs font-medium uppercase tracking-[0.08em] text-ink-muted">
                    Signing in as
                  </div>
                  <div className="truncate text-sm text-ink">{username}</div>
                </div>
              </div>

              <Field label="Password">
                <div className="relative">
                  <Input
                    ref={passwordRef}
                    type={reveal ? 'text' : 'password'}
                    value={password}
                    onChange={(event) => setPassword(event.target.value)}
                    onKeyUp={capsFrom}
                    onKeyDown={capsFrom}
                    autoComplete="current-password"
                    aria-invalid={error !== null || undefined}
                    disabled={pending}
                    // Room for the reveal button, so a long password never
                    // slides underneath it.
                    className="w-full pr-11"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      setReveal((shown) => !shown)
                      passwordRef.current?.focus()
                    }}
                    // Not a Button: this sits inside the field, and the
                    // primitive's height would fight the input's.
                    className="absolute right-1 top-1 flex h-8 w-9 items-center justify-center rounded-control text-ink-muted transition-colors hover:bg-surface-sunk hover:text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                    aria-label={reveal ? 'Hide password' : 'Show password'}
                    aria-pressed={reveal}
                    tabIndex={-1}
                  >
                    <Icon name={reveal ? 'eye-off' : 'eye'} className="h-4 w-4" />
                  </button>
                </div>
              </Field>

              {/* Before it costs her an attempt, not after. */}
              {capsLock && (
                <p className="-mt-2 flex items-center gap-2 text-xs text-warn">
                  <Icon name="alert" className="h-3.5 w-3.5 shrink-0" />
                  Caps Lock is on.
                </p>
              )}

              <label className="flex cursor-pointer items-center gap-3 text-sm text-ink">
                <input
                  type="checkbox"
                  checked={remember}
                  onChange={(event) => setRemember(event.target.checked)}
                  disabled={pending}
                  className="h-4 w-4 rounded border-line-strong text-accent focus:ring-2 focus:ring-accent focus:ring-offset-2 focus:ring-offset-surface"
                />
                Stay signed in on this laptop
              </label>

              {error && <FormError>{error}</FormError>}

              <Button type="submit" variant="primary" size="wide" disabled={pending} className="w-full">
                {pending ? 'Signing in…' : 'Sign in'}
              </Button>

              <button
                type="button"
                onClick={() => {
                  setMode('forgot')
                  setError(null)
                  setPassword('')
                }}
                className="justify-self-center text-sm text-ink-muted underline-offset-4 hover:text-ink hover:underline"
              >
                Forgot the password?
              </button>
            </form>
          )}

          {mode === 'online' && (
            <form
              onSubmit={(event) => {
                event.preventDefault()
                setError(null)
                setWaiting(true)
                startTransition(async () => {
                  const result = await checkForReset(newPassword)
                  setWaiting(false)
                  if (!result.ok) {
                    setError(result.error)
                    return
                  }
                  if (!result.data.applied) {
                    setError('Nothing has arrived yet. Give it a minute and press again.')
                    return
                  }
                  setReplacement(null)
                  setMode('done')
                })
              }}
              className="grid gap-5"
            >
              <p className="text-sm text-ink">
                Send this to Wrenz. He will unlock this laptop from wherever he is.
              </p>

              <div className="rounded-control border border-line bg-surface-sunk p-4 text-center">
                <div className="text-xs font-medium uppercase tracking-[0.08em] text-ink-muted">
                  Read this to Wrenz
                </div>
                <div className="mt-2 font-mono text-2xl font-medium tracking-[0.2em] text-ink">
                  {machineCode ?? '—'}
                </div>
              </div>

              <Field label="New password">
                <Input
                  type={reveal ? 'text' : 'password'}
                  value={newPassword}
                  onChange={(event) => setNewPassword(event.target.value)}
                  autoComplete="new-password"
                  disabled={pending}
                  className="w-full"
                />
                <span className="mt-1 text-xs text-ink-subtle">
                  At least 8 characters. Choose it now, then press below once he says it is sent.
                </span>
              </Field>

              {error && <FormError>{error}</FormError>}

              <Button type="submit" variant="primary" size="wide" disabled={pending} className="w-full">
                {waiting ? 'Checking…' : 'Check now'}
              </Button>

              <button
                type="button"
                onClick={() => {
                  setMode('forgot')
                  setError(null)
                }}
                className="justify-self-center text-sm text-ink-muted underline-offset-4 hover:text-ink hover:underline"
              >
                ← Use a recovery code instead
              </button>
            </form>
          )}

          {mode === 'forgot' && (
            <form
              onSubmit={(event) => {
                event.preventDefault()
                submitRecovery()
              }}
              className="grid gap-5"
            >
              <p className="text-sm text-ink">
                Ring Wrenz and ask for a <strong className="font-medium">recovery code</strong>. Each
                code works once, and using one does not use up the others.
              </p>

              <Field label="Recovery code">
                <Input
                  ref={passwordRef}
                  value={code}
                  onChange={(event) => setCode(event.target.value)}
                  placeholder="7QK2-4M91"
                  autoComplete="off"
                  spellCheck={false}
                  disabled={pending}
                  // Monospace and roomy: this gets read aloud down a phone and
                  // typed back, so every character has to be checkable against
                  // what was said.
                  className="w-full font-mono tracking-[0.2em]"
                />
              </Field>

              <Field label="New password">
                <div className="relative">
                  <Input
                    type={reveal ? 'text' : 'password'}
                    value={newPassword}
                    onChange={(event) => setNewPassword(event.target.value)}
                    autoComplete="new-password"
                    disabled={pending}
                    className="w-full pr-11"
                  />
                  <button
                    type="button"
                    onClick={() => setReveal((shown) => !shown)}
                    className="absolute right-1 top-1 flex h-8 w-9 items-center justify-center rounded-control text-ink-muted transition-colors hover:bg-surface-sunk hover:text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                    aria-label={reveal ? 'Hide password' : 'Show password'}
                    aria-pressed={reveal}
                    tabIndex={-1}
                  >
                    <Icon name={reveal ? 'eye-off' : 'eye'} className="h-4 w-4" />
                  </button>
                </div>
                <span className="mt-1 text-xs text-ink-subtle">At least 8 characters.</span>
              </Field>

              {error && <FormError>{error}</FormError>}

              <Button type="submit" variant="primary" size="wide" disabled={pending} className="w-full">
                {pending ? 'Checking…' : 'Set a new password'}
              </Button>

              {/* The second way in, offered beside the first rather than
                  hidden behind it: they fail in different situations - this one
                  needs the internet, the code above does not - and the moment
                  she is locked out is the wrong time to discover the other
                  exists. */}
              <div className="grid gap-2 border-t border-line pt-4">
                <p className="text-xs text-ink-subtle">
                  No code to hand? Wrenz can unlock this laptop over the internet instead.
                </p>
                <Button
                  variant="secondary"
                  disabled={pending}
                  onClick={() => {
                    setError(null)
                    startTransition(async () => {
                      const result = await requestReset()
                      if (!result.ok) {
                        setError(result.error)
                        return
                      }
                      setMachineCode(result.data.code)
                      setMode('online')
                    })
                  }}
                >
                  Ask Wrenz to unlock it
                </Button>
              </div>

              <button
                type="button"
                onClick={() => {
                  setMode('signin')
                  setError(null)
                  setCode('')
                  setNewPassword('')
                }}
                className="justify-self-center text-sm text-ink-muted underline-offset-4 hover:text-ink hover:underline"
              >
                ← Back to signing in
              </button>
            </form>
          )}

          {mode === 'done' && (
            <div className="grid gap-5 text-center">
              <div className="justify-self-center rounded-full bg-money-in/10 p-3">
                <Icon name="check" className="h-6 w-6 text-money-in" />
              </div>
              <div>
                <h2 className="font-display text-base font-semibold text-ink">
                  Password changed
                </h2>
                <p className="mt-1 text-sm text-ink-muted">You are signed in.</p>
              </div>

              {/* Only the recovery-code path mints a replacement. An online
                  reset consumes no code, so there is nothing to write down. */}
              {replacement && (
              <div className="rounded-control border border-line bg-surface-sunk p-4 text-left">
                <div className="text-xs font-medium uppercase tracking-[0.08em] text-ink-muted">
                  Read this to Wrenz now
                </div>
                <div className="mt-2 font-mono text-lg font-medium tracking-[0.2em] text-ink">
                  {replacement.code}
                </div>
                <p className="mt-2 text-xs text-ink-subtle">
                  It replaces the one you just used, so the list stays at {replacement.remaining}.
                  This is the only time it is shown.
                </p>
              </div>
              )}

              {/* Signing in happens HERE, not inside the reset, so this screen
                  is guaranteed to have been seen. When the reset started the
                  session itself, the layout swapped to the app immediately and
                  the code above was minted, hashed and lost in the same
                  request — a list of ten with one known to nobody. */}
              <Button
                variant="primary"
                size="wide"
                className="w-full"
                disabled={pending}
                onClick={() => {
                  startTransition(async () => {
                    await signIn(newPassword, true)
                    router.refresh()
                  })
                }}
              >
                {pending
                  ? 'Opening…'
                  : replacement
                    ? 'I have written it down — open the counter'
                    : 'Open the counter'}
              </Button>
            </div>
          )}
        </div>

      </div>
    </div>
  )
}
