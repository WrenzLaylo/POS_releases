import { beforeEach, describe, expect, it, vi } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'
import { hashPassword, verifyPassword } from '@/lib/password'
import { generateRecoveryCodes, hashRecoveryCode } from '@/lib/recovery-code'
import { CONFIRMATION_MINUTES, NEEDS_PASSWORD, needsPassword } from '@/lib/auth-gate'
import { confirmationGate } from './session'

/**
 * `cookies()` only exists inside a request. These actions are being exercised
 * directly, so the jar is a plain Map — enough for them to set and read a
 * session the way they would in the app.
 */
const jar = new Map<string, string>()
vi.mock('next/headers', () => ({
  cookies: async () => ({
    get: (name: string) => (jar.has(name) ? { name, value: jar.get(name) } : undefined),
    set: (name: string, value: string) => void jar.set(name, value),
    delete: (name: string) => void jar.delete(name),
  }),
}))

const {
  createLogin,
  signIn,
  confirmPassword,
  changePassword,
  resetPasswordWithCode,
  countRecoveryCodes,
  regenerateRecoveryCodes,
} = await import('./auth')

const PASSWORD = 'sacks-of-feed-2026'

beforeEach(async () => {
  await resetDb()
  jar.clear()
})

/** Sets a login up the way the Settings screen will. */
async function withLogin() {
  const result = await createLogin('violy', PASSWORD)
  if (!result.ok) throw new Error(result.error)
  return result.data.codes
}

describe('turning the login on', () => {
  it('is off until an account exists', async () => {
    // The property that lets this update reach her laptop safely: no AppUser
    // means the till is open, exactly as it was before any of this existed.
    expect(await prisma.appUser.count()).toBe(0)
    expect((await confirmPassword('anything')).ok).toBe(true)
  })

  it('creates the account and hands back ten codes, once', async () => {
    const codes = await withLogin()
    expect(codes).toHaveLength(10)
    expect(await countRecoveryCodes()).toBe(10)
  })

  it('never stores the password or the codes in readable form', async () => {
    const codes = await withLogin()
    const user = await prisma.appUser.findFirstOrThrow()
    expect(user.passwordHash).not.toContain(PASSWORD)

    const stored = await prisma.recoveryCode.findMany()
    for (const code of codes) {
      expect(stored.some((row) => row.codeHash === code)).toBe(false)
    }
  })

  it('refuses a second account, so a shop cannot be taken over', async () => {
    await withLogin()
    const again = await createLogin('someone-else', 'another-password')
    expect(again.ok).toBe(false)
  })

  it('refuses a password that is too short, before creating anything', async () => {
    const result = await createLogin('violy', 'short')
    expect(result.ok).toBe(false)
    expect(await prisma.appUser.count()).toBe(0)
  })
})

describe('signing in', () => {
  it('accepts the right password', async () => {
    await withLogin()
    jar.clear()
    expect((await signIn(PASSWORD, false)).ok).toBe(true)
  })

  it('refuses the wrong one', async () => {
    await withLogin()
    const result = await signIn('not-the-password', false)
    expect(result.ok).toBe(false)
    if (!result.ok) expect(result.error).toContain('does not match')
  })

  it('remembers, or does not, as asked', async () => {
    await withLogin()
    jar.clear()
    await signIn(PASSWORD, true)
    const remembered = await prisma.appSession.findFirst({ orderBy: { createdAt: 'desc' } })
    expect(remembered?.remembered).toBe(true)
    // A remembered session outlives the working day; that difference is the
    // whole reason the box exists.
    expect(remembered!.expiresAt.getTime() - Date.now()).toBeGreaterThan(30 * 24 * 3600 * 1000)
  })
})

describe('recovery codes', () => {
  it('lets a code through once and never again', async () => {
    const codes = await withLogin()
    const first = await resetPasswordWithCode(codes[0], 'a-brand-new-password')
    expect(first.ok).toBe(true)

    const again = await resetPasswordWithCode(codes[0], 'yet-another-password')
    expect(again.ok).toBe(false)
    if (!again.ok) expect(again.error).toContain('already been used')
  })

  it('replaces the used one, so the list never runs out', async () => {
    // The answer to "can't we make them unlimited". Each code is still
    // single-use — what is unlimited is how many times she can recover.
    const codes = await withLogin()
    expect(await countRecoveryCodes()).toBe(10)

    for (let i = 0; i < 5; i += 1) {
      const result = await resetPasswordWithCode(codes[i], `password-number-${i}`)
      expect(result.ok).toBe(true)
      if (result.ok) {
        expect(result.data.remaining).toBe(10)
        expect(result.data.replacementCode).toMatch(/^[A-Z0-9]{4}-[A-Z0-9]{4}$/)
      }
      expect(await countRecoveryCodes()).toBe(10)
    }
  })

  it('actually changes the password', async () => {
    const codes = await withLogin()
    await resetPasswordWithCode(codes[0], 'the-new-one-entirely')

    const user = await prisma.appUser.findFirstOrThrow()
    expect(verifyPassword('the-new-one-entirely', user.passwordHash)).toBe(true)
    expect(verifyPassword(PASSWORD, user.passwordHash)).toBe(false)
  })

  it('signs every laptop out, so the old password stops being useful', async () => {
    const codes = await withLogin()
    expect(await prisma.appSession.count()).toBe(1)

    await resetPasswordWithCode(codes[0], 'the-new-one-entirely')
    expect(await prisma.appSession.count()).toBe(0)
  })

  it('does not start a session itself', async () => {
    // If it did, the layout would swap to the app immediately and the
    // replacement code would be minted, hashed and lost in the same request —
    // a list of ten with one known to nobody. It happened; this pins it.
    const codes = await withLogin()
    await resetPasswordWithCode(codes[0], 'the-new-one-entirely')
    expect(await prisma.appSession.count()).toBe(0)
  })

  it('refuses a code that was never issued', async () => {
    await withLogin()
    const result = await resetPasswordWithCode('AAAA-BBBB', 'a-brand-new-password')
    expect(result.ok).toBe(false)
  })

  it('refuses a too-short new password without consuming the code', async () => {
    const codes = await withLogin()
    expect((await resetPasswordWithCode(codes[0], 'short')).ok).toBe(false)
    // The code must still work afterwards, or a typo in the password box
    // would silently burn one of ten ways back in.
    expect((await resetPasswordWithCode(codes[0], 'a-proper-password')).ok).toBe(true)
  })

  it('issues a completely fresh set on request, killing the old ones', async () => {
    const codes = await withLogin()
    const fresh = await regenerateRecoveryCodes(PASSWORD)
    expect(fresh.ok).toBe(true)
    if (!fresh.ok) return
    expect(fresh.data.codes).toHaveLength(10)
    expect(await countRecoveryCodes()).toBe(10)

    // Every old code is dead — that is the point of regenerating.
    expect((await resetPasswordWithCode(codes[0], 'a-brand-new-password')).ok).toBe(false)
    expect((await resetPasswordWithCode(fresh.data.codes[0], 'a-brand-new-password')).ok).toBe(true)
  })

  it('will not regenerate without the password', async () => {
    // This destroys the list Wrenz is holding. Someone wandering up to an
    // unlocked counter must not be able to do it.
    await withLogin()
    expect((await regenerateRecoveryCodes('wrong-password')).ok).toBe(false)
    expect(await countRecoveryCodes()).toBe(10)
  })
})

describe('changing the password while signed in', () => {
  it('needs the current one', async () => {
    await withLogin()
    expect((await changePassword('wrong-one', 'a-brand-new-password')).ok).toBe(false)

    const user = await prisma.appUser.findFirstOrThrow()
    expect(verifyPassword(PASSWORD, user.passwordHash)).toBe(true)
  })

  it('changes it when the current one is right', async () => {
    await withLogin()
    expect((await changePassword(PASSWORD, 'a-brand-new-password')).ok).toBe(true)

    const user = await prisma.appUser.findFirstOrThrow()
    expect(verifyPassword('a-brand-new-password', user.passwordHash)).toBe(true)
  })

  it('refuses a new password that is too short', async () => {
    await withLogin()
    expect((await changePassword(PASSWORD, 'short')).ok).toBe(false)
  })
})

describe('confirming a dangerous action', () => {
  it('accepts the password and does not extend the session', async () => {
    await withLogin()
    const before = await prisma.appSession.count()
    expect((await confirmPassword(PASSWORD)).ok).toBe(true)
    expect(await prisma.appSession.count()).toBe(before)
  })

  it('refuses the wrong password', async () => {
    await withLogin()
    expect((await confirmPassword('nope-not-this')).ok).toBe(false)
  })

  it('is a no-op when the shop has no login', async () => {
    // Every guarded action calls this. If it refused on a shop with no login,
    // turning the feature off would break voiding a sale.
    expect((await confirmPassword('')).ok).toBe(true)
  })
})

describe('the stored user', () => {
  it('keeps a hash that verifies only its own password', async () => {
    const hash = hashPassword(PASSWORD)
    expect(verifyPassword(PASSWORD, hash)).toBe(true)
    expect(verifyPassword(PASSWORD + ' ', hash)).toBe(false)
  })

  it('hashes recovery codes case- and dash-insensitively', async () => {
    expect(hashRecoveryCode('7QK2-4M91')).toBe(hashRecoveryCode('7qk2 4m91'))
    expect(generateRecoveryCodes(3)).toHaveLength(3)
  })
})

describe('the confirmation window on dangerous actions', () => {
  it('is wide open when the shop has no login', async () => {
    // Every guarded action calls this. If it gated on an open shop, turning
    // the feature off would break voiding a sale.
    expect(await confirmationGate()).toBeNull()
  })

  it('asks the first time, even though she just signed in', async () => {
    // Signing in proves she opened the laptop. Voiding a sale is a different
    // question, asked at a different moment.
    await withLogin()
    expect(await confirmationGate()).not.toBeNull()
  })

  it('lets the next few minutes through once confirmed', async () => {
    await withLogin()
    expect((await confirmPassword(PASSWORD)).ok).toBe(true)
    expect(await confirmationGate()).toBeNull()
  })

  it('does not open on a wrong password', async () => {
    await withLogin()
    expect((await confirmPassword('not-the-password')).ok).toBe(false)
    expect(await confirmationGate()).not.toBeNull()
  })

  it('closes again once the window has passed', async () => {
    await withLogin()
    await confirmPassword(PASSWORD)
    expect(await confirmationGate()).toBeNull()

    // Wind the stamp back past the window rather than waiting five minutes.
    await prisma.appSession.updateMany({
      data: { confirmedAt: new Date(Date.now() - (CONFIRMATION_MINUTES + 1) * 60 * 1000) },
    })
    expect(await confirmationGate()).not.toBeNull()
  })

  it('returns the sentinel the screens listen for, not prose', async () => {
    await withLogin()
    const gate = await confirmationGate()
    expect(gate?.error).toBe(NEEDS_PASSWORD)
    expect(needsPassword({ ok: false, error: NEEDS_PASSWORD })).toBe(true)
    expect(needsPassword({ ok: false, error: 'Something else' })).toBe(false)
    expect(needsPassword({ ok: true })).toBe(false)
  })
})
