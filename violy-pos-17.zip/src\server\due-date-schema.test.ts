import { beforeEach, describe, expect, it } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'

beforeEach(resetDb)

describe('customer due-date schema', () => {
  it('defaults a customer to no due date', async () => {
    const customer = await prisma.customer.create({ data: { name: 'ROMAN' } })

    expect(customer.dueAt).toBeNull()
  })

  it('stores a date without changing the customer account', async () => {
    const dueAt = new Date(2026, 8, 2)
    const customer = await prisma.customer.create({ data: { name: 'NENA', dueAt } })

    expect(customer.dueAt).toEqual(dueAt)
  })
})
