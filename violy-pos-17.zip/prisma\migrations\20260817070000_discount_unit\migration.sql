-- Which unit a PER_UNIT customer discount applies to.
--
-- Empty string, not NULL, and NOT NULL with a default so every existing
-- customer keeps the behaviour they were priced under: a discount with no unit
-- named covers every unit, exactly as it did before this column existed.
--
-- Written by hand and applied with `migrate deploy`. `migrate dev` is never
-- run against this database: it can decide the schema has drifted and offer to
-- RESET, which here means deleting the ledger.
ALTER TABLE "Customer" ADD COLUMN "discountUnit" TEXT NOT NULL DEFAULT '';
