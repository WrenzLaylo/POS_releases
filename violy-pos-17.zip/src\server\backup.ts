'use server'

import type { ActionResult } from '@/lib/types'
import {
  createBackup,
  getBackupStatus as readBackupStatus,
  type BackupStatus,
} from '@/lib/backup-run'

/**
 * The backup button, and what it reports.
 *
 * Neither of these revalidates anything, and that is not an oversight: a backup
 * reads the database and writes a file outside it, so no page in the app is
 * showing anything a backup could have made stale. The panel updates from what
 * the action returns.
 */

export async function backupStatus(): Promise<BackupStatus> {
  return readBackupStatus()
}

export async function backupNow(): Promise<ActionResult<BackupStatus>> {
  try {
    await createBackup()
  } catch {
    // The realistic causes are a missing database file and a full or read-only
    // disk. None of them are worth a stack trace at somebody who pressed a
    // button, and all of them mean the same thing to her.
    return {
      ok: false,
      error: 'Could not save a backup. Check there is space on the computer, then try again.',
    }
  }

  return { ok: true, data: await readBackupStatus() }
}
