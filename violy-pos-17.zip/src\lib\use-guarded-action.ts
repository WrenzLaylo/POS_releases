'use client'

import { useCallback, useRef, useState } from 'react'
import { needsPassword } from '@/lib/auth-gate'

/** Loose on purpose: this wrapper does not care what an action returns, only
 *  whether it succeeded and whether it is asking for the password. `data`
 *  is carried through so call sites can still read their own result. */
type Result = { ok: boolean; error?: string; data?: unknown }

/**
 * Runs an action that may ask for the password, and retries it once confirmed.
 *
 * The alternative was threading a password argument through six Server Actions
 * and six screens. This keeps the call sites almost unchanged: they hand over
 * a function, and if the server says it needs proof, the prompt appears and the
 * SAME function is re-run afterwards — the action is not rewritten, it is
 * simply called twice, the second time with a fresh confirmation on the
 * session.
 *
 * The pending action is held in a ref rather than state because it must
 * survive the prompt's own renders unchanged; re-creating it would mean
 * retrying a stale closure over the wrong row.
 */
export function useGuardedAction() {
  const [asking, setAsking] = useState(false)
  const pending = useRef<(() => Promise<Result>) | null>(null)
  const onDone = useRef<((result: Result) => void) | null>(null)

  /**
   * @param run    the action, which may return the NEEDS_PASSWORD sentinel
   * @param handle what to do with the real result, once there is one
   */
  const guard = useCallback(async (run: () => Promise<Result>, handle: (result: Result) => void) => {
    const result = await run()
    if (needsPassword(result)) {
      pending.current = run
      onDone.current = handle
      setAsking(true)
      return
    }
    handle(result)
  }, [])

  const confirmed = useCallback(async () => {
    setAsking(false)
    const run = pending.current
    const handle = onDone.current
    pending.current = null
    onDone.current = null
    if (!run || !handle) return
    // Re-run rather than assume success: the confirmation only unlocks the
    // gate, and the action can still fail on its own terms.
    handle(await run())
  }, [])

  const cancel = useCallback(() => {
    setAsking(false)
    pending.current = null
    onDone.current = null
  }, [])

  return { asking, guard, confirmed, cancel }
}
