export type IconName =
  | 'orders'
  | 'customers'
  | 'inventory'
  | 'dashboard'
  | 'history'
  | 'chevron'
  | 'hamburger'
  | 'bell'
  | 'menu'
  | 'receipt'
  | 'package'
  | 'chart'
  | 'search'
  | 'filter'
  | 'chevron-down'
  | 'close'
  | 'more-horizontal'
  | 'more'
  | 'plus'
  | 'minus'
  | 'arrow-right'
  | 'alert'
  | 'stock'
  | 'calendar'
  | 'command'
  | 'rail-collapse'
  | 'rail-expand'
  | 'tag'
  | 'settings'
  | 'sort-asc'
  | 'sort-desc'
  | 'check'
  | 'eye'
  | 'eye-off'

const RECEIPT = 'M6 3h12v18l-3-2-3 2-3-2-3 2V3ZM9 8h6M9 12h6M9 16h3'

/** Reveal / hide a password. The struck-through variant carries the same
 *  outline plus the slash, so the two read as one control changing state
 *  rather than as two unrelated marks. */
const EYE = 'M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z'
const EYE_OFF =
  'M2 12s3.5-7 10-7c1.6 0 3 .4 4.3 1M22 12s-3.5 7-10 7c-1.6 0-3-.4-4.3-1 ' +
  'M9.9 9.9a3 3 0 0 0 4.2 4.2 M3 3l18 18'
const PACKAGE = 'M4 7h16v13H4zM9 7V4h6v3'
const CHART = 'M4 20V10M10 20V4M16 20v-7M22 20H2'
const MORE_HORIZONTAL = 'M5 12h.01M12 12h.01M19 12h.01'

const PATHS: Record<IconName, string> = {
  orders: RECEIPT,
  customers: 'M16 19a4 4 0 0 0-8 0M12 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z',
  inventory: PACKAGE,
  dashboard: CHART,
  history: 'M12 8v4l3 2M4 12a8 8 0 1 0 8-8',
  chevron: 'm9 6 6 6-6 6',
  hamburger: 'M4 6h16M4 12h16M4 18h16',
  bell: 'M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4',
  menu: 'M4 4h16v16H4zM9 4v16m7-5-3-3 3-3',
  receipt: RECEIPT,
  package: PACKAGE,
  chart: CHART,
  search: 'm21 21-4.35-4.35M19 11a8 8 0 1 1-16 0 8 8 0 0 1 16 0Z',
  filter: 'M4 5h16l-6 7v5l-4 2v-7Z',
  'chevron-down': 'm6 9 6 6 6-6',
  close: 'M6 6l12 12M18 6 6 18',
  'more-horizontal': MORE_HORIZONTAL,
  more: MORE_HORIZONTAL,
  plus: 'M12 5v14M5 12h14',
  minus: 'M5 12h14',
  'arrow-right': 'M5 12h14m-6-6 6 6-6 6',
  alert: 'M12 3 2.5 20h19ZM12 9v5m0 4h.01',
  stock: 'M4 7h16v13H4zM9 7V4h6v3M12 11v4m0 2h.01',
  calendar: 'M5 4h14a2 2 0 0 1 2 2v14H3V6a2 2 0 0 1 2-2ZM8 2v4m8-4v4M3 9h18',
  command: 'M9 3a3 3 0 1 0 0 6h6a3 3 0 1 0 0-6M9 21a3 3 0 1 1 0-6h6a3 3 0 1 1 0 6M9 9h6v6H9z',
  'rail-collapse': 'M15 6l-6 6 6 6M4 4v16',
  'rail-expand': 'M9 6l6 6-6 6M20 4v16',
  tag: 'M3 3h8l10 10-8 8L3 11zM7.5 7.5h.01',
  // A gear: a circle for the hub and eight spokes. Drawn as strokes like
  // every other glyph here rather than a filled cog, so it sits at the same
  // visual weight as the bell beside it.
  settings:
    'M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6M12 2v3m0 14v3M2 12h3m14 0h3M4.9 4.9l2.2 2.2m9.8 9.8 2.2 2.2M19.1 4.9l-2.2 2.2M7.1 16.9l-2.2 2.2',
  // Arrows, not carets: they say which way the column is ordered rather than
  // merely that something is expandable.
  'sort-asc': 'M12 19V5m0 0-6 6m6-6 6 6',
  'sort-desc': 'M12 5v14m0 0 6-6m-6 6-6-6',
  check: 'M20 6 9 17l-5-5',
  eye: EYE,
  'eye-off': EYE_OFF,
}

type IconProps = {
  name: IconName
  className?: string
  size?: number | string
}

export function Icon({ name, className, size }: IconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
      className={className}
    >
      <path d={PATHS[name]} />
    </svg>
  )
}
