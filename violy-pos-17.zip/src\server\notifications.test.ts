import { beforeEach, describe, expect, it } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'
import { getNotifications } from '@/server/notifications'
import { createPlan, voidPlan } from '@/server/utang'
import { recordPayment } from '@/server/ledger'

beforeEach(resetDb)

async function addBalance(
  name: string,
  amountCentavos: number,
  dueAt: Date | null,
  isArchived = false,
) {
  return prisma.customer.create({
    data: {
      name,
      dueAt,
      isArchived,
      entries: {
        create: {
          type: 'CHARGE',
          amountCentavos,
          occurredAt: new Date(2026, 6, 1),
        },
      },
    },
  })
}

async function makeProduct(name: string, stockQty: number, lowStockThreshold: number, isArchived = false) {
  const category = await prisma.category.upsert({
    where: { name: 'Feeds' },
    create: { name: 'Feeds' },
    update: {},
  })
  return prisma.product.create({
    data: {
      categoryId: category.id,
      name,
      unit: 'sako',
      price: 100,
      costPrice: 90,
      stockQty,
      lowStockThreshold,
      isArchived,
    },
  })
}

describe('getNotifications', () => {
  it('alerts only positive balances whose due day has fully passed', async () => {
    await addBalance('YESTERDAY', 50000, new Date(2026, 7, 2))
    await addBalance('TODAY', 40000, new Date(2026, 7, 3))
    await addBalance('FUTURE', 30000, new Date(2026, 7, 4))
    const settled = await addBalance('SETTLED', 20000, new Date(2026, 7, 1))
    await prisma.ledgerEntry.create({
      data: {
        customerId: settled.id,
        type: 'PAYMENT',
        amountCentavos: 20000,
        occurredAt: new Date(2026, 7, 2),
      },
    })

    const result = await getNotifications(new Date(2026, 7, 3, 18))

    expect(result.overdueAccounts.map((row) => row.name)).toEqual(['YESTERDAY'])
    expect(result.overdueAccounts[0].balanceCentavos).toBe(50000)
  })

  it('separates due-today from overdue, and puts each customer in exactly one', async () => {
    await addBalance('LATE', 50_000, new Date(2026, 7, 1))
    await addBalance('TODAY', 40_000, new Date(2026, 7, 3))
    await addBalance('TOMORROW', 30_000, new Date(2026, 7, 4))

    const result = await getNotifications(new Date(2026, 7, 3, 14))

    expect(result.overdueAccounts.map((row) => row.name)).toEqual(['LATE'])
    expect(result.dueToday.map((row) => row.name)).toEqual(['TODAY'])
    // Counted once each, never in both lists.
    expect(result.total).toBe(2)
  })

  it('treats due-today as due all day, not from midnight onward', async () => {
    // The deadline is a DAY, not an instant. Comparing raw timestamps would
    // push a customer into "overdue" the moment the clock passed the stored
    // midnight — so an account due today reads as late by 9am.
    await addBalance('TODAY', 40_000, new Date(2026, 7, 3))

    const result = await getNotifications(new Date(2026, 7, 3, 23, 59))

    expect(result.dueToday.map((row) => row.name)).toEqual(['TODAY'])
    expect(result.overdueAccounts).toEqual([])
  })

  it('keeps archived debt visible and sorts oldest deadline first', async () => {
    await addBalance('LATER', 10000, new Date(2026, 6, 20))
    await addBalance('ARCHIVED', 20000, new Date(2026, 6, 10), true)

    const result = await getNotifications(new Date(2026, 7, 3))

    expect(result.overdueAccounts.map((row) => row.name)).toEqual(['ARCHIVED', 'LATER'])
  })

  it('includes live products at or below threshold, excludes archived, and reports the total', async () => {
    await makeProduct('OUT', 0, 2)
    await makeProduct('AT LIMIT', 5, 5)
    await makeProduct('HEALTHY', 6, 5)
    await makeProduct('ARCHIVED LOW', -2, 5, true)
    await addBalance('OVERDUE', 50000, new Date(2026, 7, 1))

    const result = await getNotifications(new Date(2026, 7, 3))

    expect(result.lowStock.map((row) => row.name)).toEqual(['OUT', 'AT LIMIT'])
    expect(result.total).toBe(3)
  })
})

describe('getNotifications, missed instalments', () => {
  /** ₱3,000 over 3 months at 5% flat: ₱1,150 due on the 15th of Feb/Mar/Apr. */
  async function planFor(name: string, paidCentavos = 0) {
    const result = await createPlan({
      customerId: (await prisma.customer.create({ data: { name } })).id,
      principalCentavos: 300_000,
      interestMethod: 'FLAT_MONTHLY',
      interestRateBps: 500,
      termMonths: 3,
      startedAt: new Date(2026, 0, 15),
    })
    if (!result.ok) throw new Error(result.error)

    const plan = await prisma.utangPlan.findUniqueOrThrow({ where: { id: result.data.planId } })
    if (paidCentavos > 0) {
      await recordPayment({
        customerId: plan.customerId,
        amountCentavos: paidCentavos,
        occurredAt: new Date(2026, 1, 16),
        planId: plan.id,
      })
    }
    return plan
  }

  it('reports one row per plan, naming how many months are behind', async () => {
    await planFor('BEHIND')

    // 20 March: February and March have both come and gone unpaid.
    const result = await getNotifications(new Date(2026, 2, 20))

    expect(result.overdueInstallments).toHaveLength(1)
    expect(result.overdueInstallments[0].name).toBe('BEHIND')
    expect(result.overdueInstallments[0].count).toBe(2)
    expect(result.overdueInstallments[0].amountCentavos).toBe(230_000)
    expect(result.overdueInstallments[0].oldestDueAt.getMonth()).toBe(1) // February
  })

  it('nets off what has been part-paid into an overdue month', async () => {
    // ₱1,500 settles February's ₱1,150 and leaves ₱350 against March's.
    await planFor('PART PAID', 150_000)

    const result = await getNotifications(new Date(2026, 2, 20))

    expect(result.overdueInstallments[0].count).toBe(1)
    // ₱1,150 − ₱350 still outstanding on March, not the full ₱1,150.
    expect(result.overdueInstallments[0].amountCentavos).toBe(80_000)
  })

  it('says nothing before the first due date', async () => {
    await planFor('NOT YET')
    const result = await getNotifications(new Date(2026, 0, 20))
    expect(result.overdueInstallments).toEqual([])
  })

  it('drops a plan that has been paid off, and one that has been voided', async () => {
    await planFor('PAID OFF', 345_000)
    const voided = await planFor('VOIDED')
    await voidPlan(voided.id)

    const result = await getNotifications(new Date(2026, 5, 1))
    expect(result.overdueInstallments).toEqual([])
  })

  it('counts alongside the other groups rather than replacing them', async () => {
    await planFor('BEHIND')
    await addBalance('STALE BALANCE', 50_000, new Date(2026, 1, 1))
    await makeProduct('OUT', 0, 2)

    const result = await getNotifications(new Date(2026, 2, 20))

    // Three separate problems, three separate rows, counted once each.
    // BEHIND appears ONLY under missed instalments: creating a plan also sets
    // the account deadline, so without the plan-outstanding deduction the same
    // debt would be reported in both groups and counted twice in the badge.
    expect(result.overdueInstallments.map((row) => row.name)).toEqual(['BEHIND'])
    expect(result.overdueAccounts.map((row) => row.name)).toEqual(['STALE BALANCE'])
    expect(result.lowStock.map((row) => row.name)).toEqual(['OUT'])
    expect(result.total).toBe(3)
  })

  it('still reports the part of a balance that belongs to no plan', async () => {
    const plan = await planFor('MIXED')
    // A ₱500 charge on top of the ₱3,450 plan — a walk-up utang with no terms.
    await prisma.ledgerEntry.create({
      data: {
        customerId: plan.customerId,
        type: 'CHARGE',
        amountCentavos: 50_000,
        occurredAt: new Date(2026, 0, 20),
      },
    })

    const result = await getNotifications(new Date(2026, 2, 20))

    // Both groups fire, but each reports only its own money.
    expect(result.overdueInstallments.map((row) => row.amountCentavos)).toEqual([230_000])
    expect(result.overdueAccounts.map((row) => row.balanceCentavos)).toEqual([50_000])
    expect(result.total).toBe(2)
  })

  it('sorts the oldest miss first', async () => {
    await planFor('NEWER')
    const older = await prisma.customer.create({ data: { name: 'OLDER' } })
    const result = await createPlan({
      customerId: older.id,
      principalCentavos: 100_000,
      interestMethod: 'FLAT_ONCE',
      interestRateBps: 0,
      termMonths: 1,
      startedAt: new Date(2025, 10, 15),
    })
    if (!result.ok) throw new Error(result.error)

    const notifications = await getNotifications(new Date(2026, 2, 20))
    expect(notifications.overdueInstallments.map((row) => row.name)).toEqual(['OLDER', 'NEWER'])
  })
})
