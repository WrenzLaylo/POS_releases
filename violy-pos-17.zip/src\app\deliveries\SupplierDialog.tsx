'use client'

import { useState, useTransition } from 'react'
import { recordSupplierOpeningBalance } from '@/server/supplier-opening'
import { parsePesoInput } from '@/lib/money'
import { occurredAtForDay } from '@/lib/dates'
import { DatePicker } from '@/components/ui/DatePicker'
import { useRouter } from 'next/navigation'
import {
  archiveSupplier,
  createSupplier,
  restoreSupplier,
  updateSupplier,
} from '@/server/suppliers'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Dialog } from '@/components/ui/Dialog'
import { Field } from '@/components/ui/Field'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'
import type { SupplierOption } from './DeliveriesScreen'

/**
 * Who the shop buys from.
 *
 * One dialog for the whole list rather than a screen of its own: suppliers are
 * a handful of names touched a few times a year, and a fifth item in the rail
 * for that would cost more attention than it returns.
 */
export function SupplierDialog({
  suppliers,
  onClose,
  withOpeningBalance,
  todayKey,
}: {
  suppliers: SupplierOption[]
  onClose: () => void
  /** Supplier ids that already carry a previous debt. */
  withOpeningBalance: number[]
  /** Computed on the server, so the two render passes cannot disagree. */
  todayKey: string
}) {
  const router = useRouter()
  const [pending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)

  const [name, setName] = useState('')
  const [contactNumber, setContactNumber] = useState('')
  const [editingId, setEditingId] = useState<number | null>(null)

  /** Which supplier is having a previous debt entered, and what was typed. */
  const [owingId, setOwingId] = useState<number | null>(null)
  const [owedAmount, setOwedAmount] = useState('')
  const [owedDate, setOwedDate] = useState(todayKey)
  const carried = new Set(withOpeningBalance)

  /**
   * Records what was already owed before the app existed.
   *
   * It becomes a delivery with no lines, so it flows through payables and
   * `payDelivery` like any other debt rather than needing a second ledger.
   */
  function saveOwed(supplierId: number) {
    setError(null)
    const centavos = parsePesoInput(owedAmount)
    if (centavos === null || centavos <= 0) {
      setError('Enter what was owed, like 45,000')
      return
    }
    startTransition(async () => {
      const result = await recordSupplierOpeningBalance(
        supplierId,
        centavos,
        occurredAtForDay(owedDate) ?? new Date(),
      )
      if (!result.ok) {
        setError(result.error)
        return
      }
      setOwingId(null)
      setOwedAmount('')
      router.refresh()
    })
  }

  function reset() {
    setName('')
    setContactNumber('')
    setEditingId(null)
  }

  function save() {
    setError(null)
    startTransition(async () => {
      const result =
        editingId === null
          ? await createSupplier({ name, contactNumber })
          : await updateSupplier(editingId, { name, contactNumber })
      if (!result.ok) {
        setError(result.error)
        return
      }
      reset()
      router.refresh()
    })
  }

  function run(action: () => Promise<{ ok: boolean; error?: string }>) {
    setError(null)
    startTransition(async () => {
      const result = await action()
      if (!result.ok) {
        setError(result.error ?? 'That did not work.')
        return
      }
      router.refresh()
    })
  }

  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title="Suppliers"
      description="Who the shop buys from. Deliveries are recorded against these names."
      footer={
        <div className="flex justify-end">
          <Button variant="secondary" onClick={onClose}>
            Done
          </Button>
        </div>
      }
    >
      <div className="grid gap-4">
        <div className="flex flex-wrap items-end gap-2">
          <Field label={editingId === null ? 'New supplier' : 'Rename supplier'}>
            <Input
              value={name}
              onChange={(event) => setName(event.target.value)}
              placeholder="e.g. Bataan Farmers Center"
              className="w-56"
            />
          </Field>
          <Field label="Contact (optional)">
            <Input
              value={contactNumber}
              onChange={(event) => setContactNumber(event.target.value)}
              placeholder="09XX XXX XXXX"
              className="w-40"
            />
          </Field>
          <Button variant="primary" onClick={save} disabled={pending || name.trim() === ''}>
            {editingId === null ? 'Add' : 'Save'}
          </Button>
          {editingId !== null && (
            <Button variant="ghost" onClick={reset} disabled={pending}>
              Cancel
            </Button>
          )}
        </div>

        {error && <FormError>{error}</FormError>}

        {suppliers.length === 0 ? (
          <p className="rounded-control bg-surface-sunk px-3 py-4 text-sm text-ink-muted">
            No suppliers yet.
          </p>
        ) : (
          <ul className="divide-y divide-line rounded-control border border-line">
            {suppliers.map((supplier) => (
              <li key={supplier.id} className="flex items-center justify-between gap-3 px-3 py-2">
                <span className="min-w-0">
                  <span className="block truncate text-sm font-medium text-ink">
                    {supplier.name}
                    {supplier.isArchived && (
                      <span className="ml-2 align-middle">
                        <Badge tone="muted">Archived</Badge>
                      </span>
                    )}
                  </span>
                  {supplier.contactNumber && (
                    <span className="block text-xs text-ink-subtle">{supplier.contactNumber}</span>
                  )}
                  {carried.has(supplier.id) && (
                    <span className="block text-xs text-ink-subtle">
                      Previous debt already recorded
                    </span>
                  )}
                  {owingId === supplier.id && (
                    <span className="mt-2 flex flex-wrap items-end gap-2">
                      <Field label="Already owed">
                        <Input
                          inputMode="decimal"
                          value={owedAmount}
                          onChange={(event) => setOwedAmount(event.target.value)}
                          placeholder="0.00"
                          className="w-32 tabular-nums"
                          autoFocus
                        />
                      </Field>
                      <Field label="As of">
                        <DatePicker value={owedDate} onChange={setOwedDate} className="w-40" />
                      </Field>
                      <Button
                        variant="success"
                        size="sm"
                        disabled={pending}
                        onClick={() => saveOwed(supplier.id)}
                      >
                        Save
                      </Button>
                      <Button variant="ghost" size="sm" disabled={pending} onClick={() => setOwingId(null)}>
                        Cancel
                      </Button>
                    </span>
                  )}
                </span>

                <span className="flex shrink-0 items-center gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    disabled={pending}
                    onClick={() => {
                      setEditingId(supplier.id)
                      setName(supplier.name)
                      setContactNumber(supplier.contactNumber)
                    }}
                  >
                    Edit
                  </Button>
                  {/* Only once, and only while the supplier is live. A second
                      carry-over would quietly double what payables reports. */}
                  {!supplier.isArchived && !carried.has(supplier.id) && owingId !== supplier.id && (
                    <Button
                      variant="ghost"
                      size="sm"
                      disabled={pending}
                      onClick={() => {
                        setError(null)
                        setOwedAmount('')
                        setOwedDate(todayKey)
                        setOwingId(supplier.id)
                      }}
                    >
                      Previous debt
                    </Button>
                  )}
                  {supplier.isArchived ? (
                    <Button
                      variant="ghost"
                      size="sm"
                      disabled={pending}
                      onClick={() => run(() => restoreSupplier(supplier.id))}
                    >
                      Restore
                    </Button>
                  ) : (
                    // Refused by the server while anything is still owed, so
                    // a debt cannot vanish because somebody tidied up.
                    <Button
                      variant="danger"
                      size="sm"
                      disabled={pending}
                      onClick={() => run(() => archiveSupplier(supplier.id))}
                    >
                      Archive
                    </Button>
                  )}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </Dialog>
  )
}
