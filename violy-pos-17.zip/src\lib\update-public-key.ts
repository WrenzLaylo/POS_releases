/**
 * The public half of the release signing key.
 *
 * It lives HERE, in `src/`, and not in `release-channel.json` or anything else
 * fetched at runtime — that is the whole point. A key downloaded from the same
 * place as the manifest protects against nothing, because whoever replaced the
 * manifest replaces the key beside it. This one arrives inside the build the
 * shop is already running, so it can only be changed by an update that the
 * previous key already vouched for.
 *
 * Its private half never leaves the developer's machine and is never committed
 * (`.release-signing-key.pem`, gitignored). See `docs/RELEASE-SIGNING.md`.
 *
 * Replacing this value orphans every laptop running an older build: they will
 * keep checking against the key they shipped with and reject everything signed
 * with the new one.
 */
export const UPDATE_PUBLIC_KEY = `
-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEA3EcDvvshdbs0HKFOl4c/Bc2GeCa342z79ZX1KS/a/rQ=
-----END PUBLIC KEY-----
`
