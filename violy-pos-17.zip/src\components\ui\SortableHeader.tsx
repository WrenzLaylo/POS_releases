'use client'

import { Icon } from '@/components/ui/Icon'
import { cn } from '@/lib/cn'
import type { SortDirection } from '@/lib/sorting'

/**
 * A clickable column heading.
 *
 * `aria-sort` on the `<th>` is what actually tells assistive technology the
 * table is sorted and which way — the arrow is only the visual half of that,
 * and a table that shows an arrow without setting `aria-sort` is sorted for
 * sighted users alone.
 *
 * The arrow renders only on the active column. Showing a faint one on every
 * heading is a common habit that ends up making the real one hard to find.
 */
export function SortableHeader({
  label,
  active,
  direction,
  onSort,
  align = 'start',
  className,
}: {
  label: string
  active: boolean
  direction: SortDirection
  onSort: () => void
  align?: 'start' | 'end'
  className?: string
}) {
  return (
    <th
      scope="col"
      aria-sort={active ? (direction === 'asc' ? 'ascending' : 'descending') : 'none'}
      className={cn('px-4 py-3 font-medium', align === 'end' && 'text-right', className)}
    >
      <button
        type="button"
        onClick={onSort}
        className={cn(
          'inline-flex items-center gap-1 rounded-control text-xs uppercase tracking-wide transition-colors duration-150',
          'hover:text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent',
          active ? 'font-semibold text-ink' : 'text-ink-muted',
          align === 'end' && 'flex-row-reverse',
        )}
      >
        {label}
        {active && (
          <Icon
            name={direction === 'asc' ? 'sort-asc' : 'sort-desc'}
            className="h-3.5 w-3.5 shrink-0"
          />
        )}
      </button>
    </th>
  )
}
