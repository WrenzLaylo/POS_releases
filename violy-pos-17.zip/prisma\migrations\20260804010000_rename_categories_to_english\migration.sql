-- Rename the two Tagalog category names to English.
--
-- The README states the UI reads in English, and a Tagalog toggle is
-- separate, future work. These two category names were the last Tagalog
-- strings the operator actually sees on screen — every other Tagalog word
-- in the catalog is a unit ("sako", "bote", "piraso", "metro") where the
-- Tagalog IS the correct term for what is being counted, so those stay.
--
-- This is a data migration, not a schema one, for the same reason
-- 20260729041234_backfill_category_sort_order was: the app has no UI and no
-- server action for renaming a category, so on the no-reseed path (a real
-- store with real sales, where `npm run seed` would destroy data) there is
-- no other way for the existing rows to pick up the new names. Editing
-- prisma/seed.ts alone only affects a fresh database.
--
-- Matched on the exact old names, so it is a no-op on a database that was
-- seeded after this change or never held these categories. Products are
-- untouched — they reference their category by id, not by name.
UPDATE "Category" SET "name" = 'Medicine and Vitamins' WHERE "name" = 'Gamot at Bitamina';
UPDATE "Category" SET "name" = 'Equipment' WHERE "name" = 'Kagamitan';
