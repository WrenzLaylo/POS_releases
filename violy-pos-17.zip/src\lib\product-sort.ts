/**
 * Which columns the stock table may be ordered by.
 *
 * In its own module rather than beside `listAllProducts`, because
 * `src/server/products.ts` carries `'use server'` and such a file may export
 * ONLY async functions. A `const` array there builds fine and then fails at
 * page-data collection with "a 'use server' file can only export async
 * functions, found object" — a message that names the rule but not the export
 * that broke it.
 */
export const PRODUCT_SORT_KEYS = ['name', 'category', 'price', 'cost', 'stock'] as const

export type ProductSortKey = (typeof PRODUCT_SORT_KEYS)[number]
