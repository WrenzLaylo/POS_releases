import Link from 'next/link'
import { notFound } from 'next/navigation'
import { getSaleReceipt } from '@/server/sales'
import { getStoreProfile } from '@/server/store-profile'
import { lineTotal } from '@/lib/money'
import { documentNumber, DOCUMENT_TITLES } from '@/lib/document-number'
import { ROUTES } from '@/lib/routes'
import { Money } from '@/components/ui/Money'
import { PageHeader } from '@/components/ui/PageHeader'
import { DocumentShell } from '@/components/DocumentShell'
import { DocumentFacts, DocumentFooter, DocumentHeading } from '@/components/DocumentHeading'
import { SaleTabs } from '../SaleTabs'

export const dynamic = 'force-dynamic'

/**
 * The paper that travels with the load, and the copy that comes back signed.
 *
 * Built from the SALE, because a delivery order is a sale that knows where it
 * is going — there is no separate delivery record to read. A sale with no
 * `deliverAt` is an ordinary counter sale and has no note to print, so it
 * 404s rather than rendering a document with the delivery lines blank.
 *
 * Not to be confused with `/deliveries/[id]`, which is the Delivery RECEIPT: a
 * supplier's consignment arriving. Same word, opposite direction, different
 * reference prefix (DN here, DR there) so a filed pile of them stays readable.
 *
 * Prices are on it deliberately. The sale is real at the moment it is saved,
 * so this is the paper that says what the load is worth and what is owed for
 * it — a picking list with no money on it would send the driver out with
 * nothing the customer can check or sign against.
 */
export default async function DeliveryNotePage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const saleId = Number(id)
  if (!Number.isInteger(saleId) || saleId <= 0) notFound()

  const sale = await getSaleReceipt(saleId)
  if (!sale) notFound()
  // The flag, and the reason this route can be reached only from a delivery
  // order: nothing was delivered, so there is no note.
  if (!sale.deliverAt) notFound()

  const profile = await getStoreProfile()

  // The document's own date, not today's and not the sale's: reprinting last
  // year's note must not renumber it into this year.
  const reference = documentNumber('DELIVERY_NOTE', sale.id, sale.deliverAt)

  const goodsCentavos = sale.totalAmount - sale.deliveryFeeCentavos
  const subtotalCentavos = sale.items.reduce(
    (total, item) => total + lineTotal(item.priceAtSale, item.quantity),
    0,
  )
  // Against the GOODS, never against `totalAmount` — the fee is part of the
  // total and would otherwise read as that much less discount.
  const discountCentavos = subtotalCentavos - goodsCentavos
  const liveCharge = sale.ledgerEntry !== null && !sale.ledgerEntry.isVoided
  const chargedCentavos = Math.max(0, sale.totalAmount - sale.cashPaidCentavos)

  return (
    <PageHeader
      title={`Delivery ${reference}`}
      hideOnPrint
      actions={
        <Link href={ROUTES.history} className="text-sm font-medium text-ink-muted hover:text-ink">
          ← Back to history
        </Link>
      }
    >
      <div data-print="hide">
        <SaleTabs saleId={sale.id} active="delivery-note" hasDeliveryNote />
      </div>

      <DocumentShell
        fileName={`${reference} ${sale.customer?.name ?? 'Delivery'}`}
        actions={
          <Link
            href={ROUTES.counter}
            className="inline-flex h-10 items-center justify-center rounded-control border border-line-strong bg-surface-raised px-4 text-sm font-medium text-ink hover:border-accent hover:bg-accent-soft"
          >
            Back to the counter
          </Link>
        }
      >
        <DocumentHeading
          profile={profile}
          title={DOCUMENT_TITLES.DELIVERY_NOTE}
          reference={reference}
          issuedAt={sale.deliverAt}
          // A day, not a moment. Nobody typed a delivery time, so printing
          // the midnight `Date` supplies would invent one.
          dateOnly
        />

        <DocumentFacts
          items={[
            {
              label: 'Deliver to',
              value: (
                <>
                  {sale.customer?.name ?? 'Customer'}
                  {sale.customer?.phone && (
                    <div className="font-normal text-ink-muted">{sale.customer.phone}</div>
                  )}
                  {sale.deliverAddress && (
                    <div className="mt-1 whitespace-pre-line font-normal text-ink-muted">
                      {sale.deliverAddress}
                    </div>
                  )}
                </>
              ),
            },
            {
              label: 'Destination',
              value: (
                <>
                  {sale.deliverTo}
                  {/* The date beside the title is the DELIVERY date. This one
                      is when the order was taken, which is a different fact
                      and the one that settles an argument about how long a
                      load sat before it went out. */}
                  <div className="font-normal text-ink-muted">
                    Ordered {sale.createdAt.toLocaleDateString('en-PH', { dateStyle: 'medium' })}
                  </div>
                </>
              ),
              align: 'end',
            },
          ]}
        />

        {/* `doc-table` plus a `data-label` per cell is what lets this become a
            stacked list on the 80mm roll instead of a table too wide to fit. */}
        <div className="overflow-x-auto">
          <table className="doc-table w-full text-sm">
            <thead className="border-b border-line text-left text-xs uppercase tracking-wide text-ink-muted">
              <tr>
                <th className="py-3 pr-3">Item</th>
                <th className="px-3 py-3 text-right">Qty</th>
                <th className="px-3 py-3 text-right">Unit price</th>
                <th className="py-3 pl-3 text-right">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {sale.items.map((item) => (
                <tr key={item.id}>
                  <td className="py-3 pr-3">
                    <div className="font-medium text-ink">{item.product.name}</div>
                    <div className="text-xs text-ink-muted">{item.product.unit}</div>
                  </td>
                  <td data-label="Qty" className="px-3 py-3 text-right font-mono">
                    {item.quantity}
                  </td>
                  <td data-label="Unit price" className="px-3 py-3 text-right">
                    <Money centavos={item.priceAtSale} />
                  </td>
                  <td data-label="Amount" className="py-3 pl-3 text-right">
                    <Money
                      centavos={lineTotal(item.priceAtSale - item.discountAtSale, item.quantity)}
                      className="font-semibold"
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <section className="doc-keep-together ml-auto mt-6 w-full max-w-sm space-y-2 border-t border-line pt-5">
          {discountCentavos > 0 && (
            <>
              <div className="flex justify-between text-sm text-ink-muted">
                <span>Subtotal</span>
                <Money centavos={subtotalCentavos} />
              </div>
              <div className="flex justify-between text-sm text-ink-muted">
                <span>Discount</span>
                <span>
                  −<Money centavos={discountCentavos} />
                </span>
              </div>
            </>
          )}
          <div className="flex justify-between text-sm text-ink-muted">
            <span>Goods</span>
            <Money centavos={goodsCentavos} />
          </div>
          {/* Named rather than folded into the total. "Why is it ₱300 more
              than the sacks come to" is a question somebody asks at the gate,
              and the paper should answer it without a phone call. */}
          {sale.deliveryFeeCentavos > 0 && (
            <div className="flex justify-between text-sm text-ink-muted">
              <span>Delivery fee</span>
              <Money centavos={sale.deliveryFeeCentavos} />
            </div>
          )}
          <div className="flex items-baseline justify-between border-t border-line pt-3">
            <span className="font-semibold text-ink">Total</span>
            <Money centavos={sale.totalAmount} scale="strong" />
          </div>
          <div className="flex justify-between text-sm text-ink-muted">
            <span>Cash received</span>
            {/* The one figure here that is cash actually in hand. */}
            <Money centavos={sale.cashPaidCentavos} tone="in" />
          </div>
          {liveCharge && (
            <div className="flex justify-between text-sm text-ink-muted">
              <span>Charged to the account</span>
              <Money centavos={chargedCentavos} tone="owed" />
            </div>
          )}
          {sale.customerBalanceAfterCentavos !== null && (
            <div className="flex items-baseline justify-between border-t border-line pt-3">
              <span className="font-medium text-ink">Account balance after this</span>
              <Money centavos={sale.customerBalanceAfterCentavos} tone="balance" scale="strong" />
            </div>
          )}
        </section>

        {sale.deliveryInstructions && (
          <section className="doc-keep-together mt-6 rounded-control border border-line bg-surface-sunk p-4 text-sm text-ink-muted">
            <div className="font-semibold text-ink">Note for the driver</div>
            <div className="mt-1 whitespace-pre-line">{sale.deliveryInstructions}</div>
          </section>
        )}

        {sale.isVoided && (
          <section className="mt-6 rounded-control border border-owed/40 bg-owed/10 p-4 text-sm text-owed">
            <div className="font-semibold">This sale was voided.</div>
            {sale.voidReason && <div className="mt-1">Reason: {sale.voidReason}</div>}
            {sale.voidedAt && (
              <div className="mt-1">Voided: {sale.voidedAt.toLocaleString('en-PH')}</div>
            )}
          </section>
        )}

        {/* Signed, like the supplier's delivery receipt and unlike the sales
            receipt — this is the copy that comes back proving the load
            actually arrived. */}
        <section className="doc-keep-together mt-10 grid grid-cols-2 gap-8 text-sm">
          <div>
            <div className="h-12 border-b border-line-strong" />
            <div className="mt-1 text-xs text-ink-muted">Delivered by ({profile.name})</div>
          </div>
          <div>
            <div className="h-12 border-b border-line-strong" />
            <div className="mt-1 text-xs text-ink-muted">
              Received by ({sale.customer?.name ?? 'customer'})
            </div>
          </div>
        </section>

        <DocumentFooter>
          This document records goods delivered by {profile.name} and forms part of its official
          records.
        </DocumentFooter>
      </DocumentShell>
    </PageHeader>
  )
}
