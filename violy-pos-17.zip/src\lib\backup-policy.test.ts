import { describe, expect, it } from 'vitest'
import {
  KEEP_DAYS,
  KEEP_RECENT,
  backupFileName,
  backupTakenAt,
  isBackupName,
  selectBackupsToDelete,
  sortNewestFirst,
} from './backup-policy'

/** A backup name for a given UTC instant, without going through Date maths. */
function at(day: string, time = '00-00-00-000'): string {
  return `violy-pos-${day}_${time}.db`
}

describe('backup names', () => {
  it('round-trips the instant it was taken', () => {
    const taken = new Date('2026-08-16T09:01:00.672Z')
    const name = backupFileName(taken)
    expect(name).toBe('violy-pos-2026-08-16_09-01-00-672.db')
    expect(backupTakenAt(name)?.getTime()).toBe(taken.getTime())
  })

  it('sorts lexically in the same order as chronologically', () => {
    // The whole scheme depends on this: a zero-padded ISO stamp means a plain
    // string sort is a date sort, so nothing has to parse to find the newest.
    const names = [at('2026-01-09'), at('2026-01-10'), at('2025-12-31')]
    expect(sortNewestFirst(names)).toEqual([
      at('2026-01-10'),
      at('2026-01-09'),
      at('2025-12-31'),
    ])
  })

  it.each([
    'dev-backup-before-pos-fixes.db',
    'violy-pos-2026-08-16.db',
    'violy-pos-2026-08-16_09-01-00.db',
    'notes.txt',
    'violy-pos-2026-08-16_09-01-00-672.db.bak',
  ])('does not recognise %s', (name) => {
    expect(isBackupName(name)).toBe(false)
    expect(backupTakenAt(name)).toBeNull()
  })
})

describe('selectBackupsToDelete', () => {
  const NOW = new Date('2026-08-16T12:00:00.000Z')

  it('deletes nothing while there are only a few', () => {
    const names = [at('2026-08-16'), at('2026-08-15'), at('2026-08-14')]
    expect(selectBackupsToDelete(names, NOW)).toEqual([])
  })

  it('never deletes a file it did not write', () => {
    // Somebody copies a database into the folder by hand before doing
    // something frightening. Pruning must leave it exactly where it is,
    // however many backups pile up around it.
    const automatic = Array.from({ length: 200 }, (_, i) =>
      at('2026-08-16', `${String(i % 24).padStart(2, '0')}-00-00-${String(i).padStart(3, '0')}`),
    )
    const deleted = selectBackupsToDelete(
      [...automatic, 'dev-backup-before-pos-fixes.db', 'ledger-2026.db'],
      NOW,
    )
    expect(deleted).not.toContain('dev-backup-before-pos-fixes.db')
    expect(deleted).not.toContain('ledger-2026.db')
  })

  it('keeps the newest few whatever else the rules say', () => {
    // Twenty backups in one morning: the daily rule alone would keep exactly
    // one of them.
    const names = Array.from({ length: 20 }, (_, i) =>
      at('2026-08-16', `${String(i).padStart(2, '0')}-00-00-000`),
    )
    const deleted = new Set(selectBackupsToDelete(names, NOW))
    const kept = names.filter((name) => !deleted.has(name))
    expect(kept).toHaveLength(KEEP_RECENT)
    expect(sortNewestFirst(kept)).toEqual(sortNewestFirst(names).slice(0, KEEP_RECENT))
  })

  it('thins older days to one backup each', () => {
    // Four a day for a fortnight. Everything outside the newest ten collapses
    // to the last backup of its day.
    const names: string[] = []
    for (let day = 1; day <= 14; day += 1) {
      for (const hour of ['02', '08', '14', '20']) {
        names.push(at(`2026-08-${String(day).padStart(2, '0')}`, `${hour}-00-00-000`))
      }
    }

    const deleted = new Set(selectBackupsToDelete(names, NOW))
    const kept = names.filter((name) => !deleted.has(name))

    // Ten recent ones, plus one per day for the days those ten do not cover.
    const keptDays = new Set(kept.map((name) => name.slice(10, 20)))
    expect(keptDays.size).toBe(14)
    expect(kept.length).toBeLessThan(names.length)

    for (const day of keptDays) {
      const forDay = kept.filter((name) => name.includes(day))
      expect(forDay.length).toBeGreaterThanOrEqual(1)
    }
  })

  it('automation cannot evict the history that manual backups built', () => {
    // The failure this rule exists to prevent. One backup a day for two
    // months, then the app starts backing up on a timer and takes 30 in a
    // week. Under a plain "keep the newest 30" the whole of the older history
    // is gone by the following Monday.
    const daily: string[] = []
    for (let day = 1; day <= 31; day += 1) {
      daily.push(at(`2026-07-${String(day).padStart(2, '0')}`, '09-00-00-000'))
    }
    const burst: string[] = []
    for (let hour = 0; hour < 24; hour += 1) {
      burst.push(at('2026-08-16', `${String(hour).padStart(2, '0')}-00-00-000`))
    }

    const deleted = new Set(selectBackupsToDelete([...daily, ...burst], NOW))
    const survivingJuly = daily.filter((name) => !deleted.has(name))

    // July 18th onwards is inside the 30-day window and survives the burst.
    expect(survivingJuly.length).toBeGreaterThan(10)
    expect(survivingJuly).toContain(at('2026-07-18', '09-00-00-000'))
  })

  it('drops days beyond the window entirely', () => {
    const old = at('2026-01-01', '09-00-00-000')
    const recent = Array.from({ length: 15 }, (_, i) =>
      at(`2026-08-${String(i + 1).padStart(2, '0')}`, '09-00-00-000'),
    )
    expect(selectBackupsToDelete([old, ...recent], NOW)).toContain(old)
  })

  it('keeps a backup on the oldest day still inside the window', () => {
    // Off-by-one guard on the boundary: KEEP_DAYS counts calendar dates
    // including today, so the earliest surviving date is today minus 29.
    const oldest = new Date(NOW)
    oldest.setDate(oldest.getDate() - (KEEP_DAYS - 1))
    const name = backupFileName(oldest)

    const filler = Array.from({ length: KEEP_RECENT + 5 }, (_, i) =>
      at('2026-08-16', `${String(i).padStart(2, '0')}-00-00-000`),
    )
    expect(selectBackupsToDelete([name, ...filler], NOW)).not.toContain(name)
  })

  it('is stable — asking twice deletes the same set', () => {
    const names = Array.from({ length: 40 }, (_, i) =>
      at(`2026-07-${String((i % 28) + 1).padStart(2, '0')}`, `${String(i % 24).padStart(2, '0')}-00-00-000`),
    )
    expect(selectBackupsToDelete(names, NOW)).toEqual(selectBackupsToDelete(names, NOW))
  })
})
