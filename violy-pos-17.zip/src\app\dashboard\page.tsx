import Link from 'next/link'
import { dayKey, startOfMonth, startOfWeek } from '@/lib/dates'
import { DrillBlock, DrillRow } from './DrillRow'
import { getDashboard } from '@/server/dashboard'
import { TrendChart } from './TrendChart'
import { Card } from '@/components/ui/Card'
import { PageHeader } from '@/components/ui/PageHeader'
import { Stat } from '@/components/ui/Stat'
import { Money } from '@/components/ui/Money'
import { Badge } from '@/components/ui/Badge'
import { EmptyState } from '@/components/ui/EmptyState'
import { TapeCell, TapeRow } from '@/components/ui/Tape'
import { ROUTES, bookEntry, deliveryNote, HISTORY_GOING_OUT } from '@/lib/routes'
import { stockLevelOf } from '@/lib/stock-level'

export const dynamic = 'force-dynamic'

/** `/history?from=&to=` lands on the Recent tab with the range applied —
 *  `HistoryScreen` already switches away from Today whenever the URL carries a
 *  filter, so these links need nothing else. */
function salesBetween(from: Date, to: Date): string {
  return `${ROUTES.history}?from=${dayKey(from)}&to=${dayKey(to)}`
}

/** The stock screen filters by name, the same way the notification bell does. */
function stockFor(name: string): string {
  return `${ROUTES.stock}?q=${encodeURIComponent(name)}`
}

/**
 * How many low-stock rows the card shows before deferring to the Stock screen.
 *
 * Five, because this card sits in a grid beside three others and has to keep
 * their height. It is not a scroll region: a list that grows without limit
 * inside a summary card pushes the rest of the dashboard off the screen, which
 * is what it did.
 */
const LOW_STOCK_SHOWN = 5

/**
 * "Today", "Tomorrow", or a weekday and date.
 *
 * Server-rendered against the page's own `now`, so there is no second clock
 * to disagree with — the hydration trap `dayKey(new Date())` in a `useState`
 * initialiser has already cost this app twice.
 */
function deliveryDayLabel(date: Date, now: Date): string {
  const key = dayKey(date)
  if (key === dayKey(now)) return 'Today'

  const tomorrow = new Date(now)
  tomorrow.setDate(tomorrow.getDate() + 1)
  if (key === dayKey(tomorrow)) return 'Tomorrow'

  return date.toLocaleDateString('en-PH', { weekday: 'short', day: 'numeric', month: 'short' })
}

export default async function DashboardPage() {
  const data = await getDashboard()

  const now = new Date()
  const today = salesBetween(now, now)
  const thisWeek = salesBetween(startOfWeek(now), now)
  const thisMonth = salesBetween(startOfMonth(now), now)

  return (
    <PageHeader title="Dashboard">
      {/* The page exists to make one comparison, so it leads with it: benta
          and cash na pumasok side by side, both at hero scale, in one wide
          band. A credit sale inflates the left figure without moving the
          right one — that gap must be the first thing seen, not one card
          among three equally-weighted ones. */}
      {/* One grid, not five stacked sections. Stacked, this page ran about
          two screens tall and everything below the fold — low stock, who owes
          most — was the part worth glancing at. Four columns on a wide screen
          put all six panels in two rows. */}
      <div className="grid gap-4 xl:grid-cols-4">
      <Card className="grid gap-6 sm:grid-cols-2 xl:col-span-2">
        <div>
          <h2 className="mb-4 text-base font-semibold text-ink">Benta (sold)</h2>
          <DrillBlock href={today}>
            <Stat label="Today" centavos={data.todayCentavos} scale="hero" />
          </DrillBlock>
          <div className="mt-2 space-y-1">
            <DrillRow
              href={thisWeek}
              label="This week"
              value={<Money centavos={data.weekCentavos} scale="strong" />}
            />
            <DrillRow
              href={thisMonth}
              label="This month"
              value={<Money centavos={data.monthCentavos} scale="strong" />}
            />
            {/* Profit is a computed margin, not a list of anything, so it
                stays text. There is no screen that "shows the profit". */}
            <div className="flex items-baseline justify-between border-t border-line px-2 pt-2">
              <span className="text-sm text-ink-muted">Profit this month</span>
              <Money centavos={data.monthProfitCentavos} tone="neutral" />
            </div>
          </div>
        </div>

        <div className="sm:border-l sm:border-line sm:pl-6">
          <h2 className="mb-4 text-base font-semibold text-ink">
            Cash na pumasok (received)
          </h2>
          {/* Deliberately NOT links, unlike benta beside it.
              Cash received is cash taken at the counter PLUS payments made
              against accounts, and no single screen shows both halves. A link
              to history would show only the sales half while appearing to
              explain the whole figure, which is exactly the kind of quiet
              overstatement the money rules in AGENTS.md exist to prevent. */}
          <Stat
            label="Today"
            centavos={data.todayCashCentavos}
            scale="hero"
            tone="in"
            secondary={
              <>
                <div className="flex items-baseline justify-between">
                  <span className="text-sm text-ink-muted">This week</span>
                  <Money centavos={data.weekCashCentavos} scale="strong" tone="in" />
                </div>
                <div className="flex items-baseline justify-between">
                  <span className="text-sm text-ink-muted">This month</span>
                  <Money centavos={data.monthCashCentavos} scale="strong" tone="in" />
                </div>
              </>
            }
          />
        </div>
      </Card>

      {/* Separate from the band above because it is a stock — a standing
          balance — not a flow measured over a period. Grouping it with
          benta and cash is what flattened this page before. */}
      <Card variant="muted">
        <h2 className="mb-4 text-base font-semibold text-ink">Utang outstanding</h2>
        <DrillBlock href={ROUTES.book}>
          <Stat label="Total owed" centavos={data.totalUtangCentavos} scale="hero" tone="owed" />
          <span className="mt-1 inline-block text-sm font-medium text-accent">
            See who owes →
          </span>
        </DrillBlock>
      </Card>

      {/* Capped at five, with the rest behind a link. Unfiltered, this card
          listed every product at or below its threshold — forty of them today,
          because nothing has been counted in yet — which turned a summary into
          a scrolling inventory and pushed everything below it off the page.
          A dashboard card answers "is there a problem and how big"; the Stock
          screen answers "which ones", and it now has the facets to do it. */}
      <Card>
        <div className="mb-3 flex items-baseline justify-between gap-3">
          <h2 className="text-base font-semibold text-ink">Low stock</h2>
          {data.lowStock.length > 0 && (
            <span className="text-xs text-ink-subtle">
              {data.lowStock.length} needing attention
            </span>
          )}
        </div>
        {data.lowStock.length === 0 && <EmptyState>Everything is above its threshold.</EmptyState>}
        <div>
          {data.lowStock.slice(0, LOW_STOCK_SHOWN).map((product) => {
            // Out of stock and low are different problems — one is a customer
            // who cannot be served today, the other is a reorder this week —
            // so they do not share a colour. Before this the card called a
            // product with nothing left "low", in the same amber as one with
            // two sacks to spare.
            const out = stockLevelOf(product) === 'out'
            return (
              <DrillRow
                key={product.id}
                href={stockFor(product.name)}
                className="border-b border-line py-2 last:border-b-0"
                label={
                  <span className="block min-w-0">
                    <span className="block truncate text-sm font-medium text-ink">
                      {product.name}
                    </span>
                    <span className="block text-xs text-ink-muted">
                      threshold {product.lowStockThreshold} {product.unit}
                    </span>
                  </span>
                }
                value={
                  <Badge tone={out ? 'owed' : 'warn'}>
                    {out ? 'Out of stock' : `${product.stockQty} left`}
                  </Badge>
                }
              />
            )
          })}
        </div>

        {data.lowStock.length > LOW_STOCK_SHOWN && (
          // Sorted lowest-first, exactly as this card is, so the link opens on
          // the same rows in the same order rather than somewhere unrelated.
          <Link
            href={`${ROUTES.stock}?sort=stock&dir=asc`}
            className="mt-3 inline-block text-sm font-medium text-accent hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
          >
            See all {data.lowStock.length} in Stock →
          </Link>
        )}
      </Card>

      {/* Full width, and only when there is something booked.

          Full width because it is a band of its own rather than a fourth
          summary card, and it sits high — above the trend chart — because
          "what goes on the truck today" is a job with a deadline, unlike
          everything else here, which is a figure to look at.

          Rendered conditionally rather than with an empty state, unlike Low
          stock. A panel that says "nothing going out" every morning is the
          kind of thing a person learns to stop seeing, and the day it does
          have something in it, they will not see that either. */}
      {data.upcomingDeliveries.length > 0 && (
        <Card className="xl:col-span-4">
          <div className="mb-3 flex items-baseline justify-between gap-3">
            <h2 className="text-base font-semibold text-ink">Going out</h2>
            <span className="text-xs text-ink-subtle">
              {data.upcomingDeliveryCount === 1
                ? '1 load booked'
                : `${data.upcomingDeliveryCount} loads booked`}
            </span>
          </div>

          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
            {data.upcomingDeliveries.map((row) => (
              <Link
                key={row.saleId}
                href={deliveryNote(row.saleId)}
                className="block rounded-control border border-line bg-surface-sunk p-3 transition-colors duration-150 hover:border-accent hover:bg-accent-soft focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
              >
                <span className="block text-xs font-semibold uppercase tracking-wide text-accent">
                  {deliveryDayLabel(row.deliverAt, now)}
                </span>
                <span className="mt-1 block truncate text-sm font-medium text-ink">
                  {row.customerName}
                </span>
                <span className="block truncate text-xs text-ink-muted">{row.deliverTo}</span>
                <span className="mt-1.5 block">
                  {/* Neutral: a booked load is benta, not cash in the drawer. */}
                  <Money centavos={row.totalCentavos} scale="body" className="font-semibold" />
                </span>
                {/* Only when it differs from the total, for the same reason
                    the Going out list does it: on an unpaid load the total is
                    the amount owed, and the same figure printed twice reads
                    as two numbers that happen to match. */}
                {row.owedCentavos > 0 && row.owedCentavos !== row.totalCentavos && (
                  <span className="mt-0.5 block text-xs">
                    <Money centavos={row.owedCentavos} scale="body" tone="owed" /> owing
                  </span>
                )}
                {row.owedCentavos === 0 && (
                  <span className="mt-0.5 block text-xs text-money-in">Paid</span>
                )}
              </Link>
            ))}
          </div>

          {data.upcomingDeliveryCount > data.upcomingDeliveries.length && (
            <Link
              href={HISTORY_GOING_OUT}
              className="mt-3 inline-block text-sm font-medium text-accent hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
            >
              See all {data.upcomingDeliveryCount} in History →
            </Link>
          )}
        </Card>
      )}

      <Card className="xl:col-span-2">
        <h2 className="mb-3 text-base font-semibold text-ink">Sales — last 30 days</h2>
        <TrendChart data={data.trend} />
      </Card>

        <Card>
          <h2 className="mb-3 text-base font-semibold text-ink">Top sellers this month</h2>
          {data.topProducts.length === 0 && (
            <EmptyState>No sales yet this month.</EmptyState>
          )}
          <div>
            {data.topProducts.map((product) => (
              <DrillRow
                key={product.productId}
                href={stockFor(product.name)}
                className="border-b border-line py-2 last:border-b-0"
                label={
                  <span className="block min-w-0">
                    <span className="block truncate text-sm font-medium text-ink">
                      {product.name}
                    </span>
                    <span className="block text-xs text-ink-muted">
                      {product.quantitySold} {product.unit}
                    </span>
                  </span>
                }
                value={
                  <Money centavos={product.revenueCentavos} scale="body" className="font-semibold" />
                }
              />
            ))}
          </div>
        </Card>

        <Card>
          <h2 className="mb-3 text-base font-semibold text-ink">Largest balances</h2>
          {data.topBalances.length === 0 && (
            <EmptyState>No outstanding credit.</EmptyState>
          )}
          <div>
            {data.topBalances.map((balance) => (
              <DrillRow
                key={balance.customerId}
                href={bookEntry(balance.customerId)}
                className="border-b border-line py-2 last:border-b-0"
                label={
                  <span className="truncate text-sm font-medium text-ink">{balance.name}</span>
                }
                value={
                  <Money
                    centavos={balance.balanceCentavos}
                    scale="body"
                    tone="owed"
                    className="font-semibold"
                  />
                }
              />
            ))}
          </div>
        </Card>
      </div>
    </PageHeader>
  )
}
