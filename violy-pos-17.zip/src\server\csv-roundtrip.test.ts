import { beforeEach, describe, expect, it } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'
import { exportTableCsv } from '@/server/export-data'
import { previewImport, applyImport } from '@/server/import-data'
import { EXPORT_TABLES } from '@/lib/export-tables'

beforeEach(resetDb)

async function seedShop() {
  const feeds = await prisma.category.create({ data: { name: 'Golden Harvest', sortOrder: 1 } })
  const meds = await prisma.category.create({ data: { name: 'Medicine', sortOrder: 2 } })
  await prisma.supplier.create({
    data: { name: 'Feedmill Inc', contactNumber: '0917 555 0101', notes: 'Delivers Tuesdays' },
  })
  await prisma.product.create({
    data: {
      categoryId: feeds.id,
      name: 'Hog Grower',
      unit: 'bag (50kg)',
      price: 201_000,
      costPrice: 190_000,
      stockQty: 12,
      lowStockThreshold: 3,
    },
  })
  await prisma.product.create({
    data: {
      categoryId: meds.id,
      name: 'Dewormer',
      unit: 'bottle',
      price: 32_000,
      costPrice: 25_000,
      stockQty: 4,
      lowStockThreshold: 1,
    },
  })
  await prisma.customer.create({
    data: { name: 'MARILOU', phone: '0918 555 0202', notes: 'Pays Fridays', discountCentavos: 2_000 },
  })
}

describe('every export builds', () => {
  it.each(EXPORT_TABLES.map((table) => table.value))(
    'produces a header row for %s even with an empty shop',
    async (table) => {
      // An empty table must still emit its header. A zero-byte file reads as a
      // failed export, and the first thing anyone does with it is re-run it.
      const csv = await exportTableCsv(table)
      expect(csv.trim().length).toBeGreaterThan(0)
      expect(csv.split(/\r?\n/)[0]).toContain(',')
    },
  )

  it('covers every table the UI offers, with no duplicates', async () => {
    const values = EXPORT_TABLES.map((table) => table.value)
    expect(new Set(values).size).toBe(values.length)
  })
})

describe('exporting and importing the same file changes nothing', () => {
  // The contract that makes an export worth editing: what comes out must go
  // straight back in. If the exporter renames a column or writes money in a
  // different shape from what the importer reads, every row would come back as
  // an update — silently rewriting the whole catalogue with itself, and one
  // day with something subtly wrong.
  it.each(['categories', 'suppliers', 'products', 'customers'] as const)(
    'reports %s as entirely unchanged',
    async (table) => {
      await seedShop()

      const csv = await exportTableCsv(table)
      const preview = await previewImport(table, csv)

      expect(preview.ok).toBe(true)
      if (!preview.ok) return
      expect(preview.data.errorCount).toBe(0)
      expect(preview.data.createCount).toBe(0)
      expect(preview.data.updateCount).toBe(0)
    },
  )

  it('leaves the row counts alone when applied for real', async () => {
    await seedShop()
    const before = {
      categories: await prisma.category.count(),
      suppliers: await prisma.supplier.count(),
      products: await prisma.product.count(),
      customers: await prisma.customer.count(),
    }

    for (const table of ['categories', 'suppliers', 'products', 'customers'] as const) {
      await applyImport(table, await exportTableCsv(table))
    }

    expect(await prisma.category.count()).toBe(before.categories)
    expect(await prisma.supplier.count()).toBe(before.suppliers)
    expect(await prisma.product.count()).toBe(before.products)
    expect(await prisma.customer.count()).toBe(before.customers)
  })
})

describe('importing into an empty shop', () => {
  it('creates categories, then the products that need them', async () => {
    // The order the Settings screen tells her to use, and the reason it does:
    // a product whose brand is not on file is refused rather than inventing
    // one, so products first means every row fails at once.
    await seedShop()
    const categoriesCsv = await exportTableCsv('categories')
    const productsCsv = await exportTableCsv('products')

    await resetDb()

    const productsFirst = await previewImport('products', productsCsv)
    expect(productsFirst.ok).toBe(true)
    if (!productsFirst.ok) return
    // Every row refused, because no brand exists yet.
    expect(productsFirst.data.errorCount).toBe(2)
    expect(productsFirst.data.createCount).toBe(0)

    const categories = await applyImport('categories', categoriesCsv)
    expect(categories.ok).toBe(true)
    if (!categories.ok) return
    expect(categories.data.created).toBe(2)

    const products = await applyImport('products', productsCsv)
    expect(products.ok).toBe(true)
    if (!products.ok) return
    expect(products.data.created).toBe(2)
    expect(products.data.failed).toBe(0)
  })

  it('does not duplicate a category that differs only in case', async () => {
    // SQLite compares TEXT case-sensitively, so "Atlas" and "atlas" would
    // otherwise become two chips holding half a brand each.
    await prisma.category.create({ data: { name: 'Atlas', sortOrder: 1 } })

    const result = await applyImport('categories', 'name,sort_order\natlas,1\nATLAS,2\n')

    expect(result.ok).toBe(true)
    expect(await prisma.category.count()).toBe(1)
  })

  it('creates a supplier once and updates it the second time', async () => {
    const csv = 'name,contact_number,notes\nFeedmill Inc,0917 555 0101,Tuesdays\n'
    const first = await applyImport('suppliers', csv)
    expect(first.ok && first.data.created).toBe(1)

    const changed = 'name,contact_number,notes\nFeedmill Inc,0917 555 9999,Tuesdays\n'
    const second = await applyImport('suppliers', changed)
    expect(second.ok && second.data.updated).toBe(1)

    expect(await prisma.supplier.count()).toBe(1)
    const supplier = await prisma.supplier.findFirstOrThrow()
    expect(supplier.contactNumber).toBe('0917 555 9999')
  })
})
