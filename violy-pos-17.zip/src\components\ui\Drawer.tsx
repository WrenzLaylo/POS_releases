'use client'

import type { ReactNode } from 'react'
import { Overlay } from './Overlay'

export type DrawerProps = {
  open: boolean
  onOpenChange: (open: boolean) => void
  title: ReactNode
  description?: ReactNode
  header?: ReactNode
  children: ReactNode
  footer?: ReactNode
  className?: string
}

export function Drawer(props: DrawerProps) {
  return (
    <Overlay
      {...props}
      surfaceClassName="ml-auto h-full w-full border-l border-line sm:max-w-md"
      backdropTestId="drawer-backdrop"
    />
  )
}
