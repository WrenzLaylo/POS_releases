-- Every sale that predates the accounts/ledger migration was a cash walk-in
-- (there was no other kind of sale). That migration rebuilt Sale and only
-- copied createdAt/id/totalAmount, leaving cashPaidCentavos at its default
-- of 0 for all of them — which makes the cash dashboard tiles read ₱0 for
-- every historical day even though benta reads correctly.
--
-- Scoped to customerId IS NULL (walk-ins only) so it can never touch a
-- pre-existing utang order row.
UPDATE "Sale" SET "cashPaidCentavos" = "totalAmount"
WHERE "customerId" IS NULL AND "cashPaidCentavos" = 0;
