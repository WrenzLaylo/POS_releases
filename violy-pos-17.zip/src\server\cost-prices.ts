'use server'

import { prisma } from '@/lib/db'
import type { ActionResult } from '@/lib/types'
import { ROUTES } from '@/lib/routes'
import { revalidateRoutes } from './revalidate'

/** Thrown inside the transaction to roll it back with a message worth reading. */
class CostPriceError extends Error {}

export type CostPriceRow = {
  productId: number
  /** What a sack costs the shop, in centavos. Absolute, not a delta. */
  costCentavos: number
}

export type CostPriceResult = {
  /** How many products actually moved. A row typed at what it already said is not one. */
  changed: number
  /**
   * Products now selling at or below what they cost, named so the screen can
   * say which. Saved rather than refused — see the note in `recordCostPrices`.
   */
  belowCost: string[]
}

/**
 * Records what the shop pays for each product.
 *
 * Every profit figure in the app is `price - costAtSale`, and `costAtSale` is
 * copied from `Product.costPrice` at the moment of the sale. With cost at zero
 * — which is where 52 of 55 products sat — the Dashboard reported the entire
 * selling price as profit. It was not slightly optimistic; it was fiction, and
 * nothing on screen said so.
 *
 * ABSOLUTE, not a delta, for the same reason `recordStockCount` is: saving the
 * same figure twice leaves the same answer, so a double-tap on Save or a lost
 * connection cannot compound. Rows matching what the product already says are
 * skipped rather than written.
 *
 * A cost ABOVE the selling price is saved, not refused, and the names come back
 * so the screen can say so plainly. Refusing would be wrong twice over: it is
 * sometimes true — old stock cleared at a loss, a supplier price that rose
 * before the shelf price followed — and refusing the save would leave her with
 * a screen of typing she cannot commit and no way to record the truth. Telling
 * her is useful; overruling her is not.
 *
 * One transaction, so a half-applied pass cannot leave her guessing which rows
 * landed.
 *
 * No audit record is written. `ProductForm` and `settleDelivery` both rewrite
 * cost with none, and adding history for one of three write paths would read as
 * a complete record while being a third of one.
 */
export async function recordCostPrices(
  rows: readonly CostPriceRow[],
): Promise<ActionResult<CostPriceResult>> {
  if (rows.length === 0) return { ok: false, error: 'Nothing was typed yet.' }

  const seen = new Set<number>()
  for (const row of rows) {
    if (!Number.isInteger(row.productId) || row.productId <= 0) {
      return { ok: false, error: 'A row is missing its product.' }
    }
    // Two rows for one product would apply in an order nobody chose, and the
    // last one silently wins. The grid cannot produce this; a caller can.
    if (seen.has(row.productId)) {
      return { ok: false, error: 'The same product was given a cost twice.' }
    }
    seen.add(row.productId)

    // Integer centavos, never a float: money is stored as centavos everywhere
    // in this app precisely so it cannot drift. Negative is refused — a cost
    // is an amount, and nothing about buying stock has a direction to express.
    if (!Number.isInteger(row.costCentavos) || row.costCentavos < 0) {
      return { ok: false, error: 'A cost must be zero or more.' }
    }
  }

  let result: CostPriceResult
  try {
    result = await prisma.$transaction(async (tx) => {
      const products = await tx.product.findMany({
        where: { id: { in: [...seen] } },
        select: { id: true, name: true, price: true, costPrice: true, isArchived: true },
      })
      const byId = new Map(products.map((product) => [product.id, product]))

      for (const row of rows) {
        const product = byId.get(row.productId)
        if (!product) throw new CostPriceError('A product on this list no longer exists.')
        // Refused rather than silently un-archiving, the same way a count and
        // a delivery both refuse.
        if (product.isArchived) {
          throw new CostPriceError(
            `${product.name} is archived. Restore it before setting its cost.`,
          )
        }
      }

      let changed = 0
      const belowCost: string[] = []

      for (const row of rows) {
        const product = byId.get(row.productId)!
        if (row.costCentavos === product.costPrice) continue

        changed += 1
        // A cost of zero is not "free", it is "not known" — so it is never
        // reported as selling below cost, or all 52 blanks would be flagged.
        if (row.costCentavos > 0 && product.price <= row.costCentavos) {
          belowCost.push(product.name)
        }

        await tx.product.update({
          where: { id: row.productId },
          data: { costPrice: row.costCentavos },
        })
      }

      return { changed, belowCost }
    })
  } catch (error) {
    if (error instanceof CostPriceError) return { ok: false, error: error.message }
    return { ok: false, error: 'Could not save the costs. Nothing was changed.' }
  }

  // After the catch, never inside it. A revalidation throw caught here would be
  // reported as "could not save" on costs that had already committed, and the
  // retry would look like the fix.
  revalidateRoutes([ROUTES.stock, ROUTES.deliveries, ROUTES.dashboard], { layout: true })
  return { ok: true, data: result }
}
