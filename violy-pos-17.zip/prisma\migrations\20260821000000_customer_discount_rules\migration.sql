-- A customer may hold several standing discounts, not one.
--
-- "P20 off Atlas bags" and "P300 off a sack of Broodsow" are two different
-- arrangements and both are real; until now the second overwrote the first.

CREATE TABLE "CustomerDiscountRule" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "customerId" INTEGER NOT NULL,
    "kind" TEXT NOT NULL DEFAULT 'AMOUNT',
    "amountCentavos" INTEGER NOT NULL DEFAULT 0,
    "bps" INTEGER NOT NULL DEFAULT 0,
    "basis" TEXT NOT NULL DEFAULT 'PER_UNIT',
    "unit" TEXT NOT NULL DEFAULT '',
    "scope" TEXT NOT NULL DEFAULT 'CATEGORIES',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "CustomerDiscountRule_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "Customer" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE INDEX "CustomerDiscountRule_customerId_idx" ON "CustomerDiscountRule"("customerId");

CREATE TABLE "_RuleDiscountCategories" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL,
    CONSTRAINT "_RuleDiscountCategories_A_fkey" FOREIGN KEY ("A") REFERENCES "Category" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "_RuleDiscountCategories_B_fkey" FOREIGN KEY ("B") REFERENCES "CustomerDiscountRule" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE UNIQUE INDEX "_RuleDiscountCategories_AB_unique" ON "_RuleDiscountCategories"("A", "B");
CREATE INDEX "_RuleDiscountCategories_B_index" ON "_RuleDiscountCategories"("B");

CREATE TABLE "_RuleDiscountProducts" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL,
    CONSTRAINT "_RuleDiscountProducts_A_fkey" FOREIGN KEY ("A") REFERENCES "CustomerDiscountRule" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "_RuleDiscountProducts_B_fkey" FOREIGN KEY ("B") REFERENCES "Product" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE UNIQUE INDEX "_RuleDiscountProducts_AB_unique" ON "_RuleDiscountProducts"("A", "B");
CREATE INDEX "_RuleDiscountProducts_B_index" ON "_RuleDiscountProducts"("B");

-- BACKFILL. Every customer who has a discount today keeps it, as their first
-- rule. Without this the migration silently removes every discount in the
-- shop, which nothing would report until a regular was charged full price.
INSERT INTO "CustomerDiscountRule"
    ("customerId", "kind", "amountCentavos", "bps", "basis", "unit", "scope")
SELECT "id", "discountKind", "discountCentavos", "discountBps",
       "discountBasis", "discountUnit", "discountScope"
FROM "Customer"
WHERE "discountCentavos" > 0 OR "discountBps" > 0;

-- Their scopes come across with them.
INSERT INTO "_RuleDiscountCategories" ("A", "B")
SELECT j."A", r."id"
FROM "_CustomerDiscountCategories" j
JOIN "CustomerDiscountRule" r ON r."customerId" = j."B";

INSERT INTO "_RuleDiscountProducts" ("A", "B")
SELECT r."id", j."B"
FROM "_CustomerDiscountProducts" j
JOIN "CustomerDiscountRule" r ON r."customerId" = j."A";
