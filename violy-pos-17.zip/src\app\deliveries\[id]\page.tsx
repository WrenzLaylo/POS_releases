import Link from 'next/link'
import { notFound } from 'next/navigation'
import { getDelivery } from '@/server/deliveries'
import { getStoreProfile } from '@/server/store-profile'
import { documentNumber, DOCUMENT_TITLES } from '@/lib/document-number'
import { ROUTES } from '@/lib/routes'
import { Money } from '@/components/ui/Money'
import { DocumentShell } from '@/components/DocumentShell'
import { DocumentFacts, DocumentFooter, DocumentHeading } from '@/components/DocumentHeading'

export const dynamic = 'force-dynamic'

/**
 * The paper that goes back with the driver.
 *
 * The only document in this app recording goods coming IN rather than money
 * going out, and the one the shop is asked for rather than the one it hands
 * over: a supplier's agent counts what he dropped off and wants a copy saying
 * the shop agrees. Until now Deliveries had no printable document at all — the
 * `delivery(id)` route helper existed and pointed at a page nobody had built.
 *
 * On `DocumentShell` like the other four, which is the whole reason this file
 * is short: paper size, Print, and the desktop shell's one-press Download PDF
 * all arrive with it and cannot drift away from the receipts.
 *
 * Consignment is spelled out rather than left to the totals. "Owed on arrival
 * ₱0.00" against a delivery worth ₱230,500 reads as a mistake unless the
 * document says why, and this is the copy somebody signs.
 */
export default async function DeliveryDocumentPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const deliveryId = Number(id)
  if (!Number.isInteger(deliveryId) || deliveryId <= 0) notFound()

  const delivery = await getDelivery(deliveryId)
  if (!delivery) notFound()

  const profile = await getStoreProfile()
  const reference = documentNumber('DELIVERY_RECEIPT', delivery.id, delivery.receivedAt)
  const consignment = delivery.terms === 'CONSIGNMENT'

  return (
    <DocumentShell
      fileName={`${reference} ${delivery.supplierName}`}
      actions={
        <Link
          href={ROUTES.deliveries}
          className="inline-flex h-10 items-center justify-center rounded-control border border-line-strong bg-surface-raised px-4 text-sm font-medium text-ink hover:border-accent hover:bg-accent-soft"
        >
          Back to deliveries
        </Link>
      }
    >
      <DocumentHeading
        profile={profile}
        title={DOCUMENT_TITLES.DELIVERY_RECEIPT}
        reference={reference}
        issuedAt={delivery.receivedAt}
      />

      <DocumentFacts
        items={[
          {
            label: 'Supplier',
            value: (
              <>
                {delivery.supplierName}
                {delivery.reference && (
                  <div className="font-normal text-ink-muted">Their ref: {delivery.reference}</div>
                )}
              </>
            ),
          },
          {
            label: 'Terms',
            value: delivery.isVoided
              ? 'Voided delivery'
              : consignment
                ? 'Consignment'
                : 'Outright purchase',
            align: 'end',
          },
        ]}
      />

      <div className="overflow-x-auto">
        <table className="doc-table w-full text-sm">
          <thead className="border-b border-line text-left text-xs uppercase tracking-wide text-ink-muted">
            <tr>
              <th className="py-3 pr-3">Item</th>
              <th className="px-3 py-3 text-right">Received</th>
              <th className="px-3 py-3 text-right">Unit cost</th>
              <th className="py-3 pl-3 text-right">Amount</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {delivery.lines.map((line) => (
              <tr key={line.productId}>
                <td className="py-3 pr-3">
                  <div className="font-medium text-ink">{line.name}</div>
                  <div className="text-xs text-ink-muted">{line.unit}</div>
                </td>
                <td data-label="Received" className="px-3 py-3 text-right font-mono">
                  {line.quantity}
                </td>
                <td data-label="Unit cost" className="px-3 py-3 text-right">
                  <Money centavos={line.unitCostCentavos} />
                </td>
                <td data-label="Amount" className="py-3 pl-3 text-right">
                  <Money centavos={line.lineCostCentavos} className="font-semibold" />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <section className="doc-keep-together ml-auto mt-6 w-full max-w-sm space-y-2 border-t border-line pt-5">
        <div className="flex items-baseline justify-between border-b border-line pb-3">
          <span className="font-semibold text-ink">Value received</span>
          <Money centavos={delivery.totalCostCentavos} scale="strong" />
        </div>
        {/* Neutral throughout, never `money-in`: stock arriving is not cash
            arriving, and what is owed for it is the shop's liability. */}
        <div className="flex justify-between text-sm text-ink-muted">
          <span>{consignment ? 'Owed on arrival' : 'Owed'}</span>
          <Money centavos={delivery.chargeableCentavos} />
        </div>
        <div className="flex justify-between text-sm text-ink-muted">
          <span>Paid</span>
          <Money centavos={delivery.amountPaidCentavos} />
        </div>
        <div className="flex items-baseline justify-between border-t border-line pt-3">
          <span className="font-medium text-ink">Still owing</span>
          <Money centavos={delivery.outstandingCentavos} tone="owed" scale="strong" />
        </div>
      </section>

      {consignment && !delivery.isVoided && (
        <section className="mt-6 rounded-control border border-line bg-surface-sunk p-4 text-sm text-ink-muted">
          <div className="font-semibold text-ink">Held on consignment</div>
          <div className="mt-1">
            These goods remain the property of {delivery.supplierName} until sold. Nothing is owed
            for stock still on the shelf; unsold goods may be returned.
          </div>
          {delivery.unaccountedCentavos > 0 && (
            <div className="mt-2">
              Still unsold at the date of this document:{' '}
              <Money centavos={delivery.unaccountedCentavos} />
            </div>
          )}
        </section>
      )}

      {delivery.isVoided && (
        <section className="mt-6 rounded-control border border-owed/40 bg-owed/10 p-4 text-sm text-owed">
          <div className="font-semibold">This delivery was voided.</div>
          {delivery.voidReason && <div className="mt-1">Reason: {delivery.voidReason}</div>}
        </section>
      )}

      {/* Signed, unlike every other document here — this one is the shop
          agreeing that what is listed above actually arrived. */}
      <section className="doc-keep-together mt-10 grid grid-cols-2 gap-8 text-sm">
        <div>
          <div className="h-12 border-b border-line-strong" />
          <div className="mt-1 text-xs text-ink-muted">Delivered by (supplier)</div>
        </div>
        <div>
          <div className="h-12 border-b border-line-strong" />
          <div className="mt-1 text-xs text-ink-muted">Received by ({profile.name})</div>
        </div>
      </section>

      <DocumentFooter>
        This document records goods received by {profile.name} and forms part of its official
        records.
      </DocumentFooter>
    </DocumentShell>
  )
}
