import { describe, expect, it } from 'vitest'
import { hasStoreIdentity, isSupplied, storeProfileLines, type StoreIdentity } from './store-profile'

function profile(overrides: Partial<StoreIdentity> = {}): StoreIdentity {
  return {
    name: 'Violy Store',
    tagline: 'Pig feeds and store supplies',
    registeredName: '',
    addressLine1: '',
    addressLine2: '',
    contactNumber: '',
    email: '',
    tin: '',
    businessRegistrationNo: '',
    ...overrides,
  }
}

describe('isSupplied', () => {
  it('treats blank and whitespace as not supplied', () => {
    expect(isSupplied('')).toBe(false)
    expect(isSupplied('   ')).toBe(false)
    expect(isSupplied(null)).toBe(false)
    expect(isSupplied(undefined)).toBe(false)
    expect(isSupplied('0')).toBe(true)
  })
})

describe('storeProfileLines', () => {
  it('prints nothing extra while only the name is filled in', () => {
    // The rule this module exists for: an unfilled field is OMITTED, never
    // printed as an empty "TIN:" on a document meant to be legally usable.
    expect(storeProfileLines(profile())).toEqual([])
    expect(hasStoreIdentity(profile())).toBe(false)
  })

  it('omits only the fields that are blank', () => {
    const lines = storeProfileLines(
      profile({ addressLine1: '123 Rizal Street', tin: '123-456-789-000' }),
    )
    expect(lines).toEqual([
      { label: null, value: '123 Rizal Street' },
      { label: 'TIN', value: '123-456-789-000' },
    ])
    // No email, no contact number, no registration number.
    expect(lines.some((line) => line.label === 'Email')).toBe(false)
  })

  it('labels each identifier so a reader knows what the number is', () => {
    const lines = storeProfileLines(
      profile({
        contactNumber: '0917 555 0101',
        email: 'store@example.com',
        tin: '123',
        businessRegistrationNo: 'DTI-1',
      }),
    )
    expect(lines.map((line) => line.label)).toEqual(['Tel', 'Email', 'TIN', 'Reg. No.'])
  })

  it('keeps the address lines in order, skipping a blank first line', () => {
    expect(
      storeProfileLines(profile({ addressLine2: 'Cabanatuan City' })).map((l) => l.value),
    ).toEqual(['Cabanatuan City'])
    expect(
      storeProfileLines(profile({ addressLine1: 'A', addressLine2: 'B' })).map((l) => l.value),
    ).toEqual(['A', 'B'])
  })

  it('does not repeat the trading name as a registered name', () => {
    // Printing the same name twice reads as a mistake, not as detail.
    expect(storeProfileLines(profile({ registeredName: 'Violy Store' }))).toEqual([])
    expect(storeProfileLines(profile({ registeredName: '  Violy Store  ' }))).toEqual([])
    expect(storeProfileLines(profile({ registeredName: 'VIOLY GEN. MDSE.' }))).toEqual([
      { label: null, value: 'VIOLY GEN. MDSE.' },
    ])
  })

  it('trims what it prints', () => {
    expect(storeProfileLines(profile({ tin: '  123  ' }))).toEqual([
      { label: 'TIN', value: '123' },
    ])
  })
})
