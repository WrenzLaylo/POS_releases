// @vitest-environment jsdom

import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { SaleTabs } from '@/app/history/[id]/SaleTabs'

const { push } = vi.hoisted(() => ({ push: vi.fn() }))

vi.mock('next/navigation', () => ({ useRouter: () => ({ push }) }))

beforeEach(() => push.mockClear())

describe('SaleTabs', () => {
  it('offers two tabs on an ordinary sale', () => {
    render(<SaleTabs saleId={4961} active="summary" />)

    expect(screen.getAllByRole('tab').map((tab) => tab.textContent)).toEqual([
      'Summary',
      'Receipt',
    ])
  })

  // The rule: every sale has a receipt, only a delivery order has a note, and
  // the note route 404s without one. A tab that leads to a 404 is worse than
  // no tab at all.
  it('offers the delivery note only on a delivery order', () => {
    render(<SaleTabs saleId={4962} active="summary" hasDeliveryNote />)

    expect(screen.getAllByRole('tab').map((tab) => tab.textContent)).toEqual([
      'Summary',
      'Receipt',
      'Delivery note',
    ])
  })

  it('navigates to each document by its route constant', async () => {
    const user = userEvent.setup()
    render(<SaleTabs saleId={4962} active="summary" hasDeliveryNote />)

    await user.click(screen.getByRole('tab', { name: 'Delivery note' }))
    expect(push).toHaveBeenCalledWith('/history/4962/delivery-note')

    await user.click(screen.getByRole('tab', { name: 'Receipt' }))
    expect(push).toHaveBeenCalledWith('/history/4962/receipt')
  })

  it('goes back to the summary from a document', async () => {
    const user = userEvent.setup()
    render(<SaleTabs saleId={4962} active="delivery-note" hasDeliveryNote />)

    expect(screen.getByRole('tab', { name: 'Delivery note' })).toHaveAttribute(
      'aria-selected',
      'true',
    )

    await user.click(screen.getByRole('tab', { name: 'Summary' }))
    expect(push).toHaveBeenCalledWith('/history/4962')
  })
})
