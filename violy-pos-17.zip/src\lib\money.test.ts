import { describe, it, expect } from 'vitest'
import { toCentavos, toPesos, formatPeso, lineTotal, parsePesoInput } from '@/lib/money'

describe('toCentavos', () => {
  it('converts a peso amount to whole centavos', () => {
    expect(toCentavos(32.5)).toBe(3250)
    expect(toCentavos(1400)).toBe(140000)
  })

  it('rounds away float representation error', () => {
    expect(toCentavos(0.1 + 0.2)).toBe(30)
    expect(toCentavos(19.99)).toBe(1999)
  })
})

describe('toPesos', () => {
  it('converts centavos back to pesos', () => {
    expect(toPesos(3250)).toBe(32.5)
  })
})

describe('formatPeso', () => {
  it('formats with two decimals and thousands separators', () => {
    expect(formatPeso(143250)).toBe('₱1,432.50')
    expect(formatPeso(3250)).toBe('₱32.50')
    expect(formatPeso(0)).toBe('₱0.00')
  })

  it('sums that motivated integer storage stay exact', () => {
    expect(formatPeso(140000 + 3250)).toBe('₱1,432.50')
  })

  it('formats negative amounts', () => {
    expect(formatPeso(-3250)).toBe('-₱32.50')
  })
})

describe('lineTotal', () => {
  it('multiplies price by a whole quantity', () => {
    expect(lineTotal(3250, 3)).toBe(9750)
  })

  it('multiplies price by a fractional kilo quantity', () => {
    expect(lineTotal(3250, 2.5)).toBe(8125)
  })

  it('rounds a fractional result to whole centavos', () => {
    expect(lineTotal(3250, 0.33)).toBe(1073)
  })
})

describe('parsePesoInput', () => {
  it('accepts the way a person actually types money', () => {
    expect(parsePesoInput('1000')).toBe(100000)
    expect(parsePesoInput('1,000')).toBe(100000)
    expect(parsePesoInput('1,000.50')).toBe(100050)
    expect(parsePesoInput('12,345,678')).toBe(1234567800)
    expect(parsePesoInput(' 1 000 ')).toBe(100000)
    expect(parsePesoInput('0')).toBe(0)
  })

  it('returns null rather than a silent zero for anything it cannot parse', () => {
    for (const bad of ['', '   ', 'abc', '1.2.3', '1,00,0.999', '-500', '₱500', '1e3']) {
      expect(parsePesoInput(bad)).toBeNull()
    }
  })

  it('rejects more than two decimal places instead of rounding them away', () => {
    expect(parsePesoInput('10.555')).toBeNull()
    expect(parsePesoInput('10.55')).toBe(1055)
  })
})
