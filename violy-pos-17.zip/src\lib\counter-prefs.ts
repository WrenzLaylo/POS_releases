/**
 * Preferences that belong to the laptop rather than to the shop.
 *
 * These live in `localStorage`, not the database, because they answer "how
 * does this machine behave" rather than "what is true about the business".
 * Nothing here is data: losing the lot costs a few taps, and a second machine
 * is entitled to a different answer.
 *
 * Every reader must handle the key being ABSENT, and absent must mean the
 * safer of the two answers — see `oversellWarningOn` below. `typeof window`
 * is checked because these modules are imported by components that also
 * render on the server pass, where `localStorage` does not exist.
 */

export const OVERSELL_WARNING_KEY = 'violy.warn-oversell'

/**
 * Whether the counter stops to ask before a line takes stock below zero.
 *
 * Defaults ON — an absent key means "warn" — so the warning is only ever
 * silenced deliberately.
 *
 * It is silenceable at all because of what the shop's data actually looks
 * like: stock has not been counted in yet, so nearly every product reads 0,
 * and the warning fires on essentially every line of every sale. A dialog
 * that appears every single time is not a warning, it is a keystroke — she
 * learns to dismiss it without reading, and it stops working on the day it
 * would have mattered. Better to let her turn it off knowingly and turn it
 * back on from Settings once stock is counted.
 */
export function oversellWarningOn(): boolean {
  if (typeof window === 'undefined') return true
  return window.localStorage.getItem(OVERSELL_WARNING_KEY) !== 'off'
}

export function setOversellWarning(on: boolean): void {
  if (typeof window === 'undefined') return
  window.localStorage.setItem(OVERSELL_WARNING_KEY, on ? 'on' : 'off')
}

export const RECEIPT_PRINTER_KEY = 'violy.receipt-printer'

/**
 * Which printer receipts go to, chosen once in Settings.
 *
 * Empty means "whatever Windows calls the default", which is the right answer
 * for a shop with one printer and the only answer available before she has
 * picked. It is stored per machine because it names a device attached to that
 * machine — the same reason the stock warning lives here.
 */
export function receiptPrinter(): string {
  if (typeof window === 'undefined') return ''
  return window.localStorage.getItem(RECEIPT_PRINTER_KEY) ?? ''
}

export function setReceiptPrinter(name: string): void {
  if (typeof window === 'undefined') return
  if (name === '') window.localStorage.removeItem(RECEIPT_PRINTER_KEY)
  else window.localStorage.setItem(RECEIPT_PRINTER_KEY, name)
}
