'use server'

import { prisma } from '@/lib/db'
import { DELIVER, ROUTES, bookEntry } from '@/lib/routes'

/**
 * A single command-palette hit. `href` is always a route the palette can
 * navigate to via `next/link` — this action reads only, it never triggers a
 * write, so there is nothing here that could commit money.
 */
export type SearchResult = {
  kind: 'workspace' | 'customer' | 'product'
  id: string
  label: string
  hint?: string
  href: string
}

const WORKSPACES: readonly { id: string; label: string; href: string }[] = [
  { id: 'counter', label: 'Counter', href: ROUTES.counter },
  { id: 'book', label: 'Book', href: ROUTES.book },
  { id: 'stock', label: 'Stock', href: ROUTES.stock },
  { id: 'dashboard', label: 'Dashboard', href: ROUTES.dashboard },
  // Not a workspace, but the one screen with no home in the rail — it is
  // nested under Counter, so nothing in the navigation names it. Typing
  // "deliver" is how somebody who has heard it exists finds it.
  { id: 'deliver', label: 'Deliver to a customer', href: DELIVER },
]

const MAX_CUSTOMERS = 8
const MAX_PRODUCTS = 8
const MAX_TOTAL = 20

/**
 * Read-only lookup for the ⌘K command palette: workspaces, customers, and
 * products whose name matches `query`. Never writes, so there is no
 * `revalidatePath` call and no revalidation concern here at all.
 *
 * A blank/whitespace query returns `[]` rather than everything — the palette
 * should never dump the whole customer or product list. Customers and
 * products are each capped at 8, and the combined result is capped at 20 so
 * the palette can never render an unbounded list.
 */
export async function searchEverything(query: string): Promise<SearchResult[]> {
  const q = query.trim()
  if (!q) return []

  const needle = q.toLowerCase()

  const workspaceResults: SearchResult[] = WORKSPACES.filter((workspace) =>
    workspace.label.toLowerCase().includes(needle),
  ).map((workspace) => ({
    kind: 'workspace',
    id: workspace.id,
    label: workspace.label,
    href: workspace.href,
  }))

  const [customers, products] = await Promise.all([
    prisma.customer.findMany({
      // SQLite's LIKE is already case-insensitive for plain ASCII, and Prisma
      // does not support `mode: 'insensitive'` on this provider (see
      // products.ts's listAllProducts for the same note).
      where: { isArchived: false, name: { contains: q } },
      select: { id: true, name: true },
      orderBy: { name: 'asc' },
      take: MAX_CUSTOMERS,
    }),
    prisma.product.findMany({
      where: { isArchived: false, name: { contains: q } },
      select: { id: true, name: true, unit: true },
      orderBy: { name: 'asc' },
      take: MAX_PRODUCTS,
    }),
  ])

  const customerResults: SearchResult[] = customers.map((customer) => ({
    kind: 'customer',
    id: String(customer.id),
    label: customer.name,
    hint: 'Customer',
    href: bookEntry(customer.id),
  }))

  const productResults: SearchResult[] = products.map((product) => ({
    kind: 'product',
    id: String(product.id),
    label: product.name,
    hint: product.unit,
    // Same pattern NotificationBell uses for a low-stock hit: built from
    // ROUTES.stock, not a literal path, and lands on the filtered row
    // instead of an unfiltered list.
    href: `${ROUTES.stock}?q=${encodeURIComponent(product.name)}`,
  }))

  return [...workspaceResults, ...customerResults, ...productResults].slice(0, MAX_TOTAL)
}
