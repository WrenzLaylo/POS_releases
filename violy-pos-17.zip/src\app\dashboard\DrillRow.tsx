import Link from 'next/link'
import type { ReactNode } from 'react'
import { Icon } from '@/components/ui/Icon'
import { cn } from '@/lib/cn'

/**
 * A dashboard row that goes somewhere.
 *
 * Every figure on this page answers a question, and the answer is always on
 * another screen — "₱2 left of AMO Gold Mix" is really "go re-order this".
 * Before, they were all dead text and the reader had to navigate by hand to
 * whichever screen they guessed held the detail.
 *
 * The chevron only appears on hover and focus. Twenty permanent chevrons turn
 * a page of figures into a page of chrome; the pointer and the hover wash
 * already say the row is live, and the chevron confirms it at the moment of
 * acting.
 */
export function DrillRow({
  href,
  label,
  value,
  className,
}: {
  href: string
  label: ReactNode
  value: ReactNode
  className?: string
}) {
  return (
    <Link
      href={href}
      className={cn(
        'group -mx-2 flex items-baseline justify-between gap-3 rounded-control px-2 py-1',
        'transition-colors duration-150 hover:bg-surface-sunk',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent',
        className,
      )}
    >
      <span className="flex min-w-0 items-baseline gap-1 text-sm text-ink-muted">
        <span className="truncate">{label}</span>
        <Icon
          name="chevron"
          className="h-3 w-3 shrink-0 self-center opacity-0 transition-opacity duration-150 group-hover:opacity-60 group-focus-visible:opacity-60"
        />
      </span>
      <span className="shrink-0">{value}</span>
    </Link>
  )
}

/** The same affordance around a whole block, e.g. a hero figure. */
export function DrillBlock({
  href,
  children,
  className,
}: {
  href: string
  children: ReactNode
  className?: string
}) {
  return (
    <Link
      href={href}
      className={cn(
        'group -mx-2 block rounded-control px-2 py-1 transition-colors duration-150',
        'hover:bg-surface-sunk focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent',
        className,
      )}
    >
      {children}
    </Link>
  )
}
