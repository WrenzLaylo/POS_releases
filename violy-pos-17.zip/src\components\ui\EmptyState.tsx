import type { ReactNode } from 'react'
import { cn } from '@/lib/cn'

/** One empty-message treatment at a contrast that actually passes AA. The
 *  `text-slate-400` this replaces measured ~2.8:1. */
export function EmptyState({
  className,
  children,
}: {
  className?: string
  children: ReactNode
}) {
  return (
    <p
      className={cn(
        // `ink-muted`, not `ink-subtle`: this sits on a sunk well, where
        // subtle measures 3.8 and fails AA. See the ink notes in globals.css.
        'rounded-card border border-line bg-surface-sunk px-5 py-8 text-center text-sm text-ink-muted',
        className,
      )}
    >
      {children}
    </p>
  )
}
