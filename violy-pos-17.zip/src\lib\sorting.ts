/**
 * Sorting a table by clicking its column heading.
 *
 * The state lives in the URL rather than in component state, for the same
 * reason paging does: a sorted view survives a refresh, can be linked to, and
 * the browser back button undoes it. It also has to be in the URL for the
 * server-paginated tables — sorting only page 3 of 12 in the browser would
 * reorder nine rows out of a hundred and look broken.
 */

export type SortDirection = 'asc' | 'desc'

export type SortState<TKey extends string> = {
  key: TKey
  direction: SortDirection
}

export function isSortDirection(value: string | undefined): value is SortDirection {
  return value === 'asc' || value === 'desc'
}

/**
 * Reads `?sort=&dir=` into a sort state, falling back to the table's default
 * whenever the parameters are missing or name a column that does not exist.
 * An odd query string must never produce an error or an empty table.
 */
export function parseSort<TKey extends string>(
  rawKey: string | undefined,
  rawDirection: string | undefined,
  allowed: readonly TKey[],
  fallback: SortState<TKey>,
): SortState<TKey> {
  const key = allowed.includes(rawKey as TKey) ? (rawKey as TKey) : fallback.key
  const direction = isSortDirection(rawDirection) ? rawDirection : fallback.direction
  return { key, direction }
}

/**
 * What clicking a heading should do next: sort by it if it is not the current
 * column, otherwise flip the direction.
 *
 * A first click sorts ascending EXCEPT on columns where the interesting end is
 * the top — nobody opens a stock table wanting to see the fullest shelf first.
 * Those pass `descendingFirst`.
 */
export function nextSort<TKey extends string>(
  current: SortState<TKey>,
  key: TKey,
  descendingFirst = false,
): SortState<TKey> {
  if (current.key !== key) return { key, direction: descendingFirst ? 'desc' : 'asc' }
  return { key, direction: current.direction === 'asc' ? 'desc' : 'asc' }
}

/** Compares two values of the same shape, nulls last regardless of direction. */
export function compareValues(
  a: string | number | Date | null,
  b: string | number | Date | null,
  direction: SortDirection,
): number {
  // Nulls sort last either way: "never paid" is not a small date, it is the
  // absence of one, and burying it under a descending sort would hide exactly
  // the rows worth looking at.
  if (a === null && b === null) return 0
  if (a === null) return 1
  if (b === null) return -1

  let result: number
  if (typeof a === 'string' && typeof b === 'string') result = a.localeCompare(b)
  else if (a instanceof Date && b instanceof Date) result = a.getTime() - b.getTime()
  else result = Number(a) - Number(b)

  return direction === 'asc' ? result : -result
}
