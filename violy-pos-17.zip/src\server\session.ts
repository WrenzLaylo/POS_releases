import { randomBytes } from 'node:crypto'
import { cookies } from 'next/headers'
import { prisma } from '@/lib/db'
import { CONFIRMATION_MINUTES, NEEDS_PASSWORD } from '@/lib/auth-gate'

/**
 * Reading and writing the signed-in state.
 *
 * Deliberately NOT a `'use server'` module. Everything marked `'use server'`
 * becomes an endpoint the browser may call by name; these are helpers the app
 * calls on itself, and `endSession` in particular has no business being
 * reachable from outside. The Server Actions live in `auth.ts` and call into
 * this.
 */

export const SESSION_COOKIE = 'violy_session'

/** A remembered session lasts a year — long enough to mean "until you sign
 *  out", short enough that an abandoned laptop eventually forgets. */
const REMEMBERED_DAYS = 365

/** An un-remembered one lasts a working day, so a shop that closes and
 *  reopens asks again, but a browser reload never does. */
const SESSION_HOURS = 14

export type SignedInUser = {
  id: number
  username: string
}

/**
 * Whether this shop has a login at all.
 *
 * No AppUser row means the till is open, exactly as it was before any of this
 * existed. That is what lets the update land on her laptop without locking a
 * working business out of its own counter: the login arrives switched off, and
 * Wrenz turns it on deliberately from Settings.
 */
export async function authIsEnabled(): Promise<boolean> {
  return (await prisma.appUser.count()) > 0
}

/**
 * Who is signed in on this laptop, or null.
 *
 * Expired sessions are deleted as they are found rather than left to
 * accumulate — this runs on nearly every request, so it is the natural place,
 * and a table of dead sessions is a table someone eventually has to explain.
 */
export async function getSession(): Promise<SignedInUser | null> {
  const jar = await cookies()
  const token = jar.get(SESSION_COOKIE)?.value
  if (!token) return null

  const session = await prisma.appSession.findUnique({
    where: { id: token },
    select: { id: true, expiresAt: true, user: { select: { id: true, username: true } } },
  })
  if (!session) return null

  if (session.expiresAt.getTime() <= Date.now()) {
    await prisma.appSession.delete({ where: { id: session.id } }).catch(() => {})
    return null
  }

  return session.user
}

/**
 * Starts a session and returns the cookie value to set.
 *
 * The token is 32 random bytes from `randomBytes`, not anything derived from
 * the user — it is a bearer credential, so its only job is to be unguessable.
 * It is stored server-side so that signing out can genuinely END it; a
 * self-contained token stays valid until it expires no matter what anyone does.
 */
export async function startSession(userId: number, remember: boolean): Promise<void> {
  const token = randomBytes(32).toString('base64url')
  const expiresAt = new Date(
    Date.now() +
      (remember ? REMEMBERED_DAYS * 24 * 60 * 60 * 1000 : SESSION_HOURS * 60 * 60 * 1000),
  )

  await prisma.appSession.create({
    data: { id: token, userId, remembered: remember, expiresAt },
  })

  const jar = await cookies()
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    // NOT `secure`. This app is served over plain HTTP on localhost, and a
    // secure cookie is silently dropped there — the sign-in would appear to
    // succeed and land straight back on the login screen, with nothing
    // reporting why.
    secure: false,
    path: '/',
    // A remembered session outlives the browser; an un-remembered one is a
    // session cookie and dies with it, which is the difference she ticked
    // the box for.
    ...(remember ? { expires: expiresAt } : {}),
  })
}

/** Ends this session everywhere: the row goes, so the cookie is worthless
 *  even if it survives somewhere. */
export async function endSession(): Promise<void> {
  const jar = await cookies()
  const token = jar.get(SESSION_COOKIE)?.value
  if (token) {
    await prisma.appSession.delete({ where: { id: token } }).catch(() => {})
  }
  jar.delete(SESSION_COOKIE)
}

/** Signs out every laptop for this user. Used after a password change or a
 *  recovery reset: whoever knew the old password should not still be inside. */
export async function endAllSessions(userId: number): Promise<void> {
  await prisma.appSession.deleteMany({ where: { userId } })
}

/**
 * Records that this laptop just proved it was still her.
 *
 * Stamped on the SESSION, not held in memory, so it survives the server
 * restarting mid-shift and cannot be forged by a second tab.
 */
export async function markConfirmed(): Promise<void> {
  const jar = await cookies()
  const token = jar.get(SESSION_COOKIE)?.value
  if (!token) return
  await prisma.appSession
    .update({ where: { id: token }, data: { confirmedAt: new Date() } })
    .catch(() => {})
}

/**
 * The gate for actions that can hide money.
 *
 * Returns null when the action may proceed, or the failure to hand straight
 * back to the caller. Written this way rather than as a throw so that a screen
 * which has not been taught to prompt still fails visibly instead of
 * proceeding — the safe direction if one is ever missed.
 *
 * Open shops pass through untouched: no login means no gate, or turning the
 * feature off would break voiding a sale.
 */
export async function confirmationGate(): Promise<{ ok: false; error: string } | null> {
  if (!(await authIsEnabled())) return null

  const jar = await cookies()
  const token = jar.get(SESSION_COOKIE)?.value
  if (!token) return { ok: false, error: NEEDS_PASSWORD }

  const session = await prisma.appSession.findUnique({
    where: { id: token },
    select: { confirmedAt: true, expiresAt: true },
  })
  if (!session || session.expiresAt.getTime() <= Date.now()) {
    return { ok: false, error: NEEDS_PASSWORD }
  }

  const confirmedAt = session.confirmedAt?.getTime() ?? 0
  const fresh = Date.now() - confirmedAt < CONFIRMATION_MINUTES * 60 * 1000
  return fresh ? null : { ok: false, error: NEEDS_PASSWORD }
}

/**
 * The guard for Server Actions that change something.
 *
 * The layout deciding not to render a screen is not access control — a signed
 * out browser can still POST to a Server Action by name. Every action that
 * writes calls this, and it throws rather than returning a result, so a call
 * site that forgets to check the answer still cannot proceed.
 */
export async function requireSession(): Promise<SignedInUser> {
  if (!(await authIsEnabled())) return { id: 0, username: '' }
  const user = await getSession()
  if (!user) throw new Error('NOT_SIGNED_IN')
  return user
}
