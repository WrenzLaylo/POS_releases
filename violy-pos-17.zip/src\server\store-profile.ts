'use server'

import { prisma } from '@/lib/db'
import type { StoreProfile } from '@prisma/client'
import type { ActionResult } from '@/lib/types'
import { ROUTES } from '@/lib/routes'
import { revalidateRoutes } from './revalidate'

/** The singleton's id. There is one shop. */
const PROFILE_ID = 1

/**
 * The shop's identity, creating the row on first read.
 *
 * Created rather than defaulted-in-memory so that the settings form always has
 * a real row to edit, and so a fresh install prints the same document as an
 * established one. Nothing has to remember to seed it.
 */
export async function getStoreProfile(): Promise<StoreProfile> {
  return prisma.storeProfile.upsert({
    where: { id: PROFILE_ID },
    create: { id: PROFILE_ID },
    update: {},
  })
}

export type StoreProfileInput = {
  name: string
  tagline: string
  registeredName: string
  addressLine1: string
  addressLine2: string
  contactNumber: string
  email: string
  tin: string
  businessRegistrationNo: string
}

export async function updateStoreProfile(
  input: StoreProfileInput,
): Promise<ActionResult<void>> {
  const name = input.name.trim()
  // The only required field. It heads every document, and a document headed by
  // nothing is not a document — everything else is legitimately blank until
  // the shop has it to hand.
  if (!name) return { ok: false, error: 'The store name is required.' }

  const data = {
    name,
    tagline: input.tagline.trim(),
    registeredName: input.registeredName.trim(),
    addressLine1: input.addressLine1.trim(),
    addressLine2: input.addressLine2.trim(),
    contactNumber: input.contactNumber.trim(),
    email: input.email.trim(),
    tin: input.tin.trim(),
    businessRegistrationNo: input.businessRegistrationNo.trim(),
  }

  try {
    await prisma.storeProfile.upsert({
      where: { id: PROFILE_ID },
      create: { id: PROFILE_ID, ...data },
      update: data,
    })
  } catch {
    return { ok: false, error: 'Could not save the store details.' }
  }

  // Every document in the app prints this, and they are spread across three
  // route families, so the whole shell is invalidated rather than one page.
  revalidateRoutes(
    [ROUTES.book, ROUTES.history, ROUTES.counter, ROUTES.dashboard, ROUTES.stock],
    { layout: true },
  )
  return { ok: true, data: undefined }
}
