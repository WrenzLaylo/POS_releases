import { describe, it, expect, beforeEach } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'
import { createOrder } from '@/server/orders'
import { voidSale, listSales } from '@/server/sales'
import {
  countDeliveriesAhead,
  listDeliveriesAhead,
  listDeliveriesToday,
  listDeliveryOrders,
} from '@/server/delivery-orders'

beforeEach(resetDb)

// Mid-afternoon, so "today" is unambiguous either side of the boundary.
const NOW = new Date(2026, 7, 24, 14, 30, 0)
const day = (offset: number) => new Date(2026, 7, 24 + offset)

async function makeProduct(name = 'Hog Grower (sako)') {
  const category = await prisma.category.upsert({
    where: { name: 'Pig Feeds' },
    create: { name: 'Pig Feeds' },
    update: {},
  })
  return prisma.product.create({
    data: {
      categoryId: category.id,
      name,
      unit: 'sako (50kg)',
      price: 201_000,
      costPrice: 180_000,
      stockQty: 500,
      lowStockThreshold: 5,
    },
  })
}

async function makeCustomer(name: string) {
  return prisma.customer.create({ data: { name } })
}

/** One booked load. Returns its sale id. */
async function book({
  customer,
  productId,
  deliverAt,
  deliverTo = 'Bagac',
  quantity = 2,
  cashPaidCentavos = 0,
  feeCentavos = 0,
}: {
  customer: number
  productId: number
  deliverAt: Date
  deliverTo?: string
  quantity?: number
  cashPaidCentavos?: number | null
  feeCentavos?: number
}) {
  const result = await createOrder({
    customerId: customer,
    lines: [{ productId, quantity }],
    cashPaidCentavos,
    delivery: { deliverAt, deliverTo, address: '', instructions: '', feeCentavos },
  })
  if (!result.ok) throw new Error(result.error)
  return result.data.saleId
}

describe('listDeliveryOrders', () => {
  it('splits at today, upcoming forwards and past backwards', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer('ADRIAN')

    const saturday = await book({ customer: customer.id, productId: product.id, deliverAt: day(2) })
    const today = await book({ customer: customer.id, productId: product.id, deliverAt: day(0) })
    const tomorrow = await book({ customer: customer.id, productId: product.id, deliverAt: day(1) })
    const yesterday = await book({ customer: customer.id, productId: product.id, deliverAt: day(-1) })
    const lastWeek = await book({ customer: customer.id, productId: product.id, deliverAt: day(-7) })

    const { upcoming, past } = await listDeliveryOrders(NOW)

    // Today counts as upcoming: at eight in the morning it is the most
    // urgent thing on the list, not something already handled.
    expect(upcoming.map((row) => row.saleId)).toEqual([today, tomorrow, saturday])
    expect(past.map((row) => row.saleId)).toEqual([yesterday, lastWeek])
  })

  it('leaves ordinary counter sales out of both lists', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer('ADRIAN')

    await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 1 }],
      cashPaidCentavos: null,
    })

    const { upcoming, past } = await listDeliveryOrders(NOW)
    expect(upcoming).toHaveLength(0)
    expect(past).toHaveLength(0)
  })

  // A voided delivery order is a load that is not going anywhere. Leaving it
  // on the list is worse than leaving it off — the void is exactly the thing
  // whoever loads the truck needs to have been told.
  it('drops a voided delivery order', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer('ADRIAN')
    const saleId = await book({ customer: customer.id, productId: product.id, deliverAt: day(1) })

    expect((await listDeliveryOrders(NOW)).upcoming).toHaveLength(1)

    const voided = await voidSale(saleId, 'Customer cancelled')
    expect(voided.ok).toBe(true)

    expect((await listDeliveryOrders(NOW)).upcoming).toHaveLength(0)
    expect(await countDeliveriesAhead(NOW)).toBe(0)
    expect(await listDeliveriesToday(NOW)).toHaveLength(0)
  })

  it('carries what is owed on each load, and what it is', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer('ADRIAN')
    await book({
      customer: customer.id,
      productId: product.id,
      deliverAt: day(1),
      quantity: 10,
      cashPaidCentavos: 0,
      feeCentavos: 30_000,
    })

    const [row] = (await listDeliveryOrders(NOW)).upcoming
    expect(row.customerName).toBe('ADRIAN')
    expect(row.deliverTo).toBe('Bagac')
    expect(row.totalCentavos).toBe(10 * 201_000 + 30_000)
    expect(row.deliveryFeeCentavos).toBe(30_000)
    expect(row.owedCentavos).toBe(10 * 201_000 + 30_000)
    expect(row.lines).toEqual([{ name: 'Hog Grower (sako)', unit: 'sako (50kg)', quantity: 10 }])
  })

  it('reports nothing owing on a load paid at the counter', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer('ADRIAN')
    await book({
      customer: customer.id,
      productId: product.id,
      deliverAt: day(1),
      cashPaidCentavos: null,
    })

    const [row] = (await listDeliveryOrders(NOW)).upcoming
    expect(row.owedCentavos).toBe(0)
  })

  it('caps the past list without capping what is coming', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer('ADRIAN')
    for (let index = 1; index <= 5; index += 1) {
      await book({ customer: customer.id, productId: product.id, deliverAt: day(-index) })
    }
    for (let index = 1; index <= 4; index += 1) {
      await book({ customer: customer.id, productId: product.id, deliverAt: day(index) })
    }

    const { upcoming, past } = await listDeliveryOrders(NOW, 2)
    expect(past).toHaveLength(2)
    expect(upcoming).toHaveLength(4)
  })
})

describe('listDeliveriesToday', () => {
  it('is today only — not tomorrow, and not yesterday', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer('ADRIAN')

    const today = await book({ customer: customer.id, productId: product.id, deliverAt: day(0) })
    await book({ customer: customer.id, productId: product.id, deliverAt: day(1) })
    await book({ customer: customer.id, productId: product.id, deliverAt: day(-1) })

    const rows = await listDeliveriesToday(NOW)
    expect(rows.map((row) => row.saleId)).toEqual([today])
  })

  // Deliberate: a delivery has no equivalent of an overdue account. The day
  // passes and the load either went or it did not, and nothing tells the app
  // which — so reporting yesterday's as outstanding would assert something
  // nobody said.
  it('does not accumulate yesterday the way an overdue balance would', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer('ADRIAN')
    await book({ customer: customer.id, productId: product.id, deliverAt: day(-3) })

    expect(await listDeliveriesToday(NOW)).toHaveLength(0)
  })
})

describe('listDeliveriesAhead', () => {
  it('looks a week out from today and caps what it names', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer('ADRIAN')

    await book({ customer: customer.id, productId: product.id, deliverAt: day(0) })
    await book({ customer: customer.id, productId: product.id, deliverAt: day(3) })
    await book({ customer: customer.id, productId: product.id, deliverAt: day(6) })
    // Outside the window.
    await book({ customer: customer.id, productId: product.id, deliverAt: day(20) })

    expect(await listDeliveriesAhead(7, NOW, 5)).toHaveLength(3)
    expect(await listDeliveriesAhead(7, NOW, 2)).toHaveLength(2)

    // The count is everything booked from today onward, so a panel showing
    // two can honestly say there are four.
    expect(await countDeliveriesAhead(NOW)).toBe(4)
  })
})

describe('the Kind filter on the sales list', () => {
  it('separates deliveries from counter sales without touching status', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer('ADRIAN')

    const delivered = await book({
      customer: customer.id,
      productId: product.id,
      deliverAt: day(1),
      cashPaidCentavos: 0,
    })
    const counter = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 1 }],
      cashPaidCentavos: null,
    })
    expect(counter.ok).toBe(true)
    if (!counter.ok) return

    const all = await listSales({})
    expect(all.rows).toHaveLength(2)

    const deliveries = await listSales({ kind: 'delivery' })
    expect(deliveries.rows.map((row) => row.id)).toEqual([delivered])

    const counterOnly = await listSales({ kind: 'counter' })
    expect(counterOnly.rows.map((row) => row.id)).toEqual([counter.data.saleId])
  })

  // The reason Kind is its own axis rather than another Status option: both
  // questions have to be askable at once.
  it('combines with a payment status rather than replacing it', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer('ADRIAN')

    const onUtang = await book({
      customer: customer.id,
      productId: product.id,
      deliverAt: day(1),
      cashPaidCentavos: 0,
    })
    // A delivery that was paid for in full.
    await book({
      customer: customer.id,
      productId: product.id,
      deliverAt: day(2),
      cashPaidCentavos: null,
    })

    const creditDeliveries = await listSales({ kind: 'delivery', status: 'credit' })
    expect(creditDeliveries.rows.map((row) => row.id)).toEqual([onUtang])
  })
})
