import { Prisma } from '@prisma/client'

/**
 * The pre-write `findUnique` checks in customers.ts and ledger.ts catch the
 * common not-found/duplicate cases, but a concurrent request can still slip
 * through between the check and the write. This reads the Prisma error code
 * so that race loses gracefully — as an ActionResult, not an uncaught throw.
 *
 * Lives here rather than in either 'use server' file because a 'use server'
 * file may only export async functions, so it could not be shared from
 * either module directly.
 */
export function prismaErrorCode(error: unknown): string | undefined {
  return error instanceof Prisma.PrismaClientKnownRequestError ? error.code : undefined
}
