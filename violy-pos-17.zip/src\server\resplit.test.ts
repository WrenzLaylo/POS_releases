import { describe, it, expect, beforeEach } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'
import { createPlan, convertBalanceToPlan, listPlans, resplitPlan } from '@/server/utang'
import { getBalance, recordPayment, setOpeningBalance } from '@/server/ledger'

beforeEach(resetDb)

const STARTED = new Date(2026, 7, 25)

async function customer(name = 'ADRIAN') {
  return prisma.customer.create({ data: { name } })
}

/** ₱25,000 due in one month, no interest — the case this exists for. */
async function onePlan(customerId: number, overrides: Partial<Parameters<typeof createPlan>[0]> = {}) {
  const result = await createPlan({
    customerId,
    principalCentavos: 2_500_000,
    interestMethod: 'FLAT_ONCE',
    interestRateBps: 0,
    termMonths: 1,
    startedAt: STARTED,
    ...overrides,
  })
  if (!result.ok) throw new Error(result.error)
  return result.data.planId
}

describe('resplitPlan', () => {
  /**
   * The whole point: ₱25,000 due in one month, spread over five, without
   * moving the day it falls on. Before this the only route was voiding and
   * retyping, which silently double-charges a plan made by putting an existing
   * balance on terms.
   */
  it('spreads the same debt over more months', async () => {
    const her = await customer()
    const planId = await onePlan(her.id)

    const result = await resplitPlan(planId, { termMonths: 5 })
    expect(result.ok).toBe(true)
    if (!result.ok) return

    const plans = await listPlans(her.id)
    const live = plans.filter((plan) => !plan.isVoided)
    expect(live).toHaveLength(1)
    expect(live[0].termMonths).toBe(5)
    expect(live[0].totalCentavos).toBe(2_500_000)
    expect(live[0].installments.map((each) => each.amountCentavos)).toEqual([
      500_000, 500_000, 500_000, 500_000, 500_000,
    ])
  })

  /** The day of the month must not move. She agreed to pay on the 25th. */
  it('keeps the payment day where it was', async () => {
    const her = await customer()
    const planId = await onePlan(her.id)
    const before = (await listPlans(her.id))[0].installments[0].dueAt.getDate()

    const result = await resplitPlan(planId, { termMonths: 5 })
    expect(result.ok).toBe(true)

    const live = (await listPlans(her.id)).filter((plan) => !plan.isVoided)[0]
    expect(live.installments.map((each) => each.dueAt.getDate())).toEqual([
      before, before, before, before, before,
    ])
    expect(live.startedAt.getTime()).toBe(STARTED.getTime())
  })

  /**
   * The balance is the thing that must not drift. Re-splitting a debt is a
   * change of terms, not a change of what is owed — with no interest, the
   * customer owes exactly what she owed a moment ago.
   */
  it('does not change what is owed when nothing about the money changed', async () => {
    const her = await customer()
    const planId = await onePlan(her.id)
    const before = await getBalance(her.id)

    const result = await resplitPlan(planId, { termMonths: 5 })
    expect(result.ok).toBe(true)

    expect(await getBalance(her.id)).toBe(before)
  })

  /**
   * The trap the void-and-retype workaround had. A plan made by putting an
   * EXISTING balance on terms posted no charge of its own — the debt was
   * already on the ledger. Voiding it and calling createPlan would charge the
   * customer a second time for money she already owed.
   */
  it('does not charge a converted plan twice', async () => {
    const her = await customer()
    const opening = await setOpeningBalance({
      customerId: her.id,
      amountCentavos: 2_500_000,
      occurredAt: STARTED,
    })
    expect(opening.ok).toBe(true)

    const converted = await convertBalanceToPlan({
      customerId: her.id,
      interestMethod: 'FLAT_ONCE',
      interestRateBps: 0,
      termMonths: 1,
      startedAt: STARTED,
    })
    expect(converted.ok).toBe(true)
    if (!converted.ok) return

    const before = await getBalance(her.id)
    expect(before).toBe(2_500_000)

    const result = await resplitPlan(converted.data.planId, { termMonths: 5 })
    expect(result.ok).toBe(true)

    // Still ₱25,000. Not ₱50,000.
    expect(await getBalance(her.id)).toBe(2_500_000)
  })

  /**
   * Money she has already handed over belongs to the debt, not to the shape
   * of the schedule. Voiding a plan un-links its payments to account level;
   * a re-split must carry them across or the new plan reports the whole sum
   * outstanding while the balance says otherwise.
   */
  it('carries what she has already paid onto the new terms', async () => {
    const her = await customer()
    const planId = await onePlan(her.id)

    const paid = await recordPayment({
      customerId: her.id,
      amountCentavos: 1_000_000,
      occurredAt: STARTED,
      planId,
    })
    expect(paid.ok).toBe(true)

    const result = await resplitPlan(planId, { termMonths: 5 })
    expect(result.ok).toBe(true)

    const live = (await listPlans(her.id)).filter((plan) => !plan.isVoided)[0]
    expect(live.paidCentavos).toBe(1_000_000)
    expect(live.outstandingCentavos).toBe(1_500_000)
  })

  /**
   * The old plan stays in the record, voided. A deleted money row is a ledger
   * that has stopped being evidence — the same reason a voided entry is struck
   * through rather than removed.
   */
  it('leaves the old terms visible, voided', async () => {
    const her = await customer()
    const planId = await onePlan(her.id)

    const result = await resplitPlan(planId, { termMonths: 5 })
    expect(result.ok).toBe(true)

    const plans = await listPlans(her.id)
    expect(plans).toHaveLength(2)
    const old = plans.find((plan) => plan.id === planId)
    expect(old?.isVoided).toBe(true)
    expect(old?.termMonths).toBe(1)
  })

  it('moves the balance by exactly the interest when terms add some', async () => {
    const her = await customer()
    const planId = await onePlan(her.id)
    const before = await getBalance(her.id)

    // 5 months at 1% per month, flat: ₱25,000 × 1% × 5 = ₱1,250.
    const result = await resplitPlan(planId, {
      termMonths: 5,
      interestMethod: 'FLAT_MONTHLY',
      interestRateBps: 100,
    })
    expect(result.ok).toBe(true)

    const live = (await listPlans(her.id)).filter((plan) => !plan.isVoided)[0]
    expect(live.interestCentavos).toBe(125_000)
    expect(await getBalance(her.id)).toBe(before + 125_000)
  })

  it('refuses a plan that is already voided', async () => {
    const her = await customer()
    const planId = await onePlan(her.id)
    const first = await resplitPlan(planId, { termMonths: 5 })
    expect(first.ok).toBe(true)

    const again = await resplitPlan(planId, { termMonths: 3 })
    expect(again.ok).toBe(false)
  })

  it('refuses terms it cannot build a schedule from', async () => {
    const her = await customer()
    const planId = await onePlan(her.id)

    expect((await resplitPlan(planId, { termMonths: 0 })).ok).toBe(false)
    expect((await resplitPlan(planId, { termMonths: -1 })).ok).toBe(false)

    // And nothing was touched on the way to refusing.
    const plans = await listPlans(her.id)
    expect(plans).toHaveLength(1)
    expect(plans[0].isVoided).toBe(false)
    expect(plans[0].termMonths).toBe(1)
  })

  it('refuses a plan that does not exist', async () => {
    expect((await resplitPlan(9999, { termMonths: 5 })).ok).toBe(false)
  })
})
