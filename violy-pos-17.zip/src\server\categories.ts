'use server'

import { prisma } from '@/lib/db'
import type { ActionResult } from '@/lib/types'
import { ROUTES } from '@/lib/routes'
import { revalidateRoutes } from './revalidate'

export type CategoryRow = {
  id: number
  name: string
  sortOrder: number
  /** How many products sit in it — what decides whether removing it has to
   *  ask where they should go. */
  productCount: number
}

/**
 * The category already on file under this name, if there is one.
 *
 * Same rule and same reason as products, customers and suppliers: `@@unique`
 * on the column is not enough, because SQLite compares TEXT case-sensitively
 * unless declared `COLLATE NOCASE`, so "Atlas" and "atlas" would both be
 * allowed and then split one brand's products across two chips on the counter.
 */
async function findByName(
  name: string,
  excludeId?: number,
): Promise<{ id: number; name: string } | null> {
  const needle = name.trim().toLowerCase()
  if (!needle) return null

  const candidates = await prisma.category.findMany({
    where: { name: { contains: needle } },
    select: { id: true, name: true },
  })
  return (
    candidates.find((row) => row.name.trim().toLowerCase() === needle && row.id !== excludeId) ??
    null
  )
}

function parseName(raw: string): string | { error: string } {
  const name = raw.trim()
  if (!name) return { error: 'Category name is required.' }
  if (name.length > 60) return { error: 'That name is too long.' }
  return name
}

export async function listCategoriesWithCounts(): Promise<CategoryRow[]> {
  const rows = await prisma.category.findMany({
    select: { id: true, name: true, sortOrder: true, _count: { select: { products: true } } },
    orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
  })
  return rows.map((row) => ({
    id: row.id,
    name: row.name,
    sortOrder: row.sortOrder,
    productCount: row._count.products,
  }))
}

/**
 * Adds a category.
 *
 * New ones sort to the END rather than into the middle. `sortOrder` drives the
 * chip strip on the counter, and quietly reordering a strip she has learned the
 * shape of is worse than a new chip appearing predictably at the far right.
 */
export async function createCategory(rawName: string): Promise<ActionResult<{ id: number }>> {
  const name = parseName(rawName)
  if (typeof name !== 'string') return { ok: false, error: name.error }

  const clash = await findByName(name)
  if (clash) return { ok: false, error: `${clash.name} is already a category.` }

  let id: number
  try {
    const last = await prisma.category.findFirst({
      orderBy: { sortOrder: 'desc' },
      select: { sortOrder: true },
    })
    const created = await prisma.category.create({
      data: { name, sortOrder: (last?.sortOrder ?? 0) + 1 },
    })
    id = created.id
  } catch {
    return { ok: false, error: 'Could not save that category.' }
  }

  revalidateRoutes([ROUTES.stock, ROUTES.counter, ROUTES.book], { layout: true })
  return { ok: true, data: { id } }
}

/**
 * Renames a category.
 *
 * Renaming is safe where deleting is not: every product keeps pointing at the
 * same row, so the whole catalogue follows the new name at once. This is the
 * answer to "Chicken should really be Gamefowl".
 */
export async function renameCategory(id: number, rawName: string): Promise<ActionResult> {
  if (!Number.isInteger(id) || id <= 0) return { ok: false, error: 'Category id is required.' }

  const name = parseName(rawName)
  if (typeof name !== 'string') return { ok: false, error: name.error }

  const existing = await prisma.category.findUnique({ where: { id } })
  if (!existing) return { ok: false, error: 'Category not found.' }

  // Excluding itself, or saving a category without changing its name would
  // report it as a duplicate of itself.
  const clash = await findByName(name, id)
  if (clash) return { ok: false, error: `${clash.name} is already a category.` }

  try {
    await prisma.category.update({ where: { id }, data: { name } })
  } catch {
    return { ok: false, error: 'Could not rename that category.' }
  }

  revalidateRoutes([ROUTES.stock, ROUTES.counter, ROUTES.book], { layout: true })
  return { ok: true, data: undefined }
}

/**
 * Removes a category. Its products are moved, never deleted.
 *
 * There is no archive flag here, unlike products and customers, and no need
 * for one: a category holds no history of its own. What it does hold is
 * products, and `Product.categoryId` is required — so a category with anything
 * in it cannot simply go.
 *
 * `moveToCategoryId` is how it goes anyway. The products are reassigned FIRST,
 * inside the same transaction as the delete, so there is no moment at which a
 * product points at a category on its way out, and a failed move removes
 * nothing.
 *
 * Still refused when the category holds products and no destination is named.
 * Where a sack belongs is the shop's decision, and silently sweeping forty of
 * them into an "Other" bucket is a worse answer than asking.
 */
export async function deleteCategory(
  id: number,
  moveToCategoryId?: number,
): Promise<ActionResult> {
  if (!Number.isInteger(id) || id <= 0) return { ok: false, error: 'Category id is required.' }

  const existing = await prisma.category.findUnique({
    where: { id },
    select: { id: true, name: true, _count: { select: { products: true } } },
  })
  if (!existing) return { ok: false, error: 'Category not found.' }

  const count = existing._count.products

  if (count > 0 && moveToCategoryId === undefined) {
    return {
      ok: false,
      error: `${existing.name} still has ${count} product${count === 1 ? '' : 's'} in it. Choose where they should go first.`,
    }
  }

  if (moveToCategoryId !== undefined) {
    if (!Number.isInteger(moveToCategoryId) || moveToCategoryId <= 0) {
      return { ok: false, error: 'Choose a category to move the products to.' }
    }
    // Into itself is not a move: the products would be pointed at the very row
    // about to be deleted, taking the catalogue with it.
    if (moveToCategoryId === id) {
      return { ok: false, error: 'Choose a different category to move the products to.' }
    }
    const destination = await prisma.category.findUnique({ where: { id: moveToCategoryId } })
    if (!destination) return { ok: false, error: 'That destination category no longer exists.' }
  }

  try {
    await prisma.$transaction(async (tx) => {
      if (moveToCategoryId !== undefined && count > 0) {
        await tx.product.updateMany({
          where: { categoryId: id },
          data: { categoryId: moveToCategoryId },
        })
      }

      // A category used to also be referenceable as a discount scope, and had
      // to be disconnected from every customer first or the delete failed on a
      // relation nobody thinks about when they press the button. Standing
      // per-customer discounts were removed on 24 Aug 2026 and the join tables
      // dropped with them, so products are the only thing left holding a
      // category — handled above.
      await tx.category.delete({ where: { id } })
    })
  } catch {
    return { ok: false, error: 'Could not remove that category. Nothing was changed.' }
  }

  revalidateRoutes([ROUTES.stock, ROUTES.counter, ROUTES.book], { layout: true })
  return { ok: true, data: undefined }
}
