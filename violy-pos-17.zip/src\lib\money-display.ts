/**
 * Display-tone decisions for money figures. Pure, so it is unit-tested
 * rather than eyeballed; the `Money` component is a thin wrapper over this.
 */

export type MoneyTone = 'owed' | 'in' | 'zero' | 'neutral'

/**
 * Tone for a customer *balance* in centavos. Positive means the customer
 * owes the store (utang), so it reads red; negative means they are in
 * credit, so it reads green; exactly zero is settled and de-emphasised.
 *
 * Only for balances. A cash-received or benta figure is always `'in'` or
 * `'neutral'` respectively regardless of sign — the caller states that.
 */
export function balanceTone(centavos: number): MoneyTone {
  if (centavos > 0) return 'owed'
  if (centavos < 0) return 'in'
  return 'zero'
}

export type SaleStatus = 'cash' | 'credit' | 'partial' | 'charge-voided' | 'voided'

/**
 * Describes how a sale was recorded, without pretending that later customer
 * payments are allocated to a specific invoice. "Cash", "Credit" and
 * "Partial cash + credit" are transaction types; they remain truthful even
 * when the customer's overall account balance changes later.
 */
export function saleStatus(sale: {
  hasLiveCharge: boolean
  cashPaidCentavos: number
  totalCentavos: number
  isVoided?: boolean
}): SaleStatus {
  if (sale.isVoided) return 'voided'
  if (sale.hasLiveCharge) {
    return sale.cashPaidCentavos > 0 ? 'partial' : 'credit'
  }
  if (sale.cashPaidCentavos >= sale.totalCentavos) return 'cash'
  return 'charge-voided'
}
