import { describe, expect, it } from 'vitest'
import { hashPassword, verifyPassword, passwordProblem, MIN_PASSWORD_LENGTH } from './password'
import {
  generateRecoveryCode,
  generateRecoveryCodes,
  hashRecoveryCode,
  normaliseRecoveryCode,
  recoveryCodeMatches,
  RECOVERY_CODE_COUNT,
} from './recovery-code'

describe('hashing a password', () => {
  it('never contains the password', () => {
    // The one property that matters. Everything else here is about whether
    // the check works; this is about what the database file gives away to
    // anyone who opens it.
    const hash = hashPassword('Violy#1313')
    expect(hash).not.toContain('Violy')
    expect(hash).not.toContain('1313')
  })

  it('verifies the password that made it', () => {
    expect(verifyPassword('correct horse battery', hashPassword('correct horse battery'))).toBe(true)
  })

  it('refuses a wrong password, including one that differs by a character', () => {
    const hash = hashPassword('sacksoffeed')
    expect(verifyPassword('sacksoffeeD', hash)).toBe(false)
    expect(verifyPassword('sacksoffee', hash)).toBe(false)
    expect(verifyPassword('', hash)).toBe(false)
  })

  it('salts, so the same password twice gives different hashes', () => {
    // Without this, identical passwords are visibly identical in the database,
    // and one cracked hash cracks every account that shares it.
    const a = hashPassword('sacksoffeed')
    const b = hashPassword('sacksoffeed')
    expect(a).not.toBe(b)
    expect(verifyPassword('sacksoffeed', a)).toBe(true)
    expect(verifyPassword('sacksoffeed', b)).toBe(true)
  })

  it('records its own cost, so raising it later cannot invalidate old hashes', () => {
    expect(hashPassword('sacksoffeed').startsWith('scrypt$16384$8$1$')).toBe(true)
  })

  it.each([
    ['empty', ''],
    ['not a hash at all', 'hunter2'],
    ['too few parts', 'scrypt$16384$8$1$abc'],
    ['unknown scheme', 'bcrypt$16384$8$1$YWJj$ZGVm'],
    ['non-numeric cost', 'scrypt$x$8$1$YWJj$ZGVm'],
    ['empty hash portion', 'scrypt$16384$8$1$YWJj$'],
  ])('returns false rather than throwing for a %s stored value', (_label, stored) => {
    // A thrown error here would be an unhandled rejection inside a Server
    // Action, which surfaces as a generic failure — not as "wrong password".
    expect(verifyPassword('sacksoffeed', stored)).toBe(false)
  })
})

describe('what makes a password acceptable', () => {
  it('accepts one of the minimum length', () => {
    expect(passwordProblem('a'.repeat(MIN_PASSWORD_LENGTH))).toBeNull()
  })

  it('refuses one a character short', () => {
    expect(passwordProblem('a'.repeat(MIN_PASSWORD_LENGTH - 1))).toContain('at least')
  })

  it('refuses a stray space at either end', () => {
    // Invisible in a password box, and it turns into a sign-in that fails for
    // no reason anybody can see.
    expect(passwordProblem(' sacksoffeed')).toContain('space')
    expect(passwordProblem('sacksoffeed ')).toContain('space')
  })

  it('allows spaces inside, so a passphrase is usable', () => {
    expect(passwordProblem('sacks of feed')).toBeNull()
  })
})

describe('recovery codes', () => {
  it('makes a full set', () => {
    expect(generateRecoveryCodes()).toHaveLength(RECOVERY_CODE_COUNT)
  })

  it('reads as two groups of four, for saying down a phone', () => {
    expect(generateRecoveryCode()).toMatch(/^[34679ACDEFGHJKMNPQRTUVWXY]{4}-[34679ACDEFGHJKMNPQRTUVWXY]{4}$/)
  })

  it('never uses a character that can be misheard', () => {
    // 0/O, 1/I/L, 5/S, 8/B and 2/Z are all the same sound or shape over a bad
    // line, and a wrong code reads as "the code does not work".
    const codes = generateRecoveryCodes(200).join('')
    for (const confusable of ['0', 'O', '1', 'I', 'L', '5', 'S', '8', 'B', '2', 'Z']) {
      expect(codes).not.toContain(confusable)
    }
  })

  it('does not repeat itself across a set', () => {
    const codes = generateRecoveryCodes(RECOVERY_CODE_COUNT)
    expect(new Set(codes).size).toBe(RECOVERY_CODE_COUNT)
  })

  it.each([
    ['lower case', '7qk2-4m91'],
    ['no dash', '7QK24M91'],
    ['spaces instead', '7QK2 4M91'],
    ['extra spaces', '  7QK2 - 4M91  '],
  ])('accepts the right code typed as %s', (_label, typed) => {
    const stored = hashRecoveryCode('7QK2-4M91')
    expect(recoveryCodeMatches(typed, stored)).toBe(true)
  })

  it('accepts lookalike characters typed for the real ones', () => {
    // She is reading Wrenz's handwriting or hearing it down a phone. A zero
    // typed for an O is the right code, not a wrong one.
    expect(normaliseRecoveryCode('0O1IL5S8B2Z')).toBe(normaliseRecoveryCode('OOJJJSSBBZZ'))
  })

  it('refuses a wrong code', () => {
    const stored = hashRecoveryCode('7QK2-4M91')
    expect(recoveryCodeMatches('7QK2-4M92', stored)).toBe(false)
    expect(recoveryCodeMatches('', stored)).toBe(false)
  })

  it('never stores the code itself', () => {
    expect(hashRecoveryCode('7QK2-4M91')).not.toContain('7QK2')
  })

  it.each([
    ['empty', ''],
    ['not hex', 'zzzz'],
    ['wrong length', 'abcd'],
  ])('returns false rather than throwing for a %s stored hash', (_label, stored) => {
    expect(recoveryCodeMatches('7QK2-4M91', stored)).toBe(false)
  })
})

describe('a corrupted stored hash', () => {
  it.each([
    ['an empty hash portion', 'scrypt$16384$8$1$YWJj$'],
    ['a truncated hash', 'scrypt$16384$8$1$YWJj$YWJjZGVm'],
    ['an empty salt', 'scrypt$16384$8$1$$' + Buffer.alloc(64).toString('base64')],
  ])('never lets a password through against %s', (_label, stored) => {
    // Found by the case above: a zero-length derived key compares equal to a
    // zero-length expected key, and timingSafeEqual returns TRUE — so a
    // corrupted row or a truncated restore became an open door for ANY
    // password. The length floor in verifyPassword is what closes it.
    expect(verifyPassword('sacksoffeed', stored)).toBe(false)
    expect(verifyPassword('', stored)).toBe(false)
    expect(verifyPassword('anything at all', stored)).toBe(false)
  })
})
