/**
 * Renders one page of this app to a PDF file, with no window and no operator.
 *
 *   electron electron/print-pdf.js -- <url> <outputFile> <a4|roll>
 *
 * The `--` is REQUIRED and is not decoration. Electron's own CLI parses argv
 * before the script sees it, and a bare `http://...` argument is taken as a
 * URL for Electron itself — the process then exits -1 having executed not one
 * line of this file, with nothing on stdout or stderr to say why. Measured,
 * after a long time spent looking in the wrong place. Everything after `--` is
 * left alone.
 *
 * Why this exists: a browser tab cannot write a styled PDF. The engine that
 * can is Chromium's print pipeline, and Electron already ships it — it is the
 * shop's desktop shell and a devDependency here. So rather than adding a PDF
 * library and a second copy of every document's layout (which would drift from
 * the real one the first time anybody edited a receipt), the server spawns
 * this and streams back what it produced.
 *
 * The same page therefore comes out identical whether it was asked for from
 * the desktop app or from a browser tab, because in both cases it is the same
 * renderer printing the same HTML with the same `@media print` rules.
 *
 * Exits non-zero with a message on stderr if anything fails; the caller treats
 * a missing file as a failure rather than serving a truncated one.
 */

const { app, BrowserWindow } = require('electron')
const { writeFileSync } = require('node:fs')
const { printOptions } = require('./pdf-page')

// Everything after `--`, or the plain tail when it is absent, so this still
// behaves under `node print-pdf.js` where nothing eats the arguments.
const separator = process.argv.indexOf('--')
const [url, out, paper] =
  separator === -1 ? process.argv.slice(2) : process.argv.slice(separator + 1)

function die(message) {
  process.stderr.write(`${message}${String.fromCharCode(10)}`)
  app.exit(1)
}

if (!url || !out) {
  process.stderr.write(`usage: print-pdf.js -- <url> <out> [a4|roll]${String.fromCharCode(10)}`)
  process.exit(1)
}

// Nothing here needs the GPU, and asking for it on a headless Windows box is a
// reliable way to hang.
app.disableHardwareAcceleration()

app.whenReady().then(async () => {
  const win = new BrowserWindow({
    show: false,
    // A real viewport width, not the default: the document is laid out in CSS
    // pixels before the print stylesheet applies, and a narrow window would
    // print the responsive layout rather than the one meant for paper.
    width: 1280,
    height: 1600,
    // `show: false` and NOT `offscreen: true`. Offscreen rendering routes
    // painting through a path `printToPDF` cannot use, and Electron exits -1
    // with nothing on stderr — measured, not guessed. A hidden ordinary window
    // is what this needs.
    webPreferences: { contextIsolation: true, nodeIntegration: false },
  })

  // A page that never answers must not leave a process alive forever holding a
  // handle to the file the server is waiting on.
  const timer = setTimeout(() => die('timed out rendering the page'), 30_000)

  try {
    await win.loadURL(url)

    // `loadURL` resolves at DOM-ready, which is BEFORE webfonts have swapped
    // in. Printing then produces a document set in the fallback face — subtly
    // wrong, and only visible once it is on paper. `document.fonts.ready` is
    // the event that actually answers "is this what it will look like".
    await win.webContents.executeJavaScript(
      'document.fonts && document.fonts.ready ? document.fonts.ready.then(() => true) : true',
    )

    const pdf = await win.webContents.printToPDF(printOptions(paper))
    writeFileSync(out, pdf)
    clearTimeout(timer)
    app.exit(0)
  } catch (error) {
    clearTimeout(timer)
    die(error instanceof Error ? error.message : String(error))
  }
})
