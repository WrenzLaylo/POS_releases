import { describe, expect, it } from 'vitest'
import { STOCK_LEVEL_OPTIONS, parseStockLevel, stockLevelOf } from './stock-level'

function product(stockQty: number, lowStockThreshold: number) {
  return { stockQty, lowStockThreshold }
}

describe('stockLevelOf', () => {
  it.each([
    ['well above the threshold', 40, 5, 'in'],
    ['one above the threshold', 6, 5, 'in'],
    ['exactly at the threshold', 5, 5, 'low'],
    ['one above empty', 1, 5, 'low'],
    ['empty', 0, 5, 'out'],
    ['negative, from a sale on uncounted stock', -3, 5, 'out'],
  ])('calls %s %s', (_label, qty, threshold, expected) => {
    expect(stockLevelOf(product(qty, threshold))).toBe(expected)
  })

  it('calls an empty product out, not low, even at a zero threshold', () => {
    // The case that made this a partition rather than a flag. Every product in
    // this shop currently has a threshold of 0, so a plain
    // `stockQty <= lowStockThreshold` test reports all forty as "low" — and
    // buries the ones that genuinely cannot be sold today among them.
    expect(stockLevelOf(product(0, 0))).toBe('out')
    expect(stockLevelOf(product(1, 0))).toBe('in')
  })

  it('puts every product in exactly one state', () => {
    for (let qty = -3; qty <= 12; qty += 1) {
      for (let threshold = 0; threshold <= 8; threshold += 1) {
        const level = stockLevelOf(product(qty, threshold))
        const matches = [
          level === 'out' && qty <= 0,
          level === 'low' && qty > 0 && qty <= threshold,
          level === 'in' && qty > threshold,
        ].filter(Boolean)
        expect(matches, `qty ${qty} threshold ${threshold} → ${level}`).toHaveLength(1)
      }
    }
  })
})

describe('parseStockLevel', () => {
  it.each(['in', 'low', 'out'])('accepts %s', (raw) => {
    expect(parseStockLevel(raw)).toBe(raw)
  })

  it.each([undefined, null, '', 'all', 'IN', 'anything', '1'])(
    'treats %s as no filter',
    (raw) => {
      expect(parseStockLevel(raw)).toBeUndefined()
    },
  )
})

describe('STOCK_LEVEL_OPTIONS', () => {
  it('offers a no-filter option first, and every real level after it', () => {
    expect(STOCK_LEVEL_OPTIONS[0].value).toBe('')
    // Every option other than "any" must be a value the parser accepts, or a
    // chip would apply a filter the server then ignores while it stays
    // visibly selected.
    for (const option of STOCK_LEVEL_OPTIONS.slice(1)) {
      expect(parseStockLevel(option.value), option.label).toBe(option.value)
    }
  })
})
