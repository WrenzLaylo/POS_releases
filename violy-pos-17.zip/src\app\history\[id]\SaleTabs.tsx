'use client'

import { useRouter } from 'next/navigation'
import { Tabs } from '@/components/ui/Tabs'
import { deliveryNote, sale as saleRoute, saleReceipt } from '@/lib/routes'

export type SaleTab = 'summary' | 'receipt' | 'delivery-note'

/**
 * Switches between the working view of a sale and its printable documents.
 *
 * A real navigation rather than local state, matching the Book's tab strip:
 * each half is its own route, so either can be linked to, refreshed, or
 * reached with the back button — and the receipt keeps the URL it already had.
 *
 * The third tab appears only on a delivery order. Every sale has a receipt;
 * only a sale with somewhere to go has a note, and a tab that 404s is worse
 * than no tab.
 */
export function SaleTabs({
  saleId,
  active,
  hasDeliveryNote = false,
}: {
  saleId: number
  active: SaleTab
  hasDeliveryNote?: boolean
}) {
  const router = useRouter()

  const tabs = [
    { value: 'summary', label: 'Summary' },
    { value: 'receipt', label: 'Receipt' },
    ...(hasDeliveryNote ? [{ value: 'delivery-note', label: 'Delivery note' }] : []),
  ]

  return (
    <Tabs
      ariaLabel="Sale view"
      tabs={tabs}
      value={active}
      onValueChange={(value) => {
        if (value === 'receipt') router.push(saleReceipt(saleId))
        else if (value === 'delivery-note') router.push(deliveryNote(saleId))
        else router.push(saleRoute(saleId))
      }}
      className="mb-4"
    />
  )
}
