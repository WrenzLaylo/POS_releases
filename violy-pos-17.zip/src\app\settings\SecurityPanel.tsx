'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import {
  changePassword,
  createLogin,
  disableLogin,
  regenerateRecoveryCodes,
} from '@/server/auth'
import { signOut } from '@/server/auth'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Field } from '@/components/ui/Field'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'
import { Icon } from '@/components/ui/Icon'
import { SectionHeader } from '@/components/ui/SectionHeader'

/**
 * Where the login gets turned on, and the only place the codes are ever shown.
 *
 * The panel has two completely different jobs depending on whether a login
 * exists, and they are written as two blocks rather than one form that changes
 * meaning — setting a password up for the first time and changing an existing
 * one look similar and are not the same act.
 *
 * The codes appear ONCE, right after they are made. They are hashed on the way
 * into the database and genuinely cannot be read back, so this screen refuses
 * to be dismissed casually: there is no way to recover them later, only to
 * issue a fresh set.
 */
export function SecurityPanel({
  username,
  codesRemaining,
}: {
  /** Null when the shop has no login yet. */
  username: string | null
  codesRemaining: number
}) {
  const router = useRouter()
  const [pending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)
  const [note, setNote] = useState<string | null>(null)

  /** Shown once, never retrievable. */
  const [codes, setCodes] = useState<string[] | null>(null)
  const [copied, setCopied] = useState(false)

  // Set up
  const [newUsername, setNewUsername] = useState('violyopto0@gmail.com')
  const [setupPassword, setSetupPassword] = useState('')
  const [setupConfirm, setSetupConfirm] = useState('')

  // Change / confirm
  const [currentPassword, setCurrentPassword] = useState('')
  const [nextPassword, setNextPassword] = useState('')
  const [confirmFor, setConfirmFor] = useState<'codes' | 'off' | null>(null)
  const [confirmPasswordValue, setConfirmPasswordValue] = useState('')

  function reset() {
    setError(null)
    setNote(null)
    setCopied(false)
  }

  function doSetup() {
    reset()
    if (setupPassword !== setupConfirm) {
      setError('The two passwords do not match.')
      return
    }
    startTransition(async () => {
      const result = await createLogin(newUsername, setupPassword)
      if (!result.ok) {
        setError(result.error)
        return
      }
      setCodes(result.data.codes)
      setSetupPassword('')
      setSetupConfirm('')
      router.refresh()
    })
  }

  function doChangePassword() {
    reset()
    startTransition(async () => {
      const result = await changePassword(currentPassword, nextPassword)
      if (!result.ok) {
        setError(result.error)
        return
      }
      setCurrentPassword('')
      setNextPassword('')
      setNote('Password changed. Every other laptop has been signed out.')
      router.refresh()
    })
  }

  function doConfirmed() {
    reset()
    const action = confirmFor
    startTransition(async () => {
      if (action === 'codes') {
        const result = await regenerateRecoveryCodes(confirmPasswordValue)
        if (!result.ok) {
          setError(result.error)
          return
        }
        setCodes(result.data.codes)
      } else {
        const result = await disableLogin(confirmPasswordValue)
        if (!result.ok) {
          setError(result.error)
          return
        }
        setNote('The login is off. The counter opens without a password again.')
      }
      setConfirmFor(null)
      setConfirmPasswordValue('')
      router.refresh()
    })
  }

  // ── The codes, shown once ────────────────────────────────────────────────
  if (codes) {
    return (
      <Card>
        <SectionHeader title="Write these down now" />
        <p className="mb-4 text-sm text-ink">
          Ten one-time codes. Each one gets Violy back into the counter if the password is
          forgotten, and using one does not use up the others — a fresh code takes its place
          automatically, so the list always has ten.
        </p>
        <p className="mb-4 text-sm font-medium text-warn">
          <Icon name="alert" className="mr-1 inline h-4 w-4 align-[-2px]" />
          This is the only time they are shown. They are stored scrambled and cannot be read back.
        </p>

        <div className="grid grid-cols-2 gap-2 rounded-control border border-line bg-surface-sunk p-4 font-mono text-sm tracking-[0.15em] text-ink">
          {codes.map((code) => (
            <div key={code}>{code}</div>
          ))}
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          <Button
            variant="secondary"
            onClick={() => {
              void navigator.clipboard.writeText(codes.join('\n')).then(() => setCopied(true))
            }}
          >
            {copied ? 'Copied' : 'Copy all'}
          </Button>
          <Button variant="secondary" onClick={() => window.print()}>
            Print
          </Button>
          <Button
            variant="primary"
            onClick={() => {
              setCodes(null)
              router.refresh()
            }}
          >
            I have saved them
          </Button>
        </div>

        <p className="mt-4 text-xs text-ink-subtle">
          Keep one copy where Wrenz can reach it from anywhere — a password manager or a photo —
          and one printed copy in the shop. Two copies in two places is what stops a forgotten
          password becoming a locked till.
        </p>
      </Card>
    )
  }

  // ── No login yet ─────────────────────────────────────────────────────────
  if (username === null) {
    return (
      <Card>
        <SectionHeader
          title="Password"
          description="The counter currently opens without one. Anyone who opens this laptop can see every balance in the book."
        />

        <form
          className="grid max-w-md gap-4"
          onSubmit={(event) => {
            event.preventDefault()
            doSetup()
          }}
        >
          <Field label="Username">
            <Input
              value={newUsername}
              onChange={(event) => setNewUsername(event.target.value)}
              autoComplete="username"
              disabled={pending}
              className="w-full"
            />
            <span className="mt-1 text-xs text-ink-subtle">
              Only shown on the sign-in screen — she never has to type it.
            </span>
          </Field>

          <Field label="Password">
            <Input
              type="password"
              value={setupPassword}
              onChange={(event) => setSetupPassword(event.target.value)}
              autoComplete="new-password"
              disabled={pending}
              className="w-full"
            />
            <span className="mt-1 text-xs text-ink-subtle">At least 8 characters.</span>
          </Field>

          <Field label="Type it again">
            <Input
              type="password"
              value={setupConfirm}
              onChange={(event) => setSetupConfirm(event.target.value)}
              autoComplete="new-password"
              disabled={pending}
              className="w-full"
            />
          </Field>

          {error && <FormError>{error}</FormError>}
          {note && <p className="text-sm text-ink">{note}</p>}

          <Button type="submit" variant="primary" disabled={pending} className="justify-self-start">
            {pending ? 'Setting up…' : 'Turn the login on'}
          </Button>
        </form>
      </Card>
    )
  }

  // ── Login exists ─────────────────────────────────────────────────────────
  return (
    <Card>
      <SectionHeader title="Password" description={`The counter is locked. Signed in as ${username}.`} />

      {confirmFor && (
        <div className="mb-6 rounded-control border border-line-strong bg-surface-sunk p-4">
          <p className="mb-3 text-sm text-ink">
            {confirmFor === 'codes'
              ? 'Making new codes throws the old ten away. Any code already written down stops working.'
              : 'Turning the login off means the counter opens without a password again.'}
          </p>
          <form
            className="flex flex-wrap items-end gap-3"
            onSubmit={(event) => {
              event.preventDefault()
              doConfirmed()
            }}
          >
            <Field label="Your password">
              <Input
                type="password"
                value={confirmPasswordValue}
                onChange={(event) => setConfirmPasswordValue(event.target.value)}
                autoComplete="current-password"
                disabled={pending}
                className="w-56"
                autoFocus
              />
            </Field>
            <Button
              type="submit"
              variant={confirmFor === 'off' ? 'destructive' : 'primary'}
              disabled={pending}
            >
              {pending
                ? 'Working…'
                : confirmFor === 'codes'
                  ? 'Yes, make new codes'
                  : 'Yes, turn it off'}
            </Button>
            <Button
              variant="ghost"
              disabled={pending}
              onClick={() => {
                setConfirmFor(null)
                setConfirmPasswordValue('')
                reset()
              }}
            >
              Cancel
            </Button>
          </form>
        </div>
      )}

      {error && <FormError className="mb-4">{error}</FormError>}
      {note && (
        <p className="mb-4 rounded-control border border-line bg-surface-sunk px-4 py-3 text-sm text-ink">
          {note}
        </p>
      )}

      {/* `mt-6`, because SectionHeader's description ends flush and the two
          column headings below would otherwise read as part of it. */}
      <div className="mt-6 grid gap-8 lg:grid-cols-2">
        <form
          className="grid content-start gap-3"
          onSubmit={(event) => {
            event.preventDefault()
            doChangePassword()
          }}
        >
          <h3 className="text-sm font-medium text-ink">Change the password</h3>
          <Field label="Current password">
            <Input
              type="password"
              value={currentPassword}
              onChange={(event) => setCurrentPassword(event.target.value)}
              autoComplete="current-password"
              disabled={pending}
              className="w-full"
            />
          </Field>
          <Field label="New password">
            <Input
              type="password"
              value={nextPassword}
              onChange={(event) => setNextPassword(event.target.value)}
              autoComplete="new-password"
              disabled={pending}
              className="w-full"
            />
          </Field>
          <Button type="submit" variant="secondary" disabled={pending} className="justify-self-start">
            Change password
          </Button>
        </form>

        <div className="grid content-start gap-3">
          <h3 className="text-sm font-medium text-ink">Recovery codes</h3>
          <p className="text-sm text-ink-muted">
            <span className="font-mono text-base font-medium text-ink">{codesRemaining}</span> codes
            can still be used. Each works once, and using one mints a replacement — so this number
            stays at ten and the way back in never runs out.
          </p>
          <Button
            variant="secondary"
            disabled={pending}
            onClick={() => {
              reset()
              setConfirmFor('codes')
            }}
            className="justify-self-start"
          >
            Make new codes
          </Button>
        </div>
      </div>

      {/* Pushed apart, not sat side by side. These two were a few pixels
          from each other and read as two strengths of the same action — one
          ends a session, the other removes the password from the shop
          entirely. Signing out also lives under the account menu in the
          corner now, which is where it is actually looked for. */}
      <div className="mt-6 flex flex-wrap items-center justify-between gap-4 border-t border-line pt-4">
        <Button
          variant="secondary"
          disabled={pending}
          onClick={() => {
            startTransition(async () => {
              await signOut()
              router.refresh()
            })
          }}
        >
          Sign out
        </Button>
        <div className="text-right">
          <Button
            variant="danger"
            disabled={pending}
            onClick={() => {
              reset()
              setConfirmFor('off')
            }}
          >
            Turn the login off
          </Button>
          <p className="mt-1 text-xs text-ink-subtle">The counter opens without a password.</p>
        </div>
      </div>
    </Card>
  )
}
