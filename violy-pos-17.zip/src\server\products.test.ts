import { describe, it, expect, beforeEach } from 'vitest'
import { prisma } from '@/lib/db'
import { PAGE_SIZE } from '@/lib/pagination'
import { resetDb } from '@/test/reset-db'
import {
  listProducts,
  listAllProducts,
  listCategories,
  createProduct,
  updateProduct,
  archiveProduct,
  restoreProduct,
} from '@/server/products'

beforeEach(resetDb)

async function makeCategory(name = 'Pig Feeds') {
  return prisma.category.create({ data: { name } })
}

function productForm(overrides: Record<string, string> = {}) {
  const form = new FormData()
  form.set('name', 'Hog Grower (sako)')
  form.set('unit', 'sako (50kg)')
  form.set('price', '1400')
  form.set('costPrice', '1280')
  form.set('stockQty', '12')
  form.set('lowStockThreshold', '5')
  form.set('description', 'Feeds for growing pigs')
  for (const [key, value] of Object.entries(overrides)) form.set(key, value)
  return form
}

describe('createProduct', () => {
  it('converts peso inputs to centavos', async () => {
    const category = await makeCategory()
    const form = productForm({ categoryId: String(category.id) })

    const result = await createProduct(form)

    expect(result.ok).toBe(true)
    const product = await prisma.product.findFirstOrThrow()
    expect(product.price).toBe(140000)
    expect(product.costPrice).toBe(128000)
  })

  it('accepts a fractional stock quantity', async () => {
    const category = await makeCategory()
    const form = productForm({ categoryId: String(category.id), stockQty: '12.5' })

    await createProduct(form)

    const product = await prisma.product.findFirstOrThrow()
    expect(product.stockQty).toBe(12.5)
  })

  it('rejects a blank name', async () => {
    const category = await makeCategory()
    const form = productForm({ categoryId: String(category.id), name: '  ' })

    const result = await createProduct(form)

    expect(result).toEqual({ ok: false, error: 'Name is required.' })
    expect(await prisma.product.count()).toBe(0)
  })

  it('rejects a negative price', async () => {
    const category = await makeCategory()
    const form = productForm({ categoryId: String(category.id), price: '-5' })

    const result = await createProduct(form)

    expect(result.ok).toBe(false)
    expect(await prisma.product.count()).toBe(0)
  })

  it('rejects a missing category', async () => {
    const form = productForm({ categoryId: '9999' })

    const result = await createProduct(form)

    expect(result).toEqual({ ok: false, error: 'Category not found.' })
  })
})

describe('updateProduct', () => {
  it('changes price and stock', async () => {
    const category = await makeCategory()
    const created = await createProduct(productForm({ categoryId: String(category.id) }))
    if (!created.ok) throw new Error('setup failed')

    const form = productForm({
      id: String(created.data),
      categoryId: String(category.id),
      price: '1450',
      stockQty: '9',
    })
    const result = await updateProduct(form)

    expect(result.ok).toBe(true)
    const product = await prisma.product.findUniqueOrThrow({ where: { id: created.data } })
    expect(product.price).toBe(145000)
    expect(product.stockQty).toBe(9)
  })

  it('reports a missing product instead of throwing', async () => {
    const category = await makeCategory()
    const form = productForm({ id: '9999', categoryId: String(category.id) })

    const result = await updateProduct(form)

    expect(result).toEqual({ ok: false, error: 'Product not found.' })
  })
})

describe('archiveProduct', () => {
  it('archives instead of deleting so sales history survives', async () => {
    const category = await makeCategory()
    const created = await createProduct(productForm({ categoryId: String(category.id) }))
    if (!created.ok) throw new Error('setup failed')

    const result = await archiveProduct(created.data)

    expect(result.ok).toBe(true)
    expect(await prisma.product.count()).toBe(1)
    const product = await prisma.product.findUniqueOrThrow({ where: { id: created.data } })
    expect(product.isArchived).toBe(true)
  })
})

describe('restoreProduct', () => {
  it('restores an archived product', async () => {
    const category = await makeCategory()
    const created = await createProduct(productForm({ categoryId: String(category.id) }))
    expect(created.ok).toBe(true)
    const id = created.ok ? created.data : 0

    await archiveProduct(id)
    const restored = await restoreProduct(id)

    expect(restored.ok).toBe(true)
    const row = await prisma.product.findUnique({ where: { id } })
    expect(row?.isArchived).toBe(false)
  })
})

describe('listProducts', () => {
  it('excludes archived products but listAllProducts can include them', async () => {
    const category = await makeCategory()
    const first = await createProduct(productForm({ categoryId: String(category.id) }))
    const second = await createProduct(
      productForm({ categoryId: String(category.id), name: 'Hog Starter (sako)' }),
    )
    if (!first.ok || !second.ok) throw new Error('setup failed')
    await archiveProduct(first.data)

    expect(await listProducts()).toHaveLength(1)
    expect((await listAllProducts({ includeArchived: true })).total).toBe(2)
  })

  it('includes the category name', async () => {
    const category = await makeCategory()
    await createProduct(productForm({ categoryId: String(category.id) }))

    const products = await listProducts()

    expect(products[0].category.name).toBe('Pig Feeds')
  })

  it('orders by category.sortOrder, not by name — "Feed Supplements" does not jump to the top', async () => {
    const supplements = await prisma.category.create({
      data: { name: 'Feed Supplements' }, // default sortOrder 100
    })
    const sako = await prisma.category.create({
      data: { name: 'Feeds (Sako)', sortOrder: 1 },
    })
    await createProduct(
      productForm({ categoryId: String(supplements.id), name: 'Vitamin Booster' }),
    )
    await createProduct(
      productForm({ categoryId: String(sako.id), name: 'ADM Starter (sako)' }),
    )

    const products = await listProducts()

    expect(products.map((p) => p.category.name)).toEqual(['Feeds (Sako)', 'Feed Supplements'])
  })
})

describe('listCategories', () => {
  it('returns categories ordered by name', async () => {
    await makeCategory('Meryenda')
    await makeCategory('De Lata')

    const categories = await listCategories()

    expect(categories.map((c) => c.name)).toEqual(['De Lata', 'Meryenda'])
  })
})

describe('listAllProducts paging and filters', () => {
  it('hides archived products unless asked for them', async () => {
    const category = await prisma.category.create({ data: { name: 'Feeds (Sako)', sortOrder: 1 } })
    await prisma.product.create({
      data: { categoryId: category.id, name: 'Live', unit: 'sako', price: 100, costPrice: 90, stockQty: 1, lowStockThreshold: 1 },
    })
    await prisma.product.create({
      data: { categoryId: category.id, name: 'Gone', unit: 'sako', price: 100, costPrice: 90, stockQty: 1, lowStockThreshold: 1, isArchived: true },
    })

    const hidden = await listAllProducts({}, 1)
    expect(hidden.total).toBe(1)
    expect(hidden.rows.map((p) => p.name)).toEqual(['Live'])

    const shown = await listAllProducts({ includeArchived: true }, 1)
    expect(shown.total).toBe(2)
  })

  it('searches product names without regard to case', async () => {
    const category = await prisma.category.create({ data: { name: 'Feeds (Sako)', sortOrder: 1 } })
    for (const name of ['ADM Grower (sako)', 'Feed Scoop']) {
      await prisma.product.create({
        data: { categoryId: category.id, name, unit: 'sako', price: 100, costPrice: 90, stockQty: 1, lowStockThreshold: 1 },
      })
    }

    const result = await listAllProducts({ q: 'grow' }, 1)

    expect(result.total).toBe(1)
    expect(result.rows[0].name).toBe('ADM Grower (sako)')
  })

  it('filters by category and counts only that category', async () => {
    const feeds = await prisma.category.create({ data: { name: 'Feeds (Sako)', sortOrder: 1 } })
    const gear = await prisma.category.create({ data: { name: 'Equipment', sortOrder: 4 } })
    await prisma.product.create({
      data: { categoryId: feeds.id, name: 'ADM Grower (sako)', unit: 'sako', price: 100, costPrice: 90, stockQty: 1, lowStockThreshold: 1 },
    })
    await prisma.product.create({
      data: { categoryId: gear.id, name: 'Feed Scoop', unit: 'piraso', price: 100, costPrice: 90, stockQty: 1, lowStockThreshold: 1 },
    })

    const result = await listAllProducts({ categoryId: gear.id }, 1)

    expect(result.total).toBe(1)
    expect(result.rows[0].name).toBe('Feed Scoop')
  })

/**
 * Paging assertions are expressed in terms of `PAGE_SIZE`, never as the number
 * it happens to hold. They were written against a literal 20/25 and every one
 * of them broke the day the page size changed — which told us nothing about
 * paging, only that a constant had moved.
 */
  it('pages and clamps past the end', async () => {
    const category = await prisma.category.create({ data: { name: 'Feeds (Sako)', sortOrder: 1 } })
    const overflow = 5
    for (let i = 0; i < PAGE_SIZE + overflow; i++) {
      await prisma.product.create({
        data: { categoryId: category.id, name: `Product ${String(i).padStart(2, '0')}`, unit: 'sako', price: 100, costPrice: 90, stockQty: 1, lowStockThreshold: 1 },
      })
    }

    const first = await listAllProducts({}, 1)
    expect(first.rows).toHaveLength(PAGE_SIZE)
    expect(first.pageCount).toBe(2)

    const past = await listAllProducts({}, 99)
    expect(past.page).toBe(2)
    expect(past.rows).toHaveLength(overflow)
  })

  it('page 2 continues where page 1 stopped — no gap, no overlap', async () => {
    const category = await prisma.category.create({ data: { name: 'Feeds (Sako)', sortOrder: 1 } })
    // Duplicate names on purpose — this is what exposes an unstable sort
    // when the tiebreaker is missing.
    const total = PAGE_SIZE + 5
    for (let i = 0; i < total; i++) {
      await prisma.product.create({
        data: { categoryId: category.id, name: 'Same Name (sako)', unit: 'sako', price: 100, costPrice: 90, stockQty: 1, lowStockThreshold: 1 },
      })
    }

    const firstIds = (await listAllProducts({}, 1)).rows.map((p) => p.id)
    const secondIds = (await listAllProducts({}, 2)).rows.map((p) => p.id)

    const overlap = firstIds.filter((id) => secondIds.includes(id))
    expect(overlap).toEqual([])

    const combined = [...firstIds, ...secondIds]
    expect(new Set(combined).size).toBe(total)
    expect(combined).toHaveLength(total)
  })
})

describe('listAllProducts, filtered by stock level', () => {
  async function stocked(name: string, stockQty: number, lowStockThreshold: number) {
    const category = await prisma.category.upsert({
      where: { name: 'Pig Feeds' },
      create: { name: 'Pig Feeds' },
      update: {},
    })
    return prisma.product.create({
      data: {
        categoryId: category.id,
        name,
        unit: 'sako',
        price: 100_000,
        costPrice: 90_000,
        stockQty,
        lowStockThreshold,
      },
    })
  }

  async function seedLevels() {
    await stocked('Plenty', 40, 5)
    await stocked('Just above', 6, 5)
    await stocked('At threshold', 5, 5)
    await stocked('Nearly gone', 1, 5)
    await stocked('Empty', 0, 5)
    await stocked('Oversold', -2, 5)
  }

  async function names(stock: 'in' | 'low' | 'out' | undefined) {
    const page = await listAllProducts({ stock }, 1)
    return page.rows.map((row) => row.name).sort()
  }

  it('splits the catalog into three states with nothing in two of them at once', async () => {
    await seedLevels()

    expect(await names('in')).toEqual(['Just above', 'Plenty'])
    expect(await names('low')).toEqual(['At threshold', 'Nearly gone'])
    expect(await names('out')).toEqual(['Empty', 'Oversold'])
    expect(await names(undefined)).toHaveLength(6)
  })

  it('compares each product against its OWN threshold, not a shared number', async () => {
    // The reason this is a field reference in SQL rather than a constant:
    // thirty sacks is comfortable for a bestseller and a year's supply of
    // something else, so "low" cannot be one number across the catalog.
    await stocked('Fast mover', 20, 30)
    await stocked('Slow mover', 20, 2)

    expect(await names('low')).toEqual(['Fast mover'])
    expect(await names('in')).toEqual(['Slow mover'])
  })

  it('counts and paginates the filtered set, not the whole catalog', async () => {
    // The filter has to reach SQL. Filtering in memory after the query would
    // leave `total` and `pageCount` describing a different set than the rows.
    await seedLevels()

    const page = await listAllProducts({ stock: 'out' }, 1)
    expect(page.total).toBe(2)
    expect(page.pageCount).toBe(1)
    expect(page.rows).toHaveLength(2)
  })

  it('still honours the other filters alongside it', async () => {
    const other = await prisma.category.create({ data: { name: 'Medicine' } })
    await stocked('Empty feed', 0, 5)
    await prisma.product.create({
      data: {
        categoryId: other.id,
        name: 'Empty medicine',
        unit: 'bottle',
        price: 5_000,
        costPrice: 4_000,
        stockQty: 0,
        lowStockThreshold: 2,
      },
    })

    const page = await listAllProducts({ stock: 'out', categoryId: other.id }, 1)
    expect(page.rows.map((row) => row.name)).toEqual(['Empty medicine'])

    const searched = await listAllProducts({ stock: 'out', q: 'feed' }, 1)
    expect(searched.rows.map((row) => row.name)).toEqual(['Empty feed'])
  })

  it('leaves archived products out unless they are asked for', async () => {
    const category = await prisma.category.upsert({
      where: { name: 'Pig Feeds' },
      create: { name: 'Pig Feeds' },
      update: {},
    })
    await prisma.product.create({
      data: {
        categoryId: category.id,
        name: 'Retired and empty',
        unit: 'sako',
        price: 100_000,
        costPrice: 90_000,
        stockQty: 0,
        lowStockThreshold: 5,
        isArchived: true,
      },
    })

    expect(await names('out')).toEqual([])
    const withArchived = await listAllProducts({ stock: 'out', includeArchived: true }, 1)
    expect(withArchived.rows.map((row) => row.name)).toEqual(['Retired and empty'])
  })
})

describe('adding a product that already exists', () => {
  it('refuses a second product with the same name, and writes nothing', async () => {
    const category = await makeCategory()
    const first = await createProduct(productForm({ categoryId: String(category.id) }))
    expect(first.ok).toBe(true)

    const again = await createProduct(productForm({ categoryId: String(category.id) }))
    expect(again.ok).toBe(false)
    if (again.ok) return
    expect(again.error).toMatch(/already in the list/)
    expect(await prisma.product.count()).toBe(1)
  })

  it.each([
    ['different case', 'hog grower (sako)'],
    ['trailing spaces', 'Hog Grower (sako)   '],
    ['leading spaces', '   Hog Grower (sako)'],
  ])('catches a duplicate typed with %s', async (_label, name) => {
    // Every one of these is the same sack to the person at the counter, and
    // the till only ever shows a name and a unit — two rows reading the same
    // are indistinguishable there.
    const category = await makeCategory()
    await createProduct(productForm({ categoryId: String(category.id) }))

    const again = await createProduct(productForm({ categoryId: String(category.id), name }))
    expect(again.ok).toBe(false)
    expect(await prisma.product.count()).toBe(1)
  })

  it('points at the archived copy rather than pretending the name is free', async () => {
    const category = await makeCategory()
    const first = await createProduct(productForm({ categoryId: String(category.id) }))
    expect(first.ok).toBe(true)
    if (!first.ok) return
    await archiveProduct(first.data)

    const again = await createProduct(productForm({ categoryId: String(category.id) }))
    expect(again.ok).toBe(false)
    if (again.ok) return
    expect(again.error).toMatch(/archived/)
    expect(await prisma.product.count()).toBe(1)
  })

  it('allows a genuinely different name', async () => {
    const category = await makeCategory()
    await createProduct(productForm({ categoryId: String(category.id) }))

    const other = await createProduct(
      productForm({ categoryId: String(category.id), name: 'Hog Starter (sako)' }),
    )
    expect(other.ok).toBe(true)
    expect(await prisma.product.count()).toBe(2)
  })

  it('does not treat a shorter name as a duplicate of a longer one', async () => {
    // The LIKE that narrows the candidates matches substrings, so "Grower"
    // finds "Hog Grower (sako)". Only an exact match after trimming and
    // lowercasing may block a save.
    const category = await makeCategory()
    await createProduct(productForm({ categoryId: String(category.id) }))

    const shorter = await createProduct(
      productForm({ categoryId: String(category.id), name: 'Grower' }),
    )
    expect(shorter.ok).toBe(true)
    expect(await prisma.product.count()).toBe(2)
  })

  it('refuses to rename one product onto another product’s name', async () => {
    const category = await makeCategory()
    await createProduct(productForm({ categoryId: String(category.id) }))
    const second = await createProduct(
      productForm({ categoryId: String(category.id), name: 'Hog Starter (sako)' }),
    )
    expect(second.ok).toBe(true)
    if (!second.ok) return

    const form = productForm({ categoryId: String(category.id), name: 'Hog Grower (sako)' })
    form.set('id', String(second.data))
    const renamed = await updateProduct(form)

    expect(renamed.ok).toBe(false)
    const row = await prisma.product.findUnique({ where: { id: second.data } })
    expect(row!.name).toBe('Hog Starter (sako)')
  })

  it('lets a product be saved without changing its own name', async () => {
    // The clash check must exclude the row being edited, or editing a price
    // would report the product as a duplicate of itself.
    const category = await makeCategory()
    const created = await createProduct(productForm({ categoryId: String(category.id) }))
    expect(created.ok).toBe(true)
    if (!created.ok) return

    const form = productForm({ categoryId: String(category.id), price: '1500' })
    form.set('id', String(created.data))
    expect((await updateProduct(form)).ok).toBe(true)

    const row = await prisma.product.findUnique({ where: { id: created.data } })
    expect(row!.price).toBe(150_000)
  })
})
