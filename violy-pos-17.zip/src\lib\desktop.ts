/**
 * The desktop shell, as the page sees it.
 *
 * The app runs two ways: inside the Electron window on the shop laptop, and in
 * an ordinary browser tab during development. Everything works in both, and
 * exactly one thing does not — writing a file to a folder — so that one thing
 * is asked for through `window.violyDesktop`, exposed by `electron/preload.js`,
 * and is simply absent in a tab.
 *
 * Absent is a supported state, not a failure: a screen checks `desktop()` and
 * offers what it can. It must never assume the bridge is there, because on the
 * developer's machine it usually is not.
 */

export type SavePdfOptions = {
  /** Without the extension — the shell adds `.pdf` and sanitises the rest. */
  fileName: string
  paper: 'a4' | 'roll'
}

export type PrinterInfo = { name: string; displayName: string; isDefault: boolean }

export type DesktopBridge = {
  isDesktop: true
  savePdf: (options: SavePdfOptions) => Promise<{ ok: true; path: string } | { ok: false; error: string }>
  listPrinters: () => Promise<PrinterInfo[]>
  printSilently: (options: {
    deviceName?: string
    paper: 'a4' | 'roll'
  }) => Promise<{ ok: true } | { ok: false; error: string }>
}

declare global {
  interface Window {
    violyDesktop?: DesktopBridge
  }
}

/** The bridge, or null in a plain browser tab. */
export function desktop(): DesktopBridge | null {
  if (typeof window === 'undefined') return null
  return window.violyDesktop ?? null
}
