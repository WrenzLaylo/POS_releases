'use client'

import { useEffect, useState } from 'react'
import {
  oversellWarningOn,
  receiptPrinter,
  setOversellWarning,
  setReceiptPrinter,
} from '@/lib/counter-prefs'
import { desktop, type PrinterInfo } from '@/lib/desktop'
import { Card } from '@/components/ui/Card'
import { Field } from '@/components/ui/Field'
import { Select } from '@/components/ui/Select'

/**
 * The way back from "Stop asking me this".
 *
 * The counter lets the stock warning be silenced from inside the dialog
 * itself, which is the only place she will ever be annoyed enough to want to.
 * That is a one-way door unless the switch also exists somewhere she can find
 * it later — and "somewhere she can find it later" is Settings, not a hidden
 * key combination at the counter.
 *
 * Reads and writes `localStorage` directly rather than going through a Server
 * Action: the preference belongs to this laptop, and there is no server state
 * to keep in step.
 */
export function CounterPanel() {
  // True on the first render so the server pass and the client agree; the
  // stored answer arrives in the effect, same as `AppRail`.
  const [warn, setWarn] = useState(true)
  const [mounted, setMounted] = useState(false)
  const [printers, setPrinters] = useState<PrinterInfo[]>([])
  const [printer, setPrinter] = useState('')

  useEffect(() => {
    setWarn(oversellWarningOn())
    setPrinter(receiptPrinter())
    setMounted(true)

    // Only the desktop shell can see the machine's printers. In a browser tab
    // the chooser is simply absent rather than empty, because an empty list
    // reads as "you have no printer" when it means "ask somewhere else".
    const bridge = desktop()
    if (bridge) void bridge.listPrinters().then(setPrinters)
  }, [])

  function choosePrinter(next: string) {
    setPrinter(next)
    setReceiptPrinter(next)
  }

  function choose(next: boolean) {
    setWarn(next)
    setOversellWarning(next)
  }

  return (
    <Card>
      <h2 className="mb-1 text-base font-semibold">Counter</h2>
      <p className="mb-3 text-sm text-ink-muted">How the sale screen behaves on this computer.</p>

      <label className="flex items-start gap-3 text-sm text-ink">
        <input
          type="checkbox"
          checked={warn}
          disabled={!mounted}
          onChange={(event) => choose(event.target.checked)}
          className="mt-0.5 h-4 w-4 shrink-0"
        />
        <span>
          Ask before a sale takes stock below zero
          <span className="block text-xs text-ink-subtle">
            {warn
              ? 'The counter stops and confirms when you sell more than the recorded stock. Useful once your stock counts are up to date.'
              : 'The counter is selling without asking. Turn this back on once your stock counts are up to date.'}
          </span>
        </span>
      </label>

      {/* Only where printing can actually be made silent. A browser tab always
          goes through the print dialog, so offering to remember a printer
          there would promise something the tab cannot do. */}
      {printers.length > 0 && (
        <div className="mt-4 border-t border-line pt-4">
          <Field label="Receipt printer">
            <Select
              aria-label="Which printer receipts go to"
              value={printer}
              onChange={(event) => choosePrinter(event.target.value)}
              className="w-full max-w-sm"
            >
              <option value="">Whatever Windows uses by default</option>
              {printers.map((each) => (
                <option key={each.name} value={each.name}>
                  {each.displayName}
                  {each.isDefault ? ' (default)' : ''}
                </option>
              ))}
            </Select>
          </Field>
          <p className="mt-2 text-xs text-ink-subtle">
            Print sends straight here — no dialog, no picking the paper each time. Set the 80mm
            roll size once in Windows for this printer and every receipt uses it.
          </p>
        </div>
      )}
    </Card>
  )
}
