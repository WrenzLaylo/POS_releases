'use client'

import { useState, useTransition } from 'react'
import { confirmPassword } from '@/server/auth'
import { Button } from '@/components/ui/Button'
import { Dialog } from '@/components/ui/Dialog'
import { Field } from '@/components/ui/Field'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'

/**
 * "Confirm it is you", for an action that can hide money.
 *
 * Built on `Dialog` rather than hand-rolled, so it inherits Escape-to-close,
 * the focus trap and focus restoration along with everything else in the app.
 *
 * Deliberately says WHAT is being confirmed. A password box with no subject is
 * something people type through on reflex, which defeats the whole point of
 * asking — the prompt has to interrupt the thought, not just the click.
 */
export function PasswordPrompt({
  what,
  onConfirmed,
  onCancel,
}: {
  /** The action in her words, e.g. "void this sale". */
  what: string
  onConfirmed: () => void
  onCancel: () => void
}) {
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [pending, startTransition] = useTransition()

  function submit() {
    setError(null)
    startTransition(async () => {
      const result = await confirmPassword(password)
      if (!result.ok) {
        setError(result.error)
        setPassword('')
        return
      }
      onConfirmed()
    })
  }

  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onCancel()
      }}
      title="Confirm it's you"
      description={`Type your password to ${what}.`}
      footer={
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={onCancel} disabled={pending}>
            Cancel
          </Button>
          <Button variant="primary" onClick={submit} disabled={pending}>
            {pending ? 'Checking…' : 'Confirm'}
          </Button>
        </div>
      }
    >
      <form
        onSubmit={(event) => {
          event.preventDefault()
          submit()
        }}
        className="grid gap-4"
      >
        <Field label="Password">
          <Input
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            autoComplete="current-password"
            aria-invalid={error !== null || undefined}
            disabled={pending}
            className="w-full"
            autoFocus
          />
        </Field>
        {error && <FormError>{error}</FormError>}
        <p className="text-xs text-ink-subtle">
          You will not be asked again for a few minutes.
        </p>
      </form>
    </Dialog>
  )
}
