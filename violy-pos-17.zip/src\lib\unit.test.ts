import { describe, expect, it } from 'vitest'
import { ANY_UNIT, unitKeyword, unitKeywordsOf, unitMatches } from './unit'

describe('unitKeyword', () => {
  it.each([
    ['bag (50kg)', 'bag'],
    ['bag (25kg)', 'bag'],
    ['bag', 'bag'],
    ['kilo', 'kilo'],
    ['pack (25x1kg)', 'pack'],
    ['  Bag (50kg) ', 'bag'],
    ['BAG', 'bag'],
    ['bag(50kg)', 'bag'],
    ['', ''],
    ['   ', ''],
  ])('reads %s as %s', (unit, expected) => {
    expect(unitKeyword(unit)).toBe(expected)
  })
})

describe('unitMatches', () => {
  it('treats every size of a bag as a bag', () => {
    // The reason this matches on the first word: "bag" and "bag (50kg)" are
    // the same kind of thing sold in different sizes, and a discount "per bag"
    // means both.
    for (const unit of ['bag', 'bag (50kg)', 'bag (25kg)']) {
      expect(unitMatches(unit, 'bag'), unit).toBe(true)
    }
  })

  it('keeps a per-bag discount away from goods sold by the kilo', () => {
    // The failure this exists to prevent. Pigrolac sells sacks at ₱2,050 and a
    // Booster at ₱110 the kilo, in ONE category — so a ₱20 per-unit discount
    // scoped only by category takes ₱20 off both, which is a rounding error on
    // the sack and a fifth of the price of the kilo.
    expect(unitMatches('kilo', 'bag')).toBe(false)
    expect(unitMatches('pack (25x1kg)', 'bag')).toBe(false)
    expect(unitMatches('bag (50kg)', 'kilo')).toBe(false)
  })

  it('applies to everything when no unit is named', () => {
    // Every customer saved before this column existed has '' here, and must
    // keep being priced exactly as they were.
    for (const unit of ['bag (50kg)', 'kilo', 'pack (25x1kg)', '']) {
      expect(unitMatches(unit, ANY_UNIT), unit).toBe(true)
    }
    expect(unitMatches('kilo', '   ')).toBe(true)
  })

  it('is not fooled by casing or a stored unit with a size on it', () => {
    expect(unitMatches('Bag (50kg)', 'BAG')).toBe(true)
    expect(unitMatches('bag (25kg)', 'bag (50kg)')).toBe(true)
  })
})

describe('unitKeywordsOf', () => {
  it('lists each kind once, sorted, ignoring sizes', () => {
    expect(
      unitKeywordsOf([
        { unit: 'bag (50kg)' },
        { unit: 'kilo' },
        { unit: 'bag (25kg)' },
        { unit: 'pack (25x1kg)' },
        { unit: 'bag' },
      ]),
    ).toEqual(['bag', 'kilo', 'pack'])
  })

  it('drops blanks rather than offering an unnamed unit', () => {
    expect(unitKeywordsOf([{ unit: '' }, { unit: '  ' }, { unit: 'bag' }])).toEqual(['bag'])
  })

  it('is empty for an empty catalog', () => {
    expect(unitKeywordsOf([])).toEqual([])
  })
})
