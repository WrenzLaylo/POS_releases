'use server'

import { prisma } from '@/lib/db'
import type { ActionResult } from '@/lib/types'
import { ROUTES } from '@/lib/routes'
import { revalidateRoutes } from './revalidate'

/** Thrown inside the transaction to roll it back with a message worth reading. */
class StockCountError extends Error {}

export type StockCountRow = {
  productId: number
  /** What is physically on the shelf, counted. An absolute figure, not a delta. */
  countedQty: number
}

export type StockCountResult = {
  /** How many products actually moved. A row counted at what it already said is not one. */
  changed: number
  /** Net units added across every changed row; negative when the count found less. */
  netQuantity: number
}

/**
 * Records a shelf count: sets each product's stock to what was actually there.
 *
 * ABSOLUTE, not a delta, and that is the whole design. A stock take answers
 * "there are 40 sacks of Atlas Grower on the floor", not "add 40" — so saving
 * the same count twice leaves the same answer, and a lost connection or a
 * double-tap on Save cannot double the inventory. Deliveries are the opposite
 * (`increment`) and need their idempotency key for exactly that reason; this
 * needs none.
 *
 * Everything lands in ONE transaction. A half-applied count is worse than no
 * count: she would have no way to tell which shelves were saved and which were
 * not, and the only way back would be counting the whole shop again.
 *
 * Rows that match what the product already says are skipped rather than
 * written. Otherwise the first stock take would post fifty-five `MANUAL`
 * movements of zero and bury the handful that actually mean something.
 *
 * A movement is written for every row that DOES change, because a stock figure
 * that moves with no record of who moved it is how an inventory stops being
 * believed. `MANUAL` is the same type the product form's stock field writes,
 * since it is the same act — a person asserting a number — only in bulk.
 */
export async function recordStockCount(
  rows: readonly StockCountRow[],
  note = 'Stock count',
): Promise<ActionResult<StockCountResult>> {
  if (rows.length === 0) return { ok: false, error: 'Nothing was counted yet.' }

  const seen = new Set<number>()
  for (const row of rows) {
    if (!Number.isInteger(row.productId) || row.productId <= 0) {
      return { ok: false, error: 'A counted row is missing its product.' }
    }
    // Two rows for one product would apply in an order nobody chose, and the
    // last one silently wins. The grid cannot produce this; a caller can.
    if (seen.has(row.productId)) {
      return { ok: false, error: 'The same product was counted twice.' }
    }
    seen.add(row.productId)

    // Finite, not integer: Broodsow sells by the kilo and 18.5 is a real
    // count. Negative is refused — a shelf cannot hold less than nothing, and
    // unlike the counter, which may oversell deliberately with a confirmation,
    // there is no reading of "I counted minus two".
    if (!Number.isFinite(row.countedQty) || row.countedQty < 0) {
      return { ok: false, error: 'A count must be zero or more.' }
    }
  }

  let result: StockCountResult
  try {
    result = await prisma.$transaction(async (tx) => {
      const products = await tx.product.findMany({
        where: { id: { in: [...seen] } },
        select: { id: true, name: true, stockQty: true, isArchived: true },
      })
      const byId = new Map(products.map((product) => [product.id, product]))

      for (const row of rows) {
        const product = byId.get(row.productId)
        if (!product) throw new StockCountError('A product on this count no longer exists.')
        // An archived product is not on the shelf to be counted. Refused
        // rather than silently un-archiving, the same way a delivery refuses.
        if (product.isArchived) {
          throw new StockCountError(
            `${product.name} is archived. Restore it before counting it in.`,
          )
        }
      }

      let changed = 0
      let netQuantity = 0

      for (const row of rows) {
        const product = byId.get(row.productId)!
        const delta = row.countedQty - product.stockQty
        if (delta === 0) continue

        changed += 1
        netQuantity += delta

        await tx.product.update({
          where: { id: row.productId },
          data: { stockQty: row.countedQty },
        })
        await tx.stockMovement.create({
          data: {
            productId: row.productId,
            type: 'MANUAL',
            quantity: delta,
            note,
          },
        })
      }

      return { changed, netQuantity }
    })
  } catch (error) {
    if (error instanceof StockCountError) return { ok: false, error: error.message }
    return { ok: false, error: 'Could not save the count. Nothing was changed.' }
  }

  revalidateRoutes([ROUTES.stock, ROUTES.counter, ROUTES.dashboard], { layout: true })
  return { ok: true, data: result }
}
