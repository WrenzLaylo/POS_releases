/**
 * Test-only stand-in for `next/cache`.
 *
 * `revalidatePath`/`revalidateTag` throw ("Invariant: static generation
 * store missing") when called outside a Next.js request/render context,
 * which is exactly how server actions run under Vitest. Actions call these
 * as a side effect they don't otherwise depend on, so tests alias
 * `next/cache` to these no-ops (see `vitest.config.ts`) instead of mocking
 * per test file.
 */
export function revalidatePath(): void {}
export function revalidateTag(): void {}
