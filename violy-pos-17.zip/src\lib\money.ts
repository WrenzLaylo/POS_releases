/**
 * All money in this app is stored and passed as integer centavos.
 * SQLite has no decimal type, and float sums drift: 1400.00 + 32.50
 * can surface as 1432.4999999. Conversion lives here and nowhere else.
 */

export function toCentavos(pesos: number): number {
  return Math.round(pesos * 100)
}

export function toPesos(centavos: number): number {
  return centavos / 100
}

export function formatPeso(centavos: number): string {
  const sign = centavos < 0 ? '-' : ''
  const abs = Math.abs(centavos)
  const whole = Math.floor(abs / 100).toLocaleString('en-US')
  const fraction = String(abs % 100).padStart(2, '0')
  return `${sign}₱${whole}.${fraction}`
}

export function lineTotal(priceCentavos: number, quantity: number): number {
  return Math.round(priceCentavos * quantity)
}

/**
 * Parses money as a person types it — `1,000.50` — into centavos.
 *
 * Returns null, never 0, for anything unparseable. A helper that coerced bad
 * input to zero would let a mistyped payment be recorded as ₱0.00 with no
 * complaint, so callers must treat null as a validation failure.
 *
 * Negatives are rejected: every money field in this app takes an amount, and
 * direction comes from context (a PAYMENT entry, cash tendered), never from a
 * minus sign the operator typed.
 */
export function parsePesoInput(raw: string): number | null {
  const cleaned = raw.replace(/[,\s]/g, '')
  if (cleaned === '') return null
  if (!/^\d+(\.\d{1,2})?$/.test(cleaned)) return null
  return toCentavos(Number(cleaned))
}
