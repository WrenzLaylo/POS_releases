/** Rows per page on the long lists. One value, so every screen that paginates
 *  behaves identically.
 *
 *  Ten, not twenty. Twenty rows do not fit a laptop screen, so the stock table
 *  wrapped itself in `max-h-[65vh] overflow-auto` and you ended up scrolling a
 *  table inside a scrolling page — two scrollbars for one list. A page that
 *  fits is the point of paging.
 *
 *  Ten was measured, not picked: with 53px rows, the filter block and the
 *  pager, ten rows leave ~70px spare in an 886px content area and twelve
 *  overflow it by 91px. No single number fits every window — a very short one
 *  will still scroll — but this fits the machine this runs on. */
export const PAGE_SIZE = 10

/** A page number out of a URL is untrusted text. Anything that is not a
 *  positive integer means page 1 — she should never see an error because a
 *  query string was odd. */
export function parsePage(raw: string | undefined): number {
  const n = Number(raw)
  if (!Number.isInteger(n) || n < 1) return 1
  return n
}

/** Always at least 1: an empty list is still "page 1 of 1", not "page 1 of 0". */
export function pageCountOf(total: number): number {
  return Math.max(1, Math.ceil(total / PAGE_SIZE))
}

export function clampPage(page: number, pageCount: number): number {
  return Math.min(Math.max(page, 1), pageCount)
}
