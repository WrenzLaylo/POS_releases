-- AlterTable
ALTER TABLE "Customer" ADD COLUMN "dueAt" DATETIME;
