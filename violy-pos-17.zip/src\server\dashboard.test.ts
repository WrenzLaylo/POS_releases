import { describe, it, expect, beforeEach } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'
import { getDashboard } from '@/server/dashboard'
import { createOrder } from '@/server/orders'
import { createSale } from '@/server/sales'
import { recordPayment, setOpeningBalance, voidEntry } from '@/server/ledger'

beforeEach(resetDb)

const NOW = new Date(2026, 6, 25, 15, 0) // Saturday 25 July 2026

async function makeProduct(name: string, price: number, cost: number, stock = 50, threshold = 10) {
  const category = await prisma.category.upsert({
    where: { name: 'Pig Feeds' },
    create: { name: 'Pig Feeds' },
    update: {},
  })
  return prisma.product.create({
    data: {
      categoryId: category.id,
      name,
      unit: 'sako (50kg)',
      price,
      costPrice: cost,
      stockQty: stock,
      lowStockThreshold: threshold,
    },
  })
}

async function makeSale(createdAt: Date, productId: number, quantity: number, price: number, cost: number) {
  return prisma.sale.create({
    data: {
      createdAt,
      totalAmount: Math.round(price * quantity),
      items: { create: [{ productId, quantity, priceAtSale: price, costAtSale: cost }] },
    },
  })
}

describe('getDashboard earnings', () => {
  it('counts only today for the today tile', async () => {
    const product = await makeProduct('Hog Grower (sako)', 140000, 128000)
    await makeSale(new Date(2026, 6, 25, 9, 0), product.id, 1, 140000, 128000)
    await makeSale(new Date(2026, 6, 24, 9, 0), product.id, 1, 140000, 128000)

    const data = await getDashboard(NOW)

    expect(data.todayCentavos).toBe(140000)
  })

  it('includes a sale at one minute past midnight today', async () => {
    const product = await makeProduct('Hog Grower (sako)', 140000, 128000)
    await makeSale(new Date(2026, 6, 25, 0, 1), product.id, 1, 140000, 128000)

    const data = await getDashboard(NOW)

    expect(data.todayCentavos).toBe(140000)
  })

  it('starts the week on Monday', async () => {
    const product = await makeProduct('Hog Grower (sako)', 140000, 128000)
    await makeSale(new Date(2026, 6, 20, 9, 0), product.id, 1, 140000, 128000) // Monday, in
    await makeSale(new Date(2026, 6, 19, 9, 0), product.id, 1, 140000, 128000) // Sunday, out

    const data = await getDashboard(NOW)

    expect(data.weekCentavos).toBe(140000)
  })

  it('counts the calendar month only', async () => {
    const product = await makeProduct('Hog Grower (sako)', 140000, 128000)
    await makeSale(new Date(2026, 6, 1, 9, 0), product.id, 1, 140000, 128000) // in
    await makeSale(new Date(2026, 5, 30, 9, 0), product.id, 1, 140000, 128000) // out

    const data = await getDashboard(NOW)

    expect(data.monthCentavos).toBe(140000)
  })
})

describe('getDashboard profit', () => {
  it('uses the snapshotted cost, not the product current cost', async () => {
    const product = await makeProduct('Hog Grower (sako)', 140000, 128000)
    await makeSale(new Date(2026, 6, 10, 9, 0), product.id, 2, 140000, 128000)

    // Cost rises after the sale; profit for that sale must not move.
    await prisma.product.update({ where: { id: product.id }, data: { costPrice: 136000 } })

    const data = await getDashboard(NOW)

    expect(data.monthProfitCentavos).toBe((140000 - 128000) * 2)
  })

  it('accounts for fractional quantities', async () => {
    const product = await makeProduct('Hog Grower (kilo)', 3250, 2800)
    await makeSale(new Date(2026, 6, 10, 9, 0), product.id, 2.5, 3250, 2800)

    const data = await getDashboard(NOW)

    expect(data.monthProfitCentavos).toBe(Math.round((3250 - 2800) * 2.5))
  })
})

describe('getDashboard and per-line discounts', () => {
  /** A sale whose line carries a granted discount, priced the way
   *  `createOrder` writes one: `totalAmount` is net, `priceAtSale` is list,
   *  and `discountAtSale` is what was taken off each unit. */
  async function makeDiscountedSale(
    createdAt: Date,
    productId: number,
    quantity: number,
    price: number,
    cost: number,
    discount: number,
  ) {
    return prisma.sale.create({
      data: {
        createdAt,
        totalAmount: Math.round((price - discount) * quantity),
        items: {
          create: [
            { productId, quantity, priceAtSale: price, costAtSale: cost, discountAtSale: discount },
          ],
        },
      },
    })
  }

  it('computes profit from the discounted price, not the list price', async () => {
    const product = await makeProduct('Starter (sako)', 157500, 145000)
    await makeDiscountedSale(new Date(2026, 6, 10, 9, 0), product.id, 5, 157500, 145000, 5000)

    const data = await getDashboard(NOW)

    // Net price is 152500, not 157500. Using the list price would overstate
    // profit by 5000 x 5 = 25000.
    expect(data.monthProfitCentavos).toBe((157500 - 5000 - 145000) * 5)
  })

  it('keeps benta and profit on the same basis for a discounted sale', async () => {
    const product = await makeProduct('Starter (sako)', 157500, 145000)
    await makeDiscountedSale(new Date(2026, 6, 10, 9, 0), product.id, 5, 157500, 145000, 5000)

    const data = await getDashboard(NOW)

    // monthCentavos comes from sale.totalAmount, which is already discounted;
    // profit must never exceed benta minus cost computed the same way.
    expect(data.monthCentavos).toBe(152500 * 5)
    expect(data.monthProfitCentavos).toBe(data.monthCentavos - 145000 * 5)
  })

  it('counts top-product revenue at the discounted price', async () => {
    const product = await makeProduct('Starter (sako)', 157500, 145000)
    await makeDiscountedSale(new Date(2026, 6, 10, 9, 0), product.id, 5, 157500, 145000, 5000)

    const data = await getDashboard(NOW)

    expect(data.topProducts[0].revenueCentavos).toBe(152500 * 5)
  })

  it('ranks top products by what was charged, not by list price', async () => {
    // At list price the discounted product would rank first (160000 vs.
    // 155000); at the price actually charged it ranks second.
    const discounted = await makeProduct('Discounted (sako)', 160000, 140000)
    const plain = await makeProduct('Plain (sako)', 155000, 140000)
    await makeDiscountedSale(new Date(2026, 6, 10, 9, 0), discounted.id, 1, 160000, 140000, 10000)
    await makeSale(new Date(2026, 6, 11, 9, 0), plain.id, 1, 155000, 140000)

    const data = await getDashboard(NOW)

    expect(data.topProducts.map((p) => p.name)).toEqual(['Plain (sako)', 'Discounted (sako)'])
  })

  it('leaves an undiscounted sale unchanged', async () => {
    const product = await makeProduct('Hog Grower (sako)', 140000, 128000)
    await makeSale(new Date(2026, 6, 10, 9, 0), product.id, 2, 140000, 128000)

    const data = await getDashboard(NOW)

    expect(data.monthProfitCentavos).toBe((140000 - 128000) * 2)
    expect(data.topProducts[0].revenueCentavos).toBe(280000)
  })
})

describe('getDashboard trend', () => {
  it('returns thirty daily buckets ending today, zero-filled', async () => {
    const product = await makeProduct('Hog Grower (sako)', 140000, 128000)
    await makeSale(new Date(2026, 6, 25, 9, 0), product.id, 1, 140000, 128000)

    const data = await getDashboard(NOW)

    expect(data.trend).toHaveLength(30)
    expect(data.trend[29]).toEqual({ day: '2026-07-25', totalCentavos: 140000 })
    expect(data.trend[0]).toEqual({ day: '2026-06-26', totalCentavos: 0 })
  })

  it('sums multiple sales landing on the same day', async () => {
    const product = await makeProduct('Hog Grower (sako)', 140000, 128000)
    await makeSale(new Date(2026, 6, 25, 9, 0), product.id, 1, 140000, 128000)
    await makeSale(new Date(2026, 6, 25, 17, 0), product.id, 1, 140000, 128000)

    const data = await getDashboard(NOW)

    expect(data.trend[29].totalCentavos).toBe(280000)
  })
})

describe('getDashboard top products', () => {
  it('ranks by revenue and caps at five', async () => {
    const sako = await makeProduct('Hog Grower (sako)', 140000, 128000)
    const kilo = await makeProduct('Hog Grower (kilo)', 3250, 2800)
    await makeSale(new Date(2026, 6, 10, 9, 0), sako.id, 1, 140000, 128000)
    await makeSale(new Date(2026, 6, 11, 9, 0), kilo.id, 4, 3250, 2800)

    const data = await getDashboard(NOW)

    expect(data.topProducts).toHaveLength(2)
    expect(data.topProducts[0].name).toBe('Hog Grower (sako)')
    expect(data.topProducts[0].revenueCentavos).toBe(140000)
    expect(data.topProducts[1].quantitySold).toBe(4)
  })
})

describe('getDashboard low stock', () => {
  it('lists products at or under threshold, excluding archived', async () => {
    await makeProduct('Hog Finisher (sako)', 152000, 139000, 3, 5) // low
    await makeProduct('Hog Grower (sako)', 140000, 128000, 12, 5) // fine
    const archived = await makeProduct('Old Feed', 100000, 90000, 0, 5)
    await prisma.product.update({ where: { id: archived.id }, data: { isArchived: true } })

    const data = await getDashboard(NOW)

    expect(data.lowStock.map((p) => p.name)).toEqual(['Hog Finisher (sako)'])
  })

  it('includes a product with negative stock from over-selling', async () => {
    await makeProduct('Hog Finisher (sako)', 152000, 139000, -2, 5)

    const data = await getDashboard(NOW)

    expect(data.lowStock[0].stockQty).toBe(-2)
  })
})

describe('cash received vs. benta', () => {
  it('counts a fully-paid order in both benta and cash', async () => {
    const product = await makeProduct('Starter', 100000, 90000)
    const customer = await prisma.customer.create({ data: { name: 'PAID' } })
    await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 1 }],
      cashPaidCentavos: 100000,
      occurredAt: NOW,
    })

    const data = await getDashboard(NOW)

    expect(data.todayCentavos).toBe(100000)
    expect(data.todayCashCentavos).toBe(100000)
    expect(data.totalUtangCentavos).toBe(0)
  })

  it('counts a pure-utang order in benta but not in cash', async () => {
    const product = await makeProduct('Starter', 100000, 90000)
    const customer = await prisma.customer.create({ data: { name: 'UTANG' } })
    await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 1 }],
      cashPaidCentavos: 0,
      occurredAt: NOW,
    })

    const data = await getDashboard(NOW)

    expect(data.todayCentavos).toBe(100000)
    expect(data.todayCashCentavos).toBe(0)
    expect(data.totalUtangCentavos).toBe(100000)
  })

  it('counts a later payment as cash without moving benta', async () => {
    const product = await makeProduct('Starter', 100000, 90000)
    const customer = await prisma.customer.create({ data: { name: 'LATER' } })
    await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 1 }],
      cashPaidCentavos: 0,
      occurredAt: NOW,
    })

    await recordPayment({
      customerId: customer.id,
      amountCentavos: 40000,
      occurredAt: NOW,
    })

    const data = await getDashboard(NOW)

    expect(data.todayCentavos).toBe(100000)
    expect(data.todayCashCentavos).toBe(40000)
    expect(data.totalUtangCentavos).toBe(60000)
  })

  it('excludes a voided payment from cash received', async () => {
    const customer = await prisma.customer.create({ data: { name: 'VOIDED' } })
    const payment = await recordPayment({
      customerId: customer.id,
      amountCentavos: 40000,
      occurredAt: NOW,
    })
    if (!payment.ok) throw new Error('setup failed')
    await voidEntry(payment.data.entryId)

    const data = await getDashboard(NOW)

    expect(data.todayCashCentavos).toBe(0)
    expect(data.totalUtangCentavos).toBe(0)
  })

  it('counts a /pos walk-in sale from createSale in both benta and cash', async () => {
    // createSale has no occurredAt override — its Sale row is timestamped by
    // the database's own CURRENT_TIMESTAMP default, not the injectable `now`
    // used elsewhere in this file. Read the row back to learn its actual
    // createdAt, then pin the dashboard's clock to that moment.
    const product = await makeProduct('Hog Grower (sako)', 140000, 128000)

    const result = await createSale([{ productId: product.id, quantity: 1 }])
    expect(result.ok).toBe(true)
    if (!result.ok) throw new Error('setup failed')

    const sale = await prisma.sale.findUniqueOrThrow({ where: { id: result.data.saleId } })
    const data = await getDashboard(sale.createdAt)

    expect(data.todayCentavos).toBe(140000)
    expect(data.todayCashCentavos).toBe(140000)
  })

  it('ranks the largest balances first', async () => {
    const big = await prisma.customer.create({ data: { name: 'BIG' } })
    const small = await prisma.customer.create({ data: { name: 'SMALL' } })
    await setOpeningBalance({ customerId: big.id, amountCentavos: 780000, occurredAt: NOW })
    await setOpeningBalance({ customerId: small.id, amountCentavos: 50000, occurredAt: NOW })

    const data = await getDashboard(NOW)

    expect(data.topBalances.map((b) => b.name)).toEqual(['BIG', 'SMALL'])
    expect(data.totalUtangCentavos).toBe(830000)
  })
})
