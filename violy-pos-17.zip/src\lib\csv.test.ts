import { describe, expect, it } from 'vitest'
import { centavosToCsv, csvToCentavos, parseCsv, rowsToRecords, toCsv } from './csv'

describe('centavosToCsv', () => {
  it('writes decimal pesos, always two places', () => {
    expect(centavosToCsv(145_000)).toBe('1450.00')
    expect(centavosToCsv(5)).toBe('0.05')
    expect(centavosToCsv(0)).toBe('0.00')
    expect(centavosToCsv(-4_200)).toBe('-42.00')
  })

  it('never emits a thousands separator', () => {
    // A comma inside a number would need quoting and trips up half the
    // spreadsheets that open it.
    expect(centavosToCsv(19_202_864)).toBe('192028.64')
  })
})

describe('csvToCentavos', () => {
  it('reads what a spreadsheet is likely to write', () => {
    expect(csvToCentavos('1450.00')).toBe(145_000)
    expect(csvToCentavos('1,450.00')).toBe(145_000)
    expect(csvToCentavos('₱1,450')).toBe(145_000)
    expect(csvToCentavos(' 33 ')).toBe(3_300)
  })

  it('returns null rather than zero for anything unreadable', () => {
    // Zero would be a silent giveaway: a price column that reads "N/A" would
    // import as free.
    expect(csvToCentavos('N/A')).toBeNull()
    expect(csvToCentavos('')).toBeNull()
    expect(csvToCentavos('1.234')).toBeNull()
    expect(csvToCentavos('abc')).toBeNull()
  })
})

describe('toCsv', () => {
  it('quotes only what needs it', () => {
    const csv = toCsv(['name', 'note'], [['Dewormer', 'plain']])
    expect(csv).toBe('name,note\r\nDewormer,plain')
  })

  it('quotes commas, quotes, newlines and edge whitespace', () => {
    const csv = toCsv(
      ['name', 'note'],
      [
        ['ADM Broodsow, 50kg', 'he said "later"'],
        ['Multi', 'line\nnote'],
        [' padded ', 'x'],
      ],
    )
    expect(csv).toContain('"ADM Broodsow, 50kg"')
    expect(csv).toContain('"he said ""later"""')
    expect(csv).toContain('"line\nnote"')
    expect(csv).toContain('" padded "')
  })
})

describe('parseCsv', () => {
  it('round-trips everything toCsv quotes', () => {
    const headers = ['name', 'note']
    const rows = [
      ['ADM Broodsow, 50kg', 'he said "later"'],
      ['Multi', 'line\nnote'],
      [' padded ', ''],
    ]
    expect(parseCsv(toCsv(headers, rows))).toEqual([headers, ...rows])
  })

  it('keeps a newline inside a quoted field as one field', () => {
    // The reason this is a scanner and not a line split: a split on \n would
    // read this as two rows.
    const parsed = parseCsv('name,note\r\nDewormer,"blue tag\nsecond line"')
    expect(parsed).toHaveLength(2)
    expect(parsed[1]).toEqual(['Dewormer', 'blue tag\nsecond line'])
  })

  it('accepts CRLF, LF and a trailing newline without inventing a row', () => {
    expect(parseCsv('a,b\r\n1,2\r\n')).toEqual([['a', 'b'], ['1', '2']])
    expect(parseCsv('a,b\n1,2\n')).toEqual([['a', 'b'], ['1', '2']])
  })

  it('strips the byte order mark Excel writes', () => {
    // Left on, the first header becomes "﻿name" and no column matches.
    const parsed = parseCsv('﻿name,price\r\nDewormer,320.00')
    expect(parsed[0][0]).toBe('name')
  })
})

describe('rowsToRecords', () => {
  it('keys on headers, ignoring case and surrounding space', () => {
    const records = rowsToRecords([
      [' Name ', 'PRICE'],
      ['Dewormer', '320.00'],
    ])
    expect(records).toEqual([{ name: 'Dewormer', price: '320.00' }])
  })

  it('fills missing trailing cells rather than leaving them undefined', () => {
    const records = rowsToRecords([
      ['name', 'price', 'note'],
      ['Dewormer', '320.00'],
    ])
    expect(records[0].note).toBe('')
  })

  it('returns nothing for an empty file', () => {
    expect(rowsToRecords([])).toEqual([])
  })
})
