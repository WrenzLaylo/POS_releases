import { describe, expect, it } from 'vitest'
import {
  MAX_DAYS_AHEAD,
  MAX_DELIVERY_FEE_CENTAVOS,
  MAX_DESTINATION_LENGTH,
  deliveryOrderTotal,
  validateDeliveryDetails,
  type DeliveryOrderDetails,
} from './delivery-order'

const TODAY = new Date(2026, 7, 24, 14, 0, 0)

function details(overrides: Partial<DeliveryOrderDetails> = {}): DeliveryOrderDetails {
  return {
    deliverAt: new Date(2026, 7, 26),
    deliverTo: 'Bagac',
    address: '',
    instructions: '',
    feeCentavos: 0,
    ...overrides,
  }
}

describe('what a delivery order comes to', () => {
  it('adds the fee to the priced goods', () => {
    expect(deliveryOrderTotal(2_010_000, 30_000)).toBe(2_040_000)
  })

  it('is the goods alone when the trip is free', () => {
    expect(deliveryOrderTotal(2_010_000, 0)).toBe(2_010_000)
  })
})

describe('validateDeliveryDetails', () => {
  it('accepts an ordinary load booked for later this week', () => {
    expect(validateDeliveryDetails(details(), TODAY)).toBeNull()
  })

  // The rule that runs the OPPOSITE way to an incoming delivery's. Sacks
  // arriving cannot be dated forward; sacks going out nearly always are.
  it('allows a delivery date in the future', () => {
    expect(
      validateDeliveryDetails(details({ deliverAt: new Date(2026, 8, 30) }), TODAY),
    ).toBeNull()
  })

  it('allows a load that went out yesterday and is typed up this morning', () => {
    expect(
      validateDeliveryDetails(details({ deliverAt: new Date(2026, 7, 23) }), TODAY),
    ).toBeNull()
  })

  it('allows a booking exactly at the limit', () => {
    const atLimit = new Date(TODAY)
    atLimit.setHours(23, 59, 59, 999)
    atLimit.setDate(atLimit.getDate() + MAX_DAYS_AHEAD)
    expect(validateDeliveryDetails(details({ deliverAt: atLimit }), TODAY)).toBeNull()
  })

  it('refuses a date more than a year out', () => {
    const tooFar = new Date(TODAY)
    tooFar.setHours(23, 59, 59, 999)
    tooFar.setDate(tooFar.getDate() + MAX_DAYS_AHEAD + 2)
    expect(validateDeliveryDetails(details({ deliverAt: tooFar }), TODAY)).toMatch(/year away/)
  })

  it('refuses a date it cannot read', () => {
    expect(
      validateDeliveryDetails(details({ deliverAt: new Date(Number.NaN) }), TODAY),
    ).toMatch(/not a date/)
  })

  it('requires somewhere to send it', () => {
    expect(validateDeliveryDetails(details({ deliverTo: '' }), TODAY)).toMatch(/where/)
    expect(validateDeliveryDetails(details({ deliverTo: '   ' }), TODAY)).toMatch(/where/)
  })

  it('refuses a destination too long to read on a line', () => {
    expect(
      validateDeliveryDetails(
        details({ deliverTo: 'x'.repeat(MAX_DESTINATION_LENGTH + 1) }),
        TODAY,
      ),
    ).toMatch(/too long/)
  })

  it('takes an address and instructions when they are given', () => {
    expect(
      validateDeliveryDetails(
        details({
          address: '123 Purok 4, Barangay Ibaba, Bagac, Bataan',
          instructions: 'Leave with the caretaker if nobody is home.',
        }),
        TODAY,
      ),
    ).toBeNull()
  })

  it('accepts a fee, and zero, and refuses nonsense', () => {
    expect(validateDeliveryDetails(details({ feeCentavos: 30_000 }), TODAY)).toBeNull()
    expect(validateDeliveryDetails(details({ feeCentavos: 0 }), TODAY)).toBeNull()
    expect(validateDeliveryDetails(details({ feeCentavos: -1 }), TODAY)).toMatch(/zero or more/)
    // Centavos are integers everywhere in this app; a float here would be a
    // peso figure that never got scaled.
    expect(validateDeliveryDetails(details({ feeCentavos: 300.5 }), TODAY)).toMatch(
      /zero or more/,
    )
    expect(
      validateDeliveryDetails(
        details({ feeCentavos: MAX_DELIVERY_FEE_CENTAVOS + 1 }),
        TODAY,
      ),
    ).toMatch(/looks wrong/)
  })

  it('complains about the date before the destination', () => {
    // Ordered so the most basic problem surfaces first: being told the
    // destination is missing while the date is unreadable is not helpful.
    expect(
      validateDeliveryDetails(
        details({ deliverAt: new Date(Number.NaN), deliverTo: '' }),
        TODAY,
      ),
    ).toMatch(/not a date/)
  })
})
