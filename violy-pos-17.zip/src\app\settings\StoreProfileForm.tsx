'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import type { StoreProfile } from '@prisma/client'
import { updateStoreProfile } from '@/server/store-profile'
import { storeProfileLines } from '@/lib/store-profile'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Field } from '@/components/ui/Field'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'

type Draft = {
  name: string
  tagline: string
  registeredName: string
  addressLine1: string
  addressLine2: string
  contactNumber: string
  email: string
  tin: string
  businessRegistrationNo: string
}

function draftFrom(profile: StoreProfile): Draft {
  return {
    name: profile.name,
    tagline: profile.tagline,
    registeredName: profile.registeredName,
    addressLine1: profile.addressLine1,
    addressLine2: profile.addressLine2,
    contactNumber: profile.contactNumber,
    email: profile.email,
    tin: profile.tin,
    businessRegistrationNo: profile.businessRegistrationNo,
  }
}

/**
 * The shop's own details, as printed on every receipt, invoice and statement.
 *
 * A live preview of the printed identity block sits beside the fields, because
 * the rule that makes this form safe — a blank field is omitted from the
 * document, never printed empty — is invisible otherwise. Seeing "TIN" vanish
 * from the preview when you clear it is the explanation.
 */
export function StoreProfileForm({ profile }: { profile: StoreProfile }) {
  const router = useRouter()
  const [draft, setDraft] = useState<Draft>(() => draftFrom(profile))
  const [error, setError] = useState<string | null>(null)
  const [saved, setSaved] = useState(false)
  const [pending, startTransition] = useTransition()

  function set<K extends keyof Draft>(key: K, value: string) {
    setDraft((current) => ({ ...current, [key]: value }))
    setSaved(false)
    setError(null)
  }

  function save() {
    setError(null)
    startTransition(async () => {
      const result = await updateStoreProfile(draft)
      if (!result.ok) {
        setError(result.error)
        return
      }
      setSaved(true)
      router.refresh()
    })
  }

  const preview = storeProfileLines(draft)

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_20rem]">
      <Card>
        <h2 className="mb-1 text-base font-semibold">Store details</h2>
        <p className="mb-4 text-sm text-ink-muted">
          These print at the head of every receipt, invoice and statement. Leave anything you do
          not have blank — a blank field is left off the document entirely, rather than printed
          empty.
        </p>

        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Store name">
            <Input
              value={draft.name}
              onChange={(event) => set('name', event.target.value)}
              className="w-full"
              placeholder="Violy Store"
            />
          </Field>

          <Field label="Tagline">
            <Input
              value={draft.tagline}
              onChange={(event) => set('tagline', event.target.value)}
              className="w-full"
              placeholder="Pig feeds and store supplies"
            />
          </Field>

          <Field label="Registered business name" className="sm:col-span-2">
            <Input
              value={draft.registeredName}
              onChange={(event) => set('registeredName', event.target.value)}
              className="w-full"
              placeholder="Only if it differs from the store name"
            />
          </Field>

          <Field label="Address line 1" className="sm:col-span-2">
            <Input
              value={draft.addressLine1}
              onChange={(event) => set('addressLine1', event.target.value)}
              className="w-full"
              placeholder="Street, barangay"
            />
          </Field>

          <Field label="Address line 2" className="sm:col-span-2">
            <Input
              value={draft.addressLine2}
              onChange={(event) => set('addressLine2', event.target.value)}
              className="w-full"
              placeholder="City, province, postal code"
            />
          </Field>

          <Field label="Contact number">
            <Input
              value={draft.contactNumber}
              onChange={(event) => set('contactNumber', event.target.value)}
              className="w-full"
              placeholder="09XX XXX XXXX"
            />
          </Field>

          <Field label="Email">
            <Input
              value={draft.email}
              onChange={(event) => set('email', event.target.value)}
              className="w-full"
              placeholder="store@example.com"
            />
          </Field>

          <Field label="TIN">
            <Input
              value={draft.tin}
              onChange={(event) => set('tin', event.target.value)}
              className="w-full tabular-nums"
              placeholder="000-000-000-000"
            />
          </Field>

          <Field label="Business registration no.">
            <Input
              value={draft.businessRegistrationNo}
              onChange={(event) => set('businessRegistrationNo', event.target.value)}
              className="w-full"
              placeholder="DTI / SEC / permit number"
            />
          </Field>
        </div>

        {error && <FormError className="mt-4">{error}</FormError>}

        <div className="mt-5 flex items-center gap-3">
          <Button variant="primary" onClick={save} disabled={pending}>
            {pending ? 'Saving…' : 'Save details'}
          </Button>
          {saved && !pending && (
            <span className="text-sm text-money-in" role="status">
              Saved. Every document now prints these.
            </span>
          )}
        </div>
      </Card>

      <Card variant="raised" className="h-fit">
        <h2 className="mb-1 text-base font-semibold">How it will print</h2>
        <p className="mb-4 text-sm text-ink-muted">
          The heading block at the top of every document.
        </p>

        <div className="rounded-card border border-line bg-surface p-4">
          <div className="text-xl font-semibold text-ink">
            {draft.name.trim() === '' ? 'Store name' : draft.name}
          </div>
          {draft.tagline.trim() !== '' && (
            <div className="mt-1 text-sm text-ink-muted">{draft.tagline}</div>
          )}
          {preview.length > 0 ? (
            <address className="mt-2 not-italic text-xs leading-relaxed text-ink-muted">
              {preview.map((line) => (
                <div key={`${line.label ?? ''}-${line.value}`}>
                  {line.label && <span className="font-medium">{line.label}: </span>}
                  {line.value}
                </div>
              ))}
            </address>
          ) : (
            <p className="mt-3 text-xs text-ink-subtle">
              Nothing else filled in yet, so documents print the name alone.
            </p>
          )}
        </div>
      </Card>
    </div>
  )
}
