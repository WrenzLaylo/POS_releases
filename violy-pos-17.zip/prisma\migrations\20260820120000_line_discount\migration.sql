-- A discount for a whole sale line, separate from the per-unit one.
--
-- "₱500 off this line" cannot be held per unit: across three sacks that is
-- ₱166.666… and rounding it reached ₱499.98, a figure nobody typed. Held in
-- its own column so the amount she says is the amount that comes off.
--
-- Additive with a default of 0, so every existing sale line keeps exactly the
-- total it already has.
ALTER TABLE "SaleItem" ADD COLUMN "lineDiscountAtSale" INTEGER NOT NULL DEFAULT 0;
