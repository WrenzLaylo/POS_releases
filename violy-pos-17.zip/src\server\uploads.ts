import { randomUUID } from 'node:crypto'
import { mkdir, unlink, writeFile } from 'node:fs/promises'
import path from 'node:path'

/**
 * Where product photos live, and why it is not `public/`.
 *
 * It used to be `public/uploads`, and photos uploaded through the app were
 * never visible: the file was written, the path was stored on the row, and the
 * browser got a 404 for it every time. Next resolves `public/` against a
 * manifest built during `next build`, so a file that appears afterwards does
 * not exist as far as the running server is concerned. `public/` is for assets
 * shipped WITH the app; it is not a runtime write target, and nothing warns you
 * that you are treating it as one — the write succeeds, and only the request
 * fails.
 *
 * So uploads go in `data/uploads` and are served by `src/app/uploads/[file]/`,
 * which reads from disk on each request and therefore sees files added a second
 * ago. The public URL is unchanged at `/uploads/<name>`, so paths already
 * stored on product rows keep resolving.
 */
const UPLOAD_DIR = path.join(process.cwd(), 'data', 'uploads')

const MAX_IMAGE_BYTES = 5 * 1024 * 1024

const EXTENSION_BY_TYPE: Record<string, string> = {
  'image/png': '.png',
  'image/jpeg': '.jpg',
  'image/webp': '.webp',
  'image/gif': '.gif',
}

const TYPE_BY_EXTENSION: Record<string, string> = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
}

/**
 * Exactly the shape this app generates: a v4 UUID and a known extension.
 *
 * An allow-list, not a search for `..`. The route handler joins this onto a
 * directory, and a name that can only be 36 hex-and-dash characters plus an
 * extension cannot climb out of it, cannot name a device, and cannot be a
 * dotfile — without anybody having to enumerate the ways a path can escape.
 */
const SAFE_NAME =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.(png|jpg|webp|gif)$/

export function isSafeUploadName(name: string): boolean {
  return SAFE_NAME.test(name)
}

/**
 * `root` is only passed by the backup code, which is handed a project root
 * rather than assuming the working directory. Everything else wants the
 * running app's own folder.
 */
export function uploadDirectory(root?: string): string {
  return root === undefined ? UPLOAD_DIR : path.join(root, 'data', 'uploads')
}

export function uploadContentType(name: string): string {
  return TYPE_BY_EXTENSION[path.extname(name).toLowerCase()] ?? 'application/octet-stream'
}

function hasValidSignature(type: string, bytes: Buffer): boolean {
  if (type === 'image/png') {
    return bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))
  }
  if (type === 'image/jpeg') {
    return bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff
  }
  if (type === 'image/gif') {
    const header = bytes.subarray(0, 6).toString('ascii')
    return header === 'GIF87a' || header === 'GIF89a'
  }
  if (type === 'image/webp') {
    return bytes.length >= 12 &&
      bytes.subarray(0, 4).toString('ascii') === 'RIFF' &&
      bytes.subarray(8, 12).toString('ascii') === 'WEBP'
  }
  return false
}

/** Saves a verified product image and returns its web path. */
export async function saveProductImage(file: File): Promise<string | null> {
  if (!file || file.size === 0 || file.size > MAX_IMAGE_BYTES) return null
  const extension = EXTENSION_BY_TYPE[file.type]
  if (!extension) return null

  try {
    const bytes = Buffer.from(await file.arrayBuffer())
    if (!hasValidSignature(file.type, bytes)) return null

    await mkdir(UPLOAD_DIR, { recursive: true })
    const fileName = `${randomUUID()}${extension}`
    await writeFile(path.join(UPLOAD_DIR, fileName), bytes, { flag: 'wx' })
    return `/uploads/${fileName}`
  } catch {
    return null
  }
}

/** Removes only files this app created, and only from the uploads directory. */
export async function deleteProductImage(imagePath: string | null | undefined): Promise<void> {
  if (!imagePath?.startsWith('/uploads/')) return
  const fileName = imagePath.slice('/uploads/'.length)
  if (!isSafeUploadName(fileName)) return
  try {
    await unlink(path.join(UPLOAD_DIR, fileName))
  } catch {
    // Missing files are harmless; the database update has already succeeded.
  }
}
