-- Existing accounts with a live positive balance get a full 30-local-day grace
-- period from migration day. Settled and overpaid accounts remain null.
UPDATE "Customer"
SET "dueAt" = CAST(
  strftime(
    '%s',
    'now',
    'localtime',
    'start of day',
    '+30 days',
    'utc'
  ) AS INTEGER
) * 1000
WHERE "dueAt" IS NULL
  AND (
    SELECT COALESCE(
      SUM(
        CASE
          WHEN "entry"."isVoided" = 1 THEN 0
          WHEN "entry"."type" = 'PAYMENT' THEN -"entry"."amountCentavos"
          WHEN "entry"."type" IN ('OPENING', 'CHARGE') THEN "entry"."amountCentavos"
          ELSE 0
        END
      ),
      0
    )
    FROM "LedgerEntry" AS "entry"
    WHERE "entry"."customerId" = "Customer"."id"
  ) > 0;
