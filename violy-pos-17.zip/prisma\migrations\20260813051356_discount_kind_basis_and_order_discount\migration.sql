-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Customer" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "name" TEXT NOT NULL,
    "phone" TEXT,
    "notes" TEXT NOT NULL DEFAULT '',
    "isArchived" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "dueAt" DATETIME,
    "discountCentavos" INTEGER NOT NULL DEFAULT 0,
    "discountKind" TEXT NOT NULL DEFAULT 'AMOUNT',
    "discountBps" INTEGER NOT NULL DEFAULT 0,
    "discountBasis" TEXT NOT NULL DEFAULT 'PER_UNIT'
);
INSERT INTO "new_Customer" ("createdAt", "discountCentavos", "dueAt", "id", "isArchived", "name", "notes", "phone") SELECT "createdAt", "discountCentavos", "dueAt", "id", "isArchived", "name", "notes", "phone" FROM "Customer";
DROP TABLE "Customer";
ALTER TABLE "new_Customer" RENAME TO "Customer";
CREATE UNIQUE INDEX "Customer_name_key" ON "Customer"("name");
CREATE TABLE "new_Sale" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "totalAmount" INTEGER NOT NULL,
    "customerId" INTEGER,
    "cashPaidCentavos" INTEGER NOT NULL DEFAULT 0,
    "cashTenderedCentavos" INTEGER,
    "changeCentavos" INTEGER NOT NULL DEFAULT 0,
    "customerBalanceAfterCentavos" INTEGER,
    "customerDiscountCentavos" INTEGER NOT NULL DEFAULT 0,
    "orderDiscountCentavos" INTEGER NOT NULL DEFAULT 0,
    "orderDiscountKind" TEXT NOT NULL DEFAULT 'AMOUNT',
    "orderDiscountBps" INTEGER NOT NULL DEFAULT 0,
    "orderDiscountMode" TEXT NOT NULL DEFAULT 'STACK',
    "clientOrderKey" TEXT,
    "isVoided" BOOLEAN NOT NULL DEFAULT false,
    "voidedAt" DATETIME,
    "voidReason" TEXT NOT NULL DEFAULT '',
    CONSTRAINT "Sale_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "Customer" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);
INSERT INTO "new_Sale" ("cashPaidCentavos", "cashTenderedCentavos", "changeCentavos", "clientOrderKey", "createdAt", "customerBalanceAfterCentavos", "customerId", "id", "isVoided", "totalAmount", "voidReason", "voidedAt") SELECT "cashPaidCentavos", "cashTenderedCentavos", "changeCentavos", "clientOrderKey", "createdAt", "customerBalanceAfterCentavos", "customerId", "id", "isVoided", "totalAmount", "voidReason", "voidedAt" FROM "Sale";
DROP TABLE "Sale";
ALTER TABLE "new_Sale" RENAME TO "Sale";
CREATE UNIQUE INDEX "Sale_clientOrderKey_key" ON "Sale"("clientOrderKey");
CREATE INDEX "Sale_createdAt_idx" ON "Sale"("createdAt");
CREATE INDEX "Sale_customerId_idx" ON "Sale"("customerId");
CREATE INDEX "Sale_isVoided_idx" ON "Sale"("isVoided");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
