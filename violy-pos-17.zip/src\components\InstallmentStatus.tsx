import type { InstallmentStatus } from '@/lib/utang'
import { Badge } from '@/components/ui/Badge'
import { Money } from '@/components/ui/Money'

/**
 * How one instalment stands, for the plan card and the invoice alike.
 *
 * "Overdue" and "partly paid" are NOT alternatives — an instalment can be
 * both, and usually is by the time anyone looks. An earlier version treated
 * them as a chain of else-ifs, so an overdue instalment carrying a real part
 * payment reported only "overdue" and the money the customer had actually
 * handed over vanished from the document. Both facts render.
 */
export function InstallmentStatusCell({
  installment,
  late,
}: {
  installment: InstallmentStatus
  /** Past its due date. Passed in, so the caller owns what "today" means. */
  late: boolean
}) {
  if (installment.isSettled) return <Badge tone="paid">paid</Badge>

  return (
    <span className="inline-flex flex-wrap items-center justify-end gap-1">
      {late && <Badge tone="owed">overdue</Badge>}
      {installment.paidCentavos > 0 ? (
        <span className="text-xs text-ink-muted">
          {/* `in`: this part really did arrive. */}
          <Money centavos={installment.paidCentavos} tone="in" /> paid
        </span>
      ) : (
        !late && <span className="text-xs text-ink-subtle">unpaid</span>
      )}
    </span>
  )
}
