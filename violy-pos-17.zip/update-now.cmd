@echo off
REM ===========================================================================
REM  Violy Store POS - install the latest version, by hand
REM
REM  PLAN B. The button inside the app does exactly the same thing; this is for
REM  when that button cannot be reached - the app will not open, it froze
REM  part-way through an update, or nothing happens when it is pressed.
REM
REM  Double-click this file. It is safe to run at any time, and safe to run
REM  twice.
REM
REM  It runs the SAME updater as the button rather than a second copy of the
REM  logic, so it cannot drift out of step with it and quietly become the
REM  version nobody has tested. The only difference is --force, which makes it
REM  reinstall even when the version number already matches - which is the
REM  whole point when the installed copy is the thing that is broken.
REM
REM  Your data is never part of an update. The customers, utang, sales and
REM  stock live in a database file that no update touches, and a fresh backup
REM  is taken before anything else happens.
REM ===========================================================================

setlocal
cd /d "%~dp0"

echo.
echo  ========================================
echo    Violy Store POS - install the latest
echo  ========================================
echo.

REM --- Node is the one thing this cannot install for itself -----------------
where node >nul 2>&1
if errorlevel 1 (
  echo  [X] Node.js is not installed on this computer.
  echo.
  echo      Install it from https://nodejs.org  ^(the "LTS" version^),
  echo      then run this file again.
  echo.
  pause
  exit /b 1
)

REM --- The updater needs the app's own packages to take a backup ------------
REM  Without node_modules the very first step - saving a backup - cannot run,
REM  and the updater stops rather than continuing without one. install.cmd is
REM  what puts those back, so say so plainly instead of failing obscurely.
if not exist "node_modules" (
  echo  The app's parts are missing, so this cannot back up your data first.
  echo.
  echo  Run install.cmd once, then run this file again.
  echo.
  pause
  exit /b 1
)

node scripts\update.mjs --force
if errorlevel 1 goto failed

exit /b 0

:failed
echo.
echo  ========================================
echo    The update did not finish.
echo  ========================================
echo.
echo  Your data was not touched, and a backup of it is in the "backups"
echo  folder. Read the message above, or send a photo of this window to
echo  whoever looks after this app.
echo.
pause
exit /b 1
