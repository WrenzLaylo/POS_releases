import type { LedgerEntry } from '@prisma/client'
import type { LedgerEntryType } from '@/lib/types'

export type BalanceEntry = Pick<LedgerEntry, 'id' | 'type' | 'amountCentavos' | 'isVoided'>

const TYPES: readonly LedgerEntryType[] = ['OPENING', 'CHARGE', 'PAYMENT']

export function isLedgerEntryType(value: string): value is LedgerEntryType {
  return (TYPES as readonly string[]).includes(value)
}

export function balanceDelta(entry: BalanceEntry): number {
  if (entry.isVoided) return 0
  if (!isLedgerEntryType(entry.type)) {
    console.error(
      `LedgerEntry ${entry.id} has an unrecognised type "${entry.type}"; excluding it from the balance.`,
    )
    return 0
  }
  return entry.type === 'PAYMENT' ? -entry.amountCentavos : entry.amountCentavos
}

/** The single balance implementation used by ledger reads and due-date state. */
export function sumBalance(entries: BalanceEntry[]): number {
  return entries.reduce((total, entry) => total + balanceDelta(entry), 0)
}
