import { describe, it, expect, afterEach } from 'vitest'
import { mkdir, readdir, rm } from 'node:fs/promises'
import path from 'node:path'
import {
  isSafeUploadName,
  saveProductImage,
  uploadContentType,
  uploadDirectory,
} from '@/server/uploads'

const UPLOAD_DIR = uploadDirectory()
const PNG_HEADER = new Uint8Array([137, 80, 78, 71, 13, 10, 26, 10, 0])

async function uploadedFiles(): Promise<string[]> {
  try {
    return await readdir(UPLOAD_DIR)
  } catch {
    return []
  }
}

afterEach(async () => {
  for (const name of await uploadedFiles()) {
    await rm(path.join(UPLOAD_DIR, name))
  }
})

describe('where uploads are written', () => {
  it('is not inside public/', () => {
    // The bug this pins down: a photo written into `public/` after `next build`
    // is answered 404 forever, because Next resolves that folder from a
    // manifest built once. The write succeeds and only the request fails, so
    // nothing reports it — which is why the location is asserted here rather
    // than left to be noticed by someone looking at a blank product card.
    expect(UPLOAD_DIR.split(path.sep)).not.toContain('public')
  })

  it('creates the directory on first use rather than requiring it to exist', async () => {
    // It is gitignored, so a fresh clone does not have it, and the first
    // upload on a new install must not be the one that fails.
    await rm(UPLOAD_DIR, { recursive: true, force: true })
    const file = new File([PNG_HEADER], 'hog-grower.png', { type: 'image/png' })

    expect(await saveProductImage(file)).not.toBeNull()
    expect(await uploadedFiles()).toHaveLength(1)
  })
})

describe('saveProductImage', () => {
  it('writes a verified image using a generated filename', async () => {
    await mkdir(UPLOAD_DIR, { recursive: true })
    const file = new File([PNG_HEADER], 'hog-grower.png', { type: 'image/png' })

    const result = await saveProductImage(file)

    expect(result).toMatch(/^\/uploads\/[0-9a-f-]+\.png$/)
    expect(await uploadedFiles()).toHaveLength(1)
  })

  it('returns a path the serving route will accept', async () => {
    // The two halves have to agree: the name `saveProductImage` invents must
    // pass the guard `route.ts` applies to an incoming request, or every
    // upload 404s again at a different step.
    const file = new File([PNG_HEADER], 'hog-grower.png', { type: 'image/png' })
    const stored = await saveProductImage(file)

    expect(stored).not.toBeNull()
    expect(isSafeUploadName(stored!.slice('/uploads/'.length))).toBe(true)
  })

  it('returns null for an empty file without writing anything', async () => {
    const file = new File([], '', { type: 'application/octet-stream' })

    expect(await saveProductImage(file)).toBeNull()
    expect(await uploadedFiles()).toHaveLength(0)
  })

  it('does not trust a browser-provided image MIME type', async () => {
    const fake = new File([new TextEncoder().encode('<script>alert(1)</script>')], 'photo.png', {
      type: 'image/png',
    })

    expect(await saveProductImage(fake)).toBeNull()
    expect(await uploadedFiles()).toHaveLength(0)
  })

  it('rejects files larger than five megabytes', async () => {
    const bytes = new Uint8Array(5 * 1024 * 1024 + 1)
    bytes.set(PNG_HEADER)
    const file = new File([bytes], 'huge.png', { type: 'image/png' })

    expect(await saveProductImage(file)).toBeNull()
    expect(await uploadedFiles()).toHaveLength(0)
  })

  it('returns null rather than throwing when the file is not an image', async () => {
    const file = new File([new Uint8Array([1])], 'notes.txt', { type: 'text/plain' })

    expect(await saveProductImage(file)).toBeNull()
  })
})

describe('isSafeUploadName', () => {
  it.each([
    '3f2504e0-4f89-41d3-9a0c-0305e82c3301.png',
    '3f2504e0-4f89-41d3-9a0c-0305e82c3301.jpg',
    '3f2504e0-4f89-41d3-9a0c-0305e82c3301.webp',
    '3f2504e0-4f89-41d3-9a0c-0305e82c3301.gif',
  ])('accepts %s', (name) => {
    expect(isSafeUploadName(name)).toBe(true)
  })

  it.each([
    ['climbs out of the folder', '../../prisma/dev.db'],
    ['climbs out with an otherwise valid name', '../3f2504e0-4f89-41d3-9a0c-0305e82c3301.png'],
    ['a Windows separator', '..\\prisma\\dev.db'],
    ['an absolute path', '/etc/passwd'],
    ['a dotfile', '.env'],
    ['a plausible name that is not a uuid', 'hog-grower.png'],
    ['an executable extension', '3f2504e0-4f89-41d3-9a0c-0305e82c3301.exe'],
    ['no extension', '3f2504e0-4f89-41d3-9a0c-0305e82c3301'],
    ['a double extension', '3f2504e0-4f89-41d3-9a0c-0305e82c3301.png.exe'],
    ['a trailing newline', '3f2504e0-4f89-41d3-9a0c-0305e82c3301.png\n'],
    ['empty', ''],
  ])('refuses %s', (_label, name) => {
    expect(isSafeUploadName(name)).toBe(false)
  })
})

describe('uploadContentType', () => {
  it.each([
    ['a.png', 'image/png'],
    ['a.jpg', 'image/jpeg'],
    ['a.webp', 'image/webp'],
    ['a.gif', 'image/gif'],
  ])('serves %s as %s', (name, type) => {
    expect(uploadContentType(name)).toBe(type)
  })

  it('never guesses at an extension it does not know', () => {
    // A browser handed `application/octet-stream` downloads the file rather
    // than rendering it, which is the right outcome for something this app
    // did not write — an SVG in particular is a script container.
    expect(uploadContentType('a.svg')).toBe('application/octet-stream')
  })
})
