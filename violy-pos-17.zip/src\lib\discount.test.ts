import { describe, expect, it } from 'vitest'
import {
  MAX_BPS,
  NO_ORDER_DISCOUNT,
  computeOrderTotals,
  hasOrderDiscount,
  isDiscountKind,
  isLineDiscountMode,
  manualPerLineOf,
  manualPerUnitOf,
  mergeLineDiscounts,
  percentOf,
  validateLineDiscount,
  validateOrderDiscount,
  type DiscountLineInput,
} from './discount'

/**
 * Every discount in this app is typed at the counter. Standing per-customer
 * rates were removed on 24 Aug 2026, and with them the "on top of theirs /
 * instead of theirs" choice — there is nothing left to be on top of.
 *
 * Sales made while those rates existed keep what they were charged:
 * `SaleItem.discountAtSale` and `Sale.customerDiscountCentavos` are snapshots,
 * so old receipts reprint unchanged. Nothing in this file recomputes them.
 */

const SACK = 200_000 // ₱2,000.00

function line(overrides: Partial<DiscountLineInput> = {}): DiscountLineInput {
  return { productId: 1, quantity: 1, priceCentavos: SACK, ...overrides }
}

describe('the type guards', () => {
  it('accepts the two discount kinds and nothing else', () => {
    expect(isDiscountKind('AMOUNT')).toBe(true)
    expect(isDiscountKind('PERCENT')).toBe(true)
    expect(isDiscountKind('STACK')).toBe(false)
    expect(isDiscountKind('')).toBe(false)
  })

  it('accepts the two line modes and nothing else', () => {
    expect(isLineDiscountMode('EACH')).toBe(true)
    expect(isLineDiscountMode('ONCE')).toBe(true)
    expect(isLineDiscountMode('PER_UNIT')).toBe(false)
  })
})

describe('percentOf', () => {
  it('reads basis points, so 500 is 5%', () => {
    expect(percentOf(200_000, 500)).toBe(10_000)
  })

  it('rounds half away from zero, like every other money conversion', () => {
    expect(percentOf(100, 50)).toBe(1)
  })

  it('takes everything at 100%', () => {
    expect(percentOf(200_000, MAX_BPS)).toBe(200_000)
  })
})

describe('hasOrderDiscount', () => {
  it('is false for nothing, and for a typed zero', () => {
    expect(hasOrderDiscount(null)).toBe(false)
    expect(hasOrderDiscount(NO_ORDER_DISCOUNT)).toBe(false)
  })

  it('reads the field its kind uses, not both', () => {
    expect(hasOrderDiscount({ kind: 'AMOUNT', amountCentavos: 100, bps: 0 })).toBe(true)
    expect(hasOrderDiscount({ kind: 'AMOUNT', amountCentavos: 0, bps: 500 })).toBe(false)
    expect(hasOrderDiscount({ kind: 'PERCENT', amountCentavos: 0, bps: 500 })).toBe(true)
    expect(hasOrderDiscount({ kind: 'PERCENT', amountCentavos: 100, bps: 0 })).toBe(false)
  })
})

describe('validateOrderDiscount', () => {
  it('treats a missing discount as the ordinary case, not an error', () => {
    expect(validateOrderDiscount(null)).toEqual({ ok: true, value: NO_ORDER_DISCOUNT })
    expect(validateOrderDiscount(undefined)).toEqual({ ok: true, value: NO_ORDER_DISCOUNT })
  })

  it('accepts a well-formed discount', () => {
    const result = validateOrderDiscount({ kind: 'PERCENT', amountCentavos: 0, bps: 1_000 })
    expect(result).toEqual({
      ok: true,
      value: { kind: 'PERCENT', amountCentavos: 0, bps: 1_000 },
    })
  })

  /**
   * Checked at runtime rather than trusted from the type: this crosses a
   * Server Action boundary, so the compiler's word for what the client sent is
   * not evidence.
   */
  it('refuses a kind it does not recognise', () => {
    expect(validateOrderDiscount({ kind: 'FREEBIE', amountCentavos: 0, bps: 0 }).ok).toBe(false)
  })

  it.each([
    ['a negative amount', { kind: 'AMOUNT', amountCentavos: -1, bps: 0 }],
    ['a fractional centavo', { kind: 'AMOUNT', amountCentavos: 10.5, bps: 0 }],
    ['a negative percentage', { kind: 'PERCENT', amountCentavos: 0, bps: -1 }],
    ['more than 100%', { kind: 'PERCENT', amountCentavos: 0, bps: MAX_BPS + 1 }],
  ])('refuses %s', (_label, input) => {
    expect(validateOrderDiscount(input).ok).toBe(false)
  })
})

describe('validateLineDiscount', () => {
  it('accepts absent and zero', () => {
    expect(validateLineDiscount(undefined)).toBeNull()
    expect(validateLineDiscount(0)).toBeNull()
  })

  it('refuses a negative or fractional figure', () => {
    expect(validateLineDiscount(-1)).toMatch(/whole, non-negative/)
    expect(validateLineDiscount(10.5)).toMatch(/whole, non-negative/)
  })
})

describe('mergeLineDiscounts', () => {
  it('takes the larger, so nothing somebody typed is silently discarded', () => {
    expect(mergeLineDiscounts(500, 900)).toBe(900)
    expect(mergeLineDiscounts(900, 500)).toBe(900)
    expect(mergeLineDiscounts(undefined, 500)).toBe(500)
    expect(mergeLineDiscounts(undefined, undefined)).toBe(0)
  })
})

/**
 * EACH and ONCE are the surviving mode, and they are NOT the removed
 * STACK/REPLACE. "₱500 off this line" across three sacks cannot be expressed
 * per unit — ₱166.666… rounds to ₱499.98, a figure nobody typed and nobody
 * wants to explain — so the whole-line figure is held apart and never divided.
 */
describe('a typed line discount, per unit or for the line', () => {
  it('splits the same figure by what it was meant as', () => {
    const each = { manualDiscountPerUnitCentavos: 500, manualDiscountMode: 'EACH' as const }
    const once = { manualDiscountPerUnitCentavos: 500, manualDiscountMode: 'ONCE' as const }

    expect(manualPerUnitOf(each)).toBe(500)
    expect(manualPerLineOf(each)).toBe(0)
    expect(manualPerUnitOf(once)).toBe(0)
    expect(manualPerLineOf(once)).toBe(500)
  })

  it('defaults to per unit when no mode was given', () => {
    expect(manualPerUnitOf({ manualDiscountPerUnitCentavos: 500 })).toBe(500)
    expect(manualPerLineOf({ manualDiscountPerUnitCentavos: 500 })).toBe(0)
  })

  it('is nothing when nothing was typed', () => {
    expect(manualPerUnitOf({})).toBe(0)
    expect(manualPerLineOf({ manualDiscountPerUnitCentavos: 0 })).toBe(0)
  })

  it('comes off every unit when it is EACH', () => {
    const totals = computeOrderTotals({
      lines: [
        line({ quantity: 3, manualDiscountPerUnitCentavos: 500, manualDiscountMode: 'EACH' }),
      ],
    })
    expect(totals.totalCentavos).toBe(3 * (SACK - 500))
    expect(totals.lineDiscountCentavos).toBe(3 * 500)
  })

  it('comes off once when it is ONCE — exactly, never divided', () => {
    const totals = computeOrderTotals({
      lines: [
        line({ quantity: 3, manualDiscountPerUnitCentavos: 500, manualDiscountMode: 'ONCE' }),
      ],
    })
    expect(totals.totalCentavos).toBe(3 * SACK - 500)
    expect(totals.lines[0].lineDiscountCentavos).toBe(500)
    expect(totals.lines[0].discountPerUnitCentavos).toBe(0)
  })

  it('can make a line free but never negative', () => {
    const once = computeOrderTotals({
      lines: [line({ manualDiscountPerUnitCentavos: SACK * 10, manualDiscountMode: 'ONCE' })],
    })
    expect(once.totalCentavos).toBe(0)
    expect(once.lines[0].lineTotalCentavos).toBe(0)

    const each = computeOrderTotals({
      lines: [line({ quantity: 2, manualDiscountPerUnitCentavos: SACK * 10 })],
    })
    expect(each.totalCentavos).toBe(0)
  })
})

describe('the ad-hoc order discount', () => {
  it('takes a peso amount off the order', () => {
    const totals = computeOrderTotals({
      lines: [line({ quantity: 2 })],
      order: { kind: 'AMOUNT', amountCentavos: 50_000, bps: 0 },
    })
    expect(totals.orderDiscountCentavos).toBe(50_000)
    expect(totals.totalCentavos).toBe(2 * SACK - 50_000)
  })

  it('takes a percentage off the order', () => {
    const totals = computeOrderTotals({
      lines: [line({ quantity: 2 })],
      order: { kind: 'PERCENT', amountCentavos: 0, bps: 1_000 },
    })
    expect(totals.orderDiscountCentavos).toBe(40_000)
    expect(totals.totalCentavos).toBe(2 * SACK - 40_000)
  })

  it('never takes off more than the order is worth', () => {
    const totals = computeOrderTotals({
      lines: [line()],
      order: { kind: 'AMOUNT', amountCentavos: SACK * 5, bps: 0 },
    })
    expect(totals.orderDiscountCentavos).toBe(SACK)
    expect(totals.totalCentavos).toBe(0)
  })

  /**
   * The pipeline order, fixed on purpose: a percentage is taken against what
   * is left AFTER the lines were discounted, not against the list subtotal.
   * Arbitrary in principle, but it has to be settled somewhere or "10% off"
   * means two different pesos depending which code path computed it.
   */
  it('takes its percentage after the line discounts, not before', () => {
    const totals = computeOrderTotals({
      lines: [line({ quantity: 2, manualDiscountPerUnitCentavos: 50_000 })],
      order: { kind: 'PERCENT', amountCentavos: 0, bps: 1_000 },
    })

    const afterLines = 2 * (SACK - 50_000)
    expect(totals.lineDiscountCentavos).toBe(2 * 50_000)
    expect(totals.orderDiscountCentavos).toBe(afterLines / 10)
    expect(totals.totalCentavos).toBe(afterLines - afterLines / 10)
  })
})

describe('what computeOrderTotals reports', () => {
  it('is all zeroes for an empty order', () => {
    expect(computeOrderTotals({ lines: [] })).toMatchObject({
      subtotalCentavos: 0,
      lineDiscountCentavos: 0,
      orderDiscountCentavos: 0,
      totalDiscountCentavos: 0,
      totalCentavos: 0,
    })
  })

  it('reports the subtotal at list price, before anything came off', () => {
    const totals = computeOrderTotals({
      lines: [line({ quantity: 2, manualDiscountPerUnitCentavos: 50_000 })],
      order: { kind: 'AMOUNT', amountCentavos: 10_000, bps: 0 },
    })
    expect(totals.subtotalCentavos).toBe(2 * SACK)
  })

  it('adds every discount up into one figure a receipt can print', () => {
    const totals = computeOrderTotals({
      lines: [line({ quantity: 2, manualDiscountPerUnitCentavos: 50_000 })],
      order: { kind: 'AMOUNT', amountCentavos: 10_000, bps: 0 },
    })
    expect(totals.totalDiscountCentavos).toBe(
      totals.lineDiscountCentavos + totals.orderDiscountCentavos,
    )
    expect(totals.subtotalCentavos - totals.totalDiscountCentavos).toBe(totals.totalCentavos)
  })

  it('prices several lines independently', () => {
    const totals = computeOrderTotals({
      lines: [
        line({ productId: 1, quantity: 2 }),
        line({ productId: 2, quantity: 1, priceCentavos: 150_000 }),
      ],
    })
    expect(totals.totalCentavos).toBe(2 * SACK + 150_000)
    expect(totals.lines.map((each) => each.lineTotalCentavos)).toEqual([2 * SACK, 150_000])
  })

  it('handles a fractional quantity, which kilo sales are', () => {
    const totals = computeOrderTotals({ lines: [line({ quantity: 2.5, priceCentavos: 6_000 })] })
    expect(totals.totalCentavos).toBe(15_000)
  })
})
