/**
 * Says whether this copy is a working till or an empty one.
 *
 * The last step of `install.cmd`, and it exists because a fresh install LOOKS
 * finished when it is not. The database is deliberately not in git — it holds
 * the shop's customers and its money — so a clone produces a perfectly working
 * app with nothing in it. Somebody could open the till, see an empty catalogue,
 * and reasonably conclude the install failed, or worse, start typing the
 * catalogue in again beside a copy that already exists on another machine.
 *
 *   npx tsx scripts/check-data.ts
 */

import { prisma } from '@/lib/db'

async function main(): Promise<void> {
  const [products, customers, sales] = await Promise.all([
    prisma.product.count(),
    prisma.customer.count(),
    prisma.sale.count(),
  ])

  if (products === 0 && customers === 0) {
    console.log('')
    console.log('  This copy has NO DATA yet — no products, no customers.')
    console.log('')
    console.log('  That is expected on a new machine: the database is never')
    console.log('  copied by git, because it holds the shop’s accounts.')
    console.log('')
    console.log('  To bring the real data across from the old computer:')
    console.log('    1. On the OLD computer:  npm run backup')
    console.log('    2. Copy the newest file from its "backups" folder to a USB stick.')
    console.log('    3. On THIS computer:     npm run restore -- <path-to-that-file>')
    console.log('')
    return
  }

  console.log('')
  console.log(`  This copy holds ${products} products, ${customers} customers, ${sales} sales.`)
  console.log('')
}

main()
  .catch((error) => {
    // Never fails the install. Not being able to count rows is worth saying,
    // not worth stopping for — everything before this step already succeeded.
    console.warn('  (Could not check the data: ' + (error instanceof Error ? error.message : error) + ')')
  })
  .finally(() => prisma.$disconnect())
