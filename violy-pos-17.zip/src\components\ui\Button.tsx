import type { ButtonHTMLAttributes } from 'react'
import { cn } from '@/lib/cn'

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'success' | 'destructive'
type Size = 'md' | 'sm' | 'wide' | 'icon'

const BASE =
  'inline-flex items-center justify-center gap-2 rounded-control font-medium ' +
  'transition-[color,background-color,border-color,box-shadow,transform] duration-150 ' +
  'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 ' +
  'focus-visible:ring-offset-canvas active:translate-y-px ' +
  'disabled:pointer-events-none disabled:opacity-50 disabled:shadow-none'

const SIZES: Record<Size, string> = {
  md: 'h-10 px-4 text-sm',
  sm: 'h-8 px-3 text-sm',
  // Same height and text as `md` — only the horizontal padding grows. For
  // buttons that want breathing room (e.g. a terminal "Save order") without
  // hand-writing a `px-*` override that a primitive cannot reliably resolve.
  wide: 'h-10 px-8 text-sm',
  // Accessible naming remains the caller's responsibility via aria-label.
  icon: 'h-10 w-10 p-0 text-sm',
}

const VARIANTS: Record<Variant, string> = {
  primary: 'bg-accent text-canvas shadow-panel hover:bg-accent-strong active:bg-accent-strong',
  secondary:
    'border border-line-strong bg-surface-raised text-ink shadow-panel hover:border-accent hover:bg-accent-soft active:bg-accent-soft',
  ghost: 'text-ink-muted hover:bg-surface-sunk hover:text-ink',
  danger: 'text-owed hover:bg-accent-soft active:bg-accent-soft',
  success: 'bg-money-in text-canvas shadow-panel hover:bg-money-in/90 active:bg-money-in',
  // Filled, not text-only — for the single confirming click of something
  // that cannot be undone (e.g. "Yes, void it"). The button that merely
  // opens that confirmation stays `danger`.
  destructive: 'bg-owed text-canvas shadow-panel hover:bg-owed/90 active:bg-owed',
}

export function Button({
  variant = 'secondary',
  size = 'md',
  className,
  type = 'button',
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; size?: Size }) {
  return (
    <button
      type={type}
      className={cn(BASE, SIZES[size], VARIANTS[variant], className)}
      {...props}
    />
  )
}
