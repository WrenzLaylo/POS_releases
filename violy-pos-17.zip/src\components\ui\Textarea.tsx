import type { TextareaHTMLAttributes } from 'react'
import { cn } from '@/lib/cn'
import { CONTROL_BASE } from './Input'

export function Textarea({ className, ...props }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea className={cn(CONTROL_BASE, 'min-h-20 py-2', className)} {...props} />
}
