'use client'

import { usePathname } from 'next/navigation'
import { useEffect, useRef } from 'react'

/**
 * Moves focus to the new page's heading after a client-side navigation.
 *
 * Without this, clicking Book in the rail changes everything on screen and
 * leaves focus sitting on the rail link. A sighted mouse user never notices; a
 * keyboard user's next Tab carries on from the rail rather than from the page
 * that just arrived, and a screen-reader user is told nothing happened at all.
 * Nothing announces the new screen either, because a client-side navigation is
 * not a page load and fires none of the events one would.
 *
 * The `h1` rather than `main`: every route has one through `PageHeader`, and it
 * names the screen, so the announcement is "Book" rather than "main". On the
 * counter that heading is `sr-only` — `dense` trades the visible title for
 * screen height — and it works exactly as well, which is the reason it was kept
 * in the document.
 *
 * Two details that stop this from being a nuisance:
 *
 * · Never on first paint. The app opening is not a navigation, and stealing
 *   focus before she has done anything is the behaviour that gets this pattern
 *   removed again.
 * · `preventScroll`, and `tabindex` taken off again on blur. The router already
 *   handles scroll position; without this an `sr-only` heading pulls the page to
 *   itself. And a permanent `tabindex` would leave a heading that swallows a Tab
 *   stop for the rest of the session.
 */
export function RouteFocus() {
  const pathname = usePathname()
  const first = useRef(true)

  useEffect(() => {
    if (first.current) {
      first.current = false
      return
    }

    let release: (() => void) | undefined

    // Deferred a frame, and this is the part that matters. This component sits
    // above the shell, so its effect runs BEFORE the effects of whatever the
    // new page rendered — and the counter deliberately focuses its product
    // search on mount, because she arrives there to start typing a product.
    // Focusing the heading first meant taking focus and immediately losing it
    // again: a flicker, and two announcements where one was wanted. Waiting a
    // frame lets the page claim focus if it means to, and yields to it.
    const frame = requestAnimationFrame(() => {
      const main = document.getElementById('main')
      if (!main) return
      // Somebody inside the new page already has focus. Leave it there.
      if (document.activeElement && main.contains(document.activeElement)) return

      const target = main.querySelector<HTMLElement>('h1') ?? main

      // -1: programmatically focusable, but not a stop in the tab order.
      target.setAttribute('tabindex', '-1')
      target.focus({ preventScroll: true })

      release = () => {
        target.removeAttribute('tabindex')
        target.removeEventListener('blur', release as () => void)
      }
      target.addEventListener('blur', release)
    })

    return () => {
      cancelAnimationFrame(frame)
      release?.()
    }
  }, [pathname])

  return null
}
