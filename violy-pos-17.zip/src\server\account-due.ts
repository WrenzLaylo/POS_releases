import type { Prisma } from '@prisma/client'
import { addDays, startOfDay } from '@/lib/dates'
import { sumBalance } from '@/lib/ledger-balance'

export const DEFAULT_DUE_DAYS = 30

/** Keeps the account-level deadline in lockstep with the live ledger balance.
 * Call inside the same transaction as the money mutation. */
export async function reconcileCustomerDueAt(
  tx: Prisma.TransactionClient,
  customerId: number,
  anchorDate: Date,
): Promise<void> {
  const customer = await tx.customer.findUnique({
    where: { id: customerId },
    select: {
      dueAt: true,
      entries: {
        where: { isVoided: false },
        select: { id: true, type: true, amountCentavos: true, isVoided: true },
      },
    },
  })
  if (!customer) throw new Error('CUSTOMER_VANISHED')

  const balance = sumBalance(customer.entries)
  if (balance <= 0) {
    if (customer.dueAt !== null) {
      await tx.customer.update({ where: { id: customerId }, data: { dueAt: null } })
    }
    return
  }

  if (customer.dueAt === null) {
    await tx.customer.update({
      where: { id: customerId },
      data: { dueAt: addDays(startOfDay(anchorDate), DEFAULT_DUE_DAYS) },
    })
  }
}
