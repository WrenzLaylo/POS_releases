'use client'

import { useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { signOut } from '@/server/auth'
import { RowActionMenu } from '@/components/ui/RowActionMenu'
import { Icon } from '@/components/ui/Icon'
import { ROUTES } from '@/lib/routes'

/**
 * Who is signed in, and the two things you do about it.
 *
 * Signing out used to live only in Settings, in the same panel as "Turn the
 * login off" — two buttons a few pixels apart, one of which ends a session and
 * one of which removes the password entirely. Sitting together they read as
 * two strengths of the same action, which is exactly the pair you do not want
 * confused. Signing out belongs where every other application puts it: under
 * the account, in the corner.
 *
 * It stays in Settings as well. Somebody looking for it will look in one place
 * or the other, and there is no cost to it being in both.
 *
 * Built on `RowActionMenu` rather than hand-rolled. That component already
 * solves outside-click, Escape, focus return, arrow-key navigation and
 * being portalled clear of its container — and AGENTS.md records that this app
 * already carries three separate hand-rolled versions of that logic which have
 * drifted apart. A fourth would be a fourth thing to keep in step.
 */
export function AccountMenu({ username }: { username: string | null }) {
  const router = useRouter()
  const [, startTransition] = useTransition()

  const initial = (username ?? '').trim().slice(0, 1).toUpperCase()

  return (
    <RowActionMenu
      ariaLabel={username ? `Account: ${username}` : 'Account'}
      trigger={
        username ? (
          // The same mark as the sign-in screen, so the corner she signs in
          // through and the corner she signs out of are recognisably the same
          // thing.
          <span className="flex h-7 w-7 items-center justify-center rounded-full bg-accent-soft font-display text-xs font-semibold uppercase text-accent">
            {initial}
          </span>
        ) : (
          <Icon name="settings" className="h-4 w-4 shrink-0" />
        )
      }
      header={
        username ? (
          <>
            <div className="text-xs font-medium uppercase tracking-[0.08em] text-ink-muted">
              Signed in as
            </div>
            <div className="max-w-56 truncate text-sm text-ink">{username}</div>
          </>
        ) : null
      }
      items={[
        {
          label: 'Settings',
          onSelect: () => router.push(ROUTES.settings),
        },
        // Only when there is a session to end. With the login switched off
        // this menu is just a route to Settings, and an item that signed
        // nobody out would be a button that does nothing.
        ...(username
          ? [
              {
                label: 'Sign out',
                destructive: true,
                onSelect: () =>
                  startTransition(async () => {
                    await signOut()
                    router.refresh()
                  }),
              },
            ]
          : []),
      ]}
    />
  )
}
