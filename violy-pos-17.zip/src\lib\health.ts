/**
 * Whether the thing answering on the port is a POS this launcher may use.
 *
 * The desktop shell used to decide by opening a TCP socket and seeing whether
 * anything answered — which is true of `next dev`, of an unrelated service, and
 * of any program that happens to hold port 3000. It would then load that and
 * present it as the till.
 *
 * `electron/main.js` implements this same check in plain JavaScript rather than
 * importing it, for the same reason `scripts/release.mjs` duplicates
 * `canonicalManifest`: the shell runs under Electron's Node before any
 * TypeScript exists. The two are kept honest by `health.test.ts`, which asserts
 * the exact shape rather than trusting that nobody edited one of them.
 */

export const HEALTH_PATH = '/health'
export const HEALTH_APP_ID = 'violy-pos'

export type HealthResponse = {
  app: string
  mode: string
  build: number | null
  version: string | null
  ready: boolean
}

export type HealthVerdict =
  | { usable: true }
  | { usable: false; reason: 'unreadable' | 'not-the-pos' | 'not-ready' | 'development' }

/**
 * `allowDevelopment` is opt-in and must stay that way. Attaching a packaged
 * copy to a development server means running the shop against whatever
 * database and half-finished code that server has — the failure is silent,
 * because the app looks completely normal.
 */
export function judgeHealth(
  value: unknown,
  options: { allowDevelopment?: boolean } = {},
): HealthVerdict {
  if (typeof value !== 'object' || value === null) return { usable: false, reason: 'unreadable' }
  const body = value as Partial<HealthResponse>

  // Checked before anything else: a JSON body from some other program is the
  // case this whole endpoint exists for, and it must not be read as "not
  // ready" or "still starting", which the shell would wait out.
  if (body.app !== HEALTH_APP_ID) return { usable: false, reason: 'not-the-pos' }
  if (body.ready !== true) return { usable: false, reason: 'not-ready' }
  if (body.mode !== 'production' && !options.allowDevelopment) {
    return { usable: false, reason: 'development' }
  }
  return { usable: true }
}

/** What to tell somebody whose port is occupied by the wrong thing. */
export function healthProblemMessage(reason: Exclude<HealthVerdict, { usable: true }>['reason']): string {
  switch (reason) {
    case 'not-the-pos':
      return 'Another program is already using this port. Close it and start Violy Store again.'
    case 'development':
      return 'A development server is already running on this port. Close it and start Violy Store again.'
    case 'not-ready':
      return 'The till is still starting up.'
    default:
      return 'Something is answering on this port but it is not the till.'
  }
}
