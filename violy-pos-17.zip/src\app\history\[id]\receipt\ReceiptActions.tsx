'use client'

import Link from 'next/link'
import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { sale as saleRoute } from '@/lib/routes'
import { voidSale } from '@/server/sales'
import { useGuardedAction } from '@/lib/use-guarded-action'
import { PasswordPrompt } from '@/components/PasswordPrompt'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Dialog } from '@/components/ui/Dialog'
import { FormError } from '@/components/ui/FormError'
import { Textarea } from '@/components/ui/Textarea'

export function ReceiptActions({ saleId, isVoided }: { saleId: number; isVoided: boolean }) {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [reason, setReason] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [pending, startTransition] = useTransition()
  const { asking, guard, confirmed, cancel } = useGuardedAction()

  function confirmVoid() {
    setError(null)
    startTransition(async () => {
      await guard(
        () => voidSale(saleId, reason),
        (result) => {
          if (!result.ok) {
            setError(result.error ?? 'Could not void the sale.')
            return
          }
          setOpen(false)
          router.refresh()
        },
      )
    })
  }

  return (
    <>
      {asking && (
        <PasswordPrompt
          what="void this sale"
          onConfirmed={() => startTransition(confirmed)}
          onCancel={cancel}
        />
      )}
      {/* Print lives in `DocumentShell` alongside the paper toggle, because
          every document has it. Only what is specific to a sale is here. */}
      <Link
        href={saleRoute(saleId)}
        className="inline-flex h-10 items-center justify-center rounded-control border border-line-strong bg-surface-raised px-4 text-sm font-medium text-ink hover:border-accent hover:bg-accent-soft"
      >
        Back to the sale
      </Link>
      {isVoided ? (
        <Badge tone="muted">VOIDED</Badge>
      ) : (
        <Button variant="danger" onClick={() => setOpen(true)}>
          Void sale
        </Button>
      )}

      <Dialog
        open={open}
        onOpenChange={(next) => {
          setOpen(next)
          if (!next) setError(null)
        }}
        title={`Void sale #${saleId}?`}
        description="This restores the stock and voids any linked customer charge. The sale remains visible for audit."
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setOpen(false)} disabled={pending}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={confirmVoid} disabled={pending}>
              {pending ? 'Voiding…' : 'Yes, void sale'}
            </Button>
          </div>
        }
      >
        <label className="block text-sm font-medium text-ink" htmlFor="void-reason">
          Reason
        </label>
        <Textarea
          id="void-reason"
          value={reason}
          onChange={(event) => setReason(event.target.value)}
          placeholder="e.g. Duplicate checkout or wrong quantity"
          className="mt-2 w-full"
        />
        {error && <FormError className="mt-3">{error}</FormError>}
      </Dialog>
    </>
  )
}
