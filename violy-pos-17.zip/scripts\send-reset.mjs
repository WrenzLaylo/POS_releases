#!/usr/bin/env node
/**
 * Signs a password reset for the shop laptop and publishes it.
 *
 *   npm run send-reset -- 4K7-Q92
 *
 * Violy reads the code off her screen; you type it here. This signs that exact
 * code with the release key and pushes `reset.json` to the public releases
 * repository, where her app is already looking for it.
 *
 * WHY PUBLISHING A PASSWORD RESET IN THE OPEN IS SAFE: the token names ONE
 * machine's one-time code and is signed with a key that is not on GitHub.
 * Anyone can read it; nobody else can make one. Publishing access alone does
 * not unlock the till — which is the same property `docs/RELEASE-SIGNING.md`
 * buys for updates, reused here.
 *
 * Needs `gh` authenticated and `.release-signing-key.pem` present.
 */

import { execFileSync } from 'node:child_process'
import { createPrivateKey, sign } from 'node:crypto'
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import path from 'node:path'
import { tmpdir } from 'node:os'

const ROOT = process.cwd()
const NEWLINE = String.fromCharCode(10)
const KEY_FILE = path.join(ROOT, '.release-signing-key.pem')

/** How long the shop has to use it. Matches REQUEST_HOURS on the app side. */
const VALID_HOURS = 6

/**
 * MUST match `canonicalReset` in `src/lib/reset-signature.ts`.
 *
 * Duplicated rather than imported because this runs under plain Node before
 * any TypeScript is compiled. `reset-signature.test.ts` asserts this exact
 * shape, because a separator that drifts here rejects every reset and looks
 * precisely like a wrong key.
 */
function canonicalReset({ code, expiresAt }) {
  return [`reset:${String(code).toUpperCase()}`, `expires:${expiresAt}`].join(NEWLINE)
}

function repoFromChannel() {
  const channel = JSON.parse(readFileSync(path.join(ROOT, 'release-channel.json'), 'utf8'))
  // https://raw.githubusercontent.com/<owner>/<repo>/<branch>
  const parts = new URL(channel.baseUrl).pathname.split('/').filter(Boolean)
  if (parts.length < 2) throw new Error(`Cannot read owner/repo from ${channel.baseUrl}`)
  return `${parts[0]}/${parts[1]}`
}

function main() {
  const raw = process.argv[2]
  if (!raw) {
    console.error('Which code? Read it off Violy’s screen.')
    console.error('  npm run send-reset -- 4K7-Q92')
    process.exit(1)
  }

  // Accept it however it was written down: case, spaces and dashes are noise.
  const code = raw.toUpperCase().replace(/[^0-9A-Z]/g, '')
  if (code.length < 4) {
    console.error(`"${raw}" does not look like a reset code.`)
    process.exit(1)
  }
  const formatted = `${code.slice(0, 3)}-${code.slice(3)}`

  if (!existsSync(KEY_FILE)) {
    console.error(
      [
        `No signing key at ${KEY_FILE}`,
        '',
        'Without it this reset cannot be signed, and the shop would refuse it.',
        'Copy the key across from wherever it is kept. See docs/RELEASE-SIGNING.md.',
      ].join(NEWLINE),
    )
    process.exit(1)
  }

  const expiresAt = new Date(Date.now() + VALID_HOURS * 60 * 60 * 1000).toISOString()
  const fields = { code: formatted, expiresAt }
  const key = createPrivateKey(readFileSync(KEY_FILE, 'utf8'))
  // Ed25519 takes a NULL algorithm — the curve carries its own hash.
  const signature = sign(null, Buffer.from(canonicalReset(fields), 'utf8'), key).toString('base64')

  const token = { ...fields, signature }
  const repo = repoFromChannel()

  // Whatever is already there is replaced, so an old reset cannot linger.
  let sha = null
  try {
    sha = execFileSync('gh', ['api', `repos/${repo}/contents/reset.json`, '--jq', '.sha'], {
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
    }).trim()
  } catch {
    // Not published before. Fine.
  }

  const body = {
    message: `Password reset for ${formatted}`,
    content: Buffer.from(JSON.stringify(token, null, 2) + NEWLINE, 'utf8').toString('base64'),
    ...(sha ? { sha } : {}),
  }
  const bodyFile = path.join(tmpdir(), `violy-reset-${Date.now()}.json`)
  writeFileSync(bodyFile, JSON.stringify(body), 'utf8')

  execFileSync('gh', ['api', '-X', 'PUT', `repos/${repo}/contents/reset.json`, '--input', bodyFile], {
    stdio: ['ignore', 'ignore', 'inherit'],
  })

  console.log('')
  console.log(`  Sent a reset for ${formatted}`)
  console.log(`  Good until ${new Date(expiresAt).toLocaleString()}`)
  console.log('')
  console.log('  Tell her to press "Check now" on her screen.')
  console.log('  It may take a minute to appear — GitHub caches for about five.')
  console.log('')
}

main()
