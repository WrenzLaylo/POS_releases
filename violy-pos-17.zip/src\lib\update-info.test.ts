import { describe, expect, it } from 'vitest'

import {
  isNewer,
  parseInstalled,
  parseManifest,
  updateHeadline,
  type InstalledRelease,
} from './update-info'


/**
 * A verifier that agrees with everything.
 *
 * These cases were written to test the SHAPE of a manifest — a missing build,
 * a plain-HTTP zipUrl, a malformed checksum — and every one of them should
 * still fail for its own reason rather than because it is unsigned. Signature
 * behaviour is covered separately, below.
 */
const allowAny = () => true

const VALID = {
  build: 7,
  version: '2026.08.18',
  publishedAt: '2026-08-18T02:00:00.000Z',
  notes: ['Deliveries can be recorded on consignment'],
  zipUrl: 'https://raw.githubusercontent.com/WrenzLaylo/POS-releases/main/violy-pos-7.zip',
  sha256: 'a'.repeat(64),
  signature: 'not-checked-by-allowAny',
}

const installed = (build: number): InstalledRelease => ({
  build,
  version: String(build),
  installedAt: '2026-08-01T00:00:00.000Z',
})

describe('parseManifest', () => {
  it('accepts a well-formed manifest', () => {
    const { signature, ...withoutSignature } = VALID
    expect(parseManifest(VALID, allowAny)).toEqual(withoutSignature)
  })

  it('refuses a download that is not https', () => {
    // A plain-HTTP download is one anybody on the same network can replace,
    // and what it replaces is the application.
    for (const zipUrl of [
      'http://example.com/app.zip',
      'ftp://example.com/app.zip',
      '//example.com/app.zip',
      'file:///C:/app.zip',
      '',
    ]) {
      expect(parseManifest({ ...VALID, zipUrl }, allowAny), zipUrl).toBeNull()
    }
  })

  it('refuses a manifest with no usable checksum', () => {
    // Without it a truncated download — an ordinary event on a shop's
    // internet — would unpack as a half-application.
    for (const sha256 of ['', 'nope', 'a'.repeat(63), 'a'.repeat(65), 'z'.repeat(64), 123]) {
      expect(parseManifest({ ...VALID, sha256 }, allowAny), String(sha256)).toBeNull()
    }
  })

  it('accepts an upper-case checksum, lowercased', () => {
    const parsed = parseManifest({ ...VALID, sha256: 'A'.repeat(64) }, allowAny)
    expect(parsed?.sha256).toBe('a'.repeat(64))
  })

  it.each([
    ['no build', { build: undefined }],
    ['a fractional build', { build: 1.5 }],
    ['a zero build', { build: 0 }],
    ['a negative build', { build: -3 }],
    ['a build that is a string', { build: '7' }],
    ['no version', { version: '' }],
  ])('refuses %s', (_label, override) => {
    expect(parseManifest({ ...VALID, ...override }, allowAny)).toBeNull()
  })

  it.each([null, undefined, 'a string', 42, []])('refuses %s outright', (raw) => {
    expect(parseManifest(raw, allowAny)).toBeNull()
  })

  it('tolerates missing notes rather than refusing the release', () => {
    // Notes are for reading. A release with none is odd, not unusable.
    expect(parseManifest({ ...VALID, notes: undefined }, allowAny)?.notes).toEqual([])
    expect(parseManifest({ ...VALID, notes: ['ok', 5, null] }, allowAny)?.notes).toEqual(['ok'])
  })
})

describe('parseInstalled', () => {
  it('reads a release stamp', () => {
    expect(parseInstalled({ build: 3, version: '2026.08.01', installedAt: 'x' })).toEqual({
      build: 3,
      version: '2026.08.01',
      installedAt: 'x',
    })
  })

  it('refuses anything without a real build number', () => {
    // A copy installed from source has no stamp at all, and must be treated as
    // "cannot update" rather than "build 0, everything is newer".
    for (const raw of [null, {}, { build: 'x' }, { build: 0 }, { build: 2.5 }]) {
      expect(parseInstalled(raw)).toBeNull()
    }
  })
})

describe('isNewer', () => {
  it('offers a higher build', () => {
    expect(isNewer({ ...VALID, build: 8 }, installed(7))).toBe(true)
  })

  it('does not offer the same build', () => {
    expect(isNewer({ ...VALID, build: 7 }, installed(7))).toBe(false)
  })

  it('does not offer an OLDER build', () => {
    // A bad release pulled and replaced with an earlier one. Offering it would
    // roll the till back, and the next check would offer it again, forever.
    expect(isNewer({ ...VALID, build: 6 }, installed(7))).toBe(false)
  })
})

describe('updateHeadline', () => {
  it('speaks to a shopkeeper, not a developer', () => {
    expect(updateHeadline({ kind: 'up-to-date', installed: installed(7) })).toBe(
      'You have the latest version.',
    )
    expect(
      updateHeadline({ kind: 'available', installed: installed(7), latest: VALID }),
    ).toBe('There is a new version ready to install.')
    expect(updateHeadline({ kind: 'offline', reason: 'x' })).toMatch(/Could not check/)
    expect(updateHeadline({ kind: 'unknown', reason: 'x' })).toMatch(/not available/)
  })

  it('never puts a build number or a hash in the headline', () => {
    const headlines = [
      updateHeadline({ kind: 'up-to-date', installed: installed(7) }),
      updateHeadline({ kind: 'available', installed: installed(7), latest: VALID }),
    ]
    for (const headline of headlines) {
      expect(headline).not.toMatch(/\d{2,}/)
      expect(headline).not.toMatch(/[0-9a-f]{16}/)
    }
  })
})
