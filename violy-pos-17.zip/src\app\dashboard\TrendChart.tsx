'use client'

import {
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  CartesianGrid,
} from 'recharts'
import { useRouter } from 'next/navigation'
import { formatPeso } from '@/lib/money'
import { ROUTES } from '@/lib/routes'
import type { TrendPoint } from '@/lib/types'

export function TrendChart({ data }: { data: TrendPoint[] }) {
  const router = useRouter()

  const points = data.map((p) => ({
    day: p.day.slice(5), // MM-DD keeps the axis readable
    // The axis label is truncated for width; the full key is kept alongside
    // it because that is what a link to that day's sales needs.
    fullDay: p.day,
    pesos: p.totalCentavos / 100,
  }))

  return (
    <ResponsiveContainer width="100%" height={200}>
      <LineChart
        data={points}
        margin={{ top: 8, right: 8, bottom: 0, left: 8 }}
        // A point on this chart is a day's takings, and the obvious next
        // question is "which sales were those". Recharts reports the index
        // rather than the datum, so the full date is read back from `points`.
        onClick={(state) => {
          const index = state?.activeTooltipIndex
          if (typeof index !== 'number') return
          const point = points[index]
          if (!point) return
          router.push(`${ROUTES.history}?from=${point.fullDay}&to=${point.fullDay}`)
        }}
        className="cursor-pointer"
      >
        {/* Recharts takes SVG props, not Tailwind classes, so these hex
            values are unavoidable — this is the one file allowed to hold
            them. They mirror `line`, `ink-muted` and `chart-1` in
            globals.css and must be changed together with it: the palette
            cannot reach in here, so a theme change that skips this file
            leaves the chart drawn in the previous theme's colours. That is
            exactly what happened to the dark values these replaced. */}
        <CartesianGrid stroke="#e6ddcd" vertical={false} />
        <XAxis dataKey="day" tick={{ fontSize: 11, fill: '#6b5f52' }} interval={4} />
        <YAxis
          tick={{ fontSize: 11, fill: '#6b5f52' }}
          tickFormatter={(value: number) => `₱${Math.round(value / 1000)}k`}
          width={48}
        />
        <Tooltip
          formatter={(value) => formatPeso(Math.round(Number(value) * 100))}
          labelFormatter={(label) => `${label} — click to see the sales`}
          contentStyle={{
            background: '#ffffff',
            border: '1px solid #e6ddcd',
            borderRadius: 10,
            color: '#1f1a15',
          }}
        />
        <Line type="monotone" dataKey="pesos" stroke="#2f5d8a" strokeWidth={2} dot={false} />
      </LineChart>
    </ResponsiveContainer>
  )
}
