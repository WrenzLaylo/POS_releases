'use server'

import { prisma } from '@/lib/db'
import type { ActionResult } from '@/lib/types'
import { hashPassword, passwordProblem, verifyPassword } from '@/lib/password'
import {
  generateRecoveryCodes,
  hashRecoveryCode,
  normaliseRecoveryCode,
  recoveryCodeMatches,
} from '@/lib/recovery-code'
import { ROUTES } from '@/lib/routes'
import { revalidateRoutes } from './revalidate'
import {
  authIsEnabled,
  endAllSessions,
  endSession,
  getSession,
  markConfirmed,
  startSession,
} from './session'

/**
 * How long a wrong password makes the next attempt wait.
 *
 * Not a lockout. A till that refuses its own operator for fifteen minutes
 * because she fat-fingered a key three times is a till that has stopped the
 * shop trading, which is worse than the guessing it prevents — and guessing
 * here requires already standing at the counter. This only makes a machine
 * grinding through the dictionary slow, and it resets the moment she gets in.
 */
const FAILURE_DELAY_MS = 400
const MAX_DELAY_MS = 3_000
const failures = new Map<string, number>()

function delayFor(username: string): number {
  return Math.min((failures.get(username) ?? 0) * FAILURE_DELAY_MS, MAX_DELAY_MS)
}

const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

/** Who the login screen should offer. Null when the shop has no login. */
export async function getLoginIdentity(): Promise<{ username: string } | null> {
  const user = await prisma.appUser.findFirst({
    select: { username: true },
    orderBy: { id: 'asc' },
  })
  return user ?? null
}

/**
 * Signs in.
 *
 * The username comes from the server's own record rather than from the form:
 * there is exactly one account, so asking her to type an email address every
 * morning is friction that buys nothing. If a second account ever exists this
 * takes a username again.
 */
export async function signIn(
  password: string,
  remember: boolean,
): Promise<ActionResult<{ username: string }>> {
  const user = await prisma.appUser.findFirst({ orderBy: { id: 'asc' } })
  if (!user) return { ok: false, error: 'This shop has no login set up yet.' }

  await wait(delayFor(user.username))

  if (!verifyPassword(password, user.passwordHash)) {
    failures.set(user.username, (failures.get(user.username) ?? 0) + 1)
    // Deliberately not "wrong password for that user" or anything naming what
    // was wrong beyond the one thing she can act on.
    return { ok: false, error: 'That password does not match. Try again.' }
  }

  failures.delete(user.username)
  await startSession(user.id, remember)
  return { ok: true, data: { username: user.username } }
}

export async function signOut(): Promise<ActionResult> {
  await endSession()
  revalidateRoutes([ROUTES.counter], { layout: true })
  return { ok: true, data: undefined }
}

/**
 * Turns the login on for the first time.
 *
 * Refuses once an account exists, so this can never be used to take a shop
 * over: adding a login is a one-time act, and changing the password afterwards
 * requires the old one or a recovery code.
 *
 * Returns the recovery codes, which are shown ONCE. They are hashed on the way
 * in and cannot be read back — the only copies are the ones she writes down.
 */
export async function createLogin(
  username: string,
  password: string,
): Promise<ActionResult<{ codes: string[] }>> {
  if (await authIsEnabled()) {
    return { ok: false, error: 'This shop already has a login.' }
  }

  const name = username.trim()
  if (name === '') return { ok: false, error: 'Enter a username.' }

  const problem = passwordProblem(password)
  if (problem) return { ok: false, error: problem }

  const codes = generateRecoveryCodes()

  try {
    const user = await prisma.appUser.create({
      data: {
        username: name,
        passwordHash: hashPassword(password),
        recoveryCodes: {
          create: codes.map((code) => ({ codeHash: hashRecoveryCode(code) })),
        },
      },
    })
    await startSession(user.id, true)
  } catch {
    return { ok: false, error: 'Could not set up the login. Nothing was changed.' }
  }

  revalidateRoutes([ROUTES.settings], { layout: true })
  return { ok: true, data: { codes } }
}

/**
 * Changes the password, knowing the old one.
 *
 * Every other laptop is signed out afterwards. Someone who knew the old
 * password and is still holding a live session should not keep it just because
 * the password moved out from under them.
 */
export async function changePassword(
  currentPassword: string,
  newPassword: string,
): Promise<ActionResult> {
  const signedIn = await getSession()
  if (!signedIn) return { ok: false, error: 'Sign in first.' }

  const user = await prisma.appUser.findUnique({ where: { id: signedIn.id } })
  if (!user) return { ok: false, error: 'That account no longer exists.' }

  await wait(delayFor(user.username))
  if (!verifyPassword(currentPassword, user.passwordHash)) {
    failures.set(user.username, (failures.get(user.username) ?? 0) + 1)
    return { ok: false, error: 'The current password does not match.' }
  }
  failures.delete(user.username)

  const problem = passwordProblem(newPassword)
  if (problem) return { ok: false, error: problem }

  try {
    await prisma.appUser.update({
      where: { id: user.id },
      data: { passwordHash: hashPassword(newPassword) },
    })
    await endAllSessions(user.id)
    await startSession(user.id, true)
  } catch {
    return { ok: false, error: 'Could not change the password. Nothing was changed.' }
  }

  revalidateRoutes([ROUTES.settings], { layout: true })
  return { ok: true, data: undefined }
}

/**
 * Confirms the person at the keyboard is still her, for a dangerous action.
 *
 * Does NOT start or extend a session — it answers one question about one
 * moment, and the caller acts on the answer immediately.
 */
export async function confirmPassword(password: string): Promise<ActionResult> {
  if (!(await authIsEnabled())) return { ok: true, data: undefined }

  const signedIn = await getSession()
  if (!signedIn) return { ok: false, error: 'Sign in first.' }

  const user = await prisma.appUser.findUnique({ where: { id: signedIn.id } })
  if (!user) return { ok: false, error: 'That account no longer exists.' }

  await wait(delayFor(user.username))
  if (!verifyPassword(password, user.passwordHash)) {
    failures.set(user.username, (failures.get(user.username) ?? 0) + 1)
    return { ok: false, error: 'That password does not match.' }
  }
  failures.delete(user.username)
  // Stamped here, so the next few minutes of dangerous actions pass without
  // asking again. Without this the confirmation would prove nothing beyond
  // the instant it happened.
  await markConfirmed()
  return { ok: true, data: undefined }
}

/**
 * Gets her back in with a one-time code, and sets a new password.
 *
 * Using a code CONSUMES it and mints a replacement in the same transaction, so
 * the list never shrinks and can never run out. That is the whole answer to
 * "can't we make them unlimited": the number stays at ten forever, while each
 * individual code still only works once — which is what makes one safe to read
 * down a phone or leave printed in a drawer.
 *
 * The replacement is returned so it can be shown on screen and written into
 * the list Wrenz keeps.
 */
export async function resetPasswordWithCode(
  code: string,
  newPassword: string,
): Promise<ActionResult<{ replacementCode: string; remaining: number }>> {
  const user = await prisma.appUser.findFirst({ orderBy: { id: 'asc' } })
  if (!user) return { ok: false, error: 'This shop has no login set up yet.' }

  const typed = normaliseRecoveryCode(code)
  if (typed === '') return { ok: false, error: 'Enter the code Wrenz gave you.' }

  const problem = passwordProblem(newPassword)
  if (problem) return { ok: false, error: problem }

  // A wrong code waits too, for the same reason a wrong password does.
  await wait(delayFor(user.username))

  const live = await prisma.recoveryCode.findMany({
    where: { userId: user.id, usedAt: null },
    orderBy: { id: 'asc' },
  })
  const matched = live.find((candidate) => recoveryCodeMatches(code, candidate.codeHash))
  if (!matched) {
    failures.set(user.username, (failures.get(user.username) ?? 0) + 1)
    return { ok: false, error: 'That code does not match, or it has already been used.' }
  }
  failures.delete(user.username)

  const replacement = generateRecoveryCodes(1)[0]

  try {
    await prisma.$transaction(async (tx) => {
      // Marked used rather than deleted, so the list keeps its history and a
      // code can never be silently reissued.
      await tx.recoveryCode.update({
        where: { id: matched.id },
        data: { usedAt: new Date() },
      })
      await tx.recoveryCode.create({
        data: { userId: user.id, codeHash: hashRecoveryCode(replacement) },
      })
      await tx.appUser.update({
        where: { id: user.id },
        data: { passwordHash: hashPassword(newPassword) },
      })
      await tx.appSession.deleteMany({ where: { userId: user.id } })
    })
  } catch {
    return { ok: false, error: 'Could not reset the password. Nothing was changed.' }
  }

  const remaining = await prisma.recoveryCode.count({
    where: { userId: user.id, usedAt: null },
  })

  // Deliberately does NOT start a session, and deliberately does not
  // revalidate. Both did, and between them they destroyed the replacement
  // code: the session made the layout render the app instead of the login,
  // so the screen showing the new code never appeared — it was minted, hashed
  // and lost in the same request, leaving a list of ten where one was known to
  // nobody. The caller signs in explicitly once she has read the code.
  //
  // If it is lost anyway — she closes the window — Settings still reports the
  // count and can issue a fresh set, so this is recoverable rather than fatal.
  return { ok: true, data: { replacementCode: replacement, remaining } }
}

/**
 * Turns the login back off, leaving the shop open as it was.
 *
 * Needs the password, so it is not a bypass — but it exists, because a switch
 * that cannot be turned off is a switch nobody should be advised to turn on.
 * If the login ever becomes a problem at the counter, Wrenz can talk her
 * through removing it in under a minute rather than being the only route back.
 *
 * The account, its sessions and its codes all go. Nothing about the shop's
 * books is touched.
 */
export async function disableLogin(password: string): Promise<ActionResult> {
  const confirmed = await confirmPassword(password)
  if (!confirmed.ok) return confirmed

  const user = await prisma.appUser.findFirst({ orderBy: { id: 'asc' } })
  if (!user) return { ok: true, data: undefined }

  try {
    // Sessions and codes cascade from the user row.
    await prisma.appUser.delete({ where: { id: user.id } })
  } catch {
    return { ok: false, error: 'Could not remove the login. Nothing was changed.' }
  }

  revalidateRoutes([ROUTES.settings], { layout: true })
  return { ok: true, data: undefined }
}

/** Who is signed in, for Settings to show. Null when the shop has no login. */
export async function currentUser(): Promise<{ username: string } | null> {
  if (!(await authIsEnabled())) return null
  return getSession()
}

/** How many one-time codes are still live, for Settings to show. */
export async function countRecoveryCodes(): Promise<number> {
  const user = await prisma.appUser.findFirst({ orderBy: { id: 'asc' } })
  if (!user) return 0
  return prisma.recoveryCode.count({ where: { userId: user.id, usedAt: null } })
}

/**
 * Throws away every code and issues a fresh set, shown once.
 *
 * Requires the password: this invalidates the list Wrenz is holding, and doing
 * it by accident — or by someone who wandered up to an unlocked counter —
 * would quietly destroy the way back in.
 */
export async function regenerateRecoveryCodes(
  password: string,
): Promise<ActionResult<{ codes: string[] }>> {
  const confirmed = await confirmPassword(password)
  if (!confirmed.ok) return confirmed

  const user = await prisma.appUser.findFirst({ orderBy: { id: 'asc' } })
  if (!user) return { ok: false, error: 'This shop has no login set up yet.' }

  const codes = generateRecoveryCodes()
  try {
    await prisma.$transaction(async (tx) => {
      await tx.recoveryCode.deleteMany({ where: { userId: user.id } })
      await tx.recoveryCode.createMany({
        data: codes.map((code) => ({ userId: user.id, codeHash: hashRecoveryCode(code) })),
      })
    })
  } catch {
    return { ok: false, error: 'Could not make new codes. The old ones still work.' }
  }

  revalidateRoutes([ROUTES.settings], { layout: true })
  return { ok: true, data: { codes } }
}
