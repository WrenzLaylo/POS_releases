import { beforeEach, describe, expect, it } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'
import { searchEverything } from './search'

beforeEach(resetDb)

describe('searchEverything', () => {
  it('returns matching workspaces for a name fragment', async () => {
    const results = await searchEverything('sto')
    expect(results.some((r) => r.kind === 'workspace' && r.href === '/stock')).toBe(true)
  })

  it('returns an empty array for a blank query rather than everything', async () => {
    expect(await searchEverything('   ')).toEqual([])
  })

  it('caps results so the palette never renders an unbounded list', async () => {
    const results = await searchEverything('a')
    expect(results.length).toBeLessThanOrEqual(20)
  })

  it('matches customers by name and links to their passbook', async () => {
    const customer = await prisma.customer.create({ data: { name: 'MARIA SANTOS' } })

    const results = await searchEverything('maria')

    const match = results.find((r) => r.kind === 'customer')
    expect(match).toEqual({
      kind: 'customer',
      id: String(customer.id),
      label: 'MARIA SANTOS',
      hint: 'Customer',
      href: `/book/${customer.id}`,
    })
  })

  it('matches products by name', async () => {
    const category = await prisma.category.create({ data: { name: 'Feeds (Sako)', sortOrder: 1 } })
    await prisma.product.create({
      data: {
        categoryId: category.id, name: 'Hog Grower', unit: 'sako', price: 100000,
        costPrice: 90000, stockQty: 5, lowStockThreshold: 2,
      },
    })

    const results = await searchEverything('hog')

    expect(results.some((r) => r.kind === 'product' && r.label === 'Hog Grower')).toBe(true)
  })

  it('excludes archived customers and products', async () => {
    await prisma.customer.create({ data: { name: 'GONE CUSTOMER', isArchived: true } })
    const category = await prisma.category.create({ data: { name: 'Feeds (Sako)', sortOrder: 1 } })
    await prisma.product.create({
      data: {
        categoryId: category.id, name: 'Gone Product', unit: 'sako', price: 100000,
        costPrice: 90000, stockQty: 5, lowStockThreshold: 2, isArchived: true,
      },
    })

    expect(await searchEverything('gone')).toEqual([])
  })

  it('caps customers and products at 8 each', async () => {
    for (let i = 0; i < 10; i++) {
      await prisma.customer.create({ data: { name: `AAA CUSTOMER ${i}` } })
    }
    const category = await prisma.category.create({ data: { name: 'Feeds (Sako)', sortOrder: 1 } })
    for (let i = 0; i < 10; i++) {
      await prisma.product.create({
        data: {
          categoryId: category.id, name: `AAA PRODUCT ${i}`, unit: 'sako', price: 100000,
          costPrice: 90000, stockQty: 5, lowStockThreshold: 2,
        },
      })
    }

    const results = await searchEverything('aaa')

    expect(results.filter((r) => r.kind === 'customer').length).toBe(8)
    expect(results.filter((r) => r.kind === 'product').length).toBe(8)
    expect(results.length).toBeLessThanOrEqual(20)
  })
})
