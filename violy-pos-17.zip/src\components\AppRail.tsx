'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Icon, type IconName } from '@/components/ui/Icon'
import { ROUTES } from '@/lib/routes'
import { cn } from '@/lib/cn'

const STORAGE_KEY = 'rail-collapsed'

// Counter leads, decided 25 Aug 2026.
//
// Dashboard led until then, on the argument that "how is the store doing" is
// what she opens the app to find out. It is not what she then does for the
// rest of the day: the counter is where the hours go, `/` already opens it,
// and a rail is a place you return to all day rather than a landing page you
// see once. Dashboard moves last — still one click, just no longer first in
// the list she scans forty times a morning.
//
// Deliveries sits beside Stock because it is the other half of the same
// question: Stock says what is on the shelf, Deliveries says how it got there.
//
// The route is `/dashboard` now, not `/pulse`; `next.config.ts` redirects the
// old path forward so existing links and bookmarks still land.
const LINKS: readonly { href: string; label: string; icon: IconName }[] = [
  { href: ROUTES.counter, label: 'Counter', icon: 'receipt' },
  { href: ROUTES.book, label: 'Book', icon: 'customers' },
  { href: ROUTES.stock, label: 'Stock', icon: 'package' },
  { href: ROUTES.deliveries, label: 'Deliveries', icon: 'tag' },
  { href: ROUTES.history, label: 'History', icon: 'history' },
  { href: ROUTES.dashboard, label: 'Dashboard', icon: 'chart' },
]

function isCurrentRoute(pathname: string, href: string) {
  return pathname === href || pathname.startsWith(`${href}/`)
}

export function AppRail() {
  const pathname = usePathname()
  const [collapsed, setCollapsed] = useState(false)

  // Read AFTER mount, never in the useState initialiser: the initialiser runs
  // on the server pass too, and localStorage does not exist there.
  useEffect(() => {
    setCollapsed(window.localStorage.getItem(STORAGE_KEY) === '1')
  }, [])

  function toggle() {
    setCollapsed((previous) => {
      const next = !previous
      window.localStorage.setItem(STORAGE_KEY, next ? '1' : '0')
      return next
    })
  }

  return (
    <aside
      // Navigation is not part of a printed document. The hook travels with
      // the element rather than living in a descendant selector, so moving
      // this component cannot silently put the rail back on the page.
      data-print="hide"
      className={cn(
        'flex shrink-0 flex-col border-r border-line bg-surface transition-[width] duration-150',
        collapsed ? 'w-16' : 'w-[220px]',
      )}
    >
      {/* The collapse control sits with the brand rather than stranded at the
          foot of the rail, where it was a long way from anything else and easy
          to miss.

          Collapsed, the two stack instead of sitting side by side: a 4rem rail
          has room for the `VS` mark OR a 2rem button on one row, not both, and
          dropping the mark to make space would lose the brand exactly where
          the rail is least identifiable. */}
      <div
        className={cn(
          'flex h-16 shrink-0 px-3',
          collapsed
            ? 'flex-col items-center justify-center gap-1 px-1'
            : 'items-center justify-between gap-2',
        )}
      >
        {/* The mark alone when collapsed, the mark plus the name when not.
            Not the supplied lockup: at 220px wide the wordmark inside it would
            render about 9px tall, which is smaller than anything else in the
            app and unreadable. The mark scales; the name is set in the app's
            own type beside it. */}
        <span className={cn('flex min-w-0 items-center', collapsed ? 'gap-0' : 'gap-2')}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/brand/violy-store-mark.png"
            alt=""
            width={28}
            height={28}
            className="h-7 w-7 shrink-0"
          />
          {!collapsed && (
            <span className="truncate font-display text-sm font-semibold uppercase tracking-[0.14em] text-accent">
              Violy Store
            </span>
          )}
        </span>
        <button
          type="button"
          onClick={toggle}
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          className="flex h-7 w-7 shrink-0 items-center justify-center rounded-control text-ink-muted transition-colors duration-150 hover:bg-surface-sunk hover:text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
        >
          <Icon name={collapsed ? 'rail-expand' : 'rail-collapse'} className="h-4 w-4" />
        </button>
      </div>

      <nav aria-label="Primary navigation" className="min-h-0 flex-1 px-2">
        <ul className="flex flex-col gap-1">
          {LINKS.map((link) => {
            const active = isCurrentRoute(pathname, link.href)
            return (
              <li key={link.href}>
                <Link
                  href={link.href}
                  aria-current={active ? 'page' : undefined}
                  title={collapsed ? link.label : undefined}
                  className={cn(
                    'flex h-10 items-center gap-3 rounded-control px-3 transition-colors duration-150',
                    'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent',
                    active
                      ? 'bg-accent-soft text-accent'
                      : 'text-ink-muted hover:bg-surface-sunk hover:text-ink',
                  )}
                >
                  <Icon name={link.icon} className="h-4 w-4 shrink-0" />
                  {/* text-base, not text-sm: a deliberate exception, because
                      the rail exists to make these readable. */}
                  {!collapsed && <span className="truncate text-base">{link.label}</span>}
                </Link>
              </li>
            )
          })}
        </ul>
      </nav>
    </aside>
  )
}
