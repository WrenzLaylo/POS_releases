'use server'

import type { Customer } from '@prisma/client'
import { prisma } from '@/lib/db'
import { parseDayKey, startOfDay } from '@/lib/dates'
import { sumBalance } from '@/lib/ledger-balance'
import type { ActionResult, CategoryCheapest, CustomerWithDiscount } from '@/lib/types'
import { prismaErrorCode } from '@/lib/prisma-errors'
import { ROUTES, bookEntry } from '@/lib/routes'
import { revalidateRoutes, revalidatePathname } from './revalidate'

type CustomerInput = {
  name: string
  phone?: string
  notes?: string
}

type ParsedCustomer = {
  name: string
  phone: string | null
  notes: string
}

function parse(input: CustomerInput): ParsedCustomer | string {
  const name = input.name.trim()
  if (!name) return 'Name is required.'

  const phone = (input.phone ?? '').trim()
  return {
    name,
    phone: phone === '' ? null : phone,
    notes: (input.notes ?? '').trim(),
  }
}

/**
 * Unarchived customers, most recently ordered first. That ordering is the
 * whole point of the picker: the names she used today are the names she is
 * most likely to use next.
 *
 * The sort happens in JavaScript because Prisma cannot order a parent by an
 * aggregate over its children on SQLite.
 */
export async function listCustomers(): Promise<CustomerWithDiscount[]> {
  const customers = await prisma.customer.findMany({
    where: { isArchived: false },
    include: {
      sales: { select: { createdAt: true }, orderBy: { createdAt: 'desc' }, take: 1 },
    },
  })

  return customers
    .map(({ sales, ...customer }) => ({
      customer,
      lastOrderedAt: sales[0]?.createdAt ?? null,
    }))
    .sort((a, b) => {
      if (a.lastOrderedAt && b.lastOrderedAt) {
        return b.lastOrderedAt.getTime() - a.lastOrderedAt.getTime()
      }
      if (a.lastOrderedAt) return -1
      if (b.lastOrderedAt) return 1
      return a.customer.name.localeCompare(b.customer.name)
    })
    .map((row) => row.customer)
}

export async function getCustomer(id: number): Promise<CustomerWithDiscount | null> {
  return prisma.customer.findUnique({
    where: { id },
    include: {
    },
  })
}

/**
 * The account already on file under this name, if there is one.
 *
 * `Customer.name` carries a `@@unique`, and it is not enough. SQLite compares
 * TEXT case-sensitively unless the column is declared `COLLATE NOCASE`, so the
 * database will happily hold MARILOU, Marilou and marilou as three separate
 * people — and `findUnique({ where: { name } })` misses two of them every
 * time. There is a test for exactly that; it failed before this existed.
 *
 * The consequence is worse here than for a duplicate product. Two accounts for
 * one person split her utang across both, so neither balance is what she
 * actually owes, a payment against one leaves the other still showing a debt,
 * and the total on the Book is right only by accident.
 *
 * `contains` narrows in SQL — LIKE is case-insensitive on this provider even
 * though `=` is not — and the exact comparison happens here. Archived accounts
 * count: the answer for one of those is "restore her", not a second file.
 */
async function findCustomerByName(
  name: string,
  excludeId?: number,
): Promise<{ id: number; name: string; isArchived: boolean } | null> {
  const needle = name.trim().toLowerCase()
  if (!needle) return null

  const candidates = await prisma.customer.findMany({
    where: { name: { contains: needle } },
    select: { id: true, name: true, isArchived: true },
  })

  return (
    candidates.find(
      (row) => row.name.trim().toLowerCase() === needle && row.id !== excludeId,
    ) ?? null
  )
}

function duplicateCustomerMessage(existing: { name: string; isArchived: boolean }): string {
  return existing.isArchived
    ? `${existing.name} is already on the list but archived. Restore that account instead of adding a new one — her utang is on it.`
    : `${existing.name} is already on the list.`
}

export async function createCustomer(
  input: CustomerInput,
): Promise<ActionResult<{ customerId: number }>> {
  const parsed = parse(input)
  if (typeof parsed === 'string') return { ok: false, error: parsed }

  const existing = await findCustomerByName(parsed.name)
  if (existing) {
    return { ok: false, error: duplicateCustomerMessage(existing) }
  }

  let customer: Customer
  try {
    customer = await prisma.customer.create({
      data: {
        name: parsed.name,
        phone: parsed.phone,
        notes: parsed.notes,
      },
    })
  } catch (error) {
    if (prismaErrorCode(error) === 'P2002') {
      return { ok: false, error: `${parsed.name} is already on the list.` }
    }
    return { ok: false, error: 'Could not save the customer.' }
  }

  revalidateRoutes([ROUTES.counter, ROUTES.history, ROUTES.book])
  return { ok: true, data: { customerId: customer.id } }
}

export async function updateCustomer(
  id: number,
  input: CustomerInput,
): Promise<ActionResult> {
  const parsed = parse(input)
  if (typeof parsed === 'string') return { ok: false, error: parsed }

  const existing = await prisma.customer.findUnique({ where: { id } })
  if (!existing) return { ok: false, error: 'Customer not found.' }

  const clash = await findCustomerByName(parsed.name, id)
  if (clash) {
    return { ok: false, error: duplicateCustomerMessage(clash) }
  }

  try {
    await prisma.customer.update({
      where: { id },
      data: {
        name: parsed.name,
        phone: parsed.phone,
        notes: parsed.notes,
      },
    })
  } catch (error) {
    const code = prismaErrorCode(error)
    if (code === 'P2002') return { ok: false, error: `${parsed.name} is already on the list.` }
    if (code === 'P2025') return { ok: false, error: 'Customer not found.' }
    return { ok: false, error: 'Could not save the customer.' }
  }

  revalidateRoutes([ROUTES.counter, ROUTES.history, ROUTES.book])
  return { ok: true, data: undefined }
}

/** Archives rather than deletes: sales and ledger entries reference the row. */
export async function archiveCustomer(id: number): Promise<ActionResult> {
  const existing = await prisma.customer.findUnique({ where: { id } })
  if (!existing) return { ok: false, error: 'Customer not found.' }

  try {
    await prisma.customer.update({ where: { id }, data: { isArchived: true } })
  } catch (error) {
    if (prismaErrorCode(error) === 'P2025') return { ok: false, error: 'Customer not found.' }
    return { ok: false, error: 'Could not archive the customer.' }
  }

  revalidateRoutes([ROUTES.counter, ROUTES.history, ROUTES.book])
  return { ok: true, data: undefined }
}

/**
 * The way back from `archiveCustomer`. Archiving is a single click, and it
 * hides the customer from the order picker and the bulk payment grid while
 * their utang stays live on the Customers page — so without this a mis-click
 * strands a debtor somewhere only a direct database edit could reach them.
 * Re-creating them is not a workaround: the unique-name check rejects it.
 */
export async function restoreCustomer(id: number): Promise<ActionResult> {
  const existing = await prisma.customer.findUnique({ where: { id } })
  if (!existing) return { ok: false, error: 'Customer not found.' }

  try {
    await prisma.customer.update({ where: { id }, data: { isArchived: false } })
  } catch (error) {
    if (prismaErrorCode(error) === 'P2025') return { ok: false, error: 'Customer not found.' }
    return { ok: false, error: 'Could not restore the customer.' }
  }

  revalidateRoutes([ROUTES.counter, ROUTES.history, ROUTES.book])
  return { ok: true, data: undefined }
}

/** Extends or corrects the deadline for a live positive balance. */
export async function setCustomerDueDate(id: number, day: string): Promise<ActionResult> {
  if (!Number.isInteger(id) || id <= 0) return { ok: false, error: 'Customer not found.' }

  const dueAt = parseDayKey(day)
  if (!dueAt) return { ok: false, error: 'Enter a valid due date.' }
  if (dueAt < startOfDay(new Date())) {
    return { ok: false, error: 'Due date cannot be in the past.' }
  }

  try {
    await prisma.$transaction(async (tx) => {
      // Validate the live balance and write the deadline under the same SQLite
      // transaction. Otherwise a concurrent payment could clear the balance
      // between this read and update, leaving a settled account with dueAt.
      const customer = await tx.customer.findUnique({
        where: { id },
        select: {
          id: true,
          entries: {
            where: { isVoided: false },
            select: { id: true, type: true, amountCentavos: true, isVoided: true },
          },
        },
      })
      if (!customer) throw new Error('DUE_DATE_CUSTOMER_NOT_FOUND')
      if (sumBalance(customer.entries) <= 0) throw new Error('DUE_DATE_NO_BALANCE')

      await tx.customer.update({ where: { id }, data: { dueAt } })
    })
  } catch (error) {
    if (
      prismaErrorCode(error) === 'P2025' ||
      (error instanceof Error && error.message === 'DUE_DATE_CUSTOMER_NOT_FOUND')
    ) {
      return { ok: false, error: 'Customer not found.' }
    }
    if (error instanceof Error && error.message === 'DUE_DATE_NO_BALANCE') {
      return { ok: false, error: 'This account has no outstanding balance.' }
    }
    return { ok: false, error: 'Could not update the due date.' }
  }

  // The write has committed. Revalidation stays outside the catch so a
  // rendering failure can never make a successful account edit look failed.
  revalidateRoutes([ROUTES.book], { layout: true })
  revalidatePathname(bookEntry(id))
  return { ok: true, data: undefined }
}

/**
 * Every category with its cheapest unarchived product, so the customer form
 * can warn that a discount would price a line at zero. Archived products are
 * excluded — a discontinued item should not trigger a warning about a
 * category she can still sell from.
 */
export async function listCategoriesWithCheapest(): Promise<CategoryCheapest[]> {
  const categories = await prisma.category.findMany({
    orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
    include: {
      products: {
        where: { isArchived: false },
        orderBy: { price: 'asc' },
        take: 1,
        select: { name: true, price: true },
      },
    },
  })

  return categories.map((category) => ({
    id: category.id,
    name: category.name,
    cheapestName: category.products[0]?.name ?? null,
    cheapestCentavos: category.products[0]?.price ?? null,
  }))
}
