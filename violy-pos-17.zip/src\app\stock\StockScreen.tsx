'use client'

import { useState } from 'react'
import type { ProductWithCategory } from '@/lib/types'
import type { CategoryRow } from '@/server/categories'
import type { ProductSortKey } from '@/lib/product-sort'
import type { SortState } from '@/lib/sorting'
import Link from 'next/link'
import { STOCK_COSTS, STOCK_COUNT } from '@/lib/routes'
import { Button } from '@/components/ui/Button'
import { RowActionMenu } from '@/components/ui/RowActionMenu'
import { useRouter } from 'next/navigation'
import { InventoryFilters } from './InventoryFilters'
import { InventoryTable } from './InventoryTable'
import { CategoryDialog } from './CategoryDialog'
import { ProductForm } from './ProductForm'

/**
 * Holds the one piece of state the filter row and the table both need: whether
 * the new-product form is open.
 *
 * "New product" belongs on the filter row — it used to sit in a block of its
 * own beneath, leaving a band of empty page between the filters and the table
 * with the primary action stranded in it. But the form it opens is the table's
 * concern, so something has to own that state above both. This does, and
 * nothing else moves.
 */
export function StockScreen({
  products,
  categories,
  categoryRows,
  sort,
  filters,
}: {
  products: ProductWithCategory[]
  categories: { id: number; name: string }[]
  /** The same categories with their product counts, for managing them. */
  categoryRows: CategoryRow[]
  sort: SortState<ProductSortKey>
  filters: { q?: string; category?: string; stock?: string; archived?: string }
}) {
  const [newOpen, setNewOpen] = useState(false)
  const [categoriesOpen, setCategoriesOpen] = useState(false)
  const router = useRouter()

  return (
    <>
      <div className="mb-4">
        <InventoryFilters
          categories={categories}
          q={filters.q}
          category={filters.category}
          stock={filters.stock}
          archived={filters.archived}
          action={
            <div className="flex flex-wrap items-center gap-2">
              {/* First of the four, because it is the one a shop does before
                  anything else works: until stock is counted in, every
                  product reads 0 and the counter drives it negative. */}
              <Link
                href={STOCK_COUNT}
                className="inline-flex h-10 items-center justify-center rounded-control border border-line-strong bg-surface-raised px-4 text-sm font-medium text-ink hover:border-accent hover:bg-accent-soft"
              >
                Count stock
              </Link>
              {/* Cost prices and Categories are things a shop SETS UP, not
                  things it does during a day, so they moved behind one menu.
                  Four buttons of near-identical weight made the row a wall to
                  read every time she came here to add a product — and the two
                  that matter hourly are the two left out here.

                  `RowActionMenu` rather than a bespoke popover: it already
                  owns outside-click, Escape and focus return. AGENTS.md
                  records three hand-rolled versions of that behaviour which
                  have already drifted apart; this is not a fourth. */}
              <RowActionMenu
                ariaLabel="Stock tools"
                align="end"
                trigger={
                  <span className="inline-flex h-10 w-full items-center justify-center whitespace-nowrap rounded-control border border-line-strong bg-surface-raised px-4 text-sm font-medium text-ink hover:border-accent hover:bg-accent-soft">
                    Stock tools
                  </span>
                }
                items={[
                  { label: 'Cost prices', onSelect: () => router.push(STOCK_COSTS) },
                  { label: 'Categories', onSelect: () => setCategoriesOpen(true) },
                ]}
              />
              <Button variant="primary" onClick={() => setNewOpen(true)}>
                New product
              </Button>
            </div>
          }
        />
      </div>

      <InventoryTable products={products} categories={categories} sort={sort} />

      {categoriesOpen && (
        <CategoryDialog categories={categoryRows} onClose={() => setCategoriesOpen(false)} />
      )}

      {/* Mounted only while open, so each opening starts from empty fields
          rather than whatever was typed and abandoned last time. */}
      {newOpen && (
        <ProductForm
          categories={categories}
          product={null}
          onClose={() => setNewOpen(false)}
        />
      )}
    </>
  )
}
