import { listAllProducts, listCategories } from '@/server/products'
import { listCategoriesWithCounts } from '@/server/categories'
import { PRODUCT_SORT_KEYS } from '@/lib/product-sort'
import { parsePage } from '@/lib/pagination'
import { parseSort } from '@/lib/sorting'
import { parseStockLevel } from '@/lib/stock-level'
import { Pagination } from '@/components/Pagination'
import { StockScreen } from './StockScreen'
import { PageHeader } from '@/components/ui/PageHeader'

export const dynamic = 'force-dynamic'

type Props = {
  searchParams: Promise<{
    page?: string
    q?: string
    category?: string
    stock?: string
    archived?: string
    sort?: string
    dir?: string
  }>
}

export default async function InventoryPage({ searchParams }: Props) {
  const params = await searchParams
  const categoryId = Number(params.category)
  const sort = parseSort(params.sort, params.dir, PRODUCT_SORT_KEYS, {
    key: 'name',
    direction: 'asc',
  })

  const [products, categories, categoryRows] = await Promise.all([
    listAllProducts(
      {
        q: params.q,
        categoryId: Number.isInteger(categoryId) && categoryId > 0 ? categoryId : undefined,
        stock: parseStockLevel(params.stock),
        includeArchived: params.archived === '1',
      },
      parsePage(params.page),
      sort.key,
      sort.direction,
    ),
    listCategories(),
    listCategoriesWithCounts(),
  ])

  return (
    <PageHeader
      title="Stock"
      actions={<span className="text-sm text-ink-muted">{products.total} products</span>}
    >
      <StockScreen
        products={products.rows}
        categories={categories}
        categoryRows={categoryRows}
        sort={sort}
        filters={{
          q: params.q,
          category: params.category,
          stock: params.stock,
          archived: params.archived,
        }}
      />

      <Pagination
        page={products.page}
        pageCount={products.pageCount}
        params={{
          q: params.q,
          category: params.category,
          stock: params.stock,
          archived: params.archived,
          sort: params.sort,
          dir: params.dir,
        }}
      />
    </PageHeader>
  )
}
