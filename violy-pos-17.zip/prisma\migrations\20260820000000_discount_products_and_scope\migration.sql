-- A discount can now name individual products, not only brands.
--
-- `discountScope` defaults to 'CATEGORIES' so every existing row keeps the
-- behaviour it has today: scoped to whatever categories are ticked, and inert
-- when none are. Without the column, "covers everything" and "covers nothing"
-- are both an empty list and cannot be told apart.
ALTER TABLE "Customer" ADD COLUMN "discountScope" TEXT NOT NULL DEFAULT 'CATEGORIES';

-- Implicit many-to-many, named to match Prisma's convention for the
-- "CustomerDiscountProducts" relation: A is the alphabetically-first model.
CREATE TABLE "_CustomerDiscountProducts" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL,
    CONSTRAINT "_CustomerDiscountProducts_A_fkey" FOREIGN KEY ("A") REFERENCES "Customer" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "_CustomerDiscountProducts_B_fkey" FOREIGN KEY ("B") REFERENCES "Product" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE UNIQUE INDEX "_CustomerDiscountProducts_AB_unique" ON "_CustomerDiscountProducts"("A", "B");
CREATE INDEX "_CustomerDiscountProducts_B_index" ON "_CustomerDiscountProducts"("B");
