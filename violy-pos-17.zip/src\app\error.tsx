'use client'

import { Button } from '@/components/ui/Button'

export default function Error({ error, reset }: { error: Error; reset: () => void }) {
  return (
    <div className="flex h-full items-center justify-center p-8">
      <div className="max-w-md rounded-xl border border-line-strong bg-surface p-6 text-center">
        <h2 className="text-base font-semibold text-ink">Something went wrong</h2>
        <p className="mt-2 text-sm text-ink-muted">{error.message}</p>
        <Button variant="primary" onClick={reset} className="mt-4">
          Try again
        </Button>
      </div>
    </div>
  )
}
