-- CreateTable
CREATE TABLE "UtangPlan" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "customerId" INTEGER NOT NULL,
    "principalCentavos" INTEGER NOT NULL,
    "interestMethod" TEXT NOT NULL,
    "interestRateBps" INTEGER NOT NULL DEFAULT 0,
    "termMonths" INTEGER NOT NULL DEFAULT 1,
    "interestCentavos" INTEGER NOT NULL,
    "totalCentavos" INTEGER NOT NULL,
    "startedAt" DATETIME NOT NULL,
    "note" TEXT NOT NULL DEFAULT '',
    "isVoided" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "UtangPlan_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "Customer" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "UtangInstallment" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "planId" INTEGER NOT NULL,
    "sequence" INTEGER NOT NULL,
    "dueAt" DATETIME NOT NULL,
    "amountCentavos" INTEGER NOT NULL,
    "principalCentavos" INTEGER NOT NULL,
    "interestCentavos" INTEGER NOT NULL,
    CONSTRAINT "UtangInstallment_planId_fkey" FOREIGN KEY ("planId") REFERENCES "UtangPlan" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_LedgerEntry" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "customerId" INTEGER NOT NULL,
    "type" TEXT NOT NULL,
    "amountCentavos" INTEGER NOT NULL,
    "occurredAt" DATETIME NOT NULL,
    "saleId" INTEGER,
    "note" TEXT NOT NULL DEFAULT '',
    "isVoided" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "planId" INTEGER,
    CONSTRAINT "LedgerEntry_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "Customer" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "LedgerEntry_saleId_fkey" FOREIGN KEY ("saleId") REFERENCES "Sale" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "LedgerEntry_planId_fkey" FOREIGN KEY ("planId") REFERENCES "UtangPlan" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);
INSERT INTO "new_LedgerEntry" ("amountCentavos", "createdAt", "customerId", "id", "isVoided", "note", "occurredAt", "saleId", "type") SELECT "amountCentavos", "createdAt", "customerId", "id", "isVoided", "note", "occurredAt", "saleId", "type" FROM "LedgerEntry";
DROP TABLE "LedgerEntry";
ALTER TABLE "new_LedgerEntry" RENAME TO "LedgerEntry";
CREATE UNIQUE INDEX "LedgerEntry_saleId_key" ON "LedgerEntry"("saleId");
CREATE INDEX "LedgerEntry_customerId_idx" ON "LedgerEntry"("customerId");
CREATE INDEX "LedgerEntry_occurredAt_idx" ON "LedgerEntry"("occurredAt");
CREATE INDEX "LedgerEntry_planId_idx" ON "LedgerEntry"("planId");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;

-- CreateIndex
CREATE INDEX "UtangPlan_customerId_idx" ON "UtangPlan"("customerId");

-- CreateIndex
CREATE INDEX "UtangInstallment_dueAt_idx" ON "UtangInstallment"("dueAt");

-- CreateIndex
CREATE UNIQUE INDEX "UtangInstallment_planId_sequence_key" ON "UtangInstallment"("planId", "sequence");
