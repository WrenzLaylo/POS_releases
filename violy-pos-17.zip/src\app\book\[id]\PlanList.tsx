'use client'

import { useState, useTransition } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import type { UtangPlanView } from '@/lib/types'
import { dayKey } from '@/lib/dates'
import { planInvoice } from '@/lib/routes'
import { resplitPlan, voidPlan } from '@/server/utang'
import { useGuardedAction } from '@/lib/use-guarded-action'
import { PasswordPrompt } from '@/components/PasswordPrompt'
import { InstallmentStatusCell } from '@/components/InstallmentStatus'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { EmptyState } from '@/components/ui/EmptyState'
import { FormError } from '@/components/ui/FormError'
import { Money } from '@/components/ui/Money'
import { cn } from '@/lib/cn'

function shortDate(date: Date): string {
  return date.toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' })
}

function PlanCard({ plan, todayKey }: { plan: UtangPlanView; todayKey: string }) {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [confirming, setConfirming] = useState(false)
  const [resplitting, setResplitting] = useState(false)
  const [months, setMonths] = useState(String(plan.termMonths))
  const [error, setError] = useState<string | null>(null)
  const [pending, startTransition] = useTransition()

  const settled = plan.outstandingCentavos === 0
  const overdue = plan.overdue.length > 0

  const { asking, guard, confirmed, cancel } = useGuardedAction()

  function remove() {
    setError(null)
    startTransition(async () => {
      await guard(
        () => voidPlan(plan.id),
        (result) => {
          if (!result.ok) {
            setError(result.error ?? 'Could not void this utang.')
            setConfirming(false)
            return
          }
          router.refresh()
        },
      )
    })
  }

  function changeTerms() {
    setError(null)
    const termMonths = Number(months)
    startTransition(async () => {
      await guard(
        () => resplitPlan(plan.id, { termMonths }),
        (result) => {
          if (!result.ok) {
            setError(result.error ?? 'Could not change these terms.')
            return
          }
          setResplitting(false)
          router.refresh()
        },
      )
    })
  }

  return (
    <>
      {asking && (
        <PasswordPrompt
          what="void this utang"
          onConfirmed={() => startTransition(confirmed)}
          onCancel={cancel}
        />
      )}
    <div
      className={cn(
        'rounded-card border bg-surface p-4',
        plan.isVoided ? 'border-line opacity-60' : overdue ? 'border-owed/50' : 'border-line',
      )}
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <span className={cn('font-medium text-ink', plan.isVoided && 'line-through')}>
              {shortDate(plan.startedAt)}
            </span>
            {/* `muted` is archived/dead; `paid` is settled clean. A voided
                record and a fully-paid one must not wear the same chip. */}
            {plan.isVoided ? (
              <Badge tone="muted">voided</Badge>
            ) : settled ? (
              <Badge tone="paid">settled</Badge>
            ) : overdue ? (
              <Badge tone="owed">
                {plan.overdue.length} overdue
              </Badge>
            ) : null}
          </div>
          <div className="mt-1 text-sm text-ink-muted">{plan.termsLabel}</div>
          {plan.note && <div className="mt-1 text-sm text-ink-subtle">{plan.note}</div>}
        </div>

        <div className="text-right">
          <div className="text-xs uppercase tracking-wide text-ink-muted">Outstanding</div>
          <Money
            centavos={plan.outstandingCentavos}
            tone={plan.isVoided || settled ? 'zero' : 'owed'}
            scale="strong"
          />
        </div>
      </div>

      <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-1 text-sm sm:grid-cols-4">
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-muted">Borrowed</dt>
          <dd><Money centavos={plan.principalCentavos} /></dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-muted">Interest</dt>
          <dd><Money centavos={plan.interestCentavos} /></dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-muted">Total</dt>
          <dd><Money centavos={plan.totalCentavos} /></dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-muted">Paid</dt>
          {/* `in`: this is cash the store actually received. */}
          <dd><Money centavos={plan.paidCentavos} tone="in" /></dd>
        </div>
      </dl>

      {!plan.isVoided && plan.nextDue && (
        <p className={cn('mt-3 text-sm', overdue ? 'font-semibold text-owed' : 'text-ink-muted')}>
          Next: <Money centavos={plan.nextDue.amountCentavos} /> due{' '}
          {shortDate(plan.nextDue.dueAt)}
          {overdue && ' — past due'}
        </p>
      )}

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setOpen((current) => !current)}
          aria-expanded={open}
        >
          {open ? 'Hide schedule' : `Show all ${plan.termMonths} months`}
        </Button>

        <Link
          href={planInvoice(plan.customerId, plan.id)}
          className="inline-flex h-8 items-center rounded-control px-3 text-sm font-medium text-accent hover:bg-accent-soft"
        >
          Invoice
        </Link>

        {/* Spreading a debt further is an ordinary conversation in a feed
            shop — "₱25,000 in a month, can I pay it over five?" — and until
            now the only answer was voiding and retyping, which double-charges
            a plan made by putting an existing balance on terms. Not shown on a
            settled plan: there is nothing left to spread. */}
        {!plan.isVoided && !settled && !confirming && (
          resplitting ? (
            <span className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-medium text-ink">Pay it over</span>
              <Input
                type="number"
                min={1}
                inputMode="numeric"
                value={months}
                onChange={(event) => setMonths(event.target.value)}
                aria-label="Number of months"
                className="h-8 w-16 tabular-nums"
              />
              <span className="text-xs font-medium text-ink">months</span>
              <Button
                variant="secondary"
                size="sm"
                onClick={changeTerms}
                disabled={pending || Number(months) === plan.termMonths || Number(months) < 1}
              >
                Save terms
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setResplitting(false)
                  setMonths(String(plan.termMonths))
                }}
                disabled={pending}
              >
                Cancel
              </Button>
            </span>
          ) : (
            <Button variant="ghost" size="sm" onClick={() => setResplitting(true)}>
              Change terms
            </Button>
          )
        )}

        {!plan.isVoided && !resplitting &&
          (confirming ? (
            <span className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-medium text-ink">Void this record?</span>
              <Button variant="destructive" size="sm" onClick={remove} disabled={pending}>
                Yes, void it
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setConfirming(false)}
                disabled={pending}
              >
                No
              </Button>
            </span>
          ) : (
            <Button variant="danger" size="sm" onClick={() => setConfirming(true)}>
              Void
            </Button>
          ))}
      </div>

      {resplitting && (
        <p className="mt-2 text-xs text-ink-subtle">
          The day of the month stays where it is, and what she has already paid
          comes with it. The old terms stay on record, voided.
        </p>
      )}

      {confirming && (
        <p className="mt-2 text-xs text-ink-subtle">
          The charge is cancelled. Payments already made stay on the ledger — the customer
          really did hand that money over.
        </p>
      )}

      {open && (
        <table className="mt-3 w-full text-sm">
          <thead className="border-b border-line text-left text-xs uppercase tracking-wide text-ink-muted">
            <tr>
              <th className="py-2 pr-2 font-medium">#</th>
              <th className="px-2 py-2 font-medium">Due</th>
              <th className="px-2 py-2 text-right font-medium">Amount</th>
              <th className="py-2 pl-2 text-right font-medium">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {plan.installments.map((installment) => {
              const late =
                !plan.isVoided && !installment.isSettled && dayKey(installment.dueAt) < todayKey
              return (
                <tr key={installment.sequence}>
                  <td className="py-2 pr-2 font-mono tabular-nums text-ink-muted">
                    {installment.sequence}
                  </td>
                  <td className="px-2 py-2">{shortDate(installment.dueAt)}</td>
                  <td className="px-2 py-2 text-right">
                    <Money centavos={installment.amountCentavos} />
                  </td>
                  <td className="py-2 pl-2 text-right">
                    <InstallmentStatusCell installment={installment} late={late} />
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      )}

      {error && <FormError className="mt-2">{error}</FormError>}
    </div>
    </>
  )
}

export function PlanList({
  plans,
  todayKey,
  unplannedCentavos,
}: {
  plans: UtangPlanView[]
  todayKey: string
  /** Owed but on no schedule — a notebook carry-over, or a credit sale. */
  unplannedCentavos: number
}) {
  const unscheduled = unplannedCentavos > 0

  return (
    <section className="mb-6">
      <h2 className="mb-3 text-base font-semibold">Utang records</h2>

      {/* Money owed on no schedule gets a row of its own. Previously this
          section said "No utang records" while the customer plainly owed
          thousands, because it only counted plans — which reads as "nothing
          is owed" rather than "nothing here is on terms". */}
      {unscheduled && (
        <div className="mb-3 rounded-card border border-line bg-surface p-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="font-medium text-ink">Unscheduled balance</div>
              <div className="mt-1 text-sm text-ink-muted">
                Owed, but on no payment schedule — carried over, or charged at the counter.
              </div>
            </div>
            <div className="text-right">
              <div className="text-xs uppercase tracking-wide text-ink-muted">Outstanding</div>
              <Money centavos={unplannedCentavos} tone="owed" scale="strong" />
            </div>
          </div>
        </div>
      )}

      {plans.length === 0 ? (
        !unscheduled && (
          <EmptyState>
            No records yet. Use “New utang” to carry one over from the notebook.
          </EmptyState>
        )
      ) : (
        <div className="grid gap-3">
          {plans.map((plan) => (
            <PlanCard key={plan.id} plan={plan} todayKey={todayKey} />
          ))}
        </div>
      )}
    </section>
  )
}
