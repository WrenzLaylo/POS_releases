import type { InputHTMLAttributes, Ref } from 'react'
import { cn } from '@/lib/cn'

// Shared by Textarea, which wants everything here except the fixed height.
export const CONTROL_BASE =
  'rounded-control border border-line-strong bg-surface-sunk px-3 text-sm text-ink shadow-panel ' +
  'transition-[border-color,background-color,box-shadow] duration-150 placeholder:text-ink-subtle ' +
  'hover:border-accent focus:border-accent focus:bg-surface focus:outline-none focus:ring-2 focus:ring-accent ' +
  'focus:ring-offset-2 focus:ring-offset-canvas ' +
  'aria-invalid:border-owed disabled:bg-surface-sunk disabled:opacity-50'

export const CONTROL = cn(CONTROL_BASE, 'h-10')

export function Input({
  className,
  ref,
  ...props
}: InputHTMLAttributes<HTMLInputElement> & { ref?: Ref<HTMLInputElement> }) {
  return <input ref={ref} className={cn(CONTROL, className)} {...props} />
}
