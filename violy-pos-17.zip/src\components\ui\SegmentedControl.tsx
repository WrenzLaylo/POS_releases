'use client'

import { useId } from 'react'
import { cn } from '@/lib/cn'

export function SegmentedControl({
  options,
  value,
  onValueChange,
  ariaLabel,
  className,
}: {
  options: readonly { value: string; label: string }[]
  value: string
  onValueChange: (value: string) => void
  ariaLabel: string
  className?: string
}) {
  const name = useId()

  return (
    <div
      role="radiogroup"
      aria-label={ariaLabel}
      className={cn(
        // `relative` so the `sr-only` radios below resolve against THIS
        // control. `sr-only` is `position: absolute`; without a positioned
        // ancestor it resolves against the document, escapes whatever is
        // scrolling, and drags the page's height out to wherever this control
        // happens to sit. The hidden input belongs to this control, so this is
        // where it should be anchored.
        'relative inline-flex h-10 items-center gap-1 rounded-control border border-line bg-surface-sunk p-1',
        className,
      )}
    >
      {options.map((option) => {
        const selected = option.value === value
        return (
          <label
            key={option.value}
            className={cn(
              'flex h-8 cursor-pointer items-center rounded-[0.4rem] px-3 text-sm font-medium transition-colors duration-150',
              selected
                ? 'bg-accent-soft text-accent'
                : 'text-ink-muted hover:text-ink',
            )}
          >
            <input
              type="radio"
              name={name}
              value={option.value}
              checked={selected}
              onChange={() => onValueChange(option.value)}
              className="sr-only"
            />
            {option.label}
          </label>
        )
      })}
    </div>
  )
}
