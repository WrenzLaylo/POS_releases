/**
 * The startup log's pure parts: what a launch is allowed to say, and how much
 * of the file it may occupy.
 *
 * Separate from `main.js` for one reason — these are the two things about a log
 * worth proving, and `main.js` cannot be unit-tested. `src/lib/startup-log.test.ts`
 * requires this file directly. Plain CommonJS with no Electron import, because
 * the shell runs under Electron's Node before any TypeScript exists.
 *
 * ONE LINE PER LAUNCH. A support person asking "why is her till slow to open"
 * wants the last twenty mornings side by side, not a paragraph each. It also
 * makes the bound honest: `MAX_SESSIONS` is a number of launches, not a number
 * of lines that happens to work out to some number of launches.
 */

/** Roughly a year of openings at a few a day. The file stays under ~40 KB. */
const MAX_SESSIONS = 200

/**
 * The only milestone names that may be written — and the whole privacy
 * guarantee, which is structural rather than a promise to be careful.
 *
 * A caller cannot log a customer name, a product search, an order, a payment or
 * a database record by passing one as a milestone: there is no path from
 * arbitrary text into the file. Anything not on this list is dropped silently
 * rather than sanitised, because a sanitiser is a thing that can be wrong.
 */
const MILESTONES = [
  'app-ready',
  // Not "boot window visible": on a warm attach the Counter finishes loading
  // before the window is shown, so what appears is already the till. The
  // milestone is the moment anything reached the screen, which is what the
  // startup target is actually about.
  'window-visible',
  'server-spawn-requested',
  'health-verified',
  'counter-navigation-started',
  'renderer-dom-ready',
  'app-load-finished',
]

/**
 * The only failure categories that may be written.
 *
 * Closed for the same reason as the milestones. An open `failed:<text>` field
 * would be a free-text channel by the back door — and the text at hand when a
 * launch fails is usually an exception message, which on this platform tends to
 * carry a file path with the operator's name in it.
 */
const FAILURE_CATEGORIES = [
  // The four `judgeHealth` refusals, verbatim.
  'not-the-pos',
  'development',
  'not-ready',
  'unreadable',
  // The shell's own.
  'timeout',
  'navigation-failed',
  'server-exit',
]

/**
 * One launch, as one line.
 *
 * Offsets are whole milliseconds from the session's own start, measured
 * monotonically by the caller — so a clock adjustment mid-boot cannot turn a
 * duration negative. The ISO stamp is only there to say which morning it was.
 */
function formatSession({ startedAtIso, milestones = [], outcome }) {
  const timings = milestones
    .filter((milestone) => MILESTONES.includes(milestone.name))
    .map((milestone) => `${milestone.name}=${Math.round(milestone.at)}`)

  let head
  if (outcome && outcome.ok) {
    head = 'ok'
  } else {
    const category =
      outcome && FAILURE_CATEGORIES.includes(outcome.category) ? outcome.category : 'unknown'
    head = `failed:${category}`
    // A number, and the one piece of failure detail that is safe by its type.
    if (outcome && Number.isInteger(outcome.exitCode)) head += ` exit=${outcome.exitCode}`
  }

  return [startedAtIso, head, ...timings].join(' ')
}

/**
 * The whole file, with the newest launches kept and the oldest dropped.
 *
 * Rewriting the file rather than appending is deliberate: an append-only log on
 * a shop laptop nobody administers grows until somebody notices, and nobody
 * does. Blank lines from an interrupted write are dropped on the way through,
 * so a half-written file heals itself on the next launch instead of slowly
 * filling the budget with nothing.
 */
function trimToBudget(existing, incoming, maxLines = MAX_SESSIONS) {
  const lines = String(existing || '')
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => line !== '')

  lines.push(...incoming)
  return lines.slice(-maxLines).join('\n')
}

module.exports = { MAX_SESSIONS, MILESTONES, FAILURE_CATEGORIES, formatSession, trimToBudget }
