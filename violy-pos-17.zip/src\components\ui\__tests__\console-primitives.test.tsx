// @vitest-environment jsdom

import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { describe, expect, it, vi } from 'vitest'
import { SegmentedControl } from '../SegmentedControl'
import { Tabs } from '../Tabs'

const options = [
  { value: 'customer', label: 'Customer' },
  { value: 'walkin', label: 'Walk-in' },
] as const

describe('SegmentedControl', () => {
  it('exposes options as radios and reports the selected value', async () => {
    const user = userEvent.setup()
    const onValueChange = vi.fn()
    render(
      <SegmentedControl
        options={options}
        value="customer"
        onValueChange={onValueChange}
        ariaLabel="Sale mode"
      />,
    )

    const group = screen.getByRole('radiogroup', { name: 'Sale mode' })
    expect(group).toBeInTheDocument()
    expect(screen.getByRole('radio', { name: 'Customer' })).toBeChecked()

    await user.click(screen.getByRole('radio', { name: 'Walk-in' }))
    expect(onValueChange).toHaveBeenCalledWith('walkin')
  })
})

describe('Tabs', () => {
  it('marks the active tab selected and reports selection', async () => {
    const user = userEvent.setup()
    const onValueChange = vi.fn()
    render(
      <Tabs
        tabs={[
          { value: 'today', label: "Today's orders" },
          { value: 'recent', label: 'Recent sales' },
        ]}
        value="today"
        onValueChange={onValueChange}
        ariaLabel="Rail views"
      />,
    )

    const list = screen.getByRole('tablist', { name: 'Rail views' })
    expect(list).toBeInTheDocument()
    expect(screen.getByRole('tab', { name: "Today's orders" })).toHaveAttribute(
      'aria-selected',
      'true',
    )

    await user.click(screen.getByRole('tab', { name: 'Recent sales' }))
    expect(onValueChange).toHaveBeenCalledWith('recent')
  })
})
