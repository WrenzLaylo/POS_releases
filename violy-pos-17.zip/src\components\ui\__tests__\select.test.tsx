// @vitest-environment jsdom

import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { useState } from 'react'
import { describe, expect, it, vi } from 'vitest'
import { Select } from '../Select'

/** A long, alphabetical-ish option list — the shape of HistoryFilters'
 *  "Customer" filter, which is the concrete reason type-ahead exists.
 *
 *  A plain array of literal `<option>` elements, not a wrapper component:
 *  `Select` reads `props.children` directly (per the design contract, so
 *  every existing caller's `<option>`/`.map()` children keep working
 *  unmodified), and `React.Children.forEach` flattens nested arrays the
 *  same way it flattens a `.map()` call — but it does not descend through
 *  a custom component boundary, the same way a real `<select>` would only
 *  care about the option tags that ultimately render. Matching that shape
 *  here is what makes this fixture representative of HistoryFilters,
 *  ProductForm, and BulkPaymentGrid, which all build their `<option>`s the
 *  same way. */
const customerOptions = [
  <option key="" value="">All customers</option>,
  <option key="1" value="1">Ana Reyes</option>,
  <option key="2" value="2">Ben Santos</option>,
  <option key="3" value="3">MANG KIKO</option>,
  <option key="4" value="4">Maria Cruz</option>,
]

describe('Select', () => {
  it('renders the selected option label on the trigger', () => {
    render(
      <Select aria-label="Customer" defaultValue="2">
        {customerOptions}
      </Select>,
    )
    expect(screen.getByRole('combobox', { name: 'Customer' })).toHaveTextContent('Ben Santos')
  })

  it('opens the listbox on click', async () => {
    const user = userEvent.setup()
    render(
      <Select aria-label="Customer" defaultValue="">
        {customerOptions}
      </Select>,
    )
    expect(screen.queryByRole('listbox')).not.toBeInTheDocument()
    await user.click(screen.getByRole('combobox', { name: 'Customer' }))
    expect(screen.getByRole('listbox')).toBeInTheDocument()
  })

  it('carries role="listbox" on an element in the document while open, which is what CatalogColumn\'s overlay guard keys off', async () => {
    const user = userEvent.setup()
    render(
      <Select aria-label="Customer" defaultValue="">
        {customerOptions}
      </Select>,
    )
    expect(document.querySelector('[role="dialog"], [role="listbox"]')).toBeNull()
    await user.click(screen.getByRole('combobox', { name: 'Customer' }))
    expect(document.querySelector('[role="dialog"], [role="listbox"]')).not.toBeNull()
  })

  it('renders every option from children with role="option" and aria-selected', async () => {
    const user = userEvent.setup()
    render(
      <Select aria-label="Customer" defaultValue="2">
        {customerOptions}
      </Select>,
    )
    await user.click(screen.getByRole('combobox', { name: 'Customer' }))
    const options = screen.getAllByRole('option')
    expect(options).toHaveLength(5)
    expect(options.map((o) => o.textContent)).toEqual([
      'All customers',
      'Ana Reyes',
      'Ben Santos',
      'MANG KIKO',
      'Maria Cruz',
    ])
    expect(options[2]).toHaveAttribute('aria-selected', 'true')
    expect(options[0]).toHaveAttribute('aria-selected', 'false')
  })

  it('moves the active option with the arrow keys without changing the committed selection', async () => {
    const user = userEvent.setup()
    render(
      <Select aria-label="Customer" defaultValue="">
        {customerOptions}
      </Select>,
    )
    const trigger = screen.getByRole('combobox', { name: 'Customer' })
    await user.click(trigger)
    const options = screen.getAllByRole('option')

    // Opening highlights the current selection first.
    expect(trigger).toHaveAttribute('aria-activedescendant', options[0].id)

    await user.keyboard('{ArrowDown}')
    expect(trigger).toHaveAttribute('aria-activedescendant', options[1].id)
    expect(options[1]).toHaveClass('bg-accent-soft')
    expect(options[0]).not.toHaveClass('bg-accent-soft')

    await user.keyboard('{ArrowDown}')
    expect(trigger).toHaveAttribute('aria-activedescendant', options[2].id)

    await user.keyboard('{ArrowUp}')
    expect(trigger).toHaveAttribute('aria-activedescendant', options[1].id)

    // Arrow movement alone never commits — aria-selected still marks "".
    expect(options[0]).toHaveAttribute('aria-selected', 'true')
  })

  it('selects the active option on Enter, fires onChange with its value, and closes', async () => {
    const user = userEvent.setup()
    const onChange = vi.fn()
    render(
      <Select aria-label="Customer" defaultValue="" onChange={onChange}>
        {customerOptions}
      </Select>,
    )
    const trigger = screen.getByRole('combobox', { name: 'Customer' })
    await user.click(trigger)
    await user.keyboard('{ArrowDown}{ArrowDown}{Enter}')

    expect(onChange).toHaveBeenCalledTimes(1)
    expect(onChange.mock.calls[0][0].target.value).toBe('2')
    expect(screen.queryByRole('listbox')).not.toBeInTheDocument()
    expect(trigger).toHaveTextContent('Ben Santos')
  })

  it('selects the active option on Space too', async () => {
    const user = userEvent.setup()
    const onChange = vi.fn()
    render(
      <Select aria-label="Customer" defaultValue="" onChange={onChange}>
        {customerOptions}
      </Select>,
    )
    await user.click(screen.getByRole('combobox', { name: 'Customer' }))
    await user.keyboard('{ArrowDown}{ArrowDown}{ArrowDown} ')
    expect(onChange).toHaveBeenCalledTimes(1)
    expect(onChange.mock.calls[0][0].target.value).toBe('3')
  })

  it('jumps to first/last with Home and End', async () => {
    const user = userEvent.setup()
    render(
      <Select aria-label="Customer" defaultValue="2">
        {customerOptions}
      </Select>,
    )
    const trigger = screen.getByRole('combobox', { name: 'Customer' })
    await user.click(trigger)
    const options = screen.getAllByRole('option')

    await user.keyboard('{End}')
    expect(trigger).toHaveAttribute('aria-activedescendant', options[options.length - 1].id)

    await user.keyboard('{Home}')
    expect(trigger).toHaveAttribute('aria-activedescendant', options[0].id)
  })

  it('closes on Escape and restores focus to the trigger', async () => {
    const user = userEvent.setup()
    render(
      <Select aria-label="Customer" defaultValue="">
        {customerOptions}
      </Select>,
    )
    const trigger = screen.getByRole('combobox', { name: 'Customer' })
    await user.click(trigger)
    expect(screen.getByRole('listbox')).toBeInTheDocument()

    await user.keyboard('{Escape}')
    expect(screen.queryByRole('listbox')).not.toBeInTheDocument()
    expect(trigger).toHaveFocus()
  })

  it('closes on an outside pointer-down', async () => {
    const user = userEvent.setup()
    render(
      <div>
        <Select aria-label="Customer" defaultValue="">
          {customerOptions}
        </Select>
        <button type="button">Outside</button>
      </div>,
    )
    await user.click(screen.getByRole('combobox', { name: 'Customer' }))
    expect(screen.getByRole('listbox')).toBeInTheDocument()

    await user.click(screen.getByRole('button', { name: 'Outside' }))
    expect(screen.queryByRole('listbox')).not.toBeInTheDocument()
  })

  it('jumps to the next option whose label starts with a typed letter — the customer-picker requirement', async () => {
    const user = userEvent.setup()
    render(
      <Select aria-label="Customer" defaultValue="">
        {customerOptions}
      </Select>,
    )
    const trigger = screen.getByRole('combobox', { name: 'Customer' })
    await user.click(trigger)
    const options = screen.getAllByRole('option')

    await user.keyboard('m')
    expect(trigger).toHaveAttribute('aria-activedescendant', options[3].id) // MANG KIKO

    await user.keyboard('m')
    expect(trigger).toHaveAttribute('aria-activedescendant', options[4].id) // Maria Cruz
  })

  it('holds the same value/onChange contract BulkPaymentGrid relies on: event.target.value is the selected value string', async () => {
    function Harness() {
      const [value, setValue] = useState('')
      return (
        <Select aria-label="Row customer" value={value} onChange={(e) => setValue(e.target.value)}>
          {customerOptions}
        </Select>
      )
    }
    const user = userEvent.setup()
    render(<Harness />)
    const trigger = screen.getByRole('combobox', { name: 'Row customer' })
    await user.click(trigger)
    await user.click(screen.getByRole('option', { name: 'Ana Reyes' }))
    expect(trigger).toHaveTextContent('Ana Reyes')
  })

  it('renders a hidden native input carrying the value when name is set, so HistoryFilters-style plain forms still submit it', () => {
    const { container } = render(
      <form>
        <Select aria-label="Status" name="status" defaultValue="paid">
          <option value="all">All</option>
          <option value="paid">Paid</option>
          <option value="unpaid">Unpaid</option>
        </Select>
      </form>,
    )
    const hidden = container.querySelector('input[name="status"]') as HTMLInputElement | null
    expect(hidden).not.toBeNull()
    expect(hidden?.type).toBe('hidden')
    expect(hidden?.value).toBe('paid')
  })

  it('keeps the hidden input in sync after a selection, matching a ProductForm-style action={fn} form', async () => {
    const user = userEvent.setup()
    const { container } = render(
      <form>
        <Select aria-label="Status" name="status" defaultValue="all">
          <option value="all">All</option>
          <option value="paid">Paid</option>
          <option value="unpaid">Unpaid</option>
        </Select>
      </form>,
    )
    await user.click(screen.getByRole('combobox', { name: 'Status' }))
    await user.click(screen.getByRole('option', { name: 'Paid' }))
    const hidden = container.querySelector('input[name="status"]') as HTMLInputElement | null
    expect(hidden?.value).toBe('paid')
  })

  it('does not render a hidden input when no name is given, matching BulkPaymentGrid', () => {
    const { container } = render(
      <Select aria-label="Row customer" value="" onChange={() => {}}>
        {customerOptions}
      </Select>,
    )
    expect(container.querySelector('input[type="hidden"]')).toBeNull()
  })

  it('gives Select the same keyboard focus treatment as Input (primitives.test.tsx pins this by role)', () => {
    render(
      <Select aria-label="Category">
        <option>All</option>
      </Select>,
    )
    expect(screen.getByRole('combobox', { name: 'Category' })).toHaveClass(
      'focus:ring-2',
      'focus:ring-accent',
      'focus:ring-offset-2',
    )
  })
})
