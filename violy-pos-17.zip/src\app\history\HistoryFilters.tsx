import { Button } from '@/components/ui/Button'
import { Field } from '@/components/ui/Field'
import { Input } from '@/components/ui/Input'
import { Select } from '@/components/ui/Select'

/** A plain GET form: submitting puts the filters in the URL, which is what
 *  makes back and refresh behave. Resetting `page` on submit matters — page 4
 *  of an old filter is meaningless under a new one.
 *
 *  `customers` must include archived customers — otherwise filtering to
 *  `?customer=<archived id>` shows the browser's default "All customers"
 *  selection while the results below are actually filtered, silently
 *  contradicting itself. */
export function HistoryFilters({
  customers,
  categories,
  from,
  to,
  customer,
  status,
  category,
  kind,
}: {
  customers: { id: number; name: string; isArchived: boolean }[]
  categories: { id: number; name: string }[]
  from?: string
  to?: string
  customer?: string
  status?: string
  category?: string
  kind?: string
}) {
  return (
    <form className="flex flex-wrap items-end gap-3">
      <input type="hidden" name="page" value="1" />

      <Field label="From">
        <Input type="date" name="from" defaultValue={from ?? ''} className="w-40" />
      </Field>

      <Field label="To">
        <Input type="date" name="to" defaultValue={to ?? ''} className="w-40" />
      </Field>

      <Field label="Customer">
        <Select name="customer" defaultValue={customer ?? ''} className="w-56">
          <option value="">All customers</option>
          <option value="walkin">Walk-in</option>
          {customers.map((c) => (
            <option key={c.id} value={String(c.id)}>
              {c.name}
              {c.isArchived ? ' (archived)' : ''}
            </option>
          ))}
        </Select>
      </Field>

      {/* Selects, not the chips the Stock screen uses, and deliberately so:
          this is a form you fill in and submit, and the brand list is one more
          field in it. Chips would mean a client component navigating on every
          tap, which would also cost this form the plain GET behaviour that
          makes back and refresh work. */}
      <Field label="Brand">
        <Select name="category" defaultValue={category ?? ''} className="w-48">
          <option value="">All brands</option>
          {categories.map((c) => (
            <option key={c.id} value={String(c.id)}>
              {c.name}
            </option>
          ))}
        </Select>
      </Field>

      <Field label="Status">
        <Select name="status" defaultValue={status ?? 'all'} className="w-40">
          <option value="all">All</option>
          <option value="cash">Cash sale</option>
          <option value="credit">Full credit</option>
          <option value="partial">Partial cash + credit</option>
          <option value="voided">Voided</option>
        </Select>
      </Field>

      {/* Its own control rather than another option in Status, and that is
          not tidiness. Status is how a sale was PAID, and a delivery order is
          paid like any other — cash, credit or partial. Folding "Deliveries"
          into that list would make two unrelated questions share one field
          and silently make them mutually exclusive, so "which deliveries went
          on utang" would stop being askable. */}
      <Field label="Kind">
        <Select name="kind" defaultValue={kind ?? 'all'} className="w-40">
          <option value="all">All sales</option>
          <option value="counter">Counter sales</option>
          <option value="delivery">Deliveries</option>
        </Select>
      </Field>

      <Button type="submit" variant="primary" size="wide">
        Filter
      </Button>
    </form>
  )
}
