import { describe, expect, it, vi } from 'vitest'
import { balanceDelta, sumBalance } from '@/lib/ledger-balance'

describe('ledger balance arithmetic', () => {
  it('adds charges and openings, subtracts payments, and ignores voids', () => {
    expect(
      sumBalance([
        { id: 1, type: 'OPENING', amountCentavos: 10000, isVoided: false },
        { id: 2, type: 'CHARGE', amountCentavos: 5000, isVoided: false },
        { id: 3, type: 'PAYMENT', amountCentavos: 4000, isVoided: false },
        { id: 4, type: 'CHARGE', amountCentavos: 999999, isVoided: true },
      ]),
    ).toBe(11000)
  })

  it('excludes and reports an unknown stored type instead of inflating debt', () => {
    const error = vi.spyOn(console, 'error').mockImplementation(() => undefined)

    expect(balanceDelta({ id: 9, type: 'BROKEN', amountCentavos: 5000, isVoided: false })).toBe(0)
    expect(error).toHaveBeenCalledWith(expect.stringContaining('BROKEN'))

    error.mockRestore()
  })
})
