import type { ReactNode } from 'react'
import { cn } from '@/lib/cn'

/** A form-level error message — one treatment used everywhere a save/void/
 *  submit can fail, so "errors fade in rather than appearing abruptly"
 *  holds on every screen instead of half of them. */
export function FormError({
  className,
  live = 'assertive',
  children,
}: {
  className?: string
  /**
   * `assertive` is the default because 38 of the 40 uses of this component are
   * `{error && …}` — a sale, a payment or a void that has just FAILED. That is
   * the definition of something needing attention before the next action: the
   * operator is about to hand over sacks on the strength of a save that did not
   * happen. None of it was announced to anybody before.
   *
   * The other two are inline validation that renders WHILE SHE TYPES ("Enter an
   * amount like 50 or 1,000"). Assertive there would interrupt on every
   * keystroke that leaves the field momentarily invalid, which is how a screen
   * reader user learns to turn the app off. Those pass `polite`.
   */
  live?: 'assertive' | 'polite'
  children: ReactNode
}) {
  return (
    // Conditionally MOUNTED rather than emptied at every call site above, so
    // the insertion is what fires the announcement.
    <p
      role={live === 'assertive' ? 'alert' : 'status'}
      className={cn('animate-fade-in text-sm text-owed', className)}
    >
      {children}
    </p>
  )
}
