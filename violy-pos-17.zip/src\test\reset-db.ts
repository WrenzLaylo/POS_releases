import { prisma } from '@/lib/db'

/**
 * Wipes all tables, children before parents so the foreign keys hold.
 * Test files that need a clean database call this in their own `beforeEach`.
 * It is deliberately explicit rather than a global hook: `prisma/seed.test.ts`
 * seeds once in `beforeAll` and must not be wiped between assertions.
 * `Customer` is last because both `Sale` and `LedgerEntry` reference it.
 * `LedgerEntry` goes before `UtangPlan` for the same reason: entries carry an
 * optional `planId`, and the delivery tables go before `Product` because
 * `DeliveryItem` references it with ON DELETE RESTRICT.
 *
 * This function and `prisma/seed.ts`'s own teardown must stay in step. They
 * have drifted before: `seed.ts` was missing `UtangPlan`, and the symptom was
 * an unrelated suite failing about one run in three.
 */
export async function resetDb(): Promise<void> {
  await prisma.ledgerEntryRevision.deleteMany()
  await prisma.ledgerEntry.deleteMany()
  await prisma.utangInstallment.deleteMany()
  await prisma.utangPlan.deleteMany()
  // Before Product: DeliveryItem references it with ON DELETE RESTRICT, so
  // leaving these behind makes `product.deleteMany()` fail on a foreign key
  // rather than anything that names the real cause.
  await prisma.deliveryItem.deleteMany()
  await prisma.delivery.deleteMany()
  await prisma.supplier.deleteMany()
  await prisma.stockMovement.deleteMany()
  await prisma.saleItem.deleteMany()
  await prisma.sale.deleteMany()
  await prisma.product.deleteMany()
  await prisma.category.deleteMany()
  await prisma.customer.deleteMany()
  // The login tables. Sessions and codes cascade from AppUser, but they are
  // named explicitly so a test that creates one without the other still starts
  // clean — and so this list keeps reading as "every table", which is the only
  // way it stays correct as the schema grows.
  await prisma.appSession.deleteMany()
  await prisma.recoveryCode.deleteMany()
  await prisma.resetRequest.deleteMany()
  await prisma.appUser.deleteMany()
}
