import { beforeEach, describe, expect, it } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'
import {
  createDelivery,
  getDelivery,
  listDeliveries,
  payDelivery,
  totalPayable,
  voidDelivery,
} from '@/server/deliveries'
import {
  archiveSupplier,
  createSupplier,
  listSuppliers,
  restoreSupplier,
  updateSupplier,
} from '@/server/suppliers'
import { createSale } from '@/server/sales'

beforeEach(resetDb)

async function supplier(name = 'Bataan Farmers Center') {
  const result = await createSupplier({ name })
  if (!result.ok) throw new Error(result.error)
  return result.data.id
}

async function product(name = 'Hog Grower', stockQty = 0, costPrice = 0) {
  const category = await prisma.category.upsert({
    where: { name: 'Pig Feeds' },
    create: { name: 'Pig Feeds' },
    update: {},
  })
  return prisma.product.create({
    data: {
      categoryId: category.id,
      name,
      unit: 'bag (50kg)',
      price: 200_000,
      costPrice,
      stockQty,
      lowStockThreshold: 5,
    },
  })
}

let keyCounter = 0
function key(): string {
  keyCounter += 1
  return `delivery-test-key-${keyCounter}`
}

async function receive(
  supplierId: number,
  lines: { productId: number; quantity: number; unitCostCentavos: number }[],
  overrides: Partial<{
    amountPaidCentavos: number
    receivedAt: Date
    clientKey: string
    terms: 'OUTRIGHT' | 'CONSIGNMENT'
  }> = {},
) {
  return createDelivery({
    supplierId,
    terms: overrides.terms ?? 'OUTRIGHT',
    receivedAt: overrides.receivedAt ?? new Date(2026, 7, 17),
    reference: 'DR-1',
    note: '',
    lines,
    amountPaidCentavos: overrides.amountPaidCentavos ?? 0,
    clientKey: overrides.clientKey ?? key(),
  })
}

describe('suppliers', () => {
  it('refuses a duplicate name whatever the casing', async () => {
    await supplier('Bataan Farmers Center')
    for (const name of ['Bataan Farmers Center', 'bataan farmers center', '  BATAAN FARMERS CENTER ']) {
      const again = await createSupplier({ name })
      expect(again.ok, name).toBe(false)
    }
    expect(await prisma.supplier.count()).toBe(1)
  })

  it('points at an archived supplier rather than letting a second one be made', async () => {
    const id = await supplier()
    expect((await archiveSupplier(id)).ok).toBe(true)

    const again = await createSupplier({ name: 'bataan farmers center' })
    expect(again.ok).toBe(false)
    if (again.ok) return
    expect(again.error).toMatch(/archived/i)
  })

  it('refuses to rename one supplier onto another, but allows saving its own name', async () => {
    const first = await supplier('Alpha Feeds')
    const second = await supplier('Beta Feeds')

    expect((await updateSupplier(second, { name: 'alpha feeds' })).ok).toBe(false)
    expect((await updateSupplier(second, { name: 'Beta Feeds', contactNumber: '0917' })).ok).toBe(true)
    expect(first).not.toBe(second)
  })

  it('will not archive a supplier that is still owed money', async () => {
    // Archiving hides it from the payables list. A debt that disappears
    // because somebody tidied up is not found until the supplier asks.
    const supplierId = await supplier()
    const sack = await product()
    await receive(supplierId, [{ productId: sack.id, quantity: 10, unitCostCentavos: 180_000 }])

    const blocked = await archiveSupplier(supplierId)
    expect(blocked.ok).toBe(false)
    if (blocked.ok) return
    expect(blocked.error).toMatch(/unpaid/i)
  })

  it('allows archiving once everything is settled', async () => {
    const supplierId = await supplier()
    const sack = await product()
    const received = await receive(
      supplierId,
      [{ productId: sack.id, quantity: 10, unitCostCentavos: 180_000 }],
      { amountPaidCentavos: 1_800_000 },
    )
    expect(received.ok).toBe(true)

    expect((await archiveSupplier(supplierId)).ok).toBe(true)
    expect((await listSuppliers()).map((s) => s.name)).toEqual([])
    expect((await listSuppliers(true)).map((s) => s.name)).toHaveLength(1)
    expect((await restoreSupplier(supplierId)).ok).toBe(true)
    expect(await listSuppliers()).toHaveLength(1)
  })
})

describe('receiving a delivery', () => {
  it('raises stock, sets the cost, and records what it was', async () => {
    const supplierId = await supplier()
    const sack = await product('Hog Grower', 3, 0)

    const result = await receive(supplierId, [
      { productId: sack.id, quantity: 20, unitCostCentavos: 180_000 },
    ])
    expect(result.ok).toBe(true)

    const after = await prisma.product.findUnique({ where: { id: sack.id } })
    expect(after!.stockQty).toBe(23)
    // The whole point: cost stops being a number somebody has to maintain by
    // hand and becomes what was actually paid.
    expect(after!.costPrice).toBe(180_000)

    const movements = await prisma.stockMovement.findMany({ where: { productId: sack.id } })
    expect(movements).toHaveLength(1)
    expect(movements[0].type).toBe('DELIVERY')
    expect(movements[0].quantity).toBe(20)
  })

  it('computes the total from the lines rather than trusting the caller', async () => {
    const supplierId = await supplier()
    const a = await product('Hog Grower')
    const b = await product('Hog Starter')

    const result = await receive(supplierId, [
      { productId: a.id, quantity: 20, unitCostCentavos: 180_000 },
      { productId: b.id, quantity: 5, unitCostCentavos: 200_000 },
    ])
    expect(result.ok).toBe(true)
    if (!result.ok) return

    const detail = await getDelivery(result.data.id)
    expect(detail!.totalCostCentavos).toBe(20 * 180_000 + 5 * 200_000)
    expect(detail!.outstandingCentavos).toBe(detail!.totalCostCentavos)
    expect(detail!.lines).toHaveLength(2)
  })

  it('saves once when the same key arrives twice', async () => {
    // A delivery raises stock and rewrites a cost. Saving it twice inflates
    // inventory silently, which is harder to notice than a duplicate sale.
    const supplierId = await supplier()
    const sack = await product()
    const clientKey = 'a-repeated-delivery-key'

    const first = await receive(
      supplierId,
      [{ productId: sack.id, quantity: 20, unitCostCentavos: 180_000 }],
      { clientKey },
    )
    const second = await receive(
      supplierId,
      [{ productId: sack.id, quantity: 20, unitCostCentavos: 180_000 }],
      { clientKey },
    )

    expect(first.ok && second.ok).toBe(true)
    if (!first.ok || !second.ok) return
    expect(second.data.id).toBe(first.data.id)
    expect(await prisma.delivery.count()).toBe(1)
    expect((await prisma.product.findUnique({ where: { id: sack.id } }))!.stockQty).toBe(20)
  })

  it('writes nothing at all when one line is bad', async () => {
    const supplierId = await supplier()
    const a = await product('Hog Grower')
    const b = await product('Hog Starter')

    const result = await receive(supplierId, [
      { productId: a.id, quantity: 20, unitCostCentavos: 180_000 },
      { productId: b.id, quantity: 0, unitCostCentavos: 200_000 },
    ])

    expect(result.ok).toBe(false)
    expect(await prisma.delivery.count()).toBe(0)
    expect(await prisma.stockMovement.count()).toBe(0)
    expect((await prisma.product.findUnique({ where: { id: a.id } }))!.stockQty).toBe(0)
  })

  it('refuses an archived supplier', async () => {
    const supplierId = await supplier()
    const sack = await product()
    await archiveSupplier(supplierId)

    const result = await receive(supplierId, [
      { productId: sack.id, quantity: 1, unitCostCentavos: 100 },
    ])
    expect(result.ok).toBe(false)
    if (result.ok) return
    expect(result.error).toMatch(/archived/i)
  })

  it('refuses an archived product rather than quietly reviving it', async () => {
    const supplierId = await supplier()
    const sack = await product()
    await prisma.product.update({ where: { id: sack.id }, data: { isArchived: true } })

    const result = await receive(supplierId, [
      { productId: sack.id, quantity: 1, unitCostCentavos: 100 },
    ])
    expect(result.ok).toBe(false)
    expect(await prisma.delivery.count()).toBe(0)
  })

  it('refuses a supplier that does not exist', async () => {
    const sack = await product()
    const result = await receive(9_999, [
      { productId: sack.id, quantity: 1, unitCostCentavos: 100 },
    ])
    expect(result.ok).toBe(false)
  })
})

describe('paying a supplier', () => {
  it('reduces what is outstanding, and refuses more than is owed', async () => {
    const supplierId = await supplier()
    const sack = await product()
    const received = await receive(supplierId, [
      { productId: sack.id, quantity: 10, unitCostCentavos: 180_000 },
    ])
    expect(received.ok).toBe(true)
    if (!received.ok) return
    const id = received.data.id

    expect((await payDelivery(id, 800_000)).ok).toBe(true)
    expect((await getDelivery(id))!.outstandingCentavos).toBe(1_000_000)

    const tooMuch = await payDelivery(id, 1_000_001)
    expect(tooMuch.ok).toBe(false)

    expect((await payDelivery(id, 1_000_000)).ok).toBe(true)
    expect((await getDelivery(id))!.outstandingCentavos).toBe(0)

    // Nothing left to pay.
    expect((await payDelivery(id, 1)).ok).toBe(false)
  })

  it.each([0, -1, 100.5])('refuses an amount of %s', async (amount) => {
    const supplierId = await supplier()
    const sack = await product()
    const received = await receive(supplierId, [
      { productId: sack.id, quantity: 1, unitCostCentavos: 100_000 },
    ])
    if (!received.ok) throw new Error(received.error)
    expect((await payDelivery(received.data.id, amount)).ok).toBe(false)
  })

  it('refuses to pay a voided delivery', async () => {
    const supplierId = await supplier()
    const sack = await product()
    const received = await receive(supplierId, [
      { productId: sack.id, quantity: 1, unitCostCentavos: 100_000 },
    ])
    if (!received.ok) throw new Error(received.error)
    await voidDelivery(received.data.id, 'Entered twice')

    expect((await payDelivery(received.data.id, 100)).ok).toBe(false)
  })
})

describe('what the shop owes its suppliers', () => {
  it('sums the unsettled consignments and ignores voided ones', async () => {
    const supplierId = await supplier()
    const sack = await product()

    await receive(supplierId, [{ productId: sack.id, quantity: 10, unitCostCentavos: 100_000 }])
    await receive(
      supplierId,
      [{ productId: sack.id, quantity: 10, unitCostCentavos: 100_000 }],
      { amountPaidCentavos: 400_000 },
    )
    const third = await receive(supplierId, [
      { productId: sack.id, quantity: 10, unitCostCentavos: 100_000 },
    ])
    if (!third.ok) throw new Error(third.error)

    // 1,000,000 + 600,000 + 1,000,000
    expect(await totalPayable()).toBe(2_600_000)

    await voidDelivery(third.data.id, 'Duplicate paperwork')
    expect(await totalPayable()).toBe(1_600_000)
  })

  it('lists only the unpaid ones when asked', async () => {
    const supplierId = await supplier()
    const sack = await product()
    await receive(
      supplierId,
      [{ productId: sack.id, quantity: 1, unitCostCentavos: 100_000 }],
      { amountPaidCentavos: 100_000 },
    )
    await receive(supplierId, [{ productId: sack.id, quantity: 1, unitCostCentavos: 100_000 }])

    expect((await listDeliveries({}, 1)).total).toBe(2)
    expect((await listDeliveries({ unpaidOnly: true }, 1)).total).toBe(1)
  })
})

describe('voiding a delivery', () => {
  it('takes the stock back off and says why on the stock card', async () => {
    const supplierId = await supplier()
    const sack = await product('Hog Grower', 3)
    const received = await receive(supplierId, [
      { productId: sack.id, quantity: 20, unitCostCentavos: 180_000 },
    ])
    if (!received.ok) throw new Error(received.error)

    expect((await voidDelivery(received.data.id, 'Entered twice')).ok).toBe(true)

    expect((await prisma.product.findUnique({ where: { id: sack.id } }))!.stockQty).toBe(3)
    const movements = await prisma.stockMovement.findMany({
      where: { productId: sack.id },
      orderBy: { id: 'asc' },
    })
    expect(movements.map((m) => m.type)).toEqual(['DELIVERY', 'VOID'])
    expect(movements[1].quantity).toBe(-20)
    expect(movements[1].note).toMatch(/Entered twice/)
  })

  it('refuses without a reason, and refuses twice', async () => {
    const supplierId = await supplier()
    const sack = await product()
    const received = await receive(supplierId, [
      { productId: sack.id, quantity: 1, unitCostCentavos: 100_000 },
    ])
    if (!received.ok) throw new Error(received.error)

    expect((await voidDelivery(received.data.id, '   ')).ok).toBe(false)
    expect((await voidDelivery(received.data.id, 'Wrong supplier')).ok).toBe(true)
    expect((await voidDelivery(received.data.id, 'Again')).ok).toBe(false)
  })

  it('restores the cost from the delivery that is still standing, not the voided one', async () => {
    // The trap this exists for: voiding an OLDER delivery must not undo the
    // price a newer one set.
    const supplierId = await supplier()
    const sack = await product()

    const older = await receive(
      supplierId,
      [{ productId: sack.id, quantity: 10, unitCostCentavos: 180_000 }],
      { receivedAt: new Date(2026, 6, 1) },
    )
    await receive(
      supplierId,
      [{ productId: sack.id, quantity: 10, unitCostCentavos: 190_000 }],
      { receivedAt: new Date(2026, 7, 1) },
    )
    if (!older.ok) throw new Error(older.error)

    expect((await prisma.product.findUnique({ where: { id: sack.id } }))!.costPrice).toBe(190_000)

    await voidDelivery(older.data.id, 'Never actually arrived')

    // Still the newer price, not rolled back to 180,000 and not to zero.
    expect((await prisma.product.findUnique({ where: { id: sack.id } }))!.costPrice).toBe(190_000)
  })

  it('leaves a hand-entered cost alone when no delivery is left', async () => {
    // A cost typed on the Stock screen was never this delivery's to set, so
    // voiding must not zero it.
    const supplierId = await supplier()
    const sack = await product('Hog Grower', 0, 175_000)
    const received = await receive(supplierId, [
      { productId: sack.id, quantity: 10, unitCostCentavos: 180_000 },
    ])
    if (!received.ok) throw new Error(received.error)

    await voidDelivery(received.data.id, 'Wrong product')
    expect((await prisma.product.findUnique({ where: { id: sack.id } }))!.costPrice).toBe(180_000)
  })

  it('lets stock go negative rather than blocking a correction', async () => {
    // The sacks may already have been sold. Refusing here would leave a
    // known-wrong delivery on file, which is worse than a negative count the
    // counter already permits.
    const supplierId = await supplier()
    const sack = await product()
    const received = await receive(supplierId, [
      { productId: sack.id, quantity: 10, unitCostCentavos: 180_000 },
    ])
    if (!received.ok) throw new Error(received.error)

    const sold = await createSale({
      items: [{ productId: sack.id, quantity: 8 }],
      cashTenderedCentavos: null,
      clientOrderKey: 'sold-before-the-void',
    })
    expect(sold.ok).toBe(true)

    expect((await voidDelivery(received.data.id, 'Never arrived')).ok).toBe(true)
    expect((await prisma.product.findUnique({ where: { id: sack.id } }))!.stockQty).toBe(-8)
  })
})
