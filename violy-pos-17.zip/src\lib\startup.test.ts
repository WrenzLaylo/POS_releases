import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { describe, expect, it } from 'vitest'
import { ROUTES } from './routes'

/**
 * `electron/main.js` cannot import anything from `src/` — it runs under
 * Electron's Node before any TypeScript exists — so the boot path is guarded
 * the way the health check is: by reading the file and asserting the shape.
 * This is the tripwire on the parallel boot quietly going back to being
 * sequential, and on the route literal in there drifting from `routes.ts`.
 */
const mainSource = readFileSync(join(process.cwd(), 'electron', 'main.js'), 'utf8')
const bootSource = readFileSync(join(process.cwd(), 'electron', 'boot.html'), 'utf8')

/**
 * Both files are heavily commented, and the comments describe the very things
 * these tests assert are absent — "not awaited", "no progress to report". A
 * check run against the raw text reads its own explanation and fails. Asserting
 * on code means removing the prose first.
 *
 * The `[^:]` guard on the line-comment rule is what stops `http://localhost`
 * being eaten as one.
 */
function stripComments(source: string): string {
  return source
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/<!--[\s\S]*?-->/g, '')
    .replace(/(^|[^:])\/\/.*$/gm, '$1')
}

const main = stripComments(mainSource)
const boot = stripComments(bootSource)

describe('the desktop shell opens one window, immediately', () => {
  /**
   * The whole defect. Two windows meant the app appeared to start twice, and
   * meant Chromium was not asked for a window until the server was already up
   * — so nothing was on screen for the first second or more.
   */
  it('constructs exactly one BrowserWindow', () => {
    expect(main.match(/new BrowserWindow\(/g) ?? []).toHaveLength(1)
  })

  it('has no splash window left to destroy', () => {
    expect(main).not.toMatch(/createSplash/)
    expect(main).not.toMatch(/splashWindow/)
    expect(existsSync(join(process.cwd(), 'electron', 'splash.html'))).toBe(false)
  })

  it('creates the window before it waits for anything', () => {
    // `createMainWindow()` must not be preceded by an await on the server
    // coming up, which is exactly what the old lifecycle did.
    const ready = main.slice(main.indexOf('app.whenReady()'))
    const createsAt = ready.indexOf('createMainWindow()')
    const bootsAt = ready.indexOf('bootSequence()')
    expect(createsAt).toBeGreaterThan(-1)
    expect(bootsAt).toBeGreaterThan(createsAt)
    expect(ready.slice(0, createsAt)).not.toMatch(/\bawait\b/)
  })

  it('shows a local boot document rather than a remote one', () => {
    expect(main).toContain("loadFile(path.join(__dirname, 'boot.html'))")
  })
})

describe('it goes straight to the Counter', () => {
  /**
   * The drift guard, and the reason a route literal is tolerable in this one
   * file: it is asserted against the single place route strings are allowed to
   * live. Renaming `ROUTES.counter` fails here rather than silently leaving the
   * shell pointed at a route that no longer exists — which is exactly how
   * `revalidatePath('/pos')` survived twice in this repo's history.
   */
  it('targets the same path routes.ts calls the counter', () => {
    expect(main).toContain(`const COUNTER_PATH = '${ROUTES.counter}'`)
    expect(main).toContain('`${URL}${COUNTER_PATH}`')
  })

  it('no longer loads the root and takes the redirect', () => {
    expect(main).not.toMatch(/loadURL\(URL\)/)
  })
})

describe('a failed boot can be recovered from', () => {
  it('offers retry and exit while booting', () => {
    expect(main).toContain("ipcMain.handle('violy:boot-retry'")
    expect(main).toContain("ipcMain.handle('violy:boot-exit'")
  })

  /**
   * The capability is temporary on purpose: a bridge that can quit the app is
   * one that can quit it mid-sale. It exists only while the till is not open.
   */
  it('takes those handlers away once the Counter is up', () => {
    expect(main).toContain("ipcMain.removeHandler('violy:boot-retry')")
    expect(main).toContain("ipcMain.removeHandler('violy:boot-exit')")
    expect(main).toMatch(/function afterFirstBoot\(\)\s*{\s*releaseBootControls\(\)/)
  })
})

describe('the boot document', () => {
  /**
   * It exists to paint on the first frame. Anything it had to fetch — a font, a
   * stylesheet, an icon from a CDN — would defeat the entire point of creating
   * the window early.
   */
  it('fetches nothing over the network', () => {
    expect(boot).not.toMatch(/(?:src|href)\s*=\s*["']https?:/i)
    expect(boot).not.toMatch(/@import/i)
    expect(boot).not.toMatch(/url\(\s*["']?https?:/i)
  })

  it('announces its status rather than only showing it', () => {
    expect(boot).toMatch(/role="status"/)
    expect(boot).toMatch(/aria-live="polite"/)
    expect(boot).toMatch(/role="alert"/)
  })

  it('honours reduced motion', () => {
    expect(boot).toMatch(/prefers-reduced-motion/)
  })

  it('shows no progress it cannot measure', () => {
    // An indeterminate bar is honest about a server boot with no milestones to
    // report. These are the two ways a document claims otherwise.
    expect(boot).not.toMatch(/<progress/i)
    expect(boot).not.toMatch(/aria-valuenow/i)
  })

  it('uses the app canvas so the transition cannot flash white', () => {
    expect(boot).toContain('#f4f0e6')
    expect(main).toContain("backgroundColor: '#f4f0e6'")
  })
})

describe('startup instrumentation', () => {
  it('never blocks the boot on a disk write', () => {
    // Every call site discards the promise rather than awaiting it.
    const calls = main.match(/(?:await |void )writeStartupLog\(/g) ?? []
    expect(calls.length).toBeGreaterThan(0)
    expect(calls.every((call) => call.startsWith('void '))).toBe(true)
  })

  it('measures with a monotonic clock', () => {
    // Date.now() can move backwards mid-boot and yield a negative duration.
    expect(main).toContain('performance.now()')
    expect(main).not.toMatch(/at: Date\.now\(\)/)
  })
})
