import { cn } from '@/lib/cn'
import { formatPeso } from '@/lib/money'
import { balanceTone, type MoneyTone } from '@/lib/money-display'

type Scale = 'hero' | 'strong' | 'body'

/**
 * `text-lg` appears here and NOWHERE else in the app. The previous spec
 * retired it as a touch-target-derived size for text read while working, on
 * a laptop with no touchscreen. It returns only as typographic emphasis on
 * numerals, scoped to this component. It is not available for prose,
 * headings, labels, or controls. See the redesign spec §2.2.
 */
const SCALES: Record<Scale, string> = {
  hero: 'text-4xl font-semibold tracking-tight',
  strong: 'text-lg font-medium',
  body: 'text-sm',
}

const TONES: Record<MoneyTone, string> = {
  owed: 'text-owed',
  in: 'text-money-in',
  zero: 'text-ink-subtle',
  neutral: 'text-ink',
}

export function Money({
  centavos,
  scale = 'body',
  tone = 'neutral',
  className,
}: {
  centavos: number
  scale?: Scale
  /** `'balance'` derives the tone from the sign via `balanceTone`. Anything
   *  else is stated outright, because sign alone cannot distinguish a debt
   *  from a receipt. */
  tone?: MoneyTone | 'balance'
  className?: string
}) {
  const resolved = tone === 'balance' ? balanceTone(centavos) : tone

  return (
    <span
      className={cn('font-mono tabular-nums', SCALES[scale], TONES[resolved], className)}
    >
      {formatPeso(centavos)}
    </span>
  )
}
