/**
 * The only bridge between the page and the desktop shell.
 *
 * `contextIsolation` is on and `nodeIntegration` off, which is what makes a
 * local web page safe to render in a window that can also write files. Nothing
 * from Node leaks across — the page gets exactly the two functions below and
 * no way to reach anything else.
 *
 * `savePdf` is here rather than in the page because a browser cannot write a
 * file to a chosen folder, and "Print → Destination → Save as PDF → pick a
 * folder → Save" is five steps and a dialog she does not read. In the shell it
 * is one press.
 *
 * `isDesktop` exists so the page can tell which of the two it is running in:
 * the Download button appears only where it can actually download. In an
 * ordinary browser tab the page falls back to Print, and does not offer a
 * button that would quietly do something else.
 */

const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('violyDesktop', {
  isDesktop: true,

  /**
   * Renders the CURRENT page to a PDF and saves it.
   *
   * @param {{ fileName: string, paper: 'a4' | 'roll' }} options
   * @returns {Promise<{ ok: true, path: string } | { ok: false, error: string }>}
   */
  savePdf: (options) => ipcRenderer.invoke('violy:save-pdf', options),

  /**
   * The printers Windows knows about, so Settings can offer a real list
   * rather than asking her to type a device name.
   *
   * @returns {Promise<{ name: string, displayName: string, isDefault: boolean }[]>}
   */
  listPrinters: () => ipcRenderer.invoke('violy:list-printers'),

  /**
   * Prints the CURRENT page with no dialog, to the printer named — or to the
   * system default when none is given.
   *
   * @param {{ deviceName?: string, paper: 'a4' | 'roll' }} options
   * @returns {Promise<{ ok: true } | { ok: false, error: string }>}
   */
  printSilently: (options) => ipcRenderer.invoke('violy:print', options),

  /**
   * The two buttons on the boot screen, and the only capability here that is
   * deliberately TEMPORARY.
   *
   * `main.js` registers the handlers behind these when it creates the boot
   * document and removes them the moment the Counter has loaded, so calling
   * either from the running app does nothing at all. That matters for `exit`:
   * a bridge that can quit the app is a bridge that can quit it mid-sale, and
   * the window in which quitting is a reasonable thing to ask for is exactly
   * the window in which the till is not open yet.
   *
   * @returns {Promise<void>}
   */
  boot: {
    retry: () => ipcRenderer.invoke('violy:boot-retry'),
    exit: () => ipcRenderer.invoke('violy:boot-exit'),
  },
})
