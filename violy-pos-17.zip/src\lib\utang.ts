/**
 * The arithmetic behind an utang plan: what interest a borrowing carries, what
 * the total becomes, and what is due each month.
 *
 * Pure — no Prisma, no React, no `new Date()` beyond the start date it is
 * handed. This is the module that decides what a person is told they owe, so
 * it is the module that gets tested hardest.
 *
 * Interest and total are computed here ONCE and then snapshotted onto the
 * stored plan. Nothing recomputes them afterwards. Editing a rate next year
 * must not silently rewrite what somebody already agreed to — the same reason
 * `priceAtSale` is snapshotted on a sale item.
 */

import { addMonthsClamped } from './dates'

export type InterestMethod = 'FLAT_MONTHLY' | 'FLAT_ONCE' | 'REDUCING'

export const INTEREST_METHODS: readonly InterestMethod[] = [
  'FLAT_MONTHLY',
  'FLAT_ONCE',
  'REDUCING',
]

export function isInterestMethod(value: string): value is InterestMethod {
  return INTEREST_METHODS.includes(value as InterestMethod)
}

/** 100.00% per month. Far past anything sane, but a hard ceiling all the same. */
export const MAX_RATE_BPS = 10_000

/** Five years of monthly instalments. */
export const MAX_TERM_MONTHS = 60

export type PlanTerms = {
  principalCentavos: number
  interestMethod: InterestMethod
  /** Basis points — 500 is 5.00%. Per month for FLAT_MONTHLY and REDUCING. */
  interestRateBps: number
  /** Number of monthly instalments. 1 means the whole thing at one due date. */
  termMonths: number
  /** The plan's start. Instalment 1 falls one month after this. */
  startedAt: Date
}

export type ScheduledInstallment = {
  /** 1-based. */
  sequence: number
  dueAt: Date
  amountCentavos: number
  principalCentavos: number
  interestCentavos: number
}

export type PlanSchedule = {
  principalCentavos: number
  interestCentavos: number
  totalCentavos: number
  installments: ScheduledInstallment[]
}

/** Human wording for a plan's terms, used on cards and on the invoice. */
export function describeTerms(terms: {
  interestMethod: InterestMethod
  interestRateBps: number
  termMonths: number
}): string {
  const months = `${terms.termMonths} month${terms.termMonths === 1 ? '' : 's'}`
  if (terms.interestRateBps === 0) return `${months}, no interest`

  const rate = `${terms.interestRateBps / 100}%`
  switch (terms.interestMethod) {
    case 'FLAT_MONTHLY':
      return `${months} at ${rate} per month, flat`
    case 'FLAT_ONCE':
      return `${months} at ${rate} one-time`
    case 'REDUCING':
      return `${months} at ${rate} per month on the balance`
  }
}

export function validateTerms(terms: PlanTerms): string | null {
  if (!Number.isInteger(terms.principalCentavos) || terms.principalCentavos <= 0) {
    return 'The amount must be more than zero.'
  }
  if (!isInterestMethod(terms.interestMethod)) {
    return 'Unrecognised interest method.'
  }
  if (
    !Number.isInteger(terms.interestRateBps) ||
    terms.interestRateBps < 0 ||
    terms.interestRateBps > MAX_RATE_BPS
  ) {
    return 'The interest rate must be between 0 and 100%.'
  }
  if (
    !Number.isInteger(terms.termMonths) ||
    terms.termMonths < 1 ||
    terms.termMonths > MAX_TERM_MONTHS
  ) {
    return `The term must be between 1 and ${MAX_TERM_MONTHS} months.`
  }
  if (Number.isNaN(terms.startedAt.getTime())) {
    return 'That start date is not valid.'
  }
  return null
}

/**
 * Total interest for the flat methods. `REDUCING` is not here because its
 * interest is not a closed-form multiple of the principal — it falls out of
 * running the amortisation, since each month charges interest only on what is
 * still outstanding.
 */
function flatInterest(terms: PlanTerms): number {
  const oneMonth = (terms.principalCentavos * terms.interestRateBps) / 10_000
  return Math.round(
    terms.interestMethod === 'FLAT_MONTHLY' ? oneMonth * terms.termMonths : oneMonth,
  )
}

/**
 * Splits a total into `count` monthly instalments that sum EXACTLY to it.
 *
 * Every instalment is the floor of the even share; the last one absorbs
 * whatever the division left over. Rounding each share independently would
 * leave the schedule off by a few centavos from the total printed above it —
 * on a document a customer is holding, that is the difference between an
 * invoice and an argument.
 */
function evenSplit(total: number, count: number): number[] {
  const base = Math.floor(total / count)
  const shares = Array<number>(count).fill(base)
  shares[count - 1] = total - base * (count - 1)
  return shares
}

/**
 * The plan's full schedule. Callers must have passed `validateTerms` first;
 * this assumes a sane term and rate.
 */
export function buildSchedule(terms: PlanTerms): PlanSchedule {
  const { principalCentavos, termMonths } = terms

  const installments: ScheduledInstallment[] =
    terms.interestMethod === 'REDUCING'
      ? reducingSchedule(terms)
      : flatSchedule(terms, flatInterest(terms))

  const withDates = installments.map((installment) => ({
    ...installment,
    dueAt: addMonthsClamped(terms.startedAt, installment.sequence),
  }))

  const totalCentavos = withDates.reduce((total, i) => total + i.amountCentavos, 0)

  return {
    principalCentavos,
    interestCentavos: totalCentavos - principalCentavos,
    totalCentavos,
    installments: withDates,
  }
}

function flatSchedule(terms: PlanTerms, interestCentavos: number): ScheduledInstallment[] {
  const total = terms.principalCentavos + interestCentavos
  // Principal and interest are split independently so that BOTH columns sum
  // exactly to their own figure, not merely the amount column to the total.
  const amounts = evenSplit(total, terms.termMonths)
  const principals = evenSplit(terms.principalCentavos, terms.termMonths)

  return amounts.map((amountCentavos, index) => ({
    sequence: index + 1,
    dueAt: terms.startedAt, // replaced by buildSchedule
    amountCentavos,
    principalCentavos: principals[index],
    interestCentavos: amountCentavos - principals[index],
  }))
}

/**
 * Bank-style amortisation: equal payments, interest charged each month on the
 * balance still outstanding.
 *
 * The final instalment deliberately does NOT use the computed payment. It
 * clears whatever principal remains plus that month's interest, so the balance
 * lands on exactly zero. Trusting `payment × n` instead would leave a few
 * centavos either owing or overpaid at the end, which is precisely the kind of
 * residue that makes a customer distrust the whole document.
 */
function reducingSchedule(terms: PlanTerms): ScheduledInstallment[] {
  const { principalCentavos, termMonths } = terms
  const rate = terms.interestRateBps / 10_000

  // A zero rate makes the annuity formula divide by zero, and it also has an
  // obvious answer: split the principal evenly and charge nothing.
  if (rate === 0) {
    return evenSplit(principalCentavos, termMonths).map((amountCentavos, index) => ({
      sequence: index + 1,
      dueAt: terms.startedAt,
      amountCentavos,
      principalCentavos: amountCentavos,
      interestCentavos: 0,
    }))
  }

  const payment = Math.round(
    (principalCentavos * rate) / (1 - Math.pow(1 + rate, -termMonths)),
  )

  const installments: ScheduledInstallment[] = []
  let balance = principalCentavos

  for (let sequence = 1; sequence <= termMonths; sequence += 1) {
    const interestCentavos = Math.round(balance * rate)
    const last = sequence === termMonths

    // Guard the middle months too: if a rounded payment ever failed to cover
    // that month's interest the balance would grow instead of shrink, and the
    // loop would never pay the plan off.
    const principalPart = last
      ? balance
      : Math.min(Math.max(0, payment - interestCentavos), balance)

    installments.push({
      sequence,
      dueAt: terms.startedAt,
      amountCentavos: principalPart + interestCentavos,
      principalCentavos: principalPart,
      interestCentavos,
    })
    balance -= principalPart
  }

  return installments
}

/**
 * How a plan stands: what has been paid into it, and which instalments that
 * covers. Payments fill instalments oldest first — she does not allocate a
 * payment to a particular month, only to a particular plan.
 */
export type InstallmentStatus = ScheduledInstallment & {
  paidCentavos: number
  isSettled: boolean
}

export function applyPayments(
  installments: readonly ScheduledInstallment[],
  paidCentavos: number,
): InstallmentStatus[] {
  let remaining = Math.max(0, paidCentavos)
  return installments.map((installment) => {
    const applied = Math.min(remaining, installment.amountCentavos)
    remaining -= applied
    return {
      ...installment,
      paidCentavos: applied,
      isSettled: applied >= installment.amountCentavos,
    }
  })
}

/**
 * The first instalment not yet fully covered, or null when the plan is
 * settled. This is the "next due" figure a plan card leads with.
 */
export function nextDue(statuses: readonly InstallmentStatus[]): InstallmentStatus | null {
  return statuses.find((installment) => !installment.isSettled) ?? null
}

/**
 * Instalments that are past their date and still not covered. `asOf` is passed
 * in rather than read from the clock, so callers stay testable and a server
 * render cannot disagree with a client one about what "today" is.
 */
export function overdueInstallments(
  statuses: readonly InstallmentStatus[],
  asOf: Date,
): InstallmentStatus[] {
  return statuses.filter(
    (installment) => !installment.isSettled && installment.dueAt.getTime() < asOf.getTime(),
  )
}
