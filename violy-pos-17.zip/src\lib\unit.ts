/**
 * Reading a product's unit well enough to scope a discount to it.
 *
 * Units are free text on each product, and the catalog holds "bag (50kg)",
 * "bag (25kg)", "bag", "kilo" and "pack (25x1kg)". A per-unit discount has to
 * be able to say "₱20 off every BAG" without also taking ₱20 off every kilo —
 * which on a ₱110/kilo item is most of the price, where on a ₱2,000 sack it is
 * a normal trade discount. Matching on the whole string cannot do that,
 * because "bag" and "bag (50kg)" are the same kind of thing sold in different
 * sizes.
 *
 * So the match is on the FIRST WORD, lowercased: "bag (50kg)" and "bag" both
 * reduce to "bag". That is a deliberately shallow rule, and it is the right
 * depth for free text somebody types at the counter — anything cleverer would
 * start guessing at what she meant.
 */

/** A discount with no unit named applies to every unit, as it always did. */
export const ANY_UNIT = ''

export function unitKeyword(unit: string): string {
  // Splits on whitespace and on "(" so "bag(50kg)" — no space — still reads
  // as a bag.
  const first = unit.trim().toLowerCase().split(/[\s(]+/)[0]
  return first ?? ''
}

/** Whether a product sold in `productUnit` is covered by a discount scoped to `discountUnit`. */
export function unitMatches(productUnit: string, discountUnit: string): boolean {
  if (discountUnit.trim() === ANY_UNIT) return true
  return unitKeyword(productUnit) === unitKeyword(discountUnit)
}

/**
 * The distinct unit kinds in a catalog, for offering as discount scopes.
 *
 * Built from the products that actually exist rather than a fixed list, so a
 * shop that starts selling by the drum gets "drum" without a code change.
 */
export function unitKeywordsOf(products: readonly { unit: string }[]): string[] {
  const seen = new Set<string>()
  for (const product of products) {
    const keyword = unitKeyword(product.unit)
    if (keyword !== '') seen.add(keyword)
  }
  return [...seen].sort()
}
