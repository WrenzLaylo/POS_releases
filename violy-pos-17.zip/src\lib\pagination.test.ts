import { describe, it, expect } from 'vitest'
import { PAGE_SIZE, parsePage, pageCountOf, clampPage } from '@/lib/pagination'

describe('parsePage', () => {
  it('defaults to page 1 for anything that is not a positive integer', () => {
    for (const raw of [undefined, '', 'abc', '0', '-3', '2.5', 'NaN']) {
      expect(parsePage(raw)).toBe(1)
    }
  })

  it('reads a positive integer', () => {
    expect(parsePage('1')).toBe(1)
    expect(parsePage('7')).toBe(7)
  })
})

describe('pageCountOf', () => {
  it('is at least 1 even when there is nothing to show', () => {
    expect(pageCountOf(0)).toBe(1)
  })

  it('rounds up a partial last page', () => {
    expect(pageCountOf(PAGE_SIZE)).toBe(1)
    expect(pageCountOf(PAGE_SIZE + 1)).toBe(2)
    expect(pageCountOf(PAGE_SIZE * 3)).toBe(3)
  })
})

describe('clampPage', () => {
  it('pulls a page past the end back to the last page', () => {
    expect(clampPage(99, 3)).toBe(3)
  })

  it('pulls a page below 1 up to 1', () => {
    expect(clampPage(0, 3)).toBe(1)
  })

  it('leaves a page inside the range alone', () => {
    expect(clampPage(2, 3)).toBe(2)
  })
})
