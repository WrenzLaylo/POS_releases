/**
 * Turns the brand MARK into the raster files Windows insists on.
 *
 * The mark, not the full lockup: the wordmark beside it is illegible below
 * about 64 pixels and a taskbar button is 16. `scripts/make-brand.mjs` cuts
 * the two apart; this only ever consumes the square one.
 *
 * Baked here rather than exported by hand from a design tool, because
 * otherwise the 16px icon and the 256px icon slowly become different pictures
 * and nobody notices which one is stale.
 *
 * Rasterised with Playwright's Chromium, already a dependency of this
 * project's screenshot tooling — no image library to install, and the renderer
 * is the same engine that draws the app.
 *
 *   node scripts/make-brand.mjs && node scripts/make-icon.mjs
 */

import { readFile, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { chromium } from 'playwright'

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..')
const MARK = path.join(ROOT, 'public', 'brand', 'violy-store-mark.png')

/**
 * 256 first so it is the entry Explorer picks for large views.
 *
 * The small sizes are not decoration: Windows scales down whatever it is given
 * when an exact size is missing, and a 256px drawing bilinearly squashed to 16
 * is mud. Every size here is drawn by the renderer at that size instead.
 */
const SIZES = [256, 128, 64, 48, 32, 24, 16]

/**
 * Packs PNGs into an .ico.
 *
 * The format is a 6-byte header, then one 16-byte directory entry per image,
 * then the images themselves. Every entry here is a PNG rather than the older
 * BMP form — supported since Windows Vista, and it keeps the file small enough
 * that a 256px entry is worth including at all.
 */
function packIco(images) {
  const HEADER = 6
  const ENTRY = 16

  const header = Buffer.alloc(HEADER)
  header.writeUInt16LE(0, 0) // reserved
  header.writeUInt16LE(1, 2) // 1 = icon, 2 = cursor
  header.writeUInt16LE(images.length, 4)

  let offset = HEADER + ENTRY * images.length
  const entries = images.map(({ size, data }) => {
    const entry = Buffer.alloc(ENTRY)
    // 256 is written as 0: the field is a single byte, so 256 does not fit and
    // the format spells it this way instead.
    entry.writeUInt8(size >= 256 ? 0 : size, 0)
    entry.writeUInt8(size >= 256 ? 0 : size, 1)
    entry.writeUInt8(0, 2) // palette size, 0 for truecolour
    entry.writeUInt8(0, 3) // reserved
    entry.writeUInt16LE(1, 4) // colour planes
    entry.writeUInt16LE(32, 6) // bits per pixel
    entry.writeUInt32LE(data.length, 8)
    entry.writeUInt32LE(offset, 12)
    offset += data.length
    return entry
  })

  return Buffer.concat([header, ...entries, ...images.map((image) => image.data)])
}

const mark = await readFile(MARK)
const dataUrl = `data:image/png;base64,${mark.toString('base64')}`

const browser = await chromium.launch()
const page = await browser.newPage()

const images = []
for (const size of SIZES) {
  await page.setViewportSize({ width: size, height: size })
  await page.setContent(
    `<style>html,body{margin:0;padding:0;background:transparent}
     img{display:block;width:${size}px;height:${size}px}</style>
     <img src="${dataUrl}">`,
  )
  // omitBackground keeps the rounded corners transparent rather than filling
  // them white, which on a dark taskbar would show as a pale square.
  images.push({ size, data: await page.screenshot({ omitBackground: true }) })
}

await browser.close()

await writeFile(path.join(ROOT, 'electron', 'icon.ico'), packIco(images))

// The window icon Electron uses on Linux and in some Windows contexts. 256 is
// the first entry in SIZES.
await writeFile(path.join(ROOT, 'electron', 'icon.png'), images[0].data)

console.log(`Wrote electron/icon.ico (${SIZES.join(', ')} px) and electron/icon.png (256 px).`)
