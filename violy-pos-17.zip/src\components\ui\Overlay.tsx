'use client'

import { useEffect, useId, useRef, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import { cn } from '@/lib/cn'
import { Button } from './Button'
import { Icon } from './Icon'

const FOCUSABLE = [
  'a[href]',
  'button:not([disabled])',
  'input:not([disabled])',
  'select:not([disabled])',
  'textarea:not([disabled])',
  '[tabindex]:not([tabindex="-1"])',
].join(',')

type OverlayProps = {
  open: boolean
  onOpenChange: (open: boolean) => void
  title: ReactNode
  description?: ReactNode
  header?: ReactNode
  children?: ReactNode
  footer?: ReactNode
  className?: string
  surfaceClassName: string
  backdropTestId: string
}

export function Overlay({
  open,
  onOpenChange,
  title,
  description,
  header,
  children,
  footer,
  className,
  surfaceClassName,
  backdropTestId,
}: OverlayProps) {
  const titleId = useId()
  const descriptionId = useId()
  const surfaceRef = useRef<HTMLDivElement>(null)
  const onOpenChangeRef = useRef(onOpenChange)
  onOpenChangeRef.current = onOpenChange

  useEffect(() => {
    if (!open) return

    const previouslyFocused = document.activeElement instanceof HTMLElement
      ? document.activeElement
      : null
    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'

    const surface = surfaceRef.current
    const firstFocusable = Array.from(surface?.querySelectorAll<HTMLElement>(FOCUSABLE) ?? [])
      .find((element) => !element.hasAttribute('data-overlay-close'))
    ;(firstFocusable ?? surface)?.focus()

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault()
        onOpenChangeRef.current(false)
        return
      }
      if (event.key !== 'Tab' || !surface) return

      const focusable = Array.from(surface.querySelectorAll<HTMLElement>(FOCUSABLE))
      if (focusable.length === 0) {
        event.preventDefault()
        surface.focus()
        return
      }

      const first = focusable[0]
      const last = focusable[focusable.length - 1]
      const active = document.activeElement
      if (active === surface || !(active instanceof Node) || !surface.contains(active)) {
        event.preventDefault()
        ;(event.shiftKey ? last : first).focus()
      } else if (event.shiftKey && active === first) {
        event.preventDefault()
        last.focus()
      } else if (!event.shiftKey && active === last) {
        event.preventDefault()
        first.focus()
      }
    }

    document.addEventListener('keydown', handleKeyDown)
    return () => {
      document.removeEventListener('keydown', handleKeyDown)
      document.body.style.overflow = previousOverflow
      previouslyFocused?.focus()
    }
  }, [open])

  if (!open || typeof document === 'undefined') return null

  return createPortal(
    <div
      // No `backdrop-blur`. A backdrop-filter over `inset-0` makes the
      // compositor re-blur the whole viewport on every repaint, and a dialog
      // repaints on every keystroke — measured at ~70ms per character in a
      // production build, against a ~31ms floor. That was the reported "why
      // does this feel laggy", and it applied to every dialog in the app, not
      // just the one it was noticed in. Removing it took typing back to the
      // floor. The 70% canvas wash alone separates the surface from the page;
      // on a light theme the blur was adding almost nothing to look at.
      className="fixed inset-0 z-50 flex bg-canvas/70"
      data-testid={backdropTestId}
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onOpenChange(false)
      }}
    >
      <div
        ref={surfaceRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description ? descriptionId : undefined}
        tabIndex={-1}
        className={cn(
          'relative flex max-h-full flex-col bg-surface-raised text-ink shadow-raised border border-line focus:outline-none',
          surfaceClassName,
          className,
        )}
      >
        <header className="border-b border-line px-5 py-4 pr-16">
          <h2 id={titleId} className="text-base font-semibold">{title}</h2>
          {description ? <p id={descriptionId} className="mt-1 text-sm text-ink-muted">{description}</p> : null}
          {header}
        </header>
        <div className="min-h-0 flex-1 overflow-y-auto p-5">{children}</div>
        {footer ? <footer className="border-t border-line p-5">{footer}</footer> : null}
        <Button
          data-overlay-close
          variant="ghost"
          size="icon"
          aria-label="Close"
          className="absolute right-3 top-3"
          onClick={() => onOpenChange(false)}
        >
          <Icon name="close" className="h-4 w-4" />
        </Button>
      </div>
    </div>,
    document.body,
  )
}
