-- Consignment: stock on the shelf that the shop does not owe for yet.
--
-- The original model assumed every delivery was an outright purchase — sacks
-- arrive, the full amount is owed that day. Consignment is the other half of
-- how feed actually moves here: the supplier leaves stock, it is sellable, and
-- the shop owes only for what sells. Whatever does not sell goes back.
--
-- Additive, with a backfill. Every delivery already on file was an outright
-- purchase, which is the default, and everything that arrived on it is owed —
-- so `chargeableCentavos` starts equal to `totalCostCentavos` rather than at
-- zero. Starting it at zero would silently wipe the payables balance.

ALTER TABLE "Delivery" ADD COLUMN "terms" TEXT NOT NULL DEFAULT 'OUTRIGHT';
ALTER TABLE "Delivery" ADD COLUMN "chargeableCentavos" INTEGER NOT NULL DEFAULT 0;
ALTER TABLE "DeliveryItem" ADD COLUMN "quantitySettled" REAL NOT NULL DEFAULT 0;
ALTER TABLE "DeliveryItem" ADD COLUMN "quantityReturned" REAL NOT NULL DEFAULT 0;

UPDATE "Delivery" SET "chargeableCentavos" = "totalCostCentavos";
