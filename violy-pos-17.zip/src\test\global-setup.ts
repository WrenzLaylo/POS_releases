import { execSync } from 'node:child_process'
import { rmSync } from 'node:fs'
import path from 'node:path'

export default function setup() {
  // Each run starts from an empty database file, so `db push` creates the
  // schema from scratch rather than migrating or resetting an existing one.
  // `force: true` makes this a no-op on the first run, when no file exists.
  rmSync(path.join(process.cwd(), 'prisma', 'test.db'), { force: true })

  execSync('npx prisma db push --skip-generate', {
    stdio: 'inherit',
    env: { ...process.env, DATABASE_URL: 'file:./test.db' },
  })
}
