import { generateKeyPairSync, sign } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { describe, expect, it } from 'vitest'
import { canonicalManifest, verifyManifestSignature } from './update-signature'
import { parseManifest } from './update-info'

/**
 * A real key, made per run rather than checked in.
 *
 * The production public key is compiled into `update-public-key.ts`, so these
 * cannot sign anything it would accept — which is the point. What is tested
 * here is the arithmetic: that a signature over the canonical form verifies,
 * that changing any signed field breaks it, and that the app refuses a
 * manifest it cannot check.
 */
const KEYS = generateKeyPairSync('ed25519')

const FIELDS = {
  build: 7,
  version: '2026.08.21',
  zipUrl: 'https://raw.githubusercontent.com/WrenzLaylo/POS_releases/main/violy-pos-7.zip',
  sha256: 'a'.repeat(64),
}

/** Signs with the throwaway key, the way `release.mjs` signs with the real one. */
function signWith(fields: typeof FIELDS): string {
  // Ed25519 takes a NULL algorithm. Passing 'sha256' throws — the curve
  // carries its own hash — and it is the usual way to get this wrong.
  return sign(null, Buffer.from(canonicalManifest(fields), 'utf8'), KEYS.privateKey).toString(
    'base64',
  )
}

/** Verifies against the throwaway key rather than the shipped one. */
function verifyWith(fields: typeof FIELDS, signature: string): boolean {
  const { verify } = require('node:crypto') as typeof import('node:crypto')
  try {
    return verify(
      null,
      Buffer.from(canonicalManifest(fields), 'utf8'),
      KEYS.publicKey,
      Buffer.from(signature, 'base64'),
    )
  } catch {
    return false
  }
}

describe('the canonical form', () => {
  it('is exactly what the release script signs', () => {
    // `scripts/release.mjs` cannot import this module — it runs under plain
    // Node before anything is compiled — so it carries its own copy. If the
    // two ever drift, every release verifies as tampered and the symptom
    // looks like a wrong key. This asserts the shape both must produce.
    const NEWLINE = String.fromCharCode(10)
    expect(canonicalManifest(FIELDS)).toBe(
      [
        'build:7',
        'version:2026.08.21',
        `zipUrl:${FIELDS.zipUrl}`,
        `sha256:${'a'.repeat(64)}`,
      ].join(NEWLINE),
    )
  })

  it('is the shape the shipped release script still writes', () => {
    // Read rather than imported, for the same reason. Catches an edit to one
    // copy that was not made to the other.
    const source = readFileSync('scripts/release.mjs', 'utf8')
    expect(source).toContain('`build:${build}`')
    expect(source).toContain('`version:${version}`')
    expect(source).toContain('`zipUrl:${zipUrl}`')
    expect(source).toContain('`sha256:${String(sha256).toLowerCase()}`')
  })

  it('lowercases the checksum, so casing cannot break a good signature', () => {
    expect(canonicalManifest({ ...FIELDS, sha256: 'A'.repeat(64) })).toBe(
      canonicalManifest(FIELDS),
    )
  })

  it('ignores the notes, so wording can be fixed without re-signing', () => {
    // `notes` are prose for the operator. Nothing about them decides what is
    // downloaded or whether it is trusted.
    const a = canonicalManifest(FIELDS)
    const b = canonicalManifest({ ...FIELDS })
    expect(a).toBe(b)
  })
})

describe('verifying a signature', () => {
  it('accepts one made over these exact fields', () => {
    expect(verifyWith(FIELDS, signWith(FIELDS))).toBe(true)
  })

  it.each([
    ['build', { build: 8 }],
    ['version', { version: '2026.09.01' }],
    ['zipUrl', { zipUrl: 'https://evil.test/violy-pos-7.zip' }],
    ['sha256', { sha256: 'b'.repeat(64) }],
  ])('rejects a manifest whose %s was changed after signing', (_field, patch) => {
    // The whole purpose. Swapping the zip URL or its checksum is exactly what
    // someone with the publishing account would do, and the signature is the
    // only thing that notices.
    const signature = signWith(FIELDS)
    expect(verifyWith({ ...FIELDS, ...patch }, signature)).toBe(false)
  })

  it('rejects a signature made with a different key', () => {
    const other = generateKeyPairSync('ed25519')
    const forged = sign(
      null,
      Buffer.from(canonicalManifest(FIELDS), 'utf8'),
      other.privateKey,
    ).toString('base64')
    expect(verifyWith(FIELDS, forged)).toBe(false)
  })

  it.each([['empty', ''], ['whitespace', '   '], ['not base64', '!!!!'], ['truncated', 'AAAA']])(
    'rejects a %s signature rather than throwing',
    (_label, signature) => {
      // The caller is asking "may this be trusted". Every answer other than a
      // clean yes is no, including a malformed one.
      expect(verifyWith(FIELDS, signature)).toBe(false)
      expect(verifyManifestSignature(FIELDS, signature)).toBe(false)
    },
  )
})

describe('parseManifest, with signature checking', () => {
  const manifest = {
    ...FIELDS,
    publishedAt: '2026-08-21T02:00:00.000Z',
    notes: ['Something changed'],
  }

  it('accepts a manifest whose signature verifies', () => {
    const result = parseManifest({ ...manifest, signature: signWith(FIELDS) }, verifyWith)
    expect(result).not.toBeNull()
    expect(result?.build).toBe(7)
  })

  it('rejects one whose zip was swapped after signing', () => {
    const signature = signWith(FIELDS)
    const tampered = { ...manifest, zipUrl: 'https://evil.test/x.zip', signature }
    expect(parseManifest(tampered, verifyWith)).toBeNull()
  })

  it('rejects one with no signature at all', () => {
    // Absence is treated exactly like a wrong signature. If it were tolerated
    // as "an older format", turning the check off would only take deleting a
    // field.
    expect(parseManifest(manifest, verifyWith)).toBeNull()
    expect(parseManifest({ ...manifest, signature: '' }, verifyWith)).toBeNull()
  })

  it('verifies the fields as PARSED, not as they arrived', () => {
    // The checksum is lowercased and the URL trimmed on the way through. If
    // verification ran over the raw JSON instead, a manifest could be signed
    // in one shape and acted on in another.
    const signature = signWith(FIELDS)
    const shouty = { ...manifest, sha256: 'A'.repeat(64), signature }
    expect(parseManifest(shouty, verifyWith)).not.toBeNull()
  })

  it('still refuses a badly shaped manifest even when the signature is good', () => {
    // Shape checks come first and stay first: a signed manifest pointing at a
    // plain-HTTP download is still a manifest pointing at a plain-HTTP
    // download.
    const fields = { ...FIELDS, zipUrl: 'http://insecure.test/x.zip' }
    const signature = signWith(fields)
    expect(parseManifest({ ...manifest, ...fields, signature }, verifyWith)).toBeNull()
  })
})

describe('the updater actually has a signature to check', () => {
  const source = readFileSync('scripts/update.mjs', 'utf8')

  it('carries the signature through fetchManifest', () => {
    // This was broken and shipped. `fetchManifest` rebuilds the manifest field
    // by field, and `signature` was not one of them — so `manifestIsAuthentic`
    // verified `undefined`, and EVERY genuine release was refused as forged.
    // Nothing caught it because the check had never run against a real signed
    // manifest: no update had been installed since signing was added.
    expect(source).toContain("signature: typeof value.signature === 'string' ? value.signature : ''")
  })

  it('checks authenticity before downloading the zip', () => {
    // Order matters: there is no reason to spend a shop's connection on a file
    // that was never going to be installed.
    const check = source.indexOf('manifestIsAuthentic(manifest)')
    const download = source.indexOf('downloadAndVerify(manifest)')
    expect(check).toBeGreaterThan(-1)
    expect(download).toBeGreaterThan(-1)
    expect(check).toBeLessThan(download)
  })

  it('can be forced, for the by-hand recovery path', () => {
    // `update-now.cmd` is Plan B for when the in-app button cannot be reached.
    // It runs this same updater rather than a second copy that would drift.
    expect(source).toContain("const FORCE = process.argv.includes('--force')")
    expect(source).toContain('if (!FORCE) {')
    expect(readFileSync('update-now.cmd', 'utf8')).toContain('update.mjs --force')
  })
})
