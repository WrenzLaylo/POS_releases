import type { Metadata } from 'next'
import { Archivo, Inter, JetBrains_Mono } from 'next/font/google'
import { AppRail } from '@/components/AppRail'
import { AppTopbar } from '@/components/AppTopbar'
import { LoginScreen } from '@/components/LoginScreen'
import { RouteFocus } from '@/components/RouteFocus'
import { getNotifications } from '@/server/notifications'
import { authIsEnabled, getSession } from '@/server/session'
import { getLoginIdentity } from '@/server/auth'
import './globals.css'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
})

// Headings and section labels. The width axis is what makes the UI read as
// an instrument panel rather than a generic dashboard.
const archivo = Archivo({
  subsets: ['latin'],
  variable: '--font-archivo',
  display: 'swap',
  axes: ['wdth'],
})

// Every peso figure and stock count renders in this, via the `Money`
// primitive. Genuinely tabular, so columns of figures align.
const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-jetbrains-mono',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'Violy Store POS',
  description: 'Point of sale for a pig feeds dealer',
}

/** Shared by both returns below, so the two cannot drift apart. */
const FONTS = `${inter.variable} ${archivo.variable} ${jetbrainsMono.variable}`

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  // The login is decided HERE rather than in a middleware or a `/login` route,
  // and that is the point: there is no page anyone can add later and forget to
  // protect, and no URL to bounce between. When she signs in, this layout
  // simply re-renders with a session and the screen she was already heading
  // for appears underneath.
  //
  // `authIsEnabled` is false until an AppUser exists, so this whole branch is
  // dead on a shop that has not set a login up — which is how the update lands
  // without locking anyone out of a working till.
  const locked = (await authIsEnabled()) && (await getSession()) === null
  const identity = locked ? await getLoginIdentity() : null

  // An early return rather than a branch inside the tree: the shell's data is
  // then only fetched when the shell is actually rendered, so a locked screen
  // runs no ledger or stock queries at all.
  if (locked && identity) {
    return (
      <html lang="en" className={FONTS}>
        <body className="bg-canvas font-sans text-ink antialiased">
          <LoginScreen username={identity.username} />
        </body>
      </html>
    )
  }

  const [notifications, signedIn] = await Promise.all([getNotifications(), getSession()])

  return (
    <html lang="en" className={FONTS}>
      <body className="bg-canvas font-sans text-ink antialiased">
        <RouteFocus />
        {(
          /* The three `app-*` class names exist for the print stylesheet, which
             has to undo this shell's `overflow: hidden` and fixed heights.
             Naming the elements beats describing their shape: the previous
             rules matched on `body > div > div`, which stopped being true the
             moment the tree changed and failed silently — the printed page
             simply came out wrong. */
          <div className="app-shell flex h-screen overflow-hidden">
            {/* The first thing Tab reaches, and it exists because of a measured
                number: on Stock it took 34 tab presses to get from the top of
                the page to the first product, every single time, past the rail,
                the filter chips and the toolbar. Visible only when focused, so
                it costs a mouse user nothing. */}
            <a
              href="#main"
              className="sr-only rounded-control bg-ink px-4 py-2 text-sm font-medium text-surface focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50"
            >
              Skip to content
            </a>
            <AppRail />
            <div className="app-body flex min-w-0 flex-1 flex-col">
              <AppTopbar notifications={notifications} username={signedIn?.username ?? null} />
              {/* `relative` is load-bearing, not decoration. Tailwind's `sr-only` is
                  `position: absolute`, and an absolutely-positioned element resolves
                  against the nearest POSITIONED ancestor — with none, that is the
                  document itself, so it escapes this scroll container completely
                  and is not clipped by it. A hidden radio inside a
                  `SegmentedControl` far down a long page therefore stretched the
                  DOCUMENT to reach it, giving the window its own scrollbar beside
                  this one: two scrollbars, and a band of blank page below the app.
                  Making this element the containing block keeps such things inside
                  it. */}
              {/* `id` and `tabIndex` are the skip link's landing site: an
                  anchor moves focus only to something focusable, and -1 keeps
                  it out of the tab order it is helping somebody escape. */}
              <main
                id="main"
                tabIndex={-1}
                className="app-main relative min-h-0 flex-1 overflow-y-auto focus:outline-none"
              >
                {children}
              </main>
            </div>
          </div>
        )}
      </body>
    </html>
  )
}
