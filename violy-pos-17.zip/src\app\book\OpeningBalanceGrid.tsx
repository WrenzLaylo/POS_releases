'use client'

import { useMemo, useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import type { BatchPaymentRow, CustomerWithBalance } from '@/lib/types'
import { parsePesoInput } from '@/lib/money'
import { occurredAtForDay } from '@/lib/dates'
import { recordOpeningBalanceBatch } from '@/server/ledger'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { EmptyState } from '@/components/ui/EmptyState'
import { Field } from '@/components/ui/Field'
import { DatePicker } from '@/components/ui/DatePicker'
import { Input } from '@/components/ui/Input'
import { Money } from '@/components/ui/Money'
import { FormError } from '@/components/ui/FormError'
import { cn } from '@/lib/cn'

/**
 * Carrying the paper notebook across, all of it, in one sitting.
 *
 * `OpeningBalanceDialog` does this one customer at a time and does it well. But
 * forty-six dialogs is the same wall that left fifty-two cost prices at zero,
 * and it produced the same result: not one customer had a starting figure, so
 * the Book insisted a shop full of debtors owed nothing.
 *
 * The customers ARE the rows, like `BulkPaymentGrid` — no dropdown to pick a
 * name wrongly, and the balance the app currently believes sits beside the box
 * so a figure typed against the wrong person is visible rather than silent.
 *
 * ONE date for the whole batch, not one per row. She is transcribing a single
 * notebook as it stood on a single day; asking the date forty-six times would
 * be forty-six chances to disagree with herself, and the date is what decides
 * whether the carry-over sorts above or below payments already recorded.
 *
 * Anyone who already has a carry-over is shown but not editable. A second
 * opening balance is always a mistake — the server refuses one — and a box that
 * accepts typing the server will reject is a worse experience than no box.
 */
export function OpeningBalanceGrid({
  customers,
  alreadySet,
  todayKey,
}: {
  customers: CustomerWithBalance[]
  /** Customer ids with a live OPENING entry. They cannot take a second. */
  alreadySet: number[]
  /** Computed on the server, so the two render passes cannot disagree. */
  todayKey: string
}) {
  const router = useRouter()
  const [date, setDate] = useState(todayKey)
  const [note, setNote] = useState('')
  const [filter, setFilter] = useState('')
  /** customerId → what she typed. Absent means this name is not being carried. */
  const [amounts, setAmounts] = useState<Map<number, string>>(new Map())
  const [topError, setTopError] = useState<string | null>(null)
  const [summary, setSummary] = useState<string | null>(null)
  const [pending, startTransition] = useTransition()

  const done = useMemo(() => new Set(alreadySet), [alreadySet])

  const visible = useMemo(() => {
    const needle = filter.trim().toLowerCase()
    return customers
      .filter((customer) => !customer.isArchived)
      .filter((customer) => needle === '' || customer.name.toLowerCase().includes(needle))
      // Still to do first, then alphabetical. She works down the notebook, and
      // the names already carried across are only there for reassurance.
      .sort((a, b) => {
        const aDone = done.has(a.customerId) ? 1 : 0
        const bDone = done.has(b.customerId) ? 1 : 0
        if (aDone !== bDone) return aDone - bDone
        return a.name.localeCompare(b.name)
      })
  }, [customers, filter, done])

  const remaining = customers.filter(
    (customer) => !customer.isArchived && !done.has(customer.customerId),
  ).length

  // Across the WHOLE book, not just what the filter shows — she may search for
  // one name mid-pass, and the running total must not appear to reset.
  const entered = [...amounts.entries()]
    .map(([customerId, raw]) => ({ customerId, value: parsePesoInput(raw) }))
    .filter((row) => row.value !== null && row.value > 0)
  const invalid = [...amounts.values()].some((raw) => {
    if (raw.trim() === '') return false
    const parsed = parsePesoInput(raw)
    return parsed === null || parsed <= 0
  })
  const totalCentavos = entered.reduce((sum, row) => sum + (row.value as number), 0)

  function setAmount(customerId: number, raw: string) {
    setSummary(null)
    setAmounts((previous) => {
      const next = new Map(previous)
      if (raw.trim() === '') next.delete(customerId)
      else next.set(customerId, raw)
      return next
    })
  }

  function save() {
    setTopError(null)
    setSummary(null)

    if (invalid) {
      setTopError('One of the amounts is not a figure above zero. Check the boxes outlined in red.')
      return
    }
    if (entered.length === 0) {
      setTopError('Type at least one starting utang before saving.')
      return
    }

    const occurredAt = occurredAtForDay(date) ?? new Date()
    const rows: BatchPaymentRow[] = entered.map((row) => ({
      customerId: row.customerId,
      amountCentavos: row.value as number,
      occurredAt,
      note: note.trim() || 'Carried over from the notebook',
    }))

    startTransition(async () => {
      const result = await recordOpeningBalanceBatch(rows)
      if (!result.ok) {
        setTopError(result.error)
        return
      }

      const { recorded, failures } = result.data
      // Only the rows that landed are cleared. Anything refused stays on screen
      // with what she typed still in it — a batch is too much work to retype
      // because one name in it was already carried across.
      const failedIds = new Set(failures.map((failure) => rows[failure.index].customerId))
      setAmounts((previous) => {
        const next = new Map<number, string>()
        for (const [customerId, raw] of previous) {
          if (failedIds.has(customerId)) next.set(customerId, raw)
        }
        return next
      })

      setSummary(
        failures.length === 0
          ? `Saved. ${recorded} starting balance${recorded === 1 ? '' : 's'} recorded.`
          : `Saved ${recorded}. ${failures.length} could not be saved and ${
              failures.length === 1 ? 'is' : 'are'
            } still on screen: ${failures[0].error}`,
      )
      router.refresh()
    })
  }

  return (
    <Card>
      <div className="mb-4 flex flex-wrap items-end justify-between gap-4">
        <div className="flex flex-wrap items-end gap-4">
          <Field label="As of">
            <DatePicker value={date} onChange={setDate} className="w-44" />
          </Field>
          <Field label="Note (optional)">
            <Input
              value={note}
              onChange={(event) => setNote(event.target.value)}
              placeholder="e.g. Blue notebook, page 12"
              className="w-64"
            />
          </Field>
          <Field label="Find a customer">
            <Input
              type="search"
              value={filter}
              onChange={(event) => setFilter(event.target.value)}
              placeholder="Customer name"
              className="w-56"
            />
          </Field>
        </div>

        <div className="flex items-end gap-4">
          <div className="text-right">
            <div className="text-xs font-semibold uppercase tracking-wide text-ink-muted">
              About to record
            </div>
            {/* Owed, not green. This is debt being written onto the book, not
                cash that has arrived. */}
            <Money centavos={totalCentavos} tone="owed" scale="strong" />
          </div>
          <Button variant="success" onClick={save} disabled={pending || amounts.size === 0}>
            {pending ? 'Saving…' : 'Save starting utang'}
          </Button>
        </div>
      </div>

      {topError && <FormError className="mb-3">{topError}</FormError>}
      {summary && (
        <p className="mb-3 rounded-control border border-line bg-surface-sunk px-4 py-3 text-sm text-ink">
          {summary}
        </p>
      )}

      {visible.length === 0 ? (
        <EmptyState>No customers match that search.</EmptyState>
      ) : (
        <div className="overflow-hidden rounded-card border border-line">
          <table className="w-full text-sm">
            <thead className="bg-surface-sunk text-left text-xs uppercase tracking-wide text-ink-muted">
              <tr>
                <th className="px-4 py-3 font-medium">Customer</th>
                <th className="px-4 py-3 text-right font-medium">Book says now</th>
                <th className="px-4 py-3 text-right font-medium">Starting utang</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {visible.map((customer) => {
                const raw = amounts.get(customer.customerId) ?? ''
                const parsed = parsePesoInput(raw)
                const bad = raw.trim() !== '' && (parsed === null || parsed <= 0)
                const carried = done.has(customer.customerId)

                return (
                  <tr
                    key={customer.customerId}
                    className={cn(raw.trim() !== '' && 'bg-accent-soft/40', carried && 'opacity-60')}
                  >
                    <td className="px-4 py-2 font-medium text-ink">{customer.name}</td>
                    <td className="px-4 py-2 text-right">
                      <Money centavos={customer.balanceCentavos} tone="balance" scale="body" />
                    </td>
                    <td className="px-4 py-2 text-right">
                      {carried ? (
                        // Shown rather than hidden, so she can see the name was
                        // dealt with instead of wondering where it went.
                        <span className="text-xs text-ink-subtle">Already carried over</span>
                      ) : (
                        <Input
                          inputMode="decimal"
                          value={raw}
                          onChange={(event) => setAmount(customer.customerId, event.target.value)}
                          placeholder="—"
                          aria-label={`Starting utang for ${customer.name}`}
                          aria-invalid={bad || undefined}
                          disabled={pending}
                          className={cn('w-32 text-right tabular-nums', bad && 'border-owed')}
                        />
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}

      <p className="mt-4 text-xs text-ink-subtle">
        {remaining > 0
          ? `${remaining} customer${remaining === 1 ? '' : 's'} still have no starting utang. `
          : 'Every customer has a starting utang. '}
        Leave a box empty for anyone who owed nothing — ₱0 is not a starting utang. This is a
        one-off; everything after it the app records by itself. The date is when the notebook was
        written, and it decides whether the carry-over sorts above or below payments already
        recorded.
      </p>
    </Card>
  )
}
