-- Persist checkout tender/change, prevent duplicate submissions, and support
-- auditable sale voids and stock movements.
ALTER TABLE "Sale" ADD COLUMN "cashTenderedCentavos" INTEGER;
ALTER TABLE "Sale" ADD COLUMN "changeCentavos" INTEGER NOT NULL DEFAULT 0;
ALTER TABLE "Sale" ADD COLUMN "customerBalanceAfterCentavos" INTEGER;
ALTER TABLE "Sale" ADD COLUMN "clientOrderKey" TEXT;
ALTER TABLE "Sale" ADD COLUMN "isVoided" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "Sale" ADD COLUMN "voidedAt" DATETIME;
ALTER TABLE "Sale" ADD COLUMN "voidReason" TEXT NOT NULL DEFAULT '';

CREATE UNIQUE INDEX "Sale_clientOrderKey_key" ON "Sale"("clientOrderKey");
CREATE INDEX "Sale_isVoided_idx" ON "Sale"("isVoided");

CREATE TABLE "StockMovement" (
  "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  "productId" INTEGER NOT NULL,
  "saleId" INTEGER,
  "type" TEXT NOT NULL,
  "quantity" REAL NOT NULL,
  "note" TEXT NOT NULL DEFAULT '',
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "StockMovement_productId_fkey" FOREIGN KEY ("productId") REFERENCES "Product" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT "StockMovement_saleId_fkey" FOREIGN KEY ("saleId") REFERENCES "Sale" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE INDEX "StockMovement_productId_idx" ON "StockMovement"("productId");
CREATE INDEX "StockMovement_saleId_idx" ON "StockMovement"("saleId");
CREATE INDEX "StockMovement_createdAt_idx" ON "StockMovement"("createdAt");
