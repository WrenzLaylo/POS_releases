-- One-time data decision, not a runtime heuristic.
--
-- The previous migration (20260729030753_category_sort_order) backfilled
-- every existing category to the default sortOrder of 100. On the
-- documented no-reseed path ("if she has entered real sales by then, do
-- not reseed — archive the groceries from the Inventory screen instead"),
-- nothing in the app can set sortOrder: there is no UI and no server
-- action for it. Left alone, the order screen would degrade to a flat
-- name sort across all categories — worse than the name-regex it
-- replaced, since the regex at least floated feeds to the top.
--
-- This assigns sensible values by name, once, for both the current pig
-- catalog and the legacy category name from the pre-pig catalog that only
-- exists on the archive path. It does not reintroduce name-based ordering
-- at query time — listProducts/listCategories still order by the stored
-- sortOrder column. This just seeds that column correctly for names the
-- app is known to produce.
UPDATE "Category" SET "sortOrder" = 1 WHERE "name" = 'Feeds (Sako)';
UPDATE "Category" SET "sortOrder" = 2 WHERE "name" = 'Feeds (Kilo)';
UPDATE "Category" SET "sortOrder" = 3 WHERE "name" = 'Gamot at Bitamina';
UPDATE "Category" SET "sortOrder" = 4 WHERE "name" = 'Kagamitan';
-- Legacy name from the pre-pig catalog, only present on the archive path.
UPDATE "Category" SET "sortOrder" = 1 WHERE "name" = 'Pig Feeds';
