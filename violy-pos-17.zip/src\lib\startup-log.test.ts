import { createRequire } from 'node:module'
import { join } from 'node:path'
import { describe, expect, it } from 'vitest'

/**
 * `electron/startup-log.js` is plain CommonJS for the same reason
 * `electron/main.js` is: the shell runs under Electron's Node before any
 * TypeScript exists. The pure parts live there rather than inline in `main.js`
 * precisely so they can be tested here — the bounding rule and the privacy
 * guarantee are the two things about a log that are worth proving.
 */
const load = createRequire(import.meta.url)
const { formatSession, trimToBudget, MAX_SESSIONS, MILESTONES } = load(
  join(process.cwd(), 'electron', 'startup-log.js'),
)

const startedAtIso = '2026-08-25T09:12:03.000Z'

function session(overrides: Record<string, unknown> = {}) {
  return {
    startedAtIso,
    milestones: [
      { name: 'app-ready', at: 48.4 },
      { name: 'window-visible', at: 112.9 },
    ],
    outcome: { ok: true },
    ...overrides,
  }
}

describe('formatSession', () => {
  it('writes one line per launch, with whole-millisecond offsets', () => {
    expect(formatSession(session())).toBe(
      `${startedAtIso} ok app-ready=48 window-visible=113`,
    )
  })

  /**
   * The privacy guarantee, and the reason milestone names are an allow-list
   * rather than free text. A caller cannot log a customer name, a product
   * search or an order by passing one as a milestone: there is no path from
   * arbitrary text to the file.
   */
  it('drops any milestone that is not on the allow-list', () => {
    const line = formatSession(
      session({
        milestones: [
          { name: 'app-ready', at: 10 },
          { name: 'customer: Aling Nena — ₱4,200 utang', at: 20 },
          { name: 'window-visible', at: 30 },
        ],
      }),
    )
    expect(line).toBe(`${startedAtIso} ok app-ready=10 window-visible=30`)
    expect(line).not.toContain('Nena')
  })

  it('records a failure as a bare category, never as a message', () => {
    expect(
      formatSession(session({ outcome: { ok: false, category: 'not-the-pos' } })),
    ).toBe(`${startedAtIso} failed:not-the-pos app-ready=48 window-visible=113`)
  })

  it('refuses a failure category it does not recognise', () => {
    // Otherwise "failed:" becomes a free-text channel by the back door.
    expect(
      formatSession(session({ outcome: { ok: false, category: 'ECONNREFUSED /home/violy/db' } })),
    ).toBe(`${startedAtIso} failed:unknown app-ready=48 window-visible=113`)
  })

  it('carries a server exit code, which is a number and safe', () => {
    expect(
      formatSession(session({ outcome: { ok: false, category: 'server-exit', exitCode: 1 } })),
    ).toBe(`${startedAtIso} failed:server-exit exit=1 app-ready=48 window-visible=113`)
  })

  it('names every milestone the brief asked for', () => {
    for (const name of [
      'app-ready',
      'window-visible',
      'server-spawn-requested',
      'health-verified',
      'counter-navigation-started',
      'renderer-dom-ready',
      'app-load-finished',
    ]) {
      expect(MILESTONES).toContain(name)
    }
  })
})

describe('trimToBudget', () => {
  it('keeps the NEWEST sessions when the log is over budget', () => {
    const existing = Array.from({ length: MAX_SESSIONS }, (_, i) => `line-${i}`).join('\n')
    const trimmed = trimToBudget(existing, ['line-new'], 	MAX_SESSIONS)
    const lines = trimmed.split('\n')

    expect(lines).toHaveLength(MAX_SESSIONS)
    expect(lines.at(-1)).toBe('line-new')
    // The oldest is the one that goes.
    expect(lines).not.toContain('line-0')
    expect(lines[0]).toBe('line-1')
  })

  it('leaves a short log alone', () => {
    expect(trimToBudget('a\nb', ['c'], 10)).toBe('a\nb\nc')
  })

  it('starts a log that does not exist yet', () => {
    expect(trimToBudget('', ['first'], 10)).toBe('first')
  })

  it('ignores blank lines left by a previous write', () => {
    expect(trimToBudget('a\n\n\nb\n', ['c'], 10)).toBe('a\nb\nc')
  })
})
