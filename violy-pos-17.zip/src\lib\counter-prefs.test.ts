// @vitest-environment jsdom

import { afterEach, describe, expect, it } from 'vitest'
import { OVERSELL_WARNING_KEY, oversellWarningOn, setOversellWarning } from './counter-prefs'

afterEach(() => {
  window.localStorage.clear()
})

describe('the stock warning preference', () => {
  it('is on when nothing has been stored', () => {
    // The whole point of the default. A fresh laptop, a cleared browser, or a
    // key this app has never written must all mean "warn me" — the quiet
    // answer is the one that has to be asked for.
    expect(oversellWarningOn()).toBe(true)
  })

  it('is on for any value that is not exactly off', () => {
    // Defensive on purpose: the only thing that silences the warning is the
    // one string this module writes. Anything else — a half-written value, a
    // key from an older build — falls back to warning.
    for (const stored of ['', 'on', 'true', 'false', 'OFF', 'nonsense']) {
      window.localStorage.setItem(OVERSELL_WARNING_KEY, stored)
      expect(oversellWarningOn()).toBe(true)
    }
  })

  it('goes off, and comes back on', () => {
    setOversellWarning(false)
    expect(oversellWarningOn()).toBe(false)

    // The way back from the counter's "Stop asking me this", which is the
    // reason the Settings toggle exists at all.
    setOversellWarning(true)
    expect(oversellWarningOn()).toBe(true)
  })

  it('stores something a later build can still read', () => {
    setOversellWarning(false)
    expect(window.localStorage.getItem(OVERSELL_WARNING_KEY)).toBe('off')
    setOversellWarning(true)
    expect(window.localStorage.getItem(OVERSELL_WARNING_KEY)).toBe('on')
  })
})
