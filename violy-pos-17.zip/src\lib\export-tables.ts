/**
 * Which tables can be exported, and how they are described in the UI.
 *
 * In its own module rather than beside `exportTableCsv`, because
 * `src/server/export-data.ts` carries `'use server'` and such a file may
 * export ONLY async functions. Next wraps every export of a `'use server'`
 * module as a server-action reference, so a `const` array arrives in a client
 * component as a FUNCTION — which fails at runtime with "g.map is not a
 * function" and not at build time.
 *
 * This is the second time that trap has bitten in this codebase; the first was
 * `PRODUCT_SORT_KEYS`, which at least failed loudly during page-data
 * collection. Non-function exports belong in `lib/`.
 */

export type ExportTable =
  | 'products'
  | 'customers'
  | 'categories'
  | 'suppliers'
  | 'sales'
  | 'sale_items'
  | 'ledger'
  | 'deliveries'
  | 'stock_movements'

/**
 * Every table, in the order a person would want to read them: what I sell, who
 * I sell to and buy from, then what actually happened.
 *
 * "Everything" downloads this list in this order, so the folder sorts the same
 * way it reads. Adding a table here is all it takes to include it — there is
 * no second list to keep in step.
 */
export const EXPORT_TABLES: readonly { value: ExportTable; label: string; note: string }[] = [
  { value: 'products', label: 'Products', note: 'Name, category, unit, prices, stock' },
  { value: 'customers', label: 'Customers', note: 'Names, contact, discount, balance' },
  { value: 'categories', label: 'Categories', note: 'The brands products are grouped under' },
  { value: 'suppliers', label: 'Suppliers', note: 'Who deliveries come from' },
  { value: 'sales', label: 'Sales', note: 'Every sale with its totals and payment' },
  { value: 'sale_items', label: 'Sale lines', note: 'What was on each sale, line by line' },
  { value: 'ledger', label: 'Ledger entries', note: 'Every charge and payment on the book' },
  { value: 'deliveries', label: 'Deliveries', note: 'Stock received, line by line' },
  { value: 'stock_movements', label: 'Stock movements', note: 'Every change to a stock figure' },
]
