import { beforeEach, describe, expect, it } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'
import { outstandingOf } from '@/lib/delivery'
import { recordSupplierOpeningBalance, suppliersWithOpeningBalance } from './supplier-opening'
import { CARRY_OVER_NOTE } from '@/lib/supplier-debt'

beforeEach(resetDb)

const DAY = new Date('2026-07-01T00:00:00')

async function makeSupplier(name = 'Golden Harvesta', isArchived = false) {
  return prisma.supplier.create({ data: { name, isArchived } })
}

describe('carrying a supplier debt across', () => {
  it('records what was already owed', async () => {
    const supplier = await makeSupplier()
    const result = await recordSupplierOpeningBalance(supplier.id, 45_000_00, DAY)

    expect(result.ok).toBe(true)
    if (!result.ok) return

    const delivery = await prisma.delivery.findUniqueOrThrow({
      where: { id: result.data.deliveryId },
    })
    expect(delivery.chargeableCentavos).toBe(45_000_00)
    expect(delivery.amountPaidCentavos).toBe(0)
    expect(outstandingOf(delivery)).toBe(45_000_00)
  })

  it('brings no stock with it', async () => {
    // This is money owed, not sacks arriving. The sacks came before the app
    // could see them, so raising stock now would invent inventory.
    const supplier = await makeSupplier()
    const result = await recordSupplierOpeningBalance(supplier.id, 45_000_00, DAY)
    expect(result.ok).toBe(true)
    if (!result.ok) return

    expect(await prisma.deliveryItem.count()).toBe(0)
    expect(await prisma.stockMovement.count()).toBe(0)
  })

  it('is OUTRIGHT, because it is owed now', async () => {
    // A consignment owes nothing until it sells, which is the opposite of a
    // debt already run up.
    const supplier = await makeSupplier()
    const result = await recordSupplierOpeningBalance(supplier.id, 10_000_00, DAY)
    if (!result.ok) return
    const delivery = await prisma.delivery.findUniqueOrThrow({ where: { id: result.data.deliveryId } })
    expect(delivery.terms).toBe('OUTRIGHT')
    expect(delivery.note).toBe(CARRY_OVER_NOTE)
  })

  it('refuses a second one for the same supplier', async () => {
    // Two would quietly double what the payables screen says is owed.
    const supplier = await makeSupplier()
    expect((await recordSupplierOpeningBalance(supplier.id, 45_000_00, DAY)).ok).toBe(true)

    const again = await recordSupplierOpeningBalance(supplier.id, 12_000_00, DAY)
    expect(again.ok).toBe(false)
    if (!again.ok) expect(again.error).toContain('already has a carried-over debt')
    expect(await prisma.delivery.count()).toBe(1)
  })

  it('allows a new one once the old is voided, so a wrong figure can be fixed', async () => {
    const supplier = await makeSupplier()
    const first = await recordSupplierOpeningBalance(supplier.id, 45_000_00, DAY)
    if (!first.ok) return
    await prisma.delivery.update({ where: { id: first.data.deliveryId }, data: { isVoided: true } })

    expect((await recordSupplierOpeningBalance(supplier.id, 12_000_00, DAY)).ok).toBe(true)
  })

  it('refuses zero, a negative, and a fractional centavo', async () => {
    const supplier = await makeSupplier()
    for (const bad of [0, -100, 1_000.5]) {
      expect((await recordSupplierOpeningBalance(supplier.id, bad, DAY)).ok).toBe(false)
    }
    expect(await prisma.delivery.count()).toBe(0)
  })

  it('refuses an archived supplier', async () => {
    const supplier = await makeSupplier('Old Feeds', true)
    expect((await recordSupplierOpeningBalance(supplier.id, 45_000_00, DAY)).ok).toBe(false)
  })

  it('refuses a supplier that does not exist', async () => {
    expect((await recordSupplierOpeningBalance(999_999, 45_000_00, DAY)).ok).toBe(false)
  })

  it('names which suppliers already have one', async () => {
    const a = await makeSupplier('Golden Harvesta')
    const b = await makeSupplier('Atlas')
    await recordSupplierOpeningBalance(a.id, 45_000_00, DAY)

    expect(await suppliersWithOpeningBalance()).toEqual([a.id])
    expect((await suppliersWithOpeningBalance()).includes(b.id)).toBe(false)
  })
})
