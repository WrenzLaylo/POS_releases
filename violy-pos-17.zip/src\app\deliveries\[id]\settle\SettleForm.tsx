'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import type { DeliveryDetail } from '@/server/deliveries'
import { reconcileDelivery } from '@/server/deliveries'
import { validateReconcile, type ReconcileLine } from '@/lib/delivery'
import { ROUTES } from '@/lib/routes'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'
import { Money } from '@/components/ui/Money'
import { cn } from '@/lib/cn'

type Entry = { sold: string; returned: string }

/** Whole sacks and half kilos, and nothing else. A quantity box that takes
 *  letters is how "500zz" reached a till; the same applies here. */
function digitsOnly(raw: string): string {
  const kept = raw.replace(/[^0-9.]/g, '')
  const dot = kept.indexOf('.')
  if (dot === -1) return kept
  return kept.slice(0, dot + 1) + kept.slice(dot + 1).replace(/\./g, '')
}

/**
 * The supplier's visit: what sold, and what goes back.
 *
 * A PAGE, not a dialog. It carries a row per delivery line, each with two
 * boxes and a cross-check against the till, and the shop's own sales figures
 * beside them — a dialog was already cramped before any of that.
 *
 * The important change is not the shape though, it is where the numbers come
 * from. This screen used to accept any figure at all: 47 sold could be typed
 * against a line the counter had sold 2 of, and the app would book ₱89,300
 * owed for sacks still on the shelf. Nothing cross-checked, nothing warned,
 * and there was no way back — settling was a one-way ratchet.
 *
 * So the boxes now START at what the till actually recorded since the delivery
 * landed. She can change them, because there are real reasons to: bags damaged,
 * sold before the app was in use, or an agent whose own count differs and whose
 * count is the one the contract runs on. But she starts from the truth, and
 * overriding it upward says so out loud.
 */
export function SettleForm({ delivery }: { delivery: DeliveryDetail }) {
  const router = useRouter()
  const [pending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)
  const consignment = delivery.terms === 'CONSIGNMENT'

  const [entries, setEntries] = useState<Record<number, Entry>>(() =>
    Object.fromEntries(
      delivery.lines.map((line) => [
        line.productId,
        // Pre-filled, not blank. A blank box invites a number from memory;
        // a filled one invites a check.
        { sold: consignment && line.soldSinceArrival > 0 ? String(line.soldSinceArrival) : '', returned: '' },
      ]),
    ),
  )

  function set(productId: number, patch: Partial<Entry>) {
    setEntries((current) => ({ ...current, [productId]: { ...current[productId], ...patch } }))
  }

  const updates: ReconcileLine[] = delivery.lines
    .map((line) => {
      const entry = entries[line.productId] ?? { sold: '', returned: '' }
      return {
        productId: line.productId,
        soldQuantity: entry.sold.trim() === '' ? 0 : Number(entry.sold),
        returnedQuantity: entry.returned.trim() === '' ? 0 : Number(entry.returned),
      }
    })
    .filter((update) => update.soldQuantity !== 0 || update.returnedQuantity !== 0)

  // The same check the server runs, against the same line state, so a disabled
  // Save always has a sentence beside it explaining itself.
  const problem = validateReconcile(delivery.terms, delivery.lines, updates)

  // Lines where she is settling more than the till ever recorded. Not an
  // error — but it is the sentence that would have stopped ₱89,300 being
  // booked against sacks still on the shelf.
  const overstated = delivery.lines
    .map((line) => {
      const typed = Number(entries[line.productId]?.sold ?? '') || 0
      return { line, typed }
    })
    .filter(({ line, typed }) => consignment && typed > line.soldSinceArrival)

  const addedCentavos = updates.reduce((total, update) => {
    const line = delivery.lines.find((candidate) => candidate.productId === update.productId)
    if (!line) return total
    const chargeable = consignment ? update.soldQuantity : -update.returnedQuantity
    return total + Math.round(chargeable * line.unitCostCentavos)
  }, 0)

  function save() {
    setError(null)
    startTransition(async () => {
      const result = await reconcileDelivery(delivery.id, updates)
      if (!result.ok) {
        setError(result.error)
        return
      }
      router.push(`${ROUTES.deliveries}?tab=settle`)
      router.refresh()
    })
  }

  return (
    <Card>
      <div className="grid gap-5">
        <p className="text-sm text-ink-muted">
          {consignment
            ? 'The boxes start at what the counter has already sold since this arrived. Change them only if the supplier’s count differs.'
            : 'This was bought outright, so it is owed in full already. Enter only what is going back.'}
        </p>

        <div className="overflow-hidden rounded-card border border-line">
          <table className="w-full text-sm">
            <thead className="bg-surface-sunk text-left text-xs uppercase tracking-wide text-ink-muted">
              <tr>
                <th className="px-4 py-3 font-medium">Product</th>
                <th className="px-4 py-3 text-right font-medium">Still open</th>
                {consignment && (
                  <th className="px-4 py-3 text-right font-medium">Counter sold</th>
                )}
                {consignment && <th className="w-28 px-4 py-3 font-medium">Settle as sold</th>}
                <th className="w-28 px-4 py-3 font-medium">Going back</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {delivery.lines.map((line) => {
                const entry = entries[line.productId] ?? { sold: '', returned: '' }
                const typed = Number(entry.sold) || 0
                const over = consignment && typed > line.soldSinceArrival
                return (
                  <tr key={line.productId}>
                    <td className="px-4 py-2">
                      <span className="block font-medium text-ink">{line.name}</span>
                      <span className="block text-xs text-ink-subtle">
                        {line.unit} @ <Money centavos={line.unitCostCentavos} scale="body" />
                      </span>
                    </td>
                    <td className="px-4 py-2 text-right font-mono text-ink-muted">
                      {line.unaccountedQuantity}
                    </td>
                    {consignment && (
                      // The figure this screen exists to be checked against.
                      <td className="px-4 py-2 text-right font-mono text-ink">
                        {line.soldSinceArrival}
                      </td>
                    )}
                    {consignment && (
                      <td className="px-4 py-2">
                        <Input
                          inputMode="decimal"
                          value={entry.sold}
                          onChange={(event) =>
                            set(line.productId, { sold: digitsOnly(event.target.value) })
                          }
                          placeholder="0"
                          aria-label={`How many ${line.name} sold`}
                          className={cn('w-24 text-right tabular-nums', over && 'border-warn')}
                        />
                      </td>
                    )}
                    <td className="px-4 py-2">
                      <Input
                        inputMode="decimal"
                        value={entry.returned}
                        onChange={(event) =>
                          set(line.productId, { returned: digitsOnly(event.target.value) })
                        }
                        placeholder="0"
                        aria-label={`How many ${line.name} going back`}
                        className="w-24 text-right tabular-nums"
                      />
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>

        {overstated.length > 0 && (
          <div className="rounded-control border border-warn/40 bg-warn/10 px-4 py-3 text-sm text-ink">
            <div className="font-semibold text-warn">More than the counter sold</div>
            <ul className="mt-1 space-y-1 text-ink-muted">
              {overstated.map(({ line, typed }) => (
                <li key={line.productId}>
                  {line.name}: the counter sold {line.soldSinceArrival}, you are settling {typed}.
                </li>
              ))}
            </ul>
            <p className="mt-2 text-xs text-ink-subtle">
              Fine if stock was damaged, or sold before this app was used, or the supplier’s own
              count differs. Worth a second look otherwise — settling a sack that is still on the
              shelf bills you for it.
            </p>
          </div>
        )}

        <div className="flex flex-wrap items-center justify-between gap-3 rounded-control bg-surface-sunk px-4 py-3">
          <span className="text-sm text-ink-muted">
            {consignment ? 'This visit adds to what you owe' : 'This visit takes off what you owe'}
          </span>
          <Money centavos={Math.abs(addedCentavos)} tone={addedCentavos > 0 ? 'owed' : undefined} scale="strong" />
        </div>

        {error && <FormError>{error}</FormError>}
        {problem && updates.length > 0 && <FormError>{problem}</FormError>}

        <div className="flex items-center gap-2">
          <Button variant="success" onClick={save} disabled={pending || problem !== null}>
            {pending ? 'Saving…' : 'Save settlement'}
          </Button>
          <Button
            variant="ghost"
            onClick={() => router.push(`${ROUTES.deliveries}?tab=settle`)}
            disabled={pending}
          >
            Cancel
          </Button>
        </div>
      </div>
    </Card>
  )
}
