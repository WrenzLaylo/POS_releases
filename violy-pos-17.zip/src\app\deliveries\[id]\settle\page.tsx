import { notFound } from 'next/navigation'
import Link from 'next/link'
import { getDelivery } from '@/server/deliveries'
import { ROUTES } from '@/lib/routes'
import { PageHeader } from '@/components/ui/PageHeader'
import { SettleForm } from './SettleForm'

export const dynamic = 'force-dynamic'

export default async function SettleDeliveryPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const deliveryId = Number(id)
  if (!Number.isInteger(deliveryId) || deliveryId <= 0) notFound()

  const delivery = await getDelivery(deliveryId)
  if (!delivery || delivery.isVoided) notFound()

  return (
    <PageHeader
      title={`Settle with ${delivery.supplierName}`}
      actions={
        <Link
          href={`${ROUTES.deliveries}?tab=settle`}
          className="text-sm font-medium text-ink-muted hover:text-ink"
        >
          ← Back to deliveries
        </Link>
      }
    >
      <SettleForm delivery={delivery} />
    </PageHeader>
  )
}
