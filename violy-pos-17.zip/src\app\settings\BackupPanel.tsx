'use client'

import { useState, useTransition } from 'react'
import type { BackupStatus } from '@/lib/backup-run'
import { AUTO_BACKUP_HOURS } from '@/lib/backup-policy'
import { backupNow } from '@/server/backup'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { FormError } from '@/components/ui/FormError'
import { Icon } from '@/components/ui/Icon'

const WHEN = new Intl.DateTimeFormat('en-PH', {
  day: 'numeric',
  month: 'short',
  year: 'numeric',
  hour: 'numeric',
  minute: '2-digit',
})

function megabytes(bytes: number): string {
  if (bytes < 1_000_000) return `${Math.max(1, Math.round(bytes / 1_000))} KB`
  return `${(bytes / 1_000_000).toFixed(1)} MB`
}

/**
 * Backups: the one she can press, and the ones that happen without her.
 *
 * Both are shown together on purpose. An automatic backup nobody can see is
 * indistinguishable from no backup at all — the only moment its existence gets
 * tested is the moment it is already too late to find out it never ran. So the
 * list of real files with real dates and real sizes is the point of this panel,
 * more than the button is.
 */
export function BackupPanel({ status: initial }: { status: BackupStatus }) {
  const [status, setStatus] = useState(initial)
  const [justSaved, setJustSaved] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [pending, startTransition] = useTransition()

  function save() {
    setError(null)
    setJustSaved(false)
    startTransition(async () => {
      const result = await backupNow()
      if (!result.ok) {
        setError(result.error)
        return
      }
      setStatus(result.data)
      setJustSaved(true)
    })
  }

  return (
    <Card>
      <div className="mb-3 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-base font-semibold">Backups</h2>
          <p className="text-sm text-ink-muted">
            A complete, restorable copy of everything — customers, utang, sales, stock and
            product photos.
          </p>
        </div>
        <Button variant="secondary" onClick={save} disabled={pending}>
          {pending ? 'Saving…' : 'Back up now'}
        </Button>
      </div>

      {error && <FormError className="mb-3">{error}</FormError>}

      {justSaved && (
        <p className="mb-3 flex items-center gap-2 rounded-control border border-accent/40 bg-accent-soft px-3 py-2 text-sm font-medium text-accent">
          <Icon name="check" className="h-4 w-4 shrink-0" />
          Saved. Your data is copied.
        </p>
      )}

      <div className="rounded-control border border-line bg-surface-sunk p-4">
        {status.lastTakenAt === null ? (
          <p className="text-sm font-semibold text-warn">
            Nothing has been backed up yet. Press “Back up now”.
          </p>
        ) : (
          <>
            <p className="text-sm text-ink">
              Last backup{' '}
              <span className="font-semibold">{WHEN.format(status.lastTakenAt)}</span>
            </p>
            <p className="mt-0.5 text-xs text-ink-subtle">
              {status.files.length} kept · {megabytes(status.totalBytes)} in total
            </p>

            <ul className="mt-3 space-y-1 border-t border-line pt-3">
              {status.files.slice(0, 5).map((file) => (
                <li
                  key={file.name}
                  className="flex items-center justify-between gap-3 text-xs text-ink-muted"
                >
                  <span className="tabular-nums">{WHEN.format(file.takenAt)}</span>
                  <span className="tabular-nums text-ink-subtle">{megabytes(file.bytes)}</span>
                </li>
              ))}
              {status.files.length > 5 && (
                <li className="text-xs text-ink-subtle">
                  …and {status.files.length - 5} older backup
                  {status.files.length - 5 === 1 ? '' : 's'}.
                </li>
              )}
            </ul>
          </>
        )}
      </div>

      <p className="mt-4 rounded-control border border-line px-3 py-2 text-xs text-ink-muted">
        The app backs up by itself when it opens and every {AUTO_BACKUP_HOURS} hours after that, so
        this button is only for before you do something you are unsure about. Backups are kept on
        this computer, in the <code className="font-mono">backups</code> folder — copy that folder
        to a USB stick now and then, because a backup on a laptop does not survive losing the
        laptop.
      </p>
    </Card>
  )
}
