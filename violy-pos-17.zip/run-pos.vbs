' Starts Violy Store POS with no console window.
'
' A shortcut to a .cmd flashes a black window on every launch and leaves it in
' the taskbar for as long as the till is open, which reads as something having
' gone wrong. This starts the same command hidden, so the only window that
' appears is the app itself.
'
' The 0 is "hidden" and the False is "do not wait" — waiting would keep this
' script alive for the whole session for no reason.
Set shell = CreateObject("WScript.Shell")
shell.CurrentDirectory = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
shell.Run "cmd /c npm run app", 0, False
