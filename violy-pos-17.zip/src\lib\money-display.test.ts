import { describe, expect, it } from 'vitest'
import { balanceTone, saleStatus } from './money-display'

describe('balanceTone', () => {
  it('treats a positive balance as owed — the customer is in debt', () => {
    expect(balanceTone(4800)).toBe('owed')
  })

  it('treats a negative balance as money in — the customer is in credit', () => {
    expect(balanceTone(-2500)).toBe('in')
  })

  it('treats a settled balance as zero, so it can be de-emphasised', () => {
    expect(balanceTone(0)).toBe('zero')
  })
})

describe('saleStatus', () => {
  it('describes a live charge with some cash as partial', () => {
    expect(
      saleStatus({ hasLiveCharge: true, cashPaidCentavos: 20000, totalCentavos: 60000 }),
    ).toBe('partial')
  })

  it('describes a live charge with no cash as full credit', () => {
    expect(
      saleStatus({ hasLiveCharge: true, cashPaidCentavos: 0, totalCentavos: 60000 }),
    ).toBe('credit')
  })

  it('describes a fully covered sale as cash', () => {
    expect(
      saleStatus({ hasLiveCharge: false, cashPaidCentavos: 60000, totalCentavos: 60000 }),
    ).toBe('cash')
  })

  it('keeps a voided linked charge distinct from a cash sale', () => {
    expect(
      saleStatus({ hasLiveCharge: false, cashPaidCentavos: 0, totalCentavos: 60000 }),
    ).toBe('charge-voided')
  })

  it('gives a voided sale precedence over payment shape', () => {
    expect(
      saleStatus({
        hasLiveCharge: false,
        cashPaidCentavos: 60000,
        totalCentavos: 60000,
        isVoided: true,
      }),
    ).toBe('voided')
  })
})
