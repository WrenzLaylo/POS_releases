'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { parsePesoInput } from '@/lib/money'
import { occurredAtForDay } from '@/lib/dates'
import { setOpeningBalance } from '@/server/ledger'
import { Button } from '@/components/ui/Button'
import { Dialog } from '@/components/ui/Dialog'
import { Field } from '@/components/ui/Field'
import { FormError } from '@/components/ui/FormError'
import { DatePicker } from '@/components/ui/DatePicker'
import { Input } from '@/components/ui/Input'
import { Textarea } from '@/components/ui/Textarea'

/**
 * What a customer already owed before this app existed.
 *
 * `setOpeningBalance` has been on the server the whole time — tested, and
 * rendered as "Opening balance" by both the ledger and the statement — but no
 * screen has called it since the New utang dialog absorbed the carry-over.
 * That left the plainest case with no way in at all: forty-six names came
 * across from the notebook and every one of them started at ₱0, which is not
 * what the notebook said.
 *
 * Deliberately NOT the New utang dialog. That one schedules instalments and
 * charges interest; a carry-over is a single figure the customer already owes,
 * on no terms, and making her invent a plan to record it is how the number
 * ends up wrong or never entered.
 *
 * The date matters and defaults to today rather than being hidden: an opening
 * balance dated after a payment she has already recorded would sort below it
 * and read as though the customer paid before they owed anything.
 */
export function OpeningBalanceDialog({
  customerId,
  customerName,
  todayKey,
  onClose,
}: {
  customerId: number
  customerName: string
  /** Computed on the server so this cannot differ between the two passes. */
  todayKey: string
  onClose: () => void
}) {
  const router = useRouter()
  const [amount, setAmount] = useState('')
  const [date, setDate] = useState(todayKey)
  const [note, setNote] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [pending, startTransition] = useTransition()

  const parsed = parsePesoInput(amount)

  function save() {
    setError(null)
    if (parsed === null) {
      setError('Enter an amount like 1,500 or 2350.50')
      return
    }
    if (parsed <= 0) {
      setError('An opening balance must be more than zero.')
      return
    }

    startTransition(async () => {
      const result = await setOpeningBalance({
        customerId,
        amountCentavos: parsed,
        // Same rule as a payment: a figure stamped at midnight sorts before
        // everything else that happened that day.
        occurredAt: occurredAtForDay(date) ?? new Date(),
        note: note.trim() || 'Carried over from the notebook',
        planId: null,
      })
      if (!result.ok) {
        // The server refuses a second one, and says so in words worth
        // showing — this is the likeliest thing to go wrong here.
        setError(result.error)
        return
      }
      router.refresh()
      onClose()
    })
  }

  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title="Starting utang"
      description={`What ${customerName} already owed before this app. Enter it once.`}
      footer={
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose} disabled={pending}>
            Cancel
          </Button>
          <Button variant="success" onClick={save} disabled={pending}>
            {pending ? 'Saving…' : 'Save starting utang'}
          </Button>
        </div>
      }
    >
      <div className="grid gap-4">
        <Field label="Amount owed">
          <Input
            inputMode="decimal"
            value={amount}
            onChange={(event) => setAmount(event.target.value)}
            placeholder="0.00"
            className="w-full tabular-nums"
            autoFocus
          />
        </Field>

        <Field label="As of">
          <DatePicker value={date} onChange={setDate} className="w-full" />
        </Field>

        <Field label="Note (optional)">
          <Textarea
            value={note}
            onChange={(event) => setNote(event.target.value)}
            placeholder="e.g. Balance from the blue notebook, page 12"
            rows={2}
            className="w-full"
          />
        </Field>

        <p className="text-xs text-ink-subtle">
          This is a one-off. Everything after it — orders, payments — the app records by itself.
        </p>

        {error && <FormError>{error}</FormError>}
      </div>
    </Dialog>
  )
}
