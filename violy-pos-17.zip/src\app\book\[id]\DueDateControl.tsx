'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { dayKey } from '@/lib/dates'
import { setCustomerDueDate } from '@/server/customers'
import { Button } from '@/components/ui/Button'
import { Field } from '@/components/ui/Field'
import { FormError } from '@/components/ui/FormError'
import { DatePicker } from '@/components/ui/DatePicker'

export function DueDateControl({ customerId, dueAt }: { customerId: number; dueAt: Date }) {
  const router = useRouter()
  const [day, setDay] = useState(dayKey(dueAt))
  const [error, setError] = useState<string | null>(null)
  const [saved, setSaved] = useState(false)
  const [pending, startTransition] = useTransition()

  function save() {
    setError(null)
    setSaved(false)
    startTransition(async () => {
      const result = await setCustomerDueDate(customerId, day)
      if (!result.ok) {
        setError(result.error)
        return
      }
      setSaved(true)
      router.refresh()
    })
  }

  return (
    <div className="mb-6 rounded-xl border border-line bg-surface px-4 py-3">
      <div className="flex flex-wrap items-end gap-3">
        <Field label="Account due date">
          <DatePicker
            value={day}
            onChange={(next) => {
              setDay(next)
              setSaved(false)
            }}
            aria-label="Account due date"
            className="w-48"
            disabled={pending}
          />
        </Field>
        <Button variant="secondary" onClick={save} disabled={pending || !day}>
          {pending ? 'Saving…' : 'Change due date'}
        </Button>
        {/* Not `text-money-in`: a due-date save is a generic confirmation,
            not cash arriving — `money-in` is reserved for actual received
            cash. `text-accent` is the app's non-money positive/interactive
            colour. */}
        {saved && <span className="pb-2 text-sm font-semibold text-accent">Due date updated.</span>}
      </div>
      {error && <FormError className="mt-3">{error}</FormError>}
    </div>
  )
}
