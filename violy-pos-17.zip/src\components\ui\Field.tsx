import type { ReactNode } from 'react'
import { cn } from '@/lib/cn'

/** Label above a control. Standardises where the label sits — previously
 *  each form invented its own placement. Form-level errors are a separate
 *  concern; use `FormError` for those rather than a per-field slot. */
export function Field({
  label,
  className,
  children,
}: {
  label?: string
  className?: string
  children: ReactNode
}) {
  return (
    <label className={cn('grid gap-1', className)}>
      {label && (
        <span className="text-xs font-medium uppercase tracking-[0.08em] text-ink-muted">{label}</span>
      )}
      {children}
    </label>
  )
}
