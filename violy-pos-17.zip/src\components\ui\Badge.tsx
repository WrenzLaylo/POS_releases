import type { ReactNode } from 'react'
import { cn } from '@/lib/cn'

type Tone = 'neutral' | 'warn' | 'owed' | 'muted' | 'paid'

const TONES: Record<Tone, string> = {
  neutral: 'bg-accent-soft text-accent',
  // `warn-soft`, not `accent-soft`: warn is the lightest of the semantic inks
  // and measures 4.33 on the blue tint, the only one of the five that fails.
  // See the token's note in globals.css for why it is a warm tint rather than
  // a bordered chip.
  warn: 'bg-warn-soft text-warn',
  owed: 'bg-accent-soft text-owed',
  muted: 'border border-line bg-surface text-ink-subtle',
  paid: 'border border-line bg-surface text-money-in',
}

export function Badge({
  tone = 'neutral',
  className,
  children,
}: {
  tone?: Tone
  className?: string
  children: ReactNode
}) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full px-2 py-0.5 text-xs font-semibold tracking-[0.01em]',
        TONES[tone],
        className,
      )}
    >
      {children}
    </span>
  )
}
