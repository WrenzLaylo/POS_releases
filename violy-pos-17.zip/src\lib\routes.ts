/**
 * Every route in the app, in one place. Nothing anywhere else writes a route
 * string literal — screens link through these, and Server Actions revalidate
 * through them via `revalidateRoutes`. A rename therefore updates every call
 * site at once and fails `tsc` if one is missed.
 */
export const ROUTES = {
  counter: '/counter',
  history: '/history',
  book: '/book',
  stock: '/stock',
  deliveries: '/deliveries',
  dashboard: '/dashboard',
  settings: '/settings',
} as const

export type AppRoute = (typeof ROUTES)[keyof typeof ROUTES]

/** A single customer's passbook. */
export function bookEntry(customerId: number): string {
  return `${ROUTES.book}/${customerId}`
}

/** The bulk payment entry grid. */
export const BOOK_BULK = `${ROUTES.book}/bulk`

/** A completed sale: what was bought and how it was paid for. */
export function sale(saleId: number): string {
  return `${ROUTES.history}/${saleId}`
}

/** A permanent printable receipt/invoice for a completed sale. */
export function saleReceipt(saleId: number): string {
  return `${ROUTES.history}/${saleId}/receipt`
}

/**
 * The paper that travels with the load, and the copy the customer signs.
 *
 * Nested under the SALE rather than given a top-level `/delivery-notes/[id]`,
 * because there is no delivery record to point at — a delivery order is a sale
 * that knows where it is going. It sits beside the receipt for the same
 * reason: they are two documents about one transaction, and the tab strip on
 * `/history/[id]` is where somebody looks for either.
 *
 * `notFound()` on a sale with no `deliverAt`. Nothing was delivered, so there
 * is no note to print.
 */
export function deliveryNote(saleId: number): string {
  return `${ROUTES.history}/${saleId}/delivery-note`
}

/**
 * The three utang documents, all nested under the customer they belong to.
 *
 * Nested rather than flat (`/book/plan/[id]`) on purpose: a static `plan`
 * segment would sit alongside `[id]` and win the match for `/book/plan`,
 * which reads as a customer named "plan". Keeping them under the customer
 * also means every document URL carries the account it concerns.
 */
export function planInvoice(customerId: number, planId: number): string {
  return `${bookEntry(customerId)}/plan/${planId}`
}

export function paymentReceipt(customerId: number, entryId: number): string {
  return `${bookEntry(customerId)}/payment/${entryId}`
}

export function accountStatement(customerId: number): string {
  return `${bookEntry(customerId)}/statement`
}

/** Recording a delivery. A page, not a dialog — the number of lines it has
 *  to hold is unbounded. */
export const NEW_DELIVERY = `${ROUTES.deliveries}/new`

/**
 * Selling something and sending it somewhere, on one screen.
 *
 * Under `/counter`, not under `/deliveries`. `/deliveries` is stock arriving
 * FROM a supplier; this is stock leaving TO a customer, and the two share a
 * word rather than a subject. Nested here the rail keeps highlighting Counter,
 * which is honest — a delivery order is a way of selling, and it goes through
 * the same `createOrder` a counter sale does.
 */
export const DELIVER = `${ROUTES.counter}/deliver`

/**
 * The booked loads, on History's "Going out" tab.
 *
 * A query string rather than a route of its own, because it IS the History
 * screen — one more page rendering the same data would be a second thing to
 * keep in step. It is a constant rather than a literal for the usual reason:
 * the Dashboard panel and the notification bell both point here, and a tab
 * held only in component state cannot be linked to at all.
 */
export const HISTORY_GOING_OUT = `${ROUTES.history}?view=going-out`

/**
 * History's Recent tab, linkable.
 *
 * Same reasoning as `HISTORY_GOING_OUT`: the tab lives in component state and
 * cannot be reached by a link without the URL saying which one to open. An
 * empty Today view offers this, because "was anything rung up before today"
 * is the other question an empty day raises.
 */
export const HISTORY_RECENT = `${ROUTES.history}?view=recent`

/** The supplier's visit: what sold and what goes back. A page, because it
 *  carries a row per line plus the counter's own figures to check against. */
export function settleDelivery(deliveryId: number): string {
  return `${delivery(deliveryId)}/settle`
}

/** Walking the shelves and typing what is actually on them. */
export const STOCK_COUNT = `${ROUTES.stock}/count`

/** Typing what each product COSTS, without which every profit figure is fiction. */
export const STOCK_COSTS = `${ROUTES.stock}/costs`

/** One consignment: what arrived, at what cost, and what is still owed. */
export function delivery(deliveryId: number): string {
  return `${ROUTES.deliveries}/${deliveryId}`
}
