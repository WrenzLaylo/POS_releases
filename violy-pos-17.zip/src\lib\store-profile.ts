/**
 * Shaping the shop's identity for print.
 *
 * The values live in the database and are edited on the Settings screen — see
 * `src/server/store-profile.ts`. This module is the pure half: it decides what
 * appears on a document and in what order, and nothing here touches Prisma, so
 * it can be unit-tested directly.
 *
 * The rule it exists to hold in ONE place: an unsupplied field is OMITTED from
 * the printed document, never printed blank and never printed as a
 * placeholder. A wrong TIN that looks real is worse than no TIN at all,
 * because nobody re-checks a field that already appears filled in. A document
 * formatted at each call site would have to remember that rule five times, and
 * the first one to forget prints an empty "TIN:" where a number belongs.
 */

/** The subset of the stored row this module reads. */
export type StoreIdentity = {
  name: string
  tagline: string
  registeredName: string
  addressLine1: string
  addressLine2: string
  contactNumber: string
  email: string
  tin: string
  businessRegistrationNo: string
}

export function isSupplied(value: string | null | undefined): boolean {
  return typeof value === 'string' && value.trim() !== ''
}

export type IdentityLine = { label: string | null; value: string }

/** The identity block, with every unsupplied field dropped. */
export function storeProfileLines(profile: StoreIdentity): IdentityLine[] {
  const lines: IdentityLine[] = []

  // Only worth printing when it differs — otherwise it is the same name twice.
  if (isSupplied(profile.registeredName) && profile.registeredName.trim() !== profile.name.trim()) {
    lines.push({ label: null, value: profile.registeredName.trim() })
  }
  for (const line of [profile.addressLine1, profile.addressLine2]) {
    if (isSupplied(line)) lines.push({ label: null, value: line.trim() })
  }
  if (isSupplied(profile.contactNumber)) {
    lines.push({ label: 'Tel', value: profile.contactNumber.trim() })
  }
  if (isSupplied(profile.email)) lines.push({ label: 'Email', value: profile.email.trim() })
  if (isSupplied(profile.tin)) lines.push({ label: 'TIN', value: profile.tin.trim() })
  if (isSupplied(profile.businessRegistrationNo)) {
    lines.push({ label: 'Reg. No.', value: profile.businessRegistrationNo.trim() })
  }

  return lines
}

/** Whether anything beyond the trading name has been filled in yet. */
export function hasStoreIdentity(profile: StoreIdentity): boolean {
  return storeProfileLines(profile).length > 0
}
