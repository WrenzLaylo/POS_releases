'use server'

import { prisma } from '@/lib/db'
import { addDays, startOfDay } from '@/lib/dates'
import type { DeliveryOrderRow } from '@/lib/types'

/**
 * Reading back what has been booked to go out.
 *
 * Its own file rather than a corner of `deliveries.ts`, which is the OPPOSITE
 * direction — stock arriving from a supplier. Two queries with the word
 * "delivery" in them, in one file, meaning different things, is how somebody
 * eventually joins the wrong one.
 *
 * Read-only throughout: nothing here writes, so there is no revalidation
 * concern in this file at all. A delivery order is created by `createOrder`
 * (`orders.ts`) and by nothing else.
 *
 * Every query filters `isVoided: false`. A voided delivery order is a load
 * that is not going anywhere, and leaving it on a list of what to load onto
 * the truck is worse than leaving it off — the void is exactly the thing the
 * driver needs to have been told.
 */

/** Sales that are delivery orders. `deliverAt` is what makes one. */
const IS_DELIVERY_ORDER = { deliverAt: { not: null }, isVoided: false } as const

const ROW_SHAPE = {
  id: true,
  createdAt: true,
  deliverAt: true,
  deliverTo: true,
  deliverAddress: true,
  deliveryInstructions: true,
  deliveryFeeCentavos: true,
  totalAmount: true,
  cashPaidCentavos: true,
  customer: { select: { id: true, name: true, phone: true } },
  items: { select: { quantity: true, product: { select: { name: true, unit: true } } } },
} as const

type Loaded = {
  id: number
  createdAt: Date
  deliverAt: Date | null
  deliverTo: string
  deliverAddress: string
  deliveryInstructions: string
  deliveryFeeCentavos: number
  totalAmount: number
  cashPaidCentavos: number
  customer: { id: number; name: string; phone: string | null } | null
  items: { quantity: number; product: { name: string; unit: string } }[]
}

function toRow(sale: Loaded): DeliveryOrderRow {
  return {
    saleId: sale.id,
    customerId: sale.customer?.id ?? null,
    customerName: sale.customer?.name ?? 'Customer',
    phone: sale.customer?.phone ?? null,
    // Non-null by construction: every caller filters on `deliverAt`. The
    // fallback exists so the type is honest rather than asserted away.
    deliverAt: sale.deliverAt ?? sale.createdAt,
    deliverTo: sale.deliverTo,
    deliverAddress: sale.deliverAddress,
    instructions: sale.deliveryInstructions,
    totalCentavos: sale.totalAmount,
    deliveryFeeCentavos: sale.deliveryFeeCentavos,
    // What is still owed on it. The question asked at the gate is "does he
    // owe anything on this load", and it is the same arithmetic the sale
    // screen does.
    owedCentavos: Math.max(0, sale.totalAmount - sale.cashPaidCentavos),
    lines: sale.items.map((item) => ({
      name: item.product.name,
      unit: item.product.unit,
      quantity: item.quantity,
    })),
  }
}

/**
 * Everything booked, split at today.
 *
 * `upcoming` runs forwards — the nearest load first, because that is the one
 * being packed. `past` runs backwards, newest first, because looking at it is
 * always "where did last week's one go".
 *
 * `past` is capped. The full history of delivery orders is reachable through
 * the Recent tab's Kind filter, which paginates; this list exists to answer
 * "what is going out", and an unbounded tail would eventually bury the part
 * that does.
 */
export async function listDeliveryOrders(
  now: Date = new Date(),
  pastLimit = 30,
): Promise<{ upcoming: DeliveryOrderRow[]; past: DeliveryOrderRow[] }> {
  const today = startOfDay(now)

  const [upcoming, past] = await Promise.all([
    prisma.sale.findMany({
      where: { ...IS_DELIVERY_ORDER, deliverAt: { gte: today } },
      select: ROW_SHAPE,
      orderBy: [{ deliverAt: 'asc' }, { id: 'asc' }],
    }),
    prisma.sale.findMany({
      where: { ...IS_DELIVERY_ORDER, deliverAt: { lt: today } },
      select: ROW_SHAPE,
      orderBy: [{ deliverAt: 'desc' }, { id: 'desc' }],
      take: pastLimit,
    }),
  ])

  return { upcoming: upcoming.map(toRow), past: past.map(toRow) }
}

/**
 * What is going out TODAY, for the notification bell.
 *
 * Today only, not "today and overdue". A delivery has no equivalent of an
 * overdue account — the day passes and the load either went or it did not,
 * and this app has no way to know which. Reporting yesterday's as outstanding
 * would be asserting something nobody told it.
 */
export async function listDeliveriesToday(now: Date = new Date()): Promise<DeliveryOrderRow[]> {
  const today = startOfDay(now)

  const rows = await prisma.sale.findMany({
    where: { ...IS_DELIVERY_ORDER, deliverAt: { gte: today, lt: addDays(today, 1) } },
    select: ROW_SHAPE,
    orderBy: [{ id: 'asc' }],
  })
  return rows.map(toRow)
}

/**
 * The next few days, for the Dashboard panel.
 *
 * From today rather than from tomorrow: at eight in the morning, today's load
 * is the most urgent thing on the list, not something already handled.
 */
export async function listDeliveriesAhead(
  days = 7,
  now: Date = new Date(),
  limit = 5,
): Promise<DeliveryOrderRow[]> {
  const today = startOfDay(now)

  const rows = await prisma.sale.findMany({
    where: { ...IS_DELIVERY_ORDER, deliverAt: { gte: today, lt: addDays(today, days) } },
    select: ROW_SHAPE,
    orderBy: [{ deliverAt: 'asc' }, { id: 'asc' }],
    take: limit,
  })
  return rows.map(toRow)
}

/** How many are booked from today onward, so a panel showing five can say
 *  there are eleven. */
export async function countDeliveriesAhead(now: Date = new Date()): Promise<number> {
  return prisma.sale.count({
    where: { ...IS_DELIVERY_ORDER, deliverAt: { gte: startOfDay(now) } },
  })
}
