import { describe, it, expect, beforeEach } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'
import { createOrder, listOrdersForDay } from '@/server/orders'
import { createSale } from '@/server/sales'
import { getBalance, setOpeningBalance } from '@/server/ledger'

beforeEach(resetDb)

async function makeProduct(overrides: Partial<{
  name: string
  price: number
  costPrice: number
  stockQty: number
  isArchived: boolean
  categoryId: number
}> = {}) {
  let categoryId = overrides.categoryId
  if (categoryId === undefined) {
    const category = await prisma.category.upsert({
      where: { name: 'Pig Feeds' },
      create: { name: 'Pig Feeds' },
      update: {},
    })
    categoryId = category.id
  }
  return prisma.product.create({
    data: {
      categoryId,
      name: overrides.name ?? 'Starter (sako)',
      unit: 'sako (50kg)',
      price: overrides.price ?? 157500,
      costPrice: overrides.costPrice ?? 145000,
      stockQty: overrides.stockQty ?? 20,
      lowStockThreshold: 5,
      isArchived: overrides.isArchived ?? false,
    },
  })
}

async function makeCustomer(name = 'ROMAN') {
  return prisma.customer.create({ data: { name } })
}

describe('createOrder', () => {
  it('writes the sale, items, stock deduction, and charge together', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer()

    const result = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 5 }],
      cashPaidCentavos: 0,
    })

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.totalCentavos).toBe(787500)
    expect(result.data.chargedCentavos).toBe(787500)

    const sale = await prisma.sale.findUniqueOrThrow({
      where: { id: result.data.saleId },
      include: { items: true },
    })
    expect(sale.customerId).toBe(customer.id)
    expect(sale.cashPaidCentavos).toBe(0)
    expect(sale.items).toHaveLength(1)
    expect(sale.items[0].priceAtSale).toBe(157500)
    expect(sale.items[0].costAtSale).toBe(145000)

    const after = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
    expect(after.stockQty).toBe(15)

    expect(await getBalance(customer.id)).toBe(787500)
  })

  it('writes no ledger entry when cash covers the order', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer()

    const result = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 2 }],
      cashPaidCentavos: 315000,
    })

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.chargedCentavos).toBe(0)
    expect(await prisma.ledgerEntry.count()).toBe(0)
    expect(await getBalance(customer.id)).toBe(0)
  })

  it('charges only the unpaid difference on a part-cash order', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer()

    const result = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 2 }],
      cashPaidCentavos: 100000,
    })

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.chargedCentavos).toBe(215000)

    const entries = await prisma.ledgerEntry.findMany()
    expect(entries).toHaveLength(1)
    expect(entries[0].type).toBe('CHARGE')
    expect(entries[0].amountCentavos).toBe(215000)
    expect(entries[0].saleId).toBe(result.data.saleId)
    expect(await getBalance(customer.id)).toBe(215000)
  })

  it('writes no ledger entry when cash exceeds the order', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer()

    const result = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 1 }],
      cashPaidCentavos: 200000,
    })

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.chargedCentavos).toBe(0)
    expect(await prisma.ledgerEntry.count()).toBe(0)

    // Cash above the total is change handed back, not money the drawer
    // kept — the stored figure must be the order total, not the 200000
    // tendered, or a downstream sum of this column overstates the till.
    const sale = await prisma.sale.findUniqueOrThrow({ where: { id: result.data.saleId } })
    expect(sale.cashPaidCentavos).toBe(result.data.totalCentavos)
  })

  it('merges duplicate lines so stock is decremented once', async () => {
    const product = await makeProduct({ stockQty: 20 })
    const customer = await makeCustomer()

    const result = await createOrder({
      customerId: customer.id,
      lines: [
        { productId: product.id, quantity: 2 },
        { productId: product.id, quantity: 3 },
      ],
      cashPaidCentavos: 0,
    })

    expect(result.ok).toBe(true)
    if (!result.ok) return
    const sale = await prisma.sale.findUniqueOrThrow({
      where: { id: result.data.saleId },
      include: { items: true },
    })
    expect(sale.items).toHaveLength(1)
    expect(sale.items[0].quantity).toBe(5)

    const after = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
    expect(after.stockQty).toBe(15)
  })

  it('totals as the sum of rounded line totals, not the rounded sum', async () => {
    // price 157500 * quantity 0.333 = 52447.5 exactly. Rounded per line
    // and summed: 52448 + 52448 = 104896. Summed first and rounded once:
    // round(104895.0) = 104895. Two distinct products so the duplicate-line
    // merge (which sums quantities before pricing) can't collapse this back
    // into a single rounding step.
    const productA = await makeProduct({ name: 'Starter A (sako)', price: 157500, stockQty: 1 })
    const productB = await makeProduct({ name: 'Starter B (sako)', price: 157500, stockQty: 1 })
    const customer = await makeCustomer()

    const result = await createOrder({
      customerId: customer.id,
      lines: [
        { productId: productA.id, quantity: 0.333 },
        { productId: productB.id, quantity: 0.333 },
      ],
      cashPaidCentavos: 0,
    })

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.totalCentavos).toBe(104896)
    expect(result.data.totalCentavos).not.toBe(104895)

    const afterA = await prisma.product.findUniqueOrThrow({ where: { id: productA.id } })
    const afterB = await prisma.product.findUniqueOrThrow({ where: { id: productB.id } })
    expect(afterA.stockQty).toBeCloseTo(0.667, 6)
    expect(afterB.stockQty).toBeCloseTo(0.667, 6)
  })

  it('reads prices from the database, not from the caller', async () => {
    const product = await makeProduct({ price: 157500 })
    const customer = await makeCustomer()
    await prisma.product.update({ where: { id: product.id }, data: { price: 160000 } })

    const result = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 1 }],
      cashPaidCentavos: 0,
    })

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.totalCentavos).toBe(160000)
  })

  it('lets stock go negative', async () => {
    const product = await makeProduct({ stockQty: 2 })
    const customer = await makeCustomer()

    const result = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 5 }],
      cashPaidCentavos: 0,
    })

    expect(result.ok).toBe(true)
    const after = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
    expect(after.stockQty).toBe(-3)
  })

  it('refuses an order with no lines', async () => {
    const customer = await makeCustomer()

    const result = await createOrder({
      customerId: customer.id,
      lines: [],
      cashPaidCentavos: 0,
    })

    expect(result.ok).toBe(false)
    expect(await prisma.sale.count()).toBe(0)
  })

  it('refuses an order with no customer', async () => {
    const product = await makeProduct()

    const result = await createOrder({
      customerId: 9999,
      lines: [{ productId: product.id, quantity: 1 }],
      cashPaidCentavos: 0,
    })

    expect(result.ok).toBe(false)
    expect(await prisma.sale.count()).toBe(0)
  })

  it('refuses an order for an archived customer', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer()
    await prisma.customer.update({ where: { id: customer.id }, data: { isArchived: true } })

    const result = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 1 }],
      cashPaidCentavos: 0,
    })

    expect(result.ok).toBe(false)
    expect(await prisma.sale.count()).toBe(0)
  })

  it('refuses an order containing an archived product', async () => {
    const product = await makeProduct({ isArchived: true })
    const customer = await makeCustomer()

    const result = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 1 }],
      cashPaidCentavos: 0,
    })

    expect(result.ok).toBe(false)
    if (result.ok) return
    expect(result.error).toContain('Starter (sako)')
    expect(await prisma.sale.count()).toBe(0)
  })

  it('refuses a negative cash amount', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer()

    const result = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 1 }],
      cashPaidCentavos: -100,
    })

    expect(result.ok).toBe(false)
    expect(await prisma.sale.count()).toBe(0)
  })

  it('refuses a fractional-centavo cash amount', async () => {
    // ledger.ts rejects non-integer amounts outright (Number.isInteger);
    // orders.ts must hold the same house rule rather than silently rounding.
    const product = await makeProduct()
    const customer = await makeCustomer()

    const result = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 1 }],
      cashPaidCentavos: 100.5,
    })

    expect(result.ok).toBe(false)
    expect(await prisma.sale.count()).toBe(0)
  })

  it('rolls back the sale, the items, the stock, and the charge together', async () => {
    const product = await makeProduct({ stockQty: 10 })
    const customer = await makeCustomer()

    // A real DB-level failure part-way through the transaction. Rejecting an
    // argument before the writes begin would prove nothing about rollback.
    await prisma.$executeRawUnsafe(
      `CREATE TRIGGER reject_extreme_stock BEFORE UPDATE ON "Product"
       WHEN NEW."stockQty" < -100
       BEGIN SELECT RAISE(ABORT, 'stock floor breached'); END;`,
    )

    try {
      const result = await createOrder({
        customerId: customer.id,
        lines: [{ productId: product.id, quantity: 200 }],
        cashPaidCentavos: 0,
      })

      expect(result.ok).toBe(false)
      expect(await prisma.sale.count()).toBe(0)
      expect(await prisma.saleItem.count()).toBe(0)
      expect(await prisma.ledgerEntry.count()).toBe(0)

      const after = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
      expect(after.stockQty).toBe(10)
      expect(await getBalance(customer.id)).toBe(0)
    } finally {
      await prisma.$executeRawUnsafe('DROP TRIGGER IF EXISTS reject_extreme_stock')
    }
  })

  it('rolls back the sale, the items, and the stock when the ledger insert fails', async () => {
    // The previous rollback test's trigger fires on the Product UPDATE,
    // which happens before any ledger insert is attempted — so it cannot
    // prove the ledger write participates in the same rollback. This
    // trigger instead aborts on the LAST write in the transaction (the
    // LedgerEntry insert), so a pass here proves the Sale, the SaleItem
    // rows, and the stock decrement all roll back behind it too.
    const product = await makeProduct({ stockQty: 10, price: 157500 })
    const customer = await makeCustomer()

    await prisma.$executeRawUnsafe(
      `CREATE TRIGGER reject_huge_charge BEFORE INSERT ON "LedgerEntry"
       WHEN NEW."amountCentavos" > 10000000
       BEGIN SELECT RAISE(ABORT, 'charge too large'); END;`,
    )

    try {
      const result = await createOrder({
        customerId: customer.id,
        // 157500 * 100 = 15,750,000 centavos charged — over the trigger's
        // 10,000,000 threshold.
        lines: [{ productId: product.id, quantity: 100 }],
        cashPaidCentavos: 0,
      })

      expect(result.ok).toBe(false)
      expect(await prisma.sale.count()).toBe(0)
      expect(await prisma.saleItem.count()).toBe(0)
      expect(await prisma.ledgerEntry.count()).toBe(0)

      const after = await prisma.product.findUniqueOrThrow({ where: { id: product.id } })
      expect(after.stockQty).toBe(10)
      expect(await getBalance(customer.id)).toBe(0)
    } finally {
      await prisma.$executeRawUnsafe('DROP TRIGGER IF EXISTS reject_huge_charge')
    }
  })
})

describe('listOrdersForDay', () => {
  it('returns only that day’s orders, newest first, with their lines', async () => {
    const product = await makeProduct({ name: 'Brood Sow (sako)' })
    const customer = await makeCustomer('ROMAN')

    await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 5 }],
      cashPaidCentavos: 0,
    })

    // Yesterday's order must not appear.
    await prisma.sale.create({
      data: {
        totalAmount: 1000,
        customerId: customer.id,
        createdAt: new Date('2026-07-27T09:00:00'),
      },
    })

    const orders = await listOrdersForDay(new Date())

    expect(orders).toHaveLength(1)
    expect(orders[0].customerName).toBe('ROMAN')
    expect(orders[0].totalCentavos).toBe(787500)
    expect(orders[0].lines).toEqual([
      { name: 'Brood Sow (sako)', unit: 'sako (50kg)', quantity: 5 },
    ])
  })

  it('orders same-day sales newest first, tiebroken by id', async () => {
    const product = await makeProduct({ name: 'Brood Sow (sako)' })
    const customer = await makeCustomer('ROMAN')

    const first = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 1 }],
      cashPaidCentavos: 0,
    })
    const second = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 2 }],
      cashPaidCentavos: 0,
    })
    expect(first.ok).toBe(true)
    expect(second.ok).toBe(true)
    if (!first.ok || !second.ok) return

    const orders = await listOrdersForDay(new Date())

    expect(orders).toHaveLength(2)
    expect(orders[0].saleId).toBe(second.data.saleId)
    expect(orders[1].saleId).toBe(first.data.saleId)
  })

  it('includes cash walk-in sales that have no customer', async () => {
    await prisma.sale.create({ data: { totalAmount: 42000, cashPaidCentavos: 42000 } })

    const orders = await listOrdersForDay(new Date())

    expect(orders).toHaveLength(1)
    expect(orders[0].customerName).toBeNull()
  })
})


describe('createOrder checkout safety', () => {
  it('treats null cash as exact cash against the authoritative total', async () => {
    const product = await makeProduct({ price: 100000 })
    const customer = await makeCustomer('EXACT CASH')
    const result = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 1 }],
      cashPaidCentavos: null,
      clientOrderKey: 'customer-exact-cash-test',
    })

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.cashPaidCentavos).toBe(100000)
    expect(result.data.cashTenderedCentavos).toBe(100000)
    expect(result.data.changeCentavos).toBe(0)
    expect(result.data.chargedCentavos).toBe(0)
  })

  it('stores the balance immediately after a credit order', async () => {
    const product = await makeProduct({ price: 100000 })
    const customer = await makeCustomer('BALANCE SNAPSHOT')
    await setOpeningBalance({
      customerId: customer.id,
      amountCentavos: 30000,
      occurredAt: new Date(),
    })

    const result = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 1 }],
      cashPaidCentavos: 40000,
      clientOrderKey: 'customer-balance-test',
    })

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.chargedCentavos).toBe(60000)
    expect(result.data.newBalanceCentavos).toBe(90000)

    const sale = await prisma.sale.findUniqueOrThrow({ where: { id: result.data.saleId } })
    expect(sale.customerBalanceAfterCentavos).toBe(90000)
  })

  it('does not duplicate a customer order when the request is retried', async () => {
    const product = await makeProduct({ price: 100000, stockQty: 10 })
    const customer = await makeCustomer('IDEMPOTENT')
    const input = {
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 2 }],
      cashPaidCentavos: 0,
      clientOrderKey: 'customer-idempotency-test',
    }

    const first = await createOrder(input)
    const second = await createOrder(input)

    expect(first.ok && second.ok).toBe(true)
    if (!first.ok || !second.ok) return
    expect(second.data.saleId).toBe(first.data.saleId)
    expect(await prisma.sale.count()).toBe(1)
    expect(await prisma.ledgerEntry.count()).toBe(1)
    expect((await prisma.product.findUniqueOrThrow({ where: { id: product.id } })).stockQty).toBe(8)
  })
})

// `createOrder discounts` covered the standing per-customer rate, removed on
// 24 Aug 2026. What a discount does now is covered below and in
// `lib/discount.test.ts`; what past sales were charged is a snapshot on the
// row and is not recomputed.

describe('createOrder, a discount typed against one line', () => {
  async function makeCategory(name: string, sortOrder: number) {
    return prisma.category.create({ data: { name, sortOrder } })
  }

  it('snapshots the typed figure as that line’s discount', async () => {
    const product = await makeProduct({ price: 157500 })
    const customer = await makeCustomer()

    const result = await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 2, discountPerUnitCentavos: 7500 }],
      cashPaidCentavos: 0,
    })

    expect(result.ok).toBe(true)
    if (!result.ok) return
    // 2 x (1575 - 75) = 3000
    expect(result.data.totalCentavos).toBe(300000)

    const sale = await prisma.sale.findUniqueOrThrow({
      where: { id: result.data.saleId },
      include: { items: true },
    })
    expect(sale.items[0].discountAtSale).toBe(7500)
  })

  it('refuses a line discount that is not a whole, non-negative amount', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer()

    for (const bad of [-1, 12.5, Number.NaN]) {
      const result = await createOrder({
        customerId: customer.id,
        lines: [{ productId: product.id, quantity: 1, discountPerUnitCentavos: bad }],
        cashPaidCentavos: 0,
      })
      expect(result.ok).toBe(false)
    }
    // Nothing was written by any of the three.
    expect(await prisma.sale.count()).toBe(0)
  })
})

describe('createOrder due dates', () => {
  it('assigns 30 days when an order first puts money on the account', async () => {
    const product = await makeProduct()
    const customer = await makeCustomer()

    await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 1 }],
      cashPaidCentavos: 0,
      occurredAt: new Date(2026, 7, 3, 15),
    })

    const after = await prisma.customer.findUniqueOrThrow({ where: { id: customer.id } })
    expect(after.dueAt).toEqual(new Date(2026, 8, 2))
  })

  it('does not move an existing due date when the customer buys again', async () => {
    const product = await makeProduct({ stockQty: 10 })
    const dueAt = new Date(2026, 7, 20)
    const customer = await prisma.customer.create({ data: { name: 'NENA', dueAt } })
    await prisma.ledgerEntry.create({
      data: {
        customerId: customer.id,
        type: 'OPENING',
        amountCentavos: 50000,
        occurredAt: new Date(2026, 6, 20),
      },
    })

    await createOrder({
      customerId: customer.id,
      lines: [{ productId: product.id, quantity: 1 }],
      cashPaidCentavos: 0,
      occurredAt: new Date(2026, 7, 10),
    })

    const after = await prisma.customer.findUniqueOrThrow({ where: { id: customer.id } })
    expect(after.dueAt).toEqual(dueAt)
  })
})
