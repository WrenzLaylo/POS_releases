'use client'

import { useMemo, useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import type { ProductWithCategory } from '@/lib/types'
import { recordStockCount } from '@/server/stock-count'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { EmptyState } from '@/components/ui/EmptyState'
import { Field } from '@/components/ui/Field'
import { FilterChips } from '@/components/ui/FilterChips'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'
import { cn } from '@/lib/cn'

/** A count is a shelf tally, so `18.5` has to be typeable — but nothing else. */
function parseCount(raw: string): number | null {
  const trimmed = raw.trim()
  if (trimmed === '') return null
  if (!/^\d+(\.\d+)?$/.test(trimmed)) return null
  const value = Number(trimmed)
  return Number.isFinite(value) ? value : null
}

/**
 * Walking the shelves once and typing what is actually there.
 *
 * The shop had no way to say where stock STARTED. Every product read 0, so the
 * counter drove them negative as sales went through, and the only fix on offer
 * was opening each product's edit dialog in turn — fifty-five dialogs, which is
 * not a thing anybody does. She reached for "record a delivery" instead, which
 * is the wrong tool: it books a debt to a supplier and rewrites the cost price,
 * and it only touched the three lines she typed while the other fifty-two
 * stayed at zero. That is why it looked like the delivery had not worked.
 *
 * The rows are the products, filtered by brand, and every box starts EMPTY
 * rather than pre-filled with the current figure. A pre-filled grid cannot tell
 * "I counted this and it was 12" from "I never got to this shelf" — and on a
 * first count, where almost everything is wrong, that difference is the whole
 * point. Blank means untouched and is left exactly as it was.
 *
 * Same shape as `BulkPaymentGrid` deliberately: one screen, one column of
 * boxes, one Save. She has already learned it for collections.
 */
export function StockCountGrid({ products }: { products: ProductWithCategory[] }) {
  const router = useRouter()
  const [filter, setFilter] = useState('')
  const [category, setCategory] = useState('')
  /** productId → what she typed. Absent means this shelf was not counted. */
  const [counts, setCounts] = useState<Map<number, string>>(new Map())
  const [error, setError] = useState<string | null>(null)
  const [summary, setSummary] = useState<string | null>(null)
  const [pending, startTransition] = useTransition()

  const categories = useMemo(() => {
    const names = new Map<number, string>()
    for (const product of products) names.set(product.categoryId, product.category.name)
    return [
      { value: '', label: 'All brands' },
      ...[...names].map(([id, name]) => ({ value: String(id), label: name })),
    ]
  }, [products])

  const visible = useMemo(() => {
    const needle = filter.trim().toLowerCase()
    return products.filter((product) => {
      if (category !== '' && String(product.categoryId) !== category) return false
      if (needle !== '' && !product.name.toLowerCase().includes(needle)) return false
      return true
    })
  }, [products, filter, category])

  // Counted across the WHOLE catalogue, not just what the filter is showing.
  // She counts one brand, filters to the next, and the figure must not appear
  // to reset — it is one count, not one per screen.
  const entered = [...counts.entries()]
    .map(([productId, raw]) => ({ productId, value: parseCount(raw) }))
    .filter((row) => row.value !== null)
  const invalid = [...counts.values()].some((raw) => raw.trim() !== '' && parseCount(raw) === null)

  function setCount(productId: number, raw: string) {
    setSummary(null)
    setCounts((previous) => {
      const next = new Map(previous)
      // An emptied box means "not counted", not "counted zero" — so it is
      // removed rather than kept as a blank string.
      if (raw.trim() === '') next.delete(productId)
      else next.set(productId, raw)
      return next
    })
  }

  function save() {
    setError(null)
    setSummary(null)

    if (invalid) {
      setError('One of the counts is not a number. Check the boxes outlined in red.')
      return
    }
    if (entered.length === 0) {
      setError('Type at least one count before saving.')
      return
    }

    startTransition(async () => {
      const result = await recordStockCount(
        entered.map((row) => ({ productId: row.productId, countedQty: row.value as number })),
      )
      if (!result.ok) {
        setError(result.error)
        return
      }
      // The boxes clear only on success. After a failure everything she typed
      // is still on screen to try again — a stock take is too much work to ask
      // her to redo because a save did not land.
      setCounts(new Map())
      setSummary(
        result.data.changed === 0
          ? 'Everything you counted already matched. Nothing changed.'
          : `Saved. ${result.data.changed} product${result.data.changed === 1 ? '' : 's'} updated.`,
      )
      router.refresh()
    })
  }

  return (
    <Card>
      <div className="mb-4 flex flex-wrap items-end justify-between gap-4">
        <div className="flex flex-wrap items-end gap-4">
          <FilterChips
            label="Brand"
            ariaLabel="Filter by brand"
            options={categories}
            value={category}
            onChange={setCategory}
          />
          <Field label="Find a product">
            <Input
              type="search"
              value={filter}
              onChange={(event) => setFilter(event.target.value)}
              placeholder="Product name"
              className="w-56"
            />
          </Field>
        </div>

        <div className="flex items-end gap-4">
          <div className="text-right">
            <div className="text-xs font-semibold uppercase tracking-wide text-ink-muted">
              Counted
            </div>
            <div className="font-mono text-base font-medium text-ink">
              {entered.length}
              <span className="text-sm text-ink-subtle"> of {products.length}</span>
            </div>
          </div>
          {/* Disabled only when nothing at all has been typed — NOT when what
              was typed fails to parse. A junk value would otherwise leave a
              dead button and no explanation of why; `save` refuses it in
              words instead, and points at the box. */}
          <Button variant="success" onClick={save} disabled={pending || counts.size === 0}>
            {pending ? 'Saving…' : 'Save count'}
          </Button>
        </div>
      </div>

      {error && <FormError className="mb-3">{error}</FormError>}
      {summary && (
        <p className="mb-3 rounded-control border border-line bg-surface-sunk px-4 py-3 text-sm text-ink">
          {summary}
        </p>
      )}

      {visible.length === 0 ? (
        <EmptyState>No products match that filter.</EmptyState>
      ) : (
        <div className="overflow-hidden rounded-card border border-line">
          <table className="w-full text-sm">
            <thead className="bg-surface-sunk text-left text-xs uppercase tracking-wide text-ink-muted">
              <tr>
                <th className="px-4 py-3 font-medium">Product</th>
                <th className="px-4 py-3 font-medium">Brand</th>
                <th className="px-4 py-3 text-right font-medium">App says</th>
                <th className="px-4 py-3 text-right font-medium">Counted</th>
                <th className="px-4 py-3 text-right font-medium">Difference</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {visible.map((product) => {
                const raw = counts.get(product.id) ?? ''
                const value = parseCount(raw)
                const bad = raw.trim() !== '' && value === null
                const delta = value === null ? null : value - product.stockQty

                return (
                  <tr key={product.id} className={cn(raw.trim() !== '' && 'bg-accent-soft/40')}>
                    <td className="px-4 py-2">
                      <div className="font-medium text-ink">{product.name}</div>
                      <div className="text-xs text-ink-subtle">{product.unit}</div>
                    </td>
                    <td className="px-4 py-2 text-ink-muted">{product.category.name}</td>
                    <td
                      className={cn(
                        'px-4 py-2 text-right font-mono',
                        // Negative stock is the symptom she is here to fix, so
                        // it is called out rather than left to blend in.
                        product.stockQty < 0 ? 'text-warn' : 'text-ink-muted',
                      )}
                    >
                      {product.stockQty}
                    </td>
                    <td className="px-4 py-2 text-right">
                      <Input
                        inputMode="decimal"
                        value={raw}
                        onChange={(event) => setCount(product.id, event.target.value)}
                        placeholder="—"
                        aria-label={`Counted stock for ${product.name}`}
                        aria-invalid={bad || undefined}
                        disabled={pending}
                        className={cn('w-28 text-right tabular-nums', bad && 'border-owed')}
                      />
                    </td>
                    <td className="px-4 py-2 text-right font-mono text-sm">
                      {delta === null || delta === 0 ? (
                        <span className="text-ink-subtle">—</span>
                      ) : (
                        <span className={delta > 0 ? 'text-money-in' : 'text-owed'}>
                          {delta > 0 ? '+' : ''}
                          {delta}
                        </span>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}

      <p className="mt-4 text-xs text-ink-subtle">
        Leave a box empty for anything you did not count — it stays exactly as it is. Saving the
        same count twice is safe: this sets the stock to what you typed rather than adding to it.
      </p>
    </Card>
  )
}
