@echo off
REM Starts the Violy Store POS and opens it in the browser.
REM
REM The updater re-invokes this file by name after installing, so that the app
REM comes back the same way it is normally started. Renaming it means an update
REM finishes and nothing reopens.
cd /d "%~dp0"
start "" http://localhost:3000
npm start
