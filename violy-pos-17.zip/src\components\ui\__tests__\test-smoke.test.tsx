// @vitest-environment jsdom

import { render, screen } from '@testing-library/react'
import { describe, expect, it } from 'vitest'

describe('DOM test infrastructure', () => {
  it('renders an accessible button', () => {
    render(<button type="button">Save order</button>)

    expect(screen.getByRole('button', { name: 'Save order' })).toBeInTheDocument()
  })

  it('starts each test with a clean document', () => {
    expect(screen.queryByRole('button', { name: 'Save order' })).not.toBeInTheDocument()
  })
})
