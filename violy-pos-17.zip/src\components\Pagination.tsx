import Link from 'next/link'

/**
 * Paging is links, not buttons: the browser back button then works, and a
 * filtered page survives a refresh. Every other query parameter is carried
 * through so paging never silently drops a filter.
 */
export function Pagination({
  page,
  pageCount,
  params,
}: {
  page: number
  pageCount: number
  params: Record<string, string | undefined>
}) {
  if (pageCount <= 1) return null

  function hrefFor(target: number): string {
    const query = new URLSearchParams()
    for (const [key, value] of Object.entries(params)) {
      if (value) query.set(key, value)
    }
    query.set('page', String(target))
    return `?${query.toString()}`
  }

  const atFirst = page <= 1
  const atLast = page >= pageCount

  const base =
    'inline-flex h-10 items-center rounded-lg border border-line-strong px-4 text-sm font-medium transition-colors duration-150'

  return (
    <nav className="mt-4 flex items-center justify-between gap-4">
      {atFirst ? (
        <span aria-disabled="true" className={`${base} border-line text-ink-subtle`}>
          Previous
        </span>
      ) : (
        <Link href={hrefFor(page - 1)} className={`${base} hover:bg-surface-sunk`}>
          Previous
        </Link>
      )}

      <span className="text-sm font-mono tabular-nums text-ink-muted">
        Page {page} of {pageCount}
      </span>

      {atLast ? (
        <span aria-disabled="true" className={`${base} border-line text-ink-subtle`}>
          Next
        </span>
      ) : (
        <Link href={hrefFor(page + 1)} className={`${base} hover:bg-surface-sunk`}>
          Next
        </Link>
      )}
    </nav>
  )
}
