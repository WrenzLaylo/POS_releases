-- When this laptop last proved it was still her.
--
-- Additive and nullable: existing sessions simply have no confirmation, which
-- means the next dangerous action asks. That is the safe direction.
ALTER TABLE "AppSession" ADD COLUMN "confirmedAt" DATETIME;
