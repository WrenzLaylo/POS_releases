/**
 * Cuts the brand assets out of the one supplied logo file.
 *
 * The source is a single wide lockup — a market-stall mark beside the words
 * "Violy Store" — on a transparent background. Three things need different
 * parts of it:
 *
 *   · the app icon needs the MARK alone, square. The wordmark is illegible
 *     below about 64px, and a taskbar button is 16.
 *   · the splash and printed documents want the whole lockup.
 *   · both want the surrounding transparent margin trimmed, or every place
 *     that uses them has to compensate for padding baked into the file.
 *
 * Bounds are MEASURED from the pixels rather than typed in, so re-exporting
 * the logo at a different size or with different margins still produces
 * correctly trimmed assets.
 *
 *   node scripts/make-brand.mjs [path-to-logo.png]
 */

import { mkdir, readFile, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { chromium } from 'playwright'

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..')
const SOURCE = process.argv[2] ?? path.join(ROOT, 'brand', 'violy-store-logo.png')
const OUT = path.join(ROOT, 'public', 'brand')

/** Breathing room around the trimmed art, as a fraction of its longest side. */
const PAD = 0.06

const bytes = await readFile(SOURCE)
const dataUrl = `data:image/png;base64,${bytes.toString('base64')}`

const browser = await chromium.launch()
const page = await browser.newPage()

/**
 * Where the art actually is.
 *
 * "Ink" is anything neither transparent nor near-white, so a white halo left
 * by an exporter does not count as part of the drawing. The gap search finds
 * the space between the mark and the wordmark: the widest empty column run is
 * where one ends and the other begins.
 */
const bounds = await page.evaluate(async (url) => {
  const img = new Image()
  img.src = url
  await img.decode()

  const canvas = document.createElement('canvas')
  canvas.width = img.naturalWidth
  canvas.height = img.naturalHeight
  const ctx = canvas.getContext('2d', { willReadFrequently: true })
  ctx.drawImage(img, 0, 0)
  const { data, width, height } = ctx.getImageData(0, 0, width_(canvas), height_(canvas))

  function width_(c) {
    return c.width
  }
  function height_(c) {
    return c.height
  }

  const inked = (x, y) => {
    const i = (y * width + x) * 4
    if (data[i + 3] < 16) return false
    return !(data[i] > 245 && data[i + 1] > 245 && data[i + 2] > 245)
  }

  let minX = width
  let minY = height
  let maxX = -1
  let maxY = -1
  const colHasInk = new Array(width).fill(false)
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      if (!inked(x, y)) continue
      colHasInk[x] = true
      if (x < minX) minX = x
      if (y < minY) minY = y
      if (x > maxX) maxX = x
      if (y > maxY) maxY = y
    }
  }

  let widest = null
  let runStart = null
  for (let x = minX; x <= maxX; x += 1) {
    if (!colHasInk[x]) {
      if (runStart === null) runStart = x
    } else if (runStart !== null) {
      const run = { from: runStart, to: x }
      if (!widest || run.to - run.from > widest.to - widest.from) widest = run
      runStart = null
    }
  }

  return { width, height, minX, minY, maxX, maxY, gap: widest }
}, dataUrl)

if (bounds.maxX < 0) throw new Error('That image has no visible artwork in it.')
if (!bounds.gap) throw new Error('Could not find the gap between the mark and the wordmark.')

const markBox = {
  x: bounds.minX,
  y: bounds.minY,
  width: bounds.gap.from - bounds.minX,
  height: bounds.maxY - bounds.minY,
}
const lockupBox = {
  x: bounds.minX,
  y: bounds.minY,
  width: bounds.maxX - bounds.minX,
  height: bounds.maxY - bounds.minY,
}

/**
 * Renders one crop, scaled to fit a box, on a transparent background.
 *
 * Drawn through CSS rather than a canvas so the browser's own high-quality
 * downscaling does the work — the same reason the icon sizes are each drawn
 * at their final size instead of one big one being squashed.
 */
async function crop(box, { width: outWidth, height: outHeight, square }) {
  const scale = square
    ? Math.min(outWidth / box.width, outHeight / box.height)
    : outWidth / box.width

  const drawnWidth = box.width * scale
  const drawnHeight = box.height * scale
  const offsetX = (outWidth - drawnWidth) / 2
  const offsetY = (outHeight - drawnHeight) / 2

  await page.setViewportSize({ width: Math.round(outWidth), height: Math.round(outHeight) })
  await page.setContent(`
    <style>
      html, body { margin: 0; padding: 0; background: transparent; }
      .frame {
        position: relative;
        width: ${outWidth}px;
        height: ${outHeight}px;
        overflow: hidden;
      }
      img {
        position: absolute;
        left: ${offsetX - box.x * scale}px;
        top: ${offsetY - box.y * scale}px;
        width: ${bounds.width * scale}px;
        height: ${bounds.height * scale}px;
      }
    </style>
    <div class="frame"><img src="${dataUrl}"></div>
  `)
  return page.screenshot({ omitBackground: true })
}

await mkdir(OUT, { recursive: true })

// The mark, square, with even padding — what every square slot wants.
const markSide = Math.round(Math.max(markBox.width, markBox.height) * (1 + PAD * 2))
await writeFile(
  path.join(OUT, 'violy-store-mark.png'),
  await crop(markBox, { width: markSide, height: markSide, square: true }),
)

// The full lockup, trimmed, at a size big enough to print sharply.
const lockupWidth = 1200
await writeFile(
  path.join(OUT, 'violy-store-logo.png'),
  await crop(lockupBox, {
    width: lockupWidth,
    height: Math.round((lockupBox.height / lockupBox.width) * lockupWidth),
  }),
)

await browser.close()

console.log(`Source ${bounds.width}x${bounds.height}`)
console.log(`  mark   ${markBox.width}x${markBox.height} at (${markBox.x}, ${markBox.y}) -> ${markSide}px square`)
console.log(`  lockup ${lockupBox.width}x${lockupBox.height} -> ${lockupWidth}px wide`)
console.log(`Wrote public/brand/violy-store-mark.png and violy-store-logo.png`)
