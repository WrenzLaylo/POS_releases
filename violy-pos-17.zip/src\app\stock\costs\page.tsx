import Link from 'next/link'
import { listProducts } from '@/server/products'
import { ROUTES } from '@/lib/routes'
import { PageHeader } from '@/components/ui/PageHeader'
import { CostPriceGrid } from './CostPriceGrid'

export const dynamic = 'force-dynamic'

/**
 * The second thing a shop has to do, and the second thing this app never let it
 * do in bulk — see `../count/page.tsx` for the first.
 *
 * `listProducts`, not `listAllProducts`: unarchived only, and deliberately
 * unpaged. This is one pass down the price list, and a grid that dropped what
 * she typed when it turned to page two would be worse than no grid.
 */
export default async function CostPricesPage() {
  const products = await listProducts()

  return (
    <PageHeader
      title="Cost prices"
      actions={
        <Link href={ROUTES.stock} className="text-sm font-medium text-ink-muted hover:text-ink">
          ← Back to stock
        </Link>
      }
    >
      <CostPriceGrid products={products} />
    </PageHeader>
  )
}
