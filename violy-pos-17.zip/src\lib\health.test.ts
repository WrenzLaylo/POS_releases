import { readFileSync } from 'node:fs'
import { join } from 'node:path'
import { describe, expect, it } from 'vitest'
import { HEALTH_APP_ID, HEALTH_PATH, healthProblemMessage, judgeHealth } from './health'

function body(overrides: Record<string, unknown> = {}) {
  return { app: HEALTH_APP_ID, mode: 'production', build: 14, version: '2026.08.24', ready: true, ...overrides }
}

describe('judgeHealth', () => {
  it('accepts a ready production POS', () => {
    expect(judgeHealth(body())).toEqual({ usable: true })
  })

  /**
   * The case the endpoint exists for. A TCP connect said "yes" to any of
   * these, and the shell would load whatever came back and present it as the
   * till.
   */
  it('refuses another program that happens to hold the port', () => {
    expect(judgeHealth({ status: 'ok' })).toEqual({ usable: false, reason: 'not-the-pos' })
    expect(judgeHealth({ app: 'something-else', ready: true, mode: 'production' })).toEqual({
      usable: false,
      reason: 'not-the-pos',
    })
  })

  it('refuses a body it cannot read at all', () => {
    for (const value of [null, undefined, 'ok', 42, []]) {
      // An array is an object but has no `app`, so it lands on not-the-pos —
      // either way it is refused, which is what matters.
      expect(judgeHealth(value).usable).toBe(false)
    }
  })

  /**
   * Silent and expensive: a packaged copy attached to `next dev` runs the shop
   * against whatever database and half-written code that server has, and looks
   * completely normal doing it.
   */
  it('refuses a development server unless asked explicitly', () => {
    expect(judgeHealth(body({ mode: 'development' }))).toEqual({
      usable: false,
      reason: 'development',
    })
    expect(judgeHealth(body({ mode: 'development' }), { allowDevelopment: true })).toEqual({
      usable: true,
    })
  })

  it('refuses a POS that says it is not ready', () => {
    expect(judgeHealth(body({ ready: false }))).toEqual({ usable: false, reason: 'not-ready' })
  })

  it('checks whose it is before whether it is ready', () => {
    // Otherwise a foreign program is reported as "still starting" and the
    // shell waits out its whole timeout instead of saying what is wrong.
    expect(judgeHealth({ app: 'other', ready: false, mode: 'production' })).toEqual({
      usable: false,
      reason: 'not-the-pos',
    })
  })

  it('has something to say about every refusal', () => {
    for (const reason of ['unreadable', 'not-the-pos', 'not-ready', 'development'] as const) {
      expect(healthProblemMessage(reason).length).toBeGreaterThan(10)
    }
  })
})

/**
 * `electron/main.js` cannot import this module — it runs under Electron's Node
 * before any TypeScript exists — so it implements the same check by hand. This
 * is the tripwire on the two drifting apart, the same guard
 * `update-signature.test.ts` puts on `scripts/release.mjs`.
 */
describe('the copy in electron/main.js', () => {
  const main = readFileSync(join(process.cwd(), 'electron', 'main.js'), 'utf8')

  it('checks the same app id and path', () => {
    expect(main).toContain(`'${HEALTH_APP_ID}'`)
    expect(main).toContain(`'${HEALTH_PATH}'`)
  })

  it('still refuses a development server by default', () => {
    expect(main).toContain("mode !== 'production'")
    expect(main).toContain('POS_ALLOW_DEV_SERVER')
  })

  it('no longer decides on a bare socket connection', () => {
    // The whole defect: `net.connect` answering was treated as "the POS is
    // here". If this ever comes back as the readiness test, so does the bug.
    expect(main).not.toMatch(/function portInUse/)
  })
})
