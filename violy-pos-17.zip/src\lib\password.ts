import { randomBytes, scryptSync, timingSafeEqual } from 'node:crypto'

/**
 * Password hashing, using only what Node already ships.
 *
 * scrypt rather than bcrypt or argon2 because both of those are native modules,
 * and a native module has to compile against the exact Node on the machine it
 * lands on. This app updates by unzipping source onto a shop laptop and running
 * `npm install` unattended; a build failure there is not a red console anyone
 * reads, it is a till that stops working on a Tuesday morning. `node:crypto` is
 * already there and cannot fail to install.
 *
 * Nothing here ever stores or returns a plaintext password.
 */

/**
 * scrypt cost. 16384/8/1 is the widely used baseline and takes roughly 50ms on
 * the shop laptop — slow enough to make guessing expensive, fast enough that
 * signing in feels instant.
 *
 * Stored INSIDE each hash rather than read from here at verify time, so raising
 * the cost later does not invalidate every existing password. Old hashes keep
 * verifying with the parameters they were made with.
 */
const N = 16384
const R = 8
const P = 1
const KEY_BYTES = 64
const SALT_BYTES = 16

/** `scrypt$N$r$p$salt$hash`, base64 for the two binary parts. */
export function hashPassword(plain: string): string {
  const salt = randomBytes(SALT_BYTES)
  const derived = scryptSync(plain, salt, KEY_BYTES, { N, r: R, p: P })
  return ['scrypt', N, R, P, salt.toString('base64'), derived.toString('base64')].join('$')
}

/**
 * Whether this password made that hash.
 *
 * Compared with `timingSafeEqual`, not `===`. A plain comparison returns as
 * soon as two bytes differ, so how long the answer takes leaks how much of a
 * guess was right — enough, over many attempts, to recover a password one
 * character at a time.
 *
 * Every malformed or unrecognised hash is a clean `false`. This is asked "may
 * this person in?", and every answer other than a confident yes is no.
 */
export function verifyPassword(plain: string, stored: string): boolean {
  try {
    const parts = stored.split('$')
    if (parts.length !== 6) return false
    const [scheme, n, r, p, salt, hash] = parts
    if (scheme !== 'scrypt') return false

    const cost = { N: Number(n), r: Number(r), p: Number(p) }
    if (!Number.isInteger(cost.N) || !Number.isInteger(cost.r) || !Number.isInteger(cost.p)) {
      return false
    }

    const expected = Buffer.from(hash, 'base64')
    // A full-length key, or nothing. Without this floor a stored value ending
    // in an empty hash — `scrypt$16384$8$1$YWJj$` — derives a zero-length key,
    // compares two empty buffers, and `timingSafeEqual` returns TRUE, letting
    // ANY password in. A corrupted row or a truncated restore would silently
    // become an open door.
    if (expected.length !== KEY_BYTES) return false

    const salted = Buffer.from(salt, 'base64')
    if (salted.length === 0) return false

    const actual = scryptSync(plain, salted, expected.length, cost)
    // Lengths must match before timingSafeEqual, which throws on a mismatch
    // rather than returning false.
    if (expected.length !== actual.length) return false
    return timingSafeEqual(expected, actual)
  } catch {
    return false
  }
}

/** The shortest password this app will accept. */
export const MIN_PASSWORD_LENGTH = 8

/**
 * Why this password is not acceptable, or null if it is.
 *
 * Deliberately only a length floor, with no character-class rules. Composition
 * requirements push people towards `Password1!` and towards writing the result
 * on a note taped to the monitor, which in a shop is the actual threat. Length
 * is the property that matters, and this is a local till reachable only by
 * someone already standing at the counter — not a login exposed to the internet.
 */
export function passwordProblem(plain: string): string | null {
  if (plain.length < MIN_PASSWORD_LENGTH) {
    return `Use at least ${MIN_PASSWORD_LENGTH} characters.`
  }
  // Leading or trailing spaces are almost always a paste accident, and they
  // are impossible to see in a password box when the sign-in later fails.
  if (plain !== plain.trim()) return 'Remove the space at the start or end.'
  return null
}
