import { beforeEach, describe, expect, it } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'
import { reconcileCustomerDueAt } from '@/server/account-due'

beforeEach(resetDb)

async function makeCustomer(name = 'ROMAN') {
  return prisma.customer.create({ data: { name } })
}

async function addEntry(customerId: number, type: 'OPENING' | 'CHARGE' | 'PAYMENT', amountCentavos: number) {
  return prisma.ledgerEntry.create({
    data: { customerId, type, amountCentavos, occurredAt: new Date(2026, 7, 3) },
  })
}

describe('reconcileCustomerDueAt', () => {
  it('assigns 30 local calendar days when a balance first becomes positive', async () => {
    const customer = await makeCustomer()
    await addEntry(customer.id, 'CHARGE', 50000)

    await prisma.$transaction((tx) => reconcileCustomerDueAt(tx, customer.id, new Date(2026, 7, 3, 15)))

    const after = await prisma.customer.findUniqueOrThrow({ where: { id: customer.id } })
    expect(after.dueAt).toEqual(new Date(2026, 8, 2))
  })

  it('does not silently postpone an existing debt', async () => {
    const original = new Date(2026, 7, 20)
    const customer = await prisma.customer.create({ data: { name: 'NENA', dueAt: original } })
    await addEntry(customer.id, 'CHARGE', 50000)
    await addEntry(customer.id, 'CHARGE', 25000)

    await prisma.$transaction((tx) => reconcileCustomerDueAt(tx, customer.id, new Date(2026, 7, 10)))

    const after = await prisma.customer.findUniqueOrThrow({ where: { id: customer.id } })
    expect(after.dueAt).toEqual(original)
  })

  it('clears the deadline when payments settle the balance', async () => {
    const customer = await prisma.customer.create({
      data: { name: 'BALDO', dueAt: new Date(2026, 7, 20) },
    })
    await addEntry(customer.id, 'CHARGE', 50000)
    await addEntry(customer.id, 'PAYMENT', 50000)

    await prisma.$transaction((tx) => reconcileCustomerDueAt(tx, customer.id, new Date(2026, 7, 5)))

    const after = await prisma.customer.findUniqueOrThrow({ where: { id: customer.id } })
    expect(after.dueAt).toBeNull()
  })

  it('assigns a fresh deadline when a settled account owes again', async () => {
    const customer = await makeCustomer('TASYO')
    await addEntry(customer.id, 'CHARGE', 50000)
    await addEntry(customer.id, 'PAYMENT', 50000)
    await prisma.$transaction((tx) => reconcileCustomerDueAt(tx, customer.id, new Date(2026, 7, 5)))
    await addEntry(customer.id, 'CHARGE', 10000)

    await prisma.$transaction((tx) => reconcileCustomerDueAt(tx, customer.id, new Date(2026, 8, 1)))

    const after = await prisma.customer.findUniqueOrThrow({ where: { id: customer.id } })
    expect(after.dueAt).toEqual(new Date(2026, 9, 1))
  })
})
