'use client'

import { useEffect, useId, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Dialog } from '@/components/ui/Dialog'
import { searchEverything, type SearchResult } from '@/server/search'
import { cn } from '@/lib/cn'

const DEBOUNCE_MS = 150

const KIND_LABEL: Record<SearchResult['kind'], string> = {
  workspace: 'Workspace',
  customer: 'Customer',
  product: 'Product',
}

type CommandPaletteProps = {
  /**
   * Both omitted (the default) lets the palette manage its own open state —
   * all it needs to answer ⌘K/Ctrl+K on its own, which is how the palette
   * test renders it. AppTopbar's visible "Search ⌘K" button passes both so
   * a click opens this same instance instead of a second one.
   */
  open?: boolean
  onOpenChange?: (open: boolean) => void
}

/**
 * Navigation only. Every result below is a `next/link` that changes the
 * route — nothing here calls a Server Action, submits a form, or reaches an
 * order/payment screen's commit button. Saving an order or recording a
 * payment must stay a deliberate click on its own screen, never something a
 * search box or a stray Enter keypress can trigger.
 */
export function CommandPalette({ open: openProp, onOpenChange: onOpenChangeProp }: CommandPaletteProps = {}) {
  const [internalOpen, setInternalOpen] = useState(false)
  const open = openProp ?? internalOpen
  const setOpen = onOpenChangeProp ?? setInternalOpen

  const [query, setQuery] = useState('')
  const [results, setResults] = useState<SearchResult[]>([])
  /** Which result the arrow keys are on. Never out of range — see below. */
  const [active, setActive] = useState(0)
  const router = useRouter()
  const listId = useId()

  // Dialog already provides Escape-to-close, the focus trap, body-scroll
  // lock, and focus restoration — none of that is reimplemented here, and
  // this listener never touches Escape, so there is only ever one handler
  // for it (Dialog's own).
  useEffect(() => {
    function onKeyDown(event: KeyboardEvent) {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault()
        setOpen(true)
      }
    }
    document.addEventListener('keydown', onKeyDown)
    return () => document.removeEventListener('keydown', onKeyDown)
  }, [setOpen])

  // Debounced search: a fast typist should not fire a query per keystroke.
  // `cancelled` guards against the race clearTimeout alone cannot stop: once
  // the timer has fired and the request is in flight, a later query's effect
  // can still run and resolve before this one does. Without this flag, that
  // stale response would land last and overwrite the newer query's results —
  // or repopulate the list after the palette has already closed.
  useEffect(() => {
    if (!open || !query.trim()) {
      setResults([])
      setActive(0)
      return
    }

    let cancelled = false
    const handle = setTimeout(() => {
      searchEverything(query).then((next) => {
        if (cancelled) return
        setResults(next)
        // Back to the top on every new result set. Keeping the old index would
        // leave the highlight on whatever now happens to sit in that slot,
        // which is a different record than the one she was looking at.
        setActive(0)
      })
    }, DEBOUNCE_MS)

    return () => {
      cancelled = true
      clearTimeout(handle)
    }
  }, [open, query])

  function close() {
    setOpen(false)
    setQuery('')
    setResults([])
    setActive(0)
  }

  /**
   * Arrow keys, Enter and Escape over the result list.
   *
   * Enter NAVIGATES and does nothing else. This palette is navigation-only by
   * design — nothing in it may reach a Server Action or a commit button — so
   * the key that is easiest to press by accident is also the one held to that
   * rule most strictly. `router.push` rather than clicking the link, because
   * a synthetic click on an anchor is a broader capability than is wanted
   * here.
   *
   * Escape is deliberately NOT handled: `Dialog` already closes on it, and a
   * second handler would be two things listening for one key — the drift
   * `AGENTS.md` records between `NotificationBell`, `RowActionMenu` and
   * `Popover`.
   */
  function onKeyDown(event: React.KeyboardEvent) {
    if (results.length === 0) return

    if (event.key === 'ArrowDown') {
      event.preventDefault()
      setActive((current) => (current + 1) % results.length)
      return
    }
    if (event.key === 'ArrowUp') {
      event.preventDefault()
      setActive((current) => (current - 1 + results.length) % results.length)
      return
    }
    if (event.key === 'Enter') {
      const chosen = results[active]
      if (!chosen) return
      event.preventDefault()
      close()
      router.push(chosen.href)
    }
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => (next ? setOpen(true) : close())}
      title="Search"
      description="Jump to a workspace, customer, or product."
    >
      <div className="flex flex-col gap-3">
        <input
          type="text"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search workspaces, customers, products…"
          aria-label="Search"
          onKeyDown={onKeyDown}
          role="combobox"
          aria-expanded={results.length > 0}
          aria-controls={listId}
          aria-activedescendant={
            results.length > 0 ? `${listId}-${active}` : undefined
          }
          className="h-10 w-full rounded-control border border-line bg-surface px-3 text-sm text-ink placeholder:text-ink-subtle focus:outline-none focus:ring-2 focus:ring-accent"
        />

        {results.length > 0 ? (
          <ul id={listId} role="listbox" className="flex flex-col gap-1">
            {results.map((result, index) => (
              <li
                key={`${result.kind}-${result.id}`}
                id={`${listId}-${index}`}
                role="option"
                aria-selected={index === active}
              >
                <Link
                  href={result.href}
                  onClick={close}
                  // The pointer moves the highlight too, so mouse and keyboard
                  // never disagree about which row is chosen.
                  onMouseEnter={() => setActive(index)}
                  className={cn(
                    'flex items-center justify-between gap-3 rounded-control px-3 py-2 text-sm text-ink hover:bg-surface-sunk focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent',
                    index === active && 'bg-surface-sunk',
                  )}
                >
                  <span className="truncate">{result.label}</span>
                  <span className="shrink-0 text-xs text-ink-subtle">
                    {result.hint ?? KIND_LABEL[result.kind]}
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        ) : query.trim() ? (
          <p className="px-3 py-2 text-sm text-ink-muted">No matches.</p>
        ) : null}
      </div>
    </Dialog>
  )
}
