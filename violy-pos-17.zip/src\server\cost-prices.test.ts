import { beforeEach, describe, expect, it, vi } from 'vitest'
import { recordCostPrices } from './cost-prices'
import { prisma } from '@/lib/db'

vi.mock('@/lib/db', () => {
  const product = { findMany: vi.fn(), update: vi.fn() }
  return { prisma: { product, $transaction: vi.fn() } }
})

const tx = { product: { findMany: vi.fn(), update: vi.fn() } }

/** Products as the transaction would read them back. */
function shelf(
  rows: { id: number; name: string; price: number; costPrice: number; isArchived?: boolean }[],
) {
  tx.product.findMany.mockResolvedValue(rows.map((row) => ({ isArchived: false, ...row })))
}

beforeEach(() => {
  vi.clearAllMocks()
  vi.mocked(prisma.$transaction).mockImplementation(
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    async (fn: any) => fn(tx),
  )
})

describe('what it refuses before touching the database', () => {
  it('refuses an empty list', async () => {
    const result = await recordCostPrices([])
    expect(result).toEqual({ ok: false, error: 'Nothing was typed yet.' })
    expect(prisma.$transaction).not.toHaveBeenCalled()
  })

  it('refuses the same product twice', async () => {
    // The last row would silently win, in an order nobody chose.
    const result = await recordCostPrices([
      { productId: 1, costCentavos: 100 },
      { productId: 1, costCentavos: 200 },
    ])
    expect(result.ok).toBe(false)
    expect(prisma.$transaction).not.toHaveBeenCalled()
  })

  it('refuses a negative cost', async () => {
    const result = await recordCostPrices([{ productId: 1, costCentavos: -1 }])
    expect(result).toEqual({ ok: false, error: 'A cost must be zero or more.' })
  })

  it('refuses a fractional centavo', async () => {
    // Money is integer centavos everywhere, precisely so it cannot drift.
    const result = await recordCostPrices([{ productId: 1, costCentavos: 190_000.5 }])
    expect(result).toEqual({ ok: false, error: 'A cost must be zero or more.' })
  })
})

describe('writing', () => {
  it('sets the cost and reports what changed', async () => {
    shelf([{ id: 1, name: 'Atlas Grower', price: 200_000, costPrice: 0 }])

    const result = await recordCostPrices([{ productId: 1, costCentavos: 150_000 }])

    expect(result).toEqual({ ok: true, data: { changed: 1, belowCost: [] } })
    expect(tx.product.update).toHaveBeenCalledWith({
      where: { id: 1 },
      data: { costPrice: 150_000 },
    })
  })

  it('skips a row already at that cost, so a second save is a no-op', async () => {
    // The absolute-not-delta property: saving twice leaves the same answer, so
    // a double-tap or a retry cannot compound.
    shelf([{ id: 1, name: 'Atlas Grower', price: 200_000, costPrice: 150_000 }])

    const result = await recordCostPrices([{ productId: 1, costCentavos: 150_000 }])

    expect(result).toEqual({ ok: true, data: { changed: 0, belowCost: [] } })
    expect(tx.product.update).not.toHaveBeenCalled()
  })

  it('refuses the whole batch if any product is archived', async () => {
    shelf([
      { id: 1, name: 'Atlas Grower', price: 200_000, costPrice: 0 },
      { id: 2, name: 'Old Feed', price: 100_000, costPrice: 0, isArchived: true },
    ])

    const result = await recordCostPrices([
      { productId: 1, costCentavos: 150_000 },
      { productId: 2, costCentavos: 90_000 },
    ])

    expect(result.ok).toBe(false)
    if (!result.ok) expect(result.error).toContain('Old Feed')
    // Checked before ANY write, so the good row is not left half-applied.
    expect(tx.product.update).not.toHaveBeenCalled()
  })

  it('reports a failure without claiming anything changed', async () => {
    shelf([{ id: 1, name: 'Atlas Grower', price: 200_000, costPrice: 0 }])
    tx.product.update.mockRejectedValueOnce(new Error('database is locked'))

    const result = await recordCostPrices([{ productId: 1, costCentavos: 150_000 }])

    expect(result).toEqual({ ok: false, error: 'Could not save the costs. Nothing was changed.' })
  })
})

describe('selling below cost', () => {
  it('saves it, and names what is now underwater', async () => {
    // Sometimes true — old stock cleared at a loss, or a supplier price that
    // rose before the shelf price followed. Refusing would leave her unable to
    // record the truth; telling her is the useful half.
    shelf([{ id: 1, name: 'Broodsow (Premium)', price: 191_000, costPrice: 0 }])

    const result = await recordCostPrices([{ productId: 1, costCentavos: 235_000 }])

    expect(result).toEqual({ ok: true, data: { changed: 1, belowCost: ['Broodsow (Premium)'] } })
    expect(tx.product.update).toHaveBeenCalled()
  })

  it('counts selling at exactly cost as underwater', async () => {
    // A margin of zero is not a healthy sale; it is a sack moved for nothing.
    shelf([{ id: 1, name: 'Boar Ration', price: 190_000, costPrice: 0 }])

    const result = await recordCostPrices([{ productId: 1, costCentavos: 190_000 }])

    expect(result.ok && result.data.belowCost).toEqual(['Boar Ration'])
  })

  it('never flags a cost of zero, which means unknown rather than free', async () => {
    // Otherwise clearing a cost would report the product as selling at a loss,
    // and a first pass over 52 blanks would be nothing but false alarms.
    shelf([{ id: 1, name: 'Atlas Grower', price: 200_000, costPrice: 150_000 }])

    const result = await recordCostPrices([{ productId: 1, costCentavos: 0 }])

    expect(result).toEqual({ ok: true, data: { changed: 1, belowCost: [] } })
  })
})
