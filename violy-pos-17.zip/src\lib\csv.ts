/**
 * Reading and writing CSV, the way Excel and Google Sheets actually behave.
 *
 * Not a general-purpose CSV library. It handles what this app's data contains
 * — product names with commas, notes with quotes and newlines, peso amounts —
 * and it is a single small file so both halves obey exactly the same quoting
 * rules. An export nobody can re-import is a dead end.
 */

/** Money is exchanged as decimal pesos, never as integer centavos. */
export function centavosToCsv(centavos: number): string {
  const sign = centavos < 0 ? '-' : ''
  const abs = Math.abs(centavos)
  return `${sign}${Math.floor(abs / 100)}.${String(abs % 100).padStart(2, '0')}`
}

/**
 * Parses a decimal-peso column back to centavos, or null when unreadable.
 *
 * Null, never zero — the same contract as `parsePesoInput`. A price column
 * that silently becomes ₱0.00 because a cell held "N/A" is how an import
 * quietly gives away stock.
 */
export function csvToCentavos(raw: string): number | null {
  const cleaned = raw.replace(/[₱,\s]/g, '')
  if (cleaned === '') return null
  if (!/^-?\d+(\.\d{1,2})?$/.test(cleaned)) return null
  return Math.round(Number(cleaned) * 100)
}

/**
 * Quotes one field.
 *
 * A field is quoted when it holds a comma, a quote, a newline, or leading or
 * trailing spaces that a round trip would otherwise eat. Embedded quotes are
 * doubled, which is the CSV convention every spreadsheet expects.
 */
function encodeField(value: string): string {
  const needsQuotes = /[",\r\n]/.test(value) || value !== value.trim()
  if (!needsQuotes) return value
  return `"${value.replace(/"/g, '""')}"`
}

export function toCsv(headers: readonly string[], rows: readonly (readonly string[])[]): string {
  const lines = [headers.map(encodeField).join(',')]
  for (const row of rows) lines.push(row.map(encodeField).join(','))

  // CRLF, and a UTF-8 BOM added by the caller: Excel on Windows reads a
  // BOM-less UTF-8 file as the local codepage, which turns ₱ into mojibake.
  return lines.join('\r\n')
}

/** What a browser download needs, BOM included. */
export function csvBlobParts(csv: string): string {
  return `﻿${csv}`
}

/**
 * Splits CSV text into rows of fields.
 *
 * Written as a character scanner rather than a line split with a regex,
 * because a quoted field may legally contain the newline that a line split
 * treats as a row boundary — a product note reading "50kg sacks,\nblue tag"
 * is one field, not two rows.
 */
export function parseCsv(text: string): string[][] {
  const rows: string[][] = []
  let row: string[] = []
  let field = ''
  let quoted = false
  let index = 0

  // Excel writes a BOM; leaving it on turns the first header into "﻿name"
  // and no column ever matches.
  const input = text.charCodeAt(0) === 0xfeff ? text.slice(1) : text

  function endField() {
    row.push(field)
    field = ''
  }
  function endRow() {
    endField()
    // A trailing newline should not produce a phantom empty row.
    if (row.length > 1 || row[0] !== '') rows.push(row)
    row = []
  }

  while (index < input.length) {
    const char = input[index]

    if (quoted) {
      if (char === '"') {
        if (input[index + 1] === '"') {
          field += '"'
          index += 2
          continue
        }
        quoted = false
        index += 1
        continue
      }
      field += char
      index += 1
      continue
    }

    if (char === '"' && field === '') {
      quoted = true
      index += 1
      continue
    }
    if (char === ',') {
      endField()
      index += 1
      continue
    }
    if (char === '\r') {
      // \r\n and a bare \r both end a row.
      if (input[index + 1] === '\n') index += 1
      endRow()
      index += 1
      continue
    }
    if (char === '\n') {
      endRow()
      index += 1
      continue
    }

    field += char
    index += 1
  }

  if (field !== '' || row.length > 0) endRow()
  return rows
}

/**
 * Turns parsed rows into objects keyed by header.
 *
 * Headers are matched case-insensitively with surrounding space ignored,
 * because a file that has been through a spreadsheet rarely comes back with
 * the exact casing it left with.
 */
export function rowsToRecords(rows: string[][]): Record<string, string>[] {
  if (rows.length === 0) return []
  const headers = rows[0].map((header) => header.trim().toLowerCase())
  return rows.slice(1).map((row) => {
    const record: Record<string, string> = {}
    headers.forEach((header, column) => {
      record[header] = (row[column] ?? '').trim()
    })
    return record
  })
}
