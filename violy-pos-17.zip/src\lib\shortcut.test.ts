import { describe, expect, it } from 'vitest'
import { CTRL_LABEL, MAC_LABEL, shortcutLabel } from './shortcut'

describe('shortcutLabel', () => {
  /**
   * The defect: the topbar printed "Search ⌘K" on every platform, and this
   * shop runs Windows — a label naming a key that is not on the keyboard.
   */
  it('names the key a Windows keyboard has', () => {
    expect(shortcutLabel('Win32')).toBe(CTRL_LABEL)
    expect(shortcutLabel('Windows')).toBe(CTRL_LABEL)
  })

  it('names the key a Mac keyboard has', () => {
    expect(shortcutLabel('MacIntel')).toBe(MAC_LABEL)
    expect(shortcutLabel('macOS')).toBe(MAC_LABEL)
  })

  it('treats Linux like Windows, because Ctrl is the key there too', () => {
    expect(shortcutLabel('Linux x86_64')).toBe(CTRL_LABEL)
  })

  /**
   * Undefined is the SERVER pass, where there is no navigator at all. It must
   * resolve to the shop's own answer rather than throwing or guessing Mac:
   * that way the label the server renders is already correct on the machine
   * this app actually runs on, and never visibly corrects itself.
   */
  it('falls back to Ctrl when it has nothing to go on', () => {
    expect(shortcutLabel(undefined)).toBe(CTRL_LABEL)
    expect(shortcutLabel('')).toBe(CTRL_LABEL)
  })
})
