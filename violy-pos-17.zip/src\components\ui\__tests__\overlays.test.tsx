// @vitest-environment jsdom

import { render, screen, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { useState } from 'react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { Button } from '../Button'
import { Dialog, type DialogProps } from '../Dialog'
import { Drawer } from '../Drawer'
import { Icon } from '../Icon'
import { Popover } from '../Popover'
import { RowActionMenu } from '../RowActionMenu'

function DialogHarness({ description = 'Supporting details.' }: { description?: string }) {
  const [open, setOpen] = useState(false)
  return (
    <>
      <button type="button" onClick={() => setOpen(true)}>Open dialog</button>
      <Dialog
        open={open}
        onOpenChange={setOpen}
        title="Edit order"
        description={description || undefined}
        footer={<button type="button">Save</button>}
      >
        <button type="button">First action</button>
        <button type="button">Last action</button>
      </Dialog>
    </>
  )
}

function DrawerHarness() {
  const [open, setOpen] = useState(false)
  return (
    <>
      <button type="button" onClick={() => setOpen(true)}>Open drawer</button>
      <Drawer
        open={open}
        onOpenChange={setOpen}
        title="Order details"
        description="Review this order."
        footer={<button type="button">Done</button>}
      >
        <button type="button">Drawer action</button>
      </Drawer>
    </>
  )
}

function EmptyDialogHarness() {
  const [open, setOpen] = useState(false)
  const dialogProps = {
    open,
    onOpenChange: setOpen,
    title: 'Empty dialog',
  } satisfies DialogProps
  return (
    <>
      <button type="button" onClick={() => setOpen(true)}>Open empty dialog</button>
      <Dialog {...dialogProps} />
    </>
  )
}

function PopoverHarness({ align }: { align?: 'start' | 'end' }) {
  return (
    <div>
      <Popover
        label="Order filters"
        align={align}
        trigger={(props) => (
          <Button {...props} aria-label="Show filters" size="icon">
            <Icon name="filter" />
          </Button>
        )}
      >
        <button type="button">First filter</button>
        <button type="button">Keep open</button>
      </Popover>
      <button type="button">Outside</button>
    </div>
  )
}

afterEach(() => {
  document.body.style.overflow = ''
})

describe('Dialog', () => {
  it('portals an accessible labelled dialog with an optional description', async () => {
    const user = userEvent.setup()
    const { container } = render(<DialogHarness />)

    await user.click(screen.getByRole('button', { name: 'Open dialog' }))

    const dialog = screen.getByRole('dialog', { name: 'Edit order', description: 'Supporting details.' })
    expect(dialog).toHaveAttribute('aria-modal', 'true')
    expect(dialog).toHaveAttribute('aria-labelledby')
    expect(dialog).toHaveAttribute('aria-describedby')
    expect(container).not.toContainElement(dialog)
    expect(document.body).toContainElement(dialog)
  })

  it('omits aria-describedby when no description exists', async () => {
    const user = userEvent.setup()
    render(<DialogHarness description="" />)
    await user.click(screen.getByRole('button', { name: 'Open dialog' }))
    expect(screen.getByRole('dialog', { name: 'Edit order' })).not.toHaveAttribute('aria-describedby')
  })

  it('focuses the first interactive descendant on open', async () => {
    const user = userEvent.setup()
    render(<DialogHarness />)
    await user.click(screen.getByRole('button', { name: 'Open dialog' }))
    expect(screen.getByRole('button', { name: 'First action' })).toHaveFocus()
  })

  it('focuses the dialog surface when no content or footer actions exist', async () => {
    const user = userEvent.setup()
    render(<EmptyDialogHarness />)
    await user.click(screen.getByRole('button', { name: 'Open empty dialog' }))
    expect(screen.getByRole('dialog', { name: 'Empty dialog' })).toHaveFocus()
  })

  it('contains Shift+Tab when fallback focus starts on the empty dialog surface', async () => {
    const user = userEvent.setup()
    render(<EmptyDialogHarness />)
    await user.click(screen.getByRole('button', { name: 'Open empty dialog' }))

    const dialog = screen.getByRole('dialog', { name: 'Empty dialog' })
    const close = within(dialog).getByRole('button', { name: 'Close' })
    expect(dialog).toHaveFocus()

    await user.tab({ shift: true })
    expect(close).toHaveFocus()
    await user.tab()
    expect(close).toHaveFocus()
  })

  it('renders a visible close button with at least a 40px target', async () => {
    const user = userEvent.setup()
    render(<DialogHarness />)
    await user.click(screen.getByRole('button', { name: 'Open dialog' }))
    const close = within(screen.getByRole('dialog')).getByRole('button', { name: 'Close' })
    expect(close).toBeVisible()
    expect(close).toHaveClass('h-10', 'w-10')
  })

  it('closes on Escape and restores focus to the trigger', async () => {
    const user = userEvent.setup()
    render(<DialogHarness />)
    const trigger = screen.getByRole('button', { name: 'Open dialog' })
    await user.click(trigger)
    await user.keyboard('{Escape}')
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    expect(trigger).toHaveFocus()
  })

  it('wraps Tab and Shift+Tab within the dialog', async () => {
    const user = userEvent.setup()
    render(<DialogHarness />)
    await user.click(screen.getByRole('button', { name: 'Open dialog' }))
    const dialog = screen.getByRole('dialog')
    const buttons = within(dialog).getAllByRole('button')
    const first = buttons[0]
    const last = buttons.at(-1)!

    last.focus()
    await user.tab()
    expect(first).toHaveFocus()
    first.focus()
    await user.tab({ shift: true })
    expect(last).toHaveFocus()
  })

  it('closes from the backdrop but not from clicks inside', async () => {
    const user = userEvent.setup()
    render(<DialogHarness />)
    await user.click(screen.getByRole('button', { name: 'Open dialog' }))
    await user.click(screen.getByText('Edit order'))
    expect(screen.getByRole('dialog')).toBeInTheDocument()
    await user.click(screen.getByTestId('dialog-backdrop'))
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
  })

  it('locks body scroll and restores the exact previous value on close and unmount', async () => {
    document.body.style.overflow = 'scroll'
    const user = userEvent.setup()
    const view = render(<DialogHarness />)
    await user.click(screen.getByRole('button', { name: 'Open dialog' }))
    expect(document.body.style.overflow).toBe('hidden')
    await user.keyboard('{Escape}')
    expect(document.body.style.overflow).toBe('scroll')

    await user.click(screen.getByRole('button', { name: 'Open dialog' }))
    view.unmount()
    expect(document.body.style.overflow).toBe('scroll')
  })
})

describe('Drawer', () => {
  it('provides equivalent dialog semantics, autofocus, Escape close, and focus restoration', async () => {
    const user = userEvent.setup()
    render(<DrawerHarness />)
    const trigger = screen.getByRole('button', { name: 'Open drawer' })
    await user.click(trigger)

    const drawer = screen.getByRole('dialog', { name: 'Order details', description: 'Review this order.' })
    expect(drawer).toHaveAttribute('aria-modal', 'true')
    expect(screen.getByRole('button', { name: 'Drawer action' })).toHaveFocus()
    await user.keyboard('{Escape}')
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    expect(trigger).toHaveFocus()
  })

  it('portals under body and renders optional header content', () => {
    const { container } = render(
      <Drawer open onOpenChange={vi.fn()} title="Order details" header={<div>Header tools</div>}>
        Drawer content
      </Drawer>,
    )
    const drawer = screen.getByRole('dialog', { name: 'Order details' })
    expect(screen.getByText('Header tools')).toBeInTheDocument()
    expect(container).not.toContainElement(drawer)
    expect(document.body).toContainElement(drawer)
  })

  it('wraps Tab and Shift+Tab within the drawer', async () => {
    const user = userEvent.setup()
    render(<DrawerHarness />)
    await user.click(screen.getByRole('button', { name: 'Open drawer' }))
    const buttons = within(screen.getByRole('dialog')).getAllByRole('button')
    const first = buttons[0]
    const last = buttons.at(-1)!

    last.focus()
    await user.tab()
    expect(first).toHaveFocus()
    first.focus()
    await user.tab({ shift: true })
    expect(last).toHaveFocus()
  })

  it('closes from its backdrop but not from clicks inside', async () => {
    const user = userEvent.setup()
    render(<DrawerHarness />)
    await user.click(screen.getByRole('button', { name: 'Open drawer' }))
    await user.click(screen.getByText('Order details'))
    expect(screen.getByRole('dialog')).toBeInTheDocument()
    await user.click(screen.getByTestId('drawer-backdrop'))
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
  })

  it('restores the exact body overflow on close and unmount', async () => {
    document.body.style.overflow = 'scroll'
    const user = userEvent.setup()
    const view = render(<DrawerHarness />)
    await user.click(screen.getByRole('button', { name: 'Open drawer' }))
    expect(document.body.style.overflow).toBe('hidden')
    await user.keyboard('{Escape}')
    expect(document.body.style.overflow).toBe('scroll')

    await user.click(screen.getByRole('button', { name: 'Open drawer' }))
    view.unmount()
    expect(document.body.style.overflow).toBe('scroll')
  })

  it('uses the responsive right-side width and raised overlay z-index contract', async () => {
    const user = userEvent.setup()
    render(<DrawerHarness />)
    await user.click(screen.getByRole('button', { name: 'Open drawer' }))
    expect(screen.getByRole('dialog')).toHaveClass('ml-auto', 'h-full', 'w-full', 'sm:max-w-md')
    expect(screen.getByTestId('drawer-backdrop')).toHaveClass('fixed', 'inset-0', 'z-50')
  })
})

describe('Popover', () => {
  it('links a decorative render trigger to its labelled dialog panel', async () => {
    const user = userEvent.setup()
    render(<PopoverHarness />)
    const trigger = screen.getByRole('button', { name: 'Show filters' })

    expect(trigger).toHaveAttribute('type', 'button')
    expect(trigger).toHaveAttribute('aria-haspopup', 'dialog')
    expect(trigger).toHaveAttribute('aria-expanded', 'false')
    expect(trigger).toHaveAttribute('aria-controls')

    await user.click(trigger)
    const panel = screen.getByRole('dialog', { name: 'Order filters' })
    expect(trigger).toHaveAttribute('aria-expanded', 'true')
    expect(panel).toHaveAttribute('id', trigger.getAttribute('aria-controls'))
  })

  it('focuses the first focusable descendant on open', async () => {
    const user = userEvent.setup()
    render(<PopoverHarness />)
    await user.click(screen.getByRole('button', { name: 'Show filters' }))
    expect(screen.getByRole('button', { name: 'First filter' })).toHaveFocus()
  })

  it('focuses the panel fallback when it has no focusable descendants', async () => {
    const user = userEvent.setup()
    render(
      <Popover label="Info" trigger={(props) => <button {...props}>Open info</button>}>
        Plain details
      </Popover>,
    )
    await user.click(screen.getByRole('button', { name: 'Open info' }))
    expect(screen.getByRole('dialog', { name: 'Info' })).toHaveFocus()
  })

  it('closes on Escape and restores focus to the trigger', async () => {
    const user = userEvent.setup()
    render(<PopoverHarness />)
    const trigger = screen.getByRole('button', { name: 'Show filters' })
    await user.click(trigger)
    await user.keyboard('{Escape}')
    expect(screen.queryByRole('dialog', { name: 'Order filters' })).not.toBeInTheDocument()
    expect(trigger).toHaveFocus()
  })

  it('stays open for inside clicks and closes from an outside pointer', async () => {
    const user = userEvent.setup()
    render(<PopoverHarness />)
    await user.click(screen.getByRole('button', { name: 'Show filters' }))
    await user.click(screen.getByRole('button', { name: 'Keep open' }))
    expect(screen.getByRole('dialog', { name: 'Order filters' })).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: 'Outside' }))
    expect(screen.queryByRole('dialog', { name: 'Order filters' })).not.toBeInTheDocument()
  })

  it('uses the tokenized raised surface and end alignment by default', async () => {
    const user = userEvent.setup()
    render(<PopoverHarness />)
    await user.click(screen.getByRole('button', { name: 'Show filters' }))
    expect(screen.getByRole('dialog', { name: 'Order filters' })).toHaveClass(
      'absolute',
      'right-0',
      'z-40',
      'border-line',
      'bg-surface-raised',
      'shadow-raised',
    )
  })

  it('supports start alignment', async () => {
    const user = userEvent.setup()
    render(<PopoverHarness align="start" />)
    await user.click(screen.getByRole('button', { name: 'Show filters' }))
    const panel = screen.getByRole('dialog', { name: 'Order filters' })
    expect(panel).toHaveClass('left-0')
    expect(panel).not.toHaveClass('right-0')
  })

  it('does not trap Tab or lock body scroll', async () => {
    document.body.style.overflow = 'scroll'
    const user = userEvent.setup()
    render(<PopoverHarness />)
    await user.click(screen.getByRole('button', { name: 'Show filters' }))
    expect(document.body.style.overflow).toBe('scroll')
    expect(screen.getByRole('button', { name: 'First filter' })).toHaveFocus()
    await user.tab()
    expect(screen.getByRole('button', { name: 'Keep open' })).toHaveFocus()
    await user.tab()
    expect(screen.getByRole('button', { name: 'Outside' })).toHaveFocus()
    expect(screen.getByRole('dialog', { name: 'Order filters' })).toBeInTheDocument()
  })
})

describe('RowActionMenu', () => {
  // `h-8`, not the `h-10` this asserted before. AGENTS.md sets the scale as
  // "controls are h-10, h-8 for row actions", and this trigger is a row
  // action — so the component was the thing out of line with the documented
  // scale, not the rule. It mattered in practice too: at 40px the trigger was
  // the tallest element in a stock row and set the row height by itself, so
  // compacting every other cell moved the row by four pixels and no further.
  //
  // The menu ITEMS stay h-10. They are a normal control surface once the menu
  // is open, not a row action.
  it('uses a row-action-sized trigger and a raised panel, portalled out of the row', async () => {
    // Portalled and `fixed`, not `absolute`. This menu lives in the last column
    // of a table, and every table here sits in `overflow-x-auto` — which clips
    // vertically too, because CSS computes the other axis from `visible` to
    // `auto`. Absolutely positioned, it rendered as a menu-and-a-half with its
    // own scrollbar hard against the right edge.
    const user = userEvent.setup()
    render(<RowActionMenu items={[{ label: 'View', onSelect: vi.fn() }]} />)
    const trigger = screen.getByRole('button', { name: 'Row actions' })
    expect(trigger).toHaveClass('h-8', 'w-8')

    await user.click(trigger)
    const menu = screen.getByRole('menu')
    expect(menu).toHaveClass('fixed', 'z-[60]', 'bg-surface-raised', 'shadow-raised')
    // Straight under body: nothing between it and the document to clip it.
    expect(menu.parentElement).toBe(document.body)
  })

  it('still runs an item when the panel is portalled away from the trigger', async () => {
    // The regression the portal invites: the outside-click check tests
    // containment against the trigger's wrapper, and the panel is no longer
    // inside it — so a click on an item would close the menu before the item's
    // own handler ever ran.
    const onSelect = vi.fn()
    const user = userEvent.setup()
    render(<RowActionMenu items={[{ label: 'Settle what sold', onSelect }]} />)

    await user.click(screen.getByRole('button', { name: 'Row actions' }))
    await user.click(screen.getByRole('menuitem', { name: 'Settle what sold' }))

    expect(onSelect).toHaveBeenCalledTimes(1)
  })

  it('opens an accessible menu and focuses its first enabled item', async () => {
    const user = userEvent.setup()
    render(<RowActionMenu ariaLabel="Actions for order 12" items={[{ label: 'View', onSelect: vi.fn() }]} />)
    const trigger = screen.getByRole('button', { name: 'Actions for order 12' })
    expect(trigger).toHaveAttribute('aria-haspopup', 'menu')
    expect(trigger).toHaveAttribute('aria-expanded', 'false')
    await user.click(trigger)
    expect(trigger).toHaveAttribute('aria-expanded', 'true')
    expect(screen.getByRole('menu')).toBeInTheDocument()
    expect(screen.getByRole('menuitem', { name: 'View' })).toHaveFocus()
  })

  it('cycles enabled items with ArrowDown and ArrowUp', async () => {
    const user = userEvent.setup()
    render(<RowActionMenu items={[
      { label: 'View', onSelect: vi.fn() },
      { label: 'Disabled', onSelect: vi.fn(), disabled: true },
      { label: 'Void', onSelect: vi.fn() },
    ]} />)
    await user.click(screen.getByRole('button', { name: 'Row actions' }))
    await user.keyboard('{ArrowDown}')
    expect(screen.getByRole('menuitem', { name: 'Void' })).toHaveFocus()
    await user.keyboard('{ArrowDown}')
    expect(screen.getByRole('menuitem', { name: 'View' })).toHaveFocus()
    await user.keyboard('{ArrowUp}')
    expect(screen.getByRole('menuitem', { name: 'Void' })).toHaveFocus()
  })

  it('selects once and closes', async () => {
    const user = userEvent.setup()
    const onSelect = vi.fn()
    render(<RowActionMenu items={[{ label: 'View', onSelect }]} />)
    await user.click(screen.getByRole('button', { name: 'Row actions' }))
    await user.click(screen.getByRole('menuitem', { name: 'View' }))
    expect(onSelect).toHaveBeenCalledTimes(1)
    expect(screen.queryByRole('menu')).not.toBeInTheDocument()
  })

  it('does not select or close for a disabled item', async () => {
    const user = userEvent.setup()
    const onSelect = vi.fn()
    render(<RowActionMenu items={[{ label: 'Unavailable', onSelect, disabled: true }]} />)
    await user.click(screen.getByRole('button', { name: 'Row actions' }))
    await user.click(screen.getByRole('menuitem', { name: 'Unavailable' }))
    expect(onSelect).not.toHaveBeenCalled()
    expect(screen.getByRole('menu')).toBeInTheDocument()
  })

  it('closes from an outside pointer', async () => {
    const user = userEvent.setup()
    render(<div><RowActionMenu items={[{ label: 'View', onSelect: vi.fn() }]} /><button type="button">Outside</button></div>)
    await user.click(screen.getByRole('button', { name: 'Row actions' }))
    await user.click(screen.getByRole('button', { name: 'Outside' }))
    expect(screen.queryByRole('menu')).not.toBeInTheDocument()
  })

  it('closes on Escape and restores focus to its trigger', async () => {
    const user = userEvent.setup()
    render(<RowActionMenu items={[{ label: 'View', onSelect: vi.fn() }]} />)
    const trigger = screen.getByRole('button', { name: 'Row actions' })
    await user.click(trigger)
    await user.keyboard('{Escape}')
    expect(screen.queryByRole('menu')).not.toBeInTheDocument()
    expect(trigger).toHaveFocus()
  })
})
