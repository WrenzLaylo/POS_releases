/**
 * What makes a delivery valid, and what it comes to.
 *
 * Pure, and separate from `src/server/deliveries.ts`, for the same reason
 * `discount.ts` is separate from `sales.ts`: the form previews a total while
 * she types and the Server Action computes the authoritative one, and those
 * two must never disagree. One implementation, called from both.
 *
 * A delivery is the mirror of a sale and is checked as strictly. It raises
 * stock and rewrites a cost price, and both of those are quiet: an inflated
 * sack count looks like a good month, and a wrong cost quietly poisons every
 * margin figure downstream. Nothing here is trusted from the browser — the
 * server re-derives all of it.
 */

/**
 * How a consignment differs from a purchase, and it is not a label.
 *
 * OUTRIGHT — the shop bought the sacks. The full amount is owed the day they
 * arrive, and stock and liability move together.
 *
 * CONSIGNMENT — the supplier's stock, sitting on our shelf. It is sellable
 * from the moment it lands, but NOTHING is owed for it until it sells; what
 * does not sell goes back. Treating it as a purchase would open a debt that
 * does not exist and overstate what the shop owes by the value of every sack
 * still unsold.
 */
export type DeliveryTerms = 'OUTRIGHT' | 'CONSIGNMENT'

export function isDeliveryTerms(value: string): value is DeliveryTerms {
  return value === 'OUTRIGHT' || value === 'CONSIGNMENT'
}

/** A line as it stands after any settling and returning. */
export type DeliveryLineState = {
  quantity: number
  quantitySettled: number
  quantityReturned: number
  unitCostCentavos: number
}

/**
 * How many units of a line the shop actually owes for.
 *
 * Outright: everything that arrived, less anything sent back — a torn sack
 * returned is a sack not paid for.
 *
 * Consignment: only what has been settled as sold. Units still on the shelf
 * belong to the supplier and are owed for by nobody.
 */
export function chargeableQuantity(line: DeliveryLineState, terms: DeliveryTerms): number {
  if (terms === 'CONSIGNMENT') return line.quantitySettled
  return Math.max(0, line.quantity - line.quantityReturned)
}

export function chargeableCentavos(
  lines: readonly DeliveryLineState[],
  terms: DeliveryTerms,
): number {
  return lines.reduce(
    (total, line) => total + Math.round(chargeableQuantity(line, terms) * line.unitCostCentavos),
    0,
  )
}

/**
 * Units still on the shelf that remain the supplier's — neither sold nor
 * returned. Meaningful only on a consignment; an outright purchase is the
 * shop's the moment it arrives.
 */
export function unaccountedQuantity(line: DeliveryLineState): number {
  return Math.max(0, line.quantity - line.quantitySettled - line.quantityReturned)
}

export type DeliveryLineInput = {
  productId: number
  quantity: number
  /** What one unit cost on this delivery, in centavos. */
  unitCostCentavos: number
}

export type DeliveryInput = {
  supplierId: number
  terms: DeliveryTerms
  /** The day the sacks physically arrived. */
  receivedAt: Date
  reference: string
  note: string
  lines: DeliveryLineInput[]
  /** What was handed to the supplier now. Zero is an unpaid consignment. */
  amountPaidCentavos: number
}

/** Guards against a fat-fingered quantity becoming a year of phantom stock. */
export const MAX_LINE_QUANTITY = 100_000

/** ₱10,000,000 a unit. Anything above this is a misplaced decimal. */
export const MAX_UNIT_COST_CENTAVOS = 1_000_000_000

export function lineCost(line: DeliveryLineInput): number {
  // Rounded once, here, so the preview and the stored total agree to the
  // centavo even when a quantity is fractional — 18.5 kilos is a real line.
  return Math.round(line.quantity * line.unitCostCentavos)
}

export function deliveryTotal(lines: readonly DeliveryLineInput[]): number {
  return lines.reduce((total, line) => total + lineCost(line), 0)
}

/**
 * Still owed on a consignment.
 *
 * Voided deliveries owe nothing — the consignment did not happen, so neither
 * did the debt. Floored at zero so an overpayment cannot read as a negative
 * amount owed, which would quietly reduce the payables total for every other
 * supplier.
 */
export function outstandingOf(delivery: {
  chargeableCentavos: number
  amountPaidCentavos: number
  isVoided: boolean
}): number {
  if (delivery.isVoided) return 0
  // Against CHARGEABLE, not against what arrived. On a consignment those are
  // different numbers for most of the delivery's life, and using the total
  // would report a debt for stock the supplier still owns.
  return Math.max(0, delivery.chargeableCentavos - delivery.amountPaidCentavos)
}

/**
 * A reconciliation: how many of each line sold, and how many went back.
 *
 * Both are DELTAS to add to what is already recorded, not new totals. A
 * supplier's agent visits, counts the shelf and bills for the difference, and
 * may do that several times against one consignment — so each visit adds to
 * the running figures rather than replacing them.
 */
export type ReconcileLine = {
  productId: number
  soldQuantity: number
  returnedQuantity: number
}

/**
 * Whether a reconciliation is allowed against the lines as they stand.
 *
 * The invariant it protects: settled + returned can never exceed what arrived.
 * Breaking it would bill the supplier's customer for sacks that were never
 * there, or take stock off the shelf that was never on it.
 */
export function validateReconcile(
  terms: DeliveryTerms,
  lines: readonly (DeliveryLineState & { productId: number })[],
  updates: readonly ReconcileLine[],
): string | null {
  if (updates.length === 0) return 'Nothing to record.'

  const byId = new Map(lines.map((line) => [line.productId, line]))
  const seen = new Set<number>()

  for (const update of updates) {
    const line = byId.get(update.productId)
    if (!line) return 'That product is not on this delivery.'
    if (seen.has(update.productId)) return 'The same product appears twice.'
    seen.add(update.productId)

    for (const value of [update.soldQuantity, update.returnedQuantity]) {
      if (!Number.isFinite(value)) return 'Enter a number.'
    }

    // NEGATIVE deltas are allowed, and this is the undo. Settling used to be a
    // one-way ratchet: enter 47 sold by mistake and the only way back was
    // voiding the whole delivery, taking the stock movements with it. What is
    // refused is a delta that would drive a running total below zero — you
    // cannot un-sell more than was ever settled.
    if (line.quantitySettled + update.soldQuantity < -1e-9) {
      return 'That would take the sold count below zero.'
    }
    if (line.quantityReturned + update.returnedQuantity < -1e-9) {
      return 'That would take the returned count below zero.'
    }

    // Nothing to settle on an outright purchase: it was owed in full on
    // arrival, so "sold" is not a state it can move through. A correction
    // downward is still allowed, which is why this tests `> 0` rather than
    // `!== 0`.
    if (terms === 'OUTRIGHT' && update.soldQuantity > 0) {
      return 'This was bought outright, so it is already owed in full. Record a return instead.'
    }

    const settled = line.quantitySettled + update.soldQuantity
    const returned = line.quantityReturned + update.returnedQuantity
    if (settled + returned > line.quantity + 1e-9) {
      return 'That is more than arrived on this delivery.'
    }
  }

  if (updates.every((update) => update.soldQuantity === 0 && update.returnedQuantity === 0)) {
    return 'Enter how many sold or how many went back.'
  }

  return null
}

/**
 * Every condition a delivery has to meet, in one place.
 *
 * Returns the first problem as a sentence for the operator, or null. Ordered
 * so the most basic complaint comes first: being told the date is in the
 * future when there are no lines yet is not helpful.
 *
 * `now` is injectable so tests can pin the clock rather than racing it.
 */
export function validateDelivery(input: DeliveryInput, now: Date = new Date()): string | null {
  if (!Number.isInteger(input.supplierId) || input.supplierId <= 0) {
    return 'Choose which supplier this came from.'
  }

  if (!isDeliveryTerms(input.terms)) {
    return 'Say whether this was bought outright or left on consignment.'
  }

  if (input.lines.length === 0) {
    return 'Add at least one item to this delivery.'
  }

  if (Number.isNaN(input.receivedAt.getTime())) {
    return 'That is not a date this app can read.'
  }

  // A consignment cannot arrive tomorrow. Compared against the END of today
  // rather than this instant, so recording this morning's delivery at 2pm is
  // not refused for being "in the future" by a few hours.
  const endOfToday = new Date(now)
  endOfToday.setHours(23, 59, 59, 999)
  if (input.receivedAt.getTime() > endOfToday.getTime()) {
    return 'A delivery cannot be dated in the future.'
  }

  const seen = new Set<number>()
  for (const line of input.lines) {
    if (!Number.isInteger(line.productId) || line.productId <= 0) {
      return 'One of the lines has no product chosen.'
    }
    // Duplicate lines are refused rather than merged, unlike the counter's
    // cart. At the till a repeated tap means "one more"; on a delivery form
    // two rows for the same sack at two different costs is a transcription
    // error, and picking one of the costs silently would be a guess.
    if (seen.has(line.productId)) {
      return 'The same product is on this delivery twice. Combine those lines.'
    }
    seen.add(line.productId)

    if (!Number.isFinite(line.quantity) || line.quantity <= 0) {
      return 'Every line needs a quantity greater than zero.'
    }
    if (line.quantity > MAX_LINE_QUANTITY) {
      return 'That quantity looks wrong. Check it before saving.'
    }
    if (!Number.isInteger(line.unitCostCentavos) || line.unitCostCentavos < 0) {
      return 'Every line needs a cost of zero or more.'
    }
    if (line.unitCostCentavos > MAX_UNIT_COST_CENTAVOS) {
      return 'That cost looks wrong. Check it before saving.'
    }
  }

  if (!Number.isInteger(input.amountPaidCentavos) || input.amountPaidCentavos < 0) {
    return 'Amount paid must be zero or more.'
  }
  // Nothing is owed on a consignment the day it arrives, so nothing can be
  // paid against it yet. Paying up front would be an advance, which needs a
  // supplier ledger to hold — deliberately not built.
  if (input.terms === 'CONSIGNMENT' && input.amountPaidCentavos > 0) {
    return 'Nothing is owed on a consignment until it sells. Record payment after settling it.'
  }

  // Refused rather than stored as a credit. An overpayment is almost always a
  // typo, and treating it as supplier credit would mean building that ledger.
  if (input.amountPaidCentavos > deliveryTotal(input.lines)) {
    return 'Amount paid is more than this delivery comes to.'
  }

  return null
}
