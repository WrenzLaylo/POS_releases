'use client'

import { Fragment, useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import type { CategoryRow } from '@/server/categories'
import { createCategory, deleteCategory, renameCategory } from '@/server/categories'
import { Button } from '@/components/ui/Button'
import { Dialog } from '@/components/ui/Dialog'
import { Field } from '@/components/ui/Field'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'
import { Select } from '@/components/ui/Select'

/**
 * Adding and renaming the brands a product can belong to.
 *
 * There was no way to do this at all until now — every category came from a
 * seed script, and the CSV importer refuses unknown ones rather than inventing
 * them. So a shop that started stocking a new brand had no way to say so.
 *
 * One dialog rather than a screen of its own, and reached from Stock, because
 * a category exists only to group products: it is a property of the catalogue,
 * not a place to visit. Same shape as the supplier list on Deliveries.
 */
export function CategoryDialog({
  categories,
  onClose,
}: {
  categories: CategoryRow[]
  onClose: () => void
}) {
  const router = useRouter()
  const [pending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)

  const [name, setName] = useState('')
  const [editingId, setEditingId] = useState<number | null>(null)
  const [confirmingId, setConfirmingId] = useState<number | null>(null)
  /** Where a doomed category's products should land. */
  const [moveTo, setMoveTo] = useState('')

  function reset() {
    setName('')
    setEditingId(null)
  }

  function save() {
    setError(null)
    startTransition(async () => {
      const result =
        editingId === null ? await createCategory(name) : await renameCategory(editingId, name)
      if (!result.ok) {
        setError(result.error)
        return
      }
      reset()
      router.refresh()
    })
  }

  function remove(id: number, destination?: number) {
    setError(null)
    startTransition(async () => {
      const result = await deleteCategory(id, destination)
      if (!result.ok) {
        // The panel stays open on a failure, so the destination she picked is
        // still there to correct rather than having to be found again.
        setError(result.error)
        return
      }
      setConfirmingId(null)
      setMoveTo('')
      router.refresh()
    })
  }

  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title="Categories"
      description="The brands and groups a product can belong to. They are the chips along the top of the counter."
      footer={
        <div className="flex justify-end">
          <Button variant="secondary" onClick={onClose}>
            Done
          </Button>
        </div>
      }
    >
      <div className="grid gap-4">
        <div className="flex flex-wrap items-end gap-2">
          <Field label={editingId === null ? 'New category' : 'Rename category'}>
            <Input
              value={name}
              onChange={(event) => setName(event.target.value)}
              placeholder="e.g. Gamefowl"
              className="w-56"
              autoFocus
            />
          </Field>
          <Button variant="primary" onClick={save} disabled={pending || name.trim() === ''}>
            {editingId === null ? 'Add' : 'Save'}
          </Button>
          {editingId !== null && (
            <Button variant="ghost" onClick={reset} disabled={pending}>
              Cancel
            </Button>
          )}
        </div>

        {error && <FormError>{error}</FormError>}

        {/* Bounded and scrolled in place. A shop with thirty brands would
            otherwise push the Done button off the bottom of the dialog, and
            the only way out would be Escape. */}
        <ul className="max-h-72 divide-y divide-line overflow-y-auto rounded-control border border-line">
          {categories.map((category) => (
            <Fragment key={category.id}>
              <li className="flex items-center justify-between gap-3 px-3 py-2">
                <span className="min-w-0">
                  <span className="block truncate text-sm font-medium text-ink">
                    {category.name}
                  </span>
                  <span className="block text-xs text-ink-subtle">
                    {category.productCount} product{category.productCount === 1 ? '' : 's'}
                  </span>
                </span>

                <span className="flex shrink-0 items-center gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    disabled={pending}
                    onClick={() => {
                      setError(null)
                      setEditingId(category.id)
                      setName(category.name)
                    }}
                  >
                    Rename
                  </Button>

                  {/* Offered for every category now, not only the empty ones.
                      One that holds products asks where they should go first
                      — the products move, they are never deleted. */}
                  {confirmingId === category.id ? (
                    <Button
                      variant="ghost"
                      size="sm"
                      disabled={pending}
                      onClick={() => {
                        setConfirmingId(null)
                        setMoveTo('')
                      }}
                    >
                      Keep
                    </Button>
                  ) : (
                    <Button
                      variant="danger"
                      size="sm"
                      disabled={pending}
                      onClick={() => {
                        setError(null)
                        setMoveTo('')
                        setConfirmingId(category.id)
                      }}
                    >
                      Remove
                    </Button>
                  )}
                </span>
              </li>

              {/* The confirmation is a row of its own beneath the category
                  rather than a nested dialog, so the list she is choosing a
                  destination from stays on screen behind it. */}
              {confirmingId === category.id && (
                <li className="bg-surface-sunk px-3 py-3">
                  {category.productCount > 0 ? (
                    <div className="grid gap-2">
                      <span className="text-sm text-ink">
                        Move its {category.productCount} product
                        {category.productCount === 1 ? '' : 's'} to:
                      </span>
                      <div className="flex flex-wrap items-center gap-2">
                        <Select
                          aria-label={`Move products from ${category.name} to`}
                          value={moveTo}
                          onChange={(event) => setMoveTo(event.target.value)}
                          className="w-56"
                        >
                          <option value="">Choose a category…</option>
                          {categories
                            .filter((other) => other.id !== category.id)
                            .map((other) => (
                              <option key={other.id} value={String(other.id)}>
                                {other.name}
                              </option>
                            ))}
                        </Select>
                        {/* Disabled until a destination is picked: the server
                            refuses a move with nowhere to go, and a button
                            that only ever errors is worse than one that
                            waits. */}
                        <Button
                          variant="destructive"
                          size="sm"
                          disabled={pending || moveTo === ''}
                          onClick={() => remove(category.id, Number(moveTo))}
                        >
                          Move and remove
                        </Button>
                      </div>
                      <span className="text-xs text-ink-subtle">
                        The products are kept — only the category goes.
                      </span>
                    </div>
                  ) : (
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-sm text-ink">
                        Remove {category.name}? There is nothing in it.
                      </span>
                      <Button
                        variant="destructive"
                        size="sm"
                        disabled={pending}
                        onClick={() => remove(category.id)}
                      >
                        Remove
                      </Button>
                    </div>
                  )}
                </li>
              )}
            </Fragment>
          ))}
        </ul>

        <p className="text-xs text-ink-subtle">
          Renaming is safe at any time — every product follows the new name. Removing one never
          removes its products: they move to the category you choose. New categories are added at
          the end of the counter&apos;s chip strip.
        </p>
      </div>
    </Dialog>
  )
}
