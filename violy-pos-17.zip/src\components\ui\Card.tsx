import type { HTMLAttributes } from 'react'
import { cn } from '@/lib/cn'

type CardVariant = 'default' | 'raised' | 'muted' | 'danger'

type CardProps = HTMLAttributes<HTMLDivElement> & {
  variant?: CardVariant
}

const VARIANTS: Record<CardVariant, string> = {
  default: 'border-line bg-surface shadow-panel',
  raised: 'border-line bg-surface-raised shadow-raised',
  muted: 'border-line bg-surface-sunk shadow-none',
  danger: 'border-owed bg-surface shadow-panel',
}

export function Card({ variant = 'default', className, ...props }: CardProps) {
  return (
    <div
      className={cn(
        'rounded-card border p-5 transition-[border-color,background-color,box-shadow] duration-150',
        VARIANTS[variant],
        className,
      )}
      {...props}
    />
  )
}
