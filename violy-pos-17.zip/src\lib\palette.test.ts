import { readFileSync } from 'node:fs'
import { join } from 'node:path'
import { describe, expect, it } from 'vitest'

/**
 * AGENTS.md claims every colour clears WCAG AA against the surface it sits on,
 * with the measured ratio recorded beside each token. That claim was a COMMENT,
 * and it had quietly stopped being true: `ink-subtle` was documented as 4.8:1 —
 * its ratio on white — while eleven elements rendered it on the cream canvas
 * (4.2) and in sunk wells (3.8), and a `warn` badge sat on the blue chip tint at
 * 4.33. axe found all of them; nothing in the repo could have.
 *
 * This turns the claim into an assertion. It reads the real tokens out of
 * `globals.css` rather than restating them, so a palette edit is checked rather
 * than merely described.
 */
const css = readFileSync(join(process.cwd(), 'src', 'app', 'globals.css'), 'utf8')
const badge = readFileSync(join(process.cwd(), 'src', 'components', 'ui', 'Badge.tsx'), 'utf8')

function token(name: string): string {
  const found = css.match(new RegExp(`--color-${name}:\\s*(#[0-9a-fA-F]{6})`))
  if (!found) throw new Error(`No --color-${name} in globals.css`)
  return found[1]
}

/** WCAG relative luminance, then the standard contrast ratio. */
function luminance(hex: string): number {
  const [r, g, b] = (hex.replace('#', '').match(/../g) as string[])
    .map((pair) => parseInt(pair, 16) / 255)
    .map((c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4))
  return 0.2126 * r + 0.7152 * g + 0.0722 * b
}

function ratio(a: string, b: string): number {
  const [hi, lo] = [luminance(a), luminance(b)].sort((x, y) => y - x)
  return (hi + 0.05) / (lo + 0.05)
}

const AA_TEXT = 4.5
const AA_CONTROL = 3

/** The three backgrounds text actually lands on in this app. */
const SURFACES = {
  surface: token('surface'),
  canvas: token('canvas'),
  'surface-sunk': token('surface-sunk'),
}

describe('text contrast', () => {
  /**
   * `ink-muted` is the one that has to work everywhere, because it is what
   * anything on the canvas or in a well must use.
   */
  it.each(['ink', 'ink-muted'])('%s clears AA on every surface', (name) => {
    for (const [surfaceName, surface] of Object.entries(SURFACES)) {
      const measured = ratio(token(name), surface)
      expect(measured, `${name} on ${surfaceName} is ${measured.toFixed(2)}`).toBeGreaterThanOrEqual(
        AA_TEXT,
      )
    }
  })

  /**
   * `ink-subtle` is deliberately a WHITE-SURFACE-ONLY token — it cannot clear AA
   * on canvas or sunk without collapsing into `ink-muted`, so the rule is a
   * usage rule instead. This pins both halves: it must keep working on white,
   * and it must stay genuinely lighter than `ink-muted`, or it has no reason to
   * exist and the usage rule is just a trap.
   */
  it('ink-subtle clears AA on white, and only claims to', () => {
    expect(ratio(token('ink-subtle'), SURFACES.surface)).toBeGreaterThanOrEqual(AA_TEXT)
    expect(ratio(token('ink-subtle'), SURFACES.surface)).toBeLessThan(
      ratio(token('ink-muted'), SURFACES.surface),
    )
  })

  it('line-strong stays a visible control boundary', () => {
    // Below 3.0 an input has no discernible edge — the reason #c4b8a3 (1.96)
    // was rejected.
    expect(ratio(token('line-strong'), SURFACES.surface)).toBeGreaterThanOrEqual(AA_CONTROL)
  })
})

/**
 * Every Badge tone, read out of the component rather than restated here, so a
 * new tone is covered the moment it is added.
 */
describe('badge tones', () => {
  const tones = [...badge.matchAll(/^\s*(\w+):\s*'([^']+)',/gm)].map(([, name, classes]) => {
    const bg = classes.match(/bg-([a-z-]+)/)?.[1]
    const fg = classes.match(/text-([a-z-]+)/)?.[1]
    return { name, bg, fg }
  })

  it('finds every tone in Badge.tsx', () => {
    expect(tones.map((t) => t.name).sort()).toEqual(['muted', 'neutral', 'owed', 'paid', 'warn'])
  })

  it.each(tones)('$name is readable on its own chip', ({ name, bg, fg }) => {
    expect(bg, `${name} has no bg-* class`).toBeTruthy()
    expect(fg, `${name} has no text-* class`).toBeTruthy()
    const measured = ratio(token(fg as string), token(bg as string))
    expect(
      measured,
      `${name}: ${fg} on ${bg} is ${measured.toFixed(2)}`,
    ).toBeGreaterThanOrEqual(AA_TEXT)
  })
})
