/**
 * Writes every exportable table to CSV files in one go.
 *
 *   npm run export:csv            -> ./exports/2026-08-17/
 *   npm run export:csv -- D:\     -> D:\violy-csv-2026-08-17\
 *
 * The same four tables the Settings screen offers, produced by the SAME
 * function, so a file written here and a file downloaded there are identical.
 * The point of the script is that it writes all four at once, straight to a
 * USB stick, rather than four downloads into a browser's Downloads folder.
 *
 * WORTH KNOWING BEFORE USING THIS TO MOVE SHOPS:
 *
 * CSV is a READABLE copy, not a complete one. Only products and customers can
 * be imported back; sales and ledger entries export for reading and nothing
 * reads them in. Suppliers, deliveries and utang plans have no CSV at all.
 *
 * To move the shop to another computer, use the database instead —
 * `npm run backup` there, `npm run restore` here. That carries everything.
 * This is for Excel, for a printed record, and for handing figures to somebody
 * who does not have the app.
 */

import { mkdir, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { EXPORT_TABLES } from '@/lib/export-tables'
import { csvBlobParts } from '@/lib/csv'
import { exportTableCsv } from '@/server/export-data'
import { dayKey } from '@/lib/dates'

async function main(): Promise<void> {
  const today = dayKey(new Date())
  const target = process.argv[2]
  const folder = target
    ? path.join(path.resolve(target), `violy-csv-${today}`)
    : path.join(process.cwd(), 'exports', today)

  await mkdir(folder, { recursive: true })

  let total = 0
  for (const table of EXPORT_TABLES) {
    const csv = await exportTableCsv(table.value)
    // `csvBlobParts` prepends the BOM, exactly as the browser download does.
    // Without it Excel on Windows reads the file in the local codepage and
    // turns every ₱ into mojibake — the figures survive, the currency does
    // not. Written as UTF-8 for the same reason.
    const file = path.join(folder, `violy-${table.value}-${today}.csv`)
    await writeFile(file, csvBlobParts(csv), 'utf8')

    // Minus the header row, so "0 rows" means empty rather than "one line".
    const rows = Math.max(0, csv.trim().split('\n').length - 1)
    total += rows
    console.log(`  ${table.label.padEnd(16)} ${String(rows).padStart(5)} rows  ->  ${path.basename(file)}`)
  }

  console.log(`\nWrote ${EXPORT_TABLES.length} files, ${total} rows in total, to:`)
  console.log(`  ${folder}\n`)
  console.log('Note: CSV is a readable copy, not a complete one. Only products and')
  console.log('customers can be imported back. To move the shop to another computer,')
  console.log('use `npm run backup` and `npm run restore` instead — those carry the')
  console.log('utang, the sales, the suppliers and the deliveries too.\n')
}

main().catch((error: unknown) => {
  console.error(`\nExport FAILED: ${error instanceof Error ? error.message : String(error)}\n`)
  process.exit(1)
})
