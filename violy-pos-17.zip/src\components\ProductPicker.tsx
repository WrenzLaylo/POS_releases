'use client'

import { useMemo, useRef, useState } from 'react'
import type { ProductWithCategory } from '@/lib/types'
import { Dialog } from '@/components/ui/Dialog'
import { Input } from '@/components/ui/Input'
import { EmptyState } from '@/components/ui/EmptyState'
import { Money } from '@/components/ui/Money'
import { cn } from '@/lib/cn'

/**
 * Choosing one of fifty-five products, by typing part of its name.
 *
 * It replaced a native `<select>`. A dropdown is fine at six options and
 * unusable at fifty-five: there is no search, the list is alphabetical rather
 * than relevant, and "Hog Finisher (High Density)" and "Hog Finisher
 * (Premium)" sit next to each other with the part that distinguishes them at
 * the far end of the line. Recording a delivery meant scrolling for each row.
 *
 * A `Dialog` rather than an inline popup, deliberately. Delivery rows live in
 * a table inside `overflow-x-auto`, and an absolutely-positioned panel is
 * clipped by that container — the exact failure `RowActionMenu` and `Select`
 * both had to be portalled to escape. A dialog has no such argument with its
 * parent, and it gives the search box the whole screen's attention on the one
 * screen where she is working down a supplier's invoice.
 *
 * The brand and the stock on hand are shown beside every name, because the two
 * questions asked while typing a delivery are "is this the right Atlas one"
 * and "how many did we have before this arrived".
 */
export function ProductPicker({
  products,
  value,
  onChange,
  label = 'Product',
  disabled,
}: {
  products: ProductWithCategory[]
  /** The chosen product's id, or '' for none. */
  value: string
  onChange: (productId: string) => void
  label?: string
  disabled?: boolean
}) {
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState('')
  const searchRef = useRef<HTMLInputElement>(null)

  const chosen = products.find((product) => String(product.id) === value) ?? null

  const matches = useMemo(() => {
    const needle = query.trim().toLowerCase()
    if (needle === '') return products
    // Matches the brand as well as the name: she thinks "the Atlas grower",
    // and the brand is not part of the product's own name.
    return products.filter(
      (product) =>
        product.name.toLowerCase().includes(needle) ||
        product.category.name.toLowerCase().includes(needle) ||
        product.unit.toLowerCase().includes(needle),
    )
  }, [products, query])

  function choose(productId: number) {
    onChange(String(productId))
    setOpen(false)
    setQuery('')
  }

  return (
    <>
      <button
        type="button"
        disabled={disabled}
        onClick={() => {
          setOpen(true)
          setQuery('')
        }}
        aria-label={label}
        className={cn(
          'flex h-10 w-full items-center justify-between gap-2 rounded-control border border-line-strong bg-surface-sunk px-3 text-left text-sm shadow-panel',
          'transition-[border-color,background-color] duration-150 hover:border-accent',
          'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-canvas',
          'disabled:opacity-50',
          // `ink-muted` for the unchosen state, not `ink-subtle`: the control
          // is `bg-surface-sunk`, where subtle measures 3.8 and fails AA.
          chosen ? 'text-ink' : 'text-ink-muted',
        )}
      >
        <span className="truncate">{chosen ? chosen.name : 'Choose a product…'}</span>
        <span className="shrink-0 text-xs text-ink-muted">
          {chosen ? chosen.unit : 'search'}
        </span>
      </button>

      {open && (
        <Dialog
          open
          onOpenChange={(next) => {
            if (!next) setOpen(false)
          }}
          title="Choose a product"
          description="Type any part of the name, the brand, or the unit."
        >
          <div className="grid gap-3">
            <Input
              ref={searchRef}
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="e.g. grower, Atlas, 25kg"
              className="w-full"
              autoFocus
            />

            {matches.length === 0 ? (
              <EmptyState>Nothing matches “{query}”.</EmptyState>
            ) : (
              // Capped height with its own scroll: fifty-five rows would push
              // the dialog past the bottom of a 768px laptop screen and take
              // the search box with it.
              <div className="max-h-80 overflow-y-auto rounded-control border border-line">
                {matches.map((product) => (
                  <button
                    key={product.id}
                    type="button"
                    onClick={() => choose(product.id)}
                    className={cn(
                      'flex w-full items-center justify-between gap-4 border-b border-line px-3 py-2 text-left last:border-b-0',
                      'hover:bg-accent-soft focus-visible:outline-none focus-visible:bg-accent-soft',
                      String(product.id) === value && 'bg-accent-soft',
                    )}
                  >
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-medium text-ink">
                        {product.name}
                      </span>
                      <span className="block truncate text-xs text-ink-subtle">
                        {product.category.name} · {product.unit}
                      </span>
                    </span>
                    <span className="shrink-0 text-right">
                      <Money centavos={product.price} scale="body" />
                      <span
                        className={cn(
                          'block font-mono text-xs',
                          product.stockQty < 0 ? 'text-warn' : 'text-ink-subtle',
                        )}
                      >
                        {product.stockQty} on hand
                      </span>
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </Dialog>
      )}
    </>
  )
}
