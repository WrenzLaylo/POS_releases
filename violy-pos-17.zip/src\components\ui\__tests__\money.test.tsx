// @vitest-environment jsdom

import { render, screen } from '@testing-library/react'
import { describe, expect, it } from 'vitest'
import { Money } from '../Money'
import { Stat } from '../Stat'

describe('Money', () => {
  it.each([
    ['owed', 'text-owed'],
    ['in', 'text-money-in'],
    ['zero', 'text-ink-subtle'],
    ['neutral', 'text-ink'],
  ] as const)(
    // This is the single most dangerous line in the app: a customer's debt
    // must read red and cash received must read green. Swapping `owed` and
    // `in` in Money's TONES map would flip every peso figure in the app and
    // every other test would still pass.
    'renders the %s tone with %s',
    (tone, expectedClass) => {
      render(<Money centavos={12345} tone={tone} />)
      expect(screen.getByText('₱123.45')).toHaveClass(expectedClass)
    },
  )

  it('defaults to the neutral tone when no tone prop is given', () => {
    // Benta, profit, and change-due all rely on this default to stay
    // un-green — none of them pass a tone explicitly.
    render(<Money centavos={50000} />)
    expect(screen.getByText('₱500.00')).toHaveClass('text-ink')
  })

  describe('tone="balance"', () => {
    it('renders a positive balance (customer owes) as owed/red', () => {
      render(<Money centavos={10000} tone="balance" />)
      expect(screen.getByText('₱100.00')).toHaveClass('text-owed')
    })

    it('renders a negative balance (customer in credit) as in/green', () => {
      render(<Money centavos={-10000} tone="balance" />)
      expect(screen.getByText('-₱100.00')).toHaveClass('text-money-in')
    })

    it('renders an exactly-zero balance as de-emphasised', () => {
      render(<Money centavos={0} tone="balance" />)
      expect(screen.getByText('₱0.00')).toHaveClass('text-ink-subtle')
    })
  })

  describe('scale', () => {
    it.each([
      ['hero', 'text-4xl'],
      ['strong', 'text-lg'],
      ['body', 'text-sm'],
    ] as const)('renders the %s scale with %s', (scale, expectedClass) => {
      render(<Money centavos={100} scale={scale} />)
      expect(screen.getByText('₱1.00')).toHaveClass(expectedClass)
    })
  })
})

describe('Stat', () => {
  it('forwards tone and scale through to the underlying Money figure', () => {
    render(<Stat label="Today" centavos={75000} tone="in" scale="hero" />)
    expect(screen.getByText('₱750.00')).toHaveClass('text-money-in', 'text-4xl')
  })
})
