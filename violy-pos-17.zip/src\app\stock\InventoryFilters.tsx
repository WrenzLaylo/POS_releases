'use client'

import { useEffect, useRef, useState } from 'react'
import { usePathname, useRouter } from 'next/navigation'
import { Field } from '@/components/ui/Field'
import { FilterChips } from '@/components/ui/FilterChips'
import { Input } from '@/components/ui/Input'
import { STOCK_LEVEL_OPTIONS } from '@/lib/stock-level'
import type { ReactNode } from 'react'

export function InventoryFilters({
  categories,
  q,
  category,
  stock,
  archived,
  action,
}: {
  categories: { id: number; name: string }[]
  q?: string
  category?: string
  stock?: string
  archived?: string
  /** The screen's primary action, placed on the filter row's right edge. */
  action?: ReactNode
}) {
  const router = useRouter()
  const pathname = usePathname()

  const searchRef = useRef<HTMLInputElement>(null)
  const archivedRef = useRef<HTMLInputElement>(null)

  // Typed, not submitted. Every other search in this app filters as you type,
  // and having to press a button here was the odd one out.
  const [search, setSearch] = useState(q ?? '')

  // Re-seeded when the URL changes underneath — a chip tap, the back button —
  // so the box never disagrees with the results below it.
  useEffect(() => {
    setSearch(q ?? '')
  }, [q])

  /**
   * Waits for a pause in typing before navigating.
   *
   * The Stock table is paged on the SERVER, so every keystroke would otherwise
   * be a round trip and a re-render: "starter" is seven of them, and the
   * results would visibly chase the cursor. 300ms is long enough to finish a
   * word and short enough not to feel like waiting.
   *
   * The debounce is skipped on an empty box: clearing a search is a deliberate
   * act with a known answer, and making her wait for it feels broken.
   */
  useEffect(() => {
    if (search === (q ?? '')) return
    const delay = search === '' ? 0 : 300
    const timer = setTimeout(() => apply({ q: search }), delay)
    return () => clearTimeout(timer)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search])

  // Everything applies the moment it changes — chips on tap, the search box
  // after a pause, the archived tick immediately. There is no Filter button
  // any more: every other search in this app filters as you type, and this one
  // made her press a button to see her own results.
  //
  // Show-archived is read from the LIVE input rather than the `archived` prop,
  // which holds only what the URL last committed. The search is held in state
  // instead, because it now drives navigation itself.
  //
  // Written as a patch over the current values rather than one function per
  // chip row. With two rows and a third plausible, "rebuild the whole query
  // string, remembering every other facet" is the step that gets forgotten,
  // and forgetting it silently drops a filter the operator can still see
  // selected on screen.
  function apply(patch: { category?: string; stock?: string; q?: string }) {
    const params = new URLSearchParams()
    const search = patch.q ?? searchRef.current?.value ?? q ?? ''
    const showArchived = archivedRef.current?.checked ?? archived === '1'
    const nextCategory = patch.category ?? category ?? ''
    const nextStock = patch.stock ?? stock ?? ''

    if (search) params.set('q', search)
    if (showArchived) params.set('archived', '1')
    if (nextCategory) params.set('category', nextCategory)
    if (nextStock) params.set('stock', nextStock)
    // Page 4 of the old filter is meaningless under the new one.
    params.set('page', '1')
    router.push(`${pathname}?${params.toString()}`)
  }

  const brandOptions = [
    { value: '', label: 'All brands' },
    ...categories.map((c) => ({ value: String(c.id), label: c.name })),
  ]

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap gap-x-8 gap-y-4">
        <FilterChips
          label="Brand"
          ariaLabel="Filter by brand"
          options={brandOptions}
          value={category ?? ''}
          onChange={(value) => apply({ category: value })}
        />

        {/* The facet this table was missing. Every product reads "0 left"
            until stock is counted in, and once it is, the question she
            actually asks the Stock screen is "what do I need to reorder" —
            which no amount of scrolling a name-sorted list answers. */}
        <FilterChips
          label="Stock level"
          ariaLabel="Filter by stock level"
          options={STOCK_LEVEL_OPTIONS}
          value={stock ?? ''}
          onChange={(value) => apply({ stock: value })}
        />
      </div>

      <div className="flex flex-wrap items-end gap-3">
        <Field label="Search">
          <Input
            ref={searchRef}
            type="search"
            name="q"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Product name"
            className="w-64"
          />
        </Field>

        <label className="flex h-10 items-center gap-2 text-sm text-ink">
          <input
            ref={archivedRef}
            type="checkbox"
            name="archived"
            value="1"
            defaultChecked={archived === '1'}
            onChange={() => apply({})}
            className="h-4 w-4"
          />
          Show archived
        </label>

        {/* Pushed to the right edge of this same row. It used to sit in its
            own full-width block below, which left a band of empty page
            between the filters and the table and made the primary action look
            stranded. */}
        {action && <div className="ml-auto">{action}</div>}
      </div>
    </div>
  )
}
