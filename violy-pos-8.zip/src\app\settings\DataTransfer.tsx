'use client'

import { useRef, useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { csvBlobParts } from '@/lib/csv'
import { dayKey } from '@/lib/dates'
import { EXPORT_TABLES, type ExportTable } from '@/lib/export-tables'
import { exportTableCsv } from '@/server/export-data'
import { applyImport, previewImport, type ImportPreview, type ImportTable } from '@/server/import-data'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { FormError } from '@/components/ui/FormError'
import { SegmentedControl } from '@/components/ui/SegmentedControl'
import { cn } from '@/lib/cn'

/**
 * Categories FIRST, and that order is the instruction.
 *
 * A products file whose category is not already on file has every row
 * refused — the importer will not invent a brand. On a fresh laptop that
 * means categories, then suppliers, then products, then customers.
 */
const IMPORT_TABLES = [
  { value: 'categories', label: 'Categories' },
  { value: 'suppliers', label: 'Suppliers' },
  { value: 'products', label: 'Products' },
  { value: 'customers', label: 'Customers' },
] as const

/**
 * Getting data out of the app and back into it.
 *
 * Export is unconditional — it only reads. Import never writes without showing
 * what it is about to do first: a spreadsheet is edited by hand, so a column
 * can be shifted, a price can be a word, and a mistyped name creates a
 * duplicate product rather than updating the one that exists. Finding that out
 * afterwards means finding it out in the data.
 */
export function DataTransfer() {
  const router = useRouter()
  const [busy, startTransition] = useTransition()

  // ── export ──────────────────────────────────────────────────────────────
  const [exporting, setExporting] = useState<ExportTable | null>(null)
  const [exportingAll, setExportingAll] = useState(false)
  const [exportError, setExportError] = useState<string | null>(null)

  /**
   * Builds one table and hands it to the browser as a download.
   *
   * `revokeObjectURL` is deferred rather than called on the next line. The
   * click is asynchronous — revoking immediately can pull the blob out from
   * under a download that has not started, which is the sort of failure that
   * only shows up on a slower machine.
   */
  async function downloadOne(table: ExportTable) {
    const csv = await exportTableCsv(table)
    // The BOM is added here rather than on the server: it exists purely so
    // Excel on Windows reads the file as UTF-8 instead of the local
    // codepage, which otherwise turns every ₱ into mojibake.
    const blob = new Blob([csvBlobParts(csv)], { type: 'text/csv;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `violy-${table}-${dayKey(new Date())}.csv`
    link.click()
    setTimeout(() => URL.revokeObjectURL(url), 30_000)
  }

  function download(table: ExportTable) {
    setExportError(null)
    setExporting(table)
    startTransition(async () => {
      try {
        await downloadOne(table)
      } catch {
        setExportError('Could not build that file. Try again.')
      } finally {
        setExporting(null)
      }
    })
  }

  /**
   * Every table, one after another.
   *
   * Sequential, not `Promise.all`: each one is a separate download, and a
   * browser handed nine at the same instant drops most of them. The short
   * pause between is what makes all nine actually arrive. It also means the
   * server builds one query at a time rather than nine at once on a laptop
   * that is also running the till.
   */
  function downloadEverything() {
    setExportError(null)
    setExportingAll(true)
    startTransition(async () => {
      try {
        for (const table of EXPORT_TABLES) {
          setExporting(table.value)
          await downloadOne(table.value)
          await new Promise((resolve) => setTimeout(resolve, 400))
        }
      } catch {
        setExportError('Could not build every file. The ones already saved are fine.')
      } finally {
        setExporting(null)
        setExportingAll(false)
      }
    })
  }

  // ── import ──────────────────────────────────────────────────────────────
  const fileRef = useRef<HTMLInputElement>(null)
  const [importTable, setImportTable] = useState<ImportTable>('products')
  const [csvText, setCsvText] = useState<string | null>(null)
  const [fileName, setFileName] = useState<string | null>(null)
  const [preview, setPreview] = useState<ImportPreview | null>(null)
  const [importError, setImportError] = useState<string | null>(null)
  const [applied, setApplied] = useState<{ created: number; updated: number; failed: number } | null>(null)

  function reset() {
    setCsvText(null)
    setFileName(null)
    setPreview(null)
    setImportError(null)
    setApplied(null)
    if (fileRef.current) fileRef.current.value = ''
  }

  async function chooseFile(file: File) {
    setImportError(null)
    setApplied(null)
    const text = await file.text()
    setCsvText(text)
    setFileName(file.name)

    startTransition(async () => {
      const result = await previewImport(importTable, text)
      if (!result.ok) {
        setPreview(null)
        setImportError(result.error)
        return
      }
      setPreview(result.data)
    })
  }

  function apply() {
    if (!csvText) return
    setImportError(null)
    startTransition(async () => {
      const result = await applyImport(importTable, csvText)
      if (!result.ok) {
        setImportError(result.error)
        return
      }
      setApplied(result.data)
      setPreview(null)
      setCsvText(null)
      setFileName(null)
      if (fileRef.current) fileRef.current.value = ''
      router.refresh()
    })
  }

  return (
    // `xl`, not `lg`. Two columns at 1024 leaves each card ~480px, and the
    // import chooser grew from two options to four — it overflowed by 18px,
    // which is how 1024 stopped fitting. 1366 is above `xl` so the shop
    // laptop keeps the side-by-side layout it has always had.
    <div className="grid gap-6 xl:grid-cols-2">
      <Card>
        <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
          <div>
            <h2 className="mb-1 text-base font-semibold">Export to CSV</h2>
            <p className="text-sm text-ink-muted">
              Opens directly in Excel and Google Sheets. Money is written as pesos, so a column
              sums to what you expect.
            </p>
          </div>
          {/* One press for the whole shop. Downloading nine files by hand is
              nine chances to miss one, and the one missed is the one wanted. */}
          <Button variant="primary" onClick={downloadEverything} disabled={busy}>
            {exportingAll ? 'Saving all…' : 'Export everything'}
          </Button>
        </div>

        <div className="grid gap-2">
          {EXPORT_TABLES.map((table) => (
            <div
              key={table.value}
              className="flex items-center justify-between gap-3 rounded-control border border-line px-3 py-2"
            >
              <div className="min-w-0">
                <div className="text-sm font-medium text-ink">{table.label}</div>
                <div className="text-xs text-ink-subtle">{table.note}</div>
              </div>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => download(table.value)}
                disabled={busy}
              >
                {exporting === table.value ? 'Building…' : 'Download'}
              </Button>
            </div>
          ))}
        </div>

        {exportError && <FormError className="mt-3">{exportError}</FormError>}

        <p className="mt-4 rounded-control border border-line bg-surface-sunk px-3 py-2 text-xs text-ink-muted">
          These are readable copies, not a backup — a spreadsheet cannot be turned back into the
          app. For a restorable copy of everything, use <span className="font-medium">Backups</span>{' '}
          above.
        </p>
      </Card>

      <Card>
        <h2 className="mb-1 text-base font-semibold">Import from CSV</h2>
        <p className="mb-4 text-sm text-ink-muted">
          Nothing is written until you have seen what will change. A row is matched by name —
          same name updates, new name creates.
        </p>
        {/* Said here because getting the order wrong looks like the importer
            is broken: every product row fails at once, with no clue that the
            missing thing is a category. */}
        <p className="mb-4 rounded-control border border-line bg-surface-sunk px-3 py-2 text-xs text-ink-muted">
          Setting up a second computer? Import in this order:{' '}
          <span className="font-medium">categories, suppliers, products, customers</span>. A
          product cannot be imported before the brand it belongs to exists.
        </p>

        <div className="mb-3">
          <SegmentedControl
            ariaLabel="What to import"
            options={IMPORT_TABLES}
            value={importTable}
            onValueChange={(value) => {
              setImportTable(value as ImportTable)
              reset()
            }}
          />
        </div>

        <input
          ref={fileRef}
          type="file"
          accept=".csv,text/csv"
          aria-label="Choose a CSV file"
          disabled={busy}
          onChange={(event) => {
            const file = event.target.files?.[0]
            if (file) void chooseFile(file)
          }}
          className="block w-full text-sm text-ink-muted file:mr-3 file:h-9 file:cursor-pointer file:rounded-control file:border file:border-line-strong file:bg-surface-raised file:px-3 file:text-sm file:font-medium file:text-ink hover:file:border-accent hover:file:bg-accent-soft"
        />

        {fileName && (
          <p className="mt-2 text-xs text-ink-subtle">
            {fileName}
            {preview && ` · ${preview.rows.length} rows`}
          </p>
        )}

        {importError && <FormError className="mt-3">{importError}</FormError>}

        {applied && (
          <p className="mt-3 rounded-control border border-money-in/30 bg-money-in/10 px-3 py-2 text-sm text-money-in">
            {applied.created} created, {applied.updated} updated
            {applied.failed > 0 && `, ${applied.failed} skipped`}.
          </p>
        )}

        {preview && (
          <div className="mt-4">
            <div className="mb-2 flex flex-wrap items-center gap-3 text-sm">
              <span className="font-medium text-ink">
                {preview.createCount} new · {preview.updateCount} changed
              </span>
              {preview.errorCount > 0 && (
                <span className="font-medium text-owed">{preview.errorCount} cannot be read</span>
              )}
            </div>

            <div className="max-h-64 overflow-y-auto rounded-control border border-line">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-surface-sunk text-left text-xs uppercase tracking-wide text-ink-muted">
                  <tr>
                    <th className="px-3 py-2 font-medium">Row</th>
                    <th className="px-3 py-2 font-medium">Name</th>
                    <th className="px-3 py-2 font-medium">What happens</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line">
                  {preview.rows.map((row) => (
                    <tr
                      key={row.line}
                      className={cn(row.error && 'bg-owed/10', row.action === 'create' && 'bg-money-in/5')}
                    >
                      <td className="px-3 py-1.5 font-mono tabular-nums text-ink-subtle">
                        {row.line}
                      </td>
                      <td className="px-3 py-1.5">{row.name || <span className="text-ink-subtle">—</span>}</td>
                      <td className="px-3 py-1.5">
                        {row.error ? (
                          <span className="text-owed">{row.error}</span>
                        ) : row.action === 'skip' ? (
                          <span className="text-ink-subtle">no change</span>
                        ) : (
                          <span className="text-ink-muted">
                            <span className="font-medium text-ink">
                              {row.action === 'create' ? 'Create' : 'Update'}
                            </span>{' '}
                            — {row.changes.join(', ')}
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-2">
              <Button
                variant="success"
                onClick={apply}
                disabled={busy || preview.createCount + preview.updateCount === 0}
              >
                {busy
                  ? 'Importing…'
                  : `Apply ${preview.createCount + preview.updateCount} change${
                      preview.createCount + preview.updateCount === 1 ? '' : 's'
                    }`}
              </Button>
              <Button variant="ghost" onClick={reset} disabled={busy}>
                Cancel
              </Button>
              {preview.errorCount > 0 && (
                <span className="text-xs text-ink-subtle">
                  Unreadable rows are skipped, not guessed at.
                </span>
              )}
            </div>
          </div>
        )}
      </Card>
    </div>
  )
}
