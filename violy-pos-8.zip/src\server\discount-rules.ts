'use server'

import { prisma } from '@/lib/db'
import type { ActionResult } from '@/lib/types'
import { ROUTES, bookEntry } from '@/lib/routes'
import {
  MAX_BPS,
  isDiscountBasis,
  isDiscountKind,
  isDiscountScope,
} from '@/lib/discount'
import { unitKeyword } from '@/lib/unit'
import { revalidateRoutes, revalidatePathname } from './revalidate'

export type DiscountRuleInput = {
  kind: string
  amountCentavos: number
  bps: number
  basis: string
  unit: string
  scope: string
  categoryIds: number[]
  productIds: number[]
}

type Parsed = Omit<DiscountRuleInput, 'kind' | 'basis' | 'scope'> & {
  kind: 'AMOUNT' | 'PERCENT'
  basis: 'PER_UNIT' | 'ONCE_PER_ORDER' | 'ORDER_TOTAL'
  scope: 'ALL' | 'CATEGORIES' | 'PRODUCTS'
}

/**
 * Checks a rule at the write boundary.
 *
 * Every union is validated at runtime rather than trusted from the type: these
 * cross a Server Action, and SQLite has no enum to refuse a bad value at the
 * column.
 */
function parse(input: DiscountRuleInput): Parsed | string {
  if (!isDiscountKind(input.kind)) return 'Unrecognised discount type.'
  if (!isDiscountBasis(input.basis)) return 'Unrecognised discount basis.'
  if (!isDiscountScope(input.scope)) return 'Unrecognised discount scope.'

  if (!Number.isInteger(input.amountCentavos) || input.amountCentavos < 0) {
    return 'The amount must be zero or more.'
  }
  if (!Number.isInteger(input.bps) || input.bps < 0 || input.bps > MAX_BPS) {
    return 'The percentage must be between 0 and 100.'
  }
  if (input.kind === 'AMOUNT' ? input.amountCentavos === 0 : input.bps === 0) {
    return 'Enter how much comes off.'
  }

  // A whole-order rule has no per-line scope, so nothing is stored for one —
  // the same reason the unused amount/percent column is written as zero.
  const scoped = input.basis !== 'ORDER_TOTAL'
  const scope = scoped ? input.scope : 'ALL'

  return {
    kind: input.kind,
    basis: input.basis,
    scope,
    amountCentavos: input.kind === 'AMOUNT' ? input.amountCentavos : 0,
    bps: input.kind === 'PERCENT' ? input.bps : 0,
    unit: scoped ? unitKeyword(input.unit ?? '') : '',
    categoryIds: scoped && scope === 'CATEGORIES' ? input.categoryIds : [],
    productIds: scoped && scope === 'PRODUCTS' ? input.productIds : [],
  }
}

/** Both screens that show a customer's money need refreshing after a change. */
function refresh(customerId: number): void {
  revalidatePathname(bookEntry(customerId))
  revalidateRoutes([ROUTES.counter, ROUTES.book])
}

export async function addDiscountRule(
  customerId: number,
  input: DiscountRuleInput,
): Promise<ActionResult<{ id: number }>> {
  if (!Number.isInteger(customerId) || customerId <= 0) {
    return { ok: false, error: 'Customer is required.' }
  }
  const parsed = parse(input)
  if (typeof parsed === 'string') return { ok: false, error: parsed }

  let id: number
  try {
    const created = await prisma.customerDiscountRule.create({
      data: {
        customerId,
        kind: parsed.kind,
        amountCentavos: parsed.amountCentavos,
        bps: parsed.bps,
        basis: parsed.basis,
        unit: parsed.unit,
        scope: parsed.scope,
        categories: { connect: parsed.categoryIds.map((each) => ({ id: each })) },
        products: { connect: parsed.productIds.map((each) => ({ id: each })) },
      },
    })
    id = created.id
  } catch {
    return { ok: false, error: 'Could not save that discount.' }
  }

  refresh(customerId)
  return { ok: true, data: { id } }
}

export async function updateDiscountRule(
  ruleId: number,
  input: DiscountRuleInput,
): Promise<ActionResult> {
  if (!Number.isInteger(ruleId) || ruleId <= 0) return { ok: false, error: 'Rule is required.' }
  const parsed = parse(input)
  if (typeof parsed === 'string') return { ok: false, error: parsed }

  const existing = await prisma.customerDiscountRule.findUnique({ where: { id: ruleId } })
  if (!existing) return { ok: false, error: 'That discount no longer exists.' }

  try {
    await prisma.customerDiscountRule.update({
      where: { id: ruleId },
      data: {
        kind: parsed.kind,
        amountCentavos: parsed.amountCentavos,
        bps: parsed.bps,
        basis: parsed.basis,
        unit: parsed.unit,
        scope: parsed.scope,
        // `set`, NOT `connect` — this replaces the scope rather than adding to
        // it. An unticked brand left connected keeps earning a discount she
        // believes she removed.
        categories: { set: parsed.categoryIds.map((each) => ({ id: each })) },
        products: { set: parsed.productIds.map((each) => ({ id: each })) },
      },
    })
  } catch {
    return { ok: false, error: 'Could not save that discount.' }
  }

  refresh(existing.customerId)
  return { ok: true, data: undefined }
}

/**
 * Removes a rule outright.
 *
 * Deleted rather than archived, unlike products and customers: a rule holds no
 * history of its own. What it granted is already snapshotted on every sale it
 * touched — `discountAtSale` and `lineDiscountAtSale` — so removing it cannot
 * change what any past sale was worth.
 */
export async function removeDiscountRule(ruleId: number): Promise<ActionResult> {
  if (!Number.isInteger(ruleId) || ruleId <= 0) return { ok: false, error: 'Rule is required.' }

  const existing = await prisma.customerDiscountRule.findUnique({ where: { id: ruleId } })
  if (!existing) return { ok: false, error: 'That discount no longer exists.' }

  try {
    await prisma.customerDiscountRule.delete({ where: { id: ruleId } })
  } catch {
    return { ok: false, error: 'Could not remove that discount.' }
  }

  refresh(existing.customerId)
  return { ok: true, data: undefined }
}
