import { describe, it, expect, beforeEach } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'

beforeEach(resetDb)

describe('discount schema', () => {
  it('defaults a customer to no discount and no categories', async () => {
    const customer = await prisma.customer.create({
      data: { name: 'ROMAN' },
      include: { discountCategories: true },
    })

    expect(customer.discountCentavos).toBe(0)
    expect(customer.discountCategories).toEqual([])
  })

  it('links a discount to specific categories', async () => {
    const sako = await prisma.category.create({ data: { name: 'Feeds (Sako)', sortOrder: 1 } })
    const gamot = await prisma.category.create({ data: { name: 'Medicine and Vitamins', sortOrder: 3 } })

    const customer = await prisma.customer.create({
      data: {
        name: 'DENNIS FARM',
        discountCentavos: 5000,
        discountCategories: { connect: [{ id: sako.id }] },
      },
      include: { discountCategories: { select: { id: true } } },
    })

    expect(customer.discountCentavos).toBe(5000)
    expect(customer.discountCategories.map((c) => c.id)).toEqual([sako.id])
    expect(customer.discountCategories.map((c) => c.id)).not.toContain(gamot.id)
  })

  it('defaults a sale item to no discount', async () => {
    const category = await prisma.category.create({ data: { name: 'Feeds (Sako)', sortOrder: 1 } })
    const product = await prisma.product.create({
      data: {
        categoryId: category.id,
        name: 'ADM Starter (sako)',
        unit: 'sako (50kg)',
        price: 157500,
        costPrice: 145000,
        stockQty: 10,
        lowStockThreshold: 4,
      },
    })
    const sale = await prisma.sale.create({
      data: {
        totalAmount: 157500,
        items: {
          create: [{ productId: product.id, quantity: 1, priceAtSale: 157500, costAtSale: 145000 }],
        },
      },
      include: { items: true },
    })

    expect(sale.items[0].discountAtSale).toBe(0)
  })

  it('keeps a category usable by several customers', async () => {
    const sako = await prisma.category.create({ data: { name: 'Feeds (Sako)', sortOrder: 1 } })
    for (const name of ['ROMAN', 'NENA']) {
      await prisma.customer.create({
        data: { name, discountCentavos: 5000, discountCategories: { connect: [{ id: sako.id }] } },
      })
    }

    const withCategory = await prisma.category.findUniqueOrThrow({
      where: { id: sako.id },
      include: { discountedFor: { select: { name: true } } },
    })
    expect(withCategory.discountedFor.map((c) => c.name).sort()).toEqual(['NENA', 'ROMAN'])
  })
})
