'use client'

import { useState } from 'react'
import Link from 'next/link'
import type { CategoryCheapest, CustomerWithDiscount, UtangPlanView } from '@/lib/types'
import { accountStatement, customerDiscount } from '@/lib/routes'
import { Button } from '@/components/ui/Button'
import { CustomerForm } from '../CustomerForm'
import { OpeningBalanceDialog } from './OpeningBalanceDialog'
import { PaymentDialog } from './PaymentDialog'
import { UtangPlanDialog } from './UtangPlanDialog'

/**
 * The money actions on a customer's page. All are dialogs, and all are
 * mounted only while open, so each opening starts from clean fields rather
 * than whatever was typed and abandoned last time.
 */
export function CustomerActions({
  customerId,
  customerName,
  plans,
  todayKey,
  balanceCentavos,
  unplannedCentavos,
  hasOpeningBalance,
  customer,
  categories,
  units,
}: {
  customerId: number
  customerName: string
  /** Live plans only — a voided record cannot take a payment. */
  plans: UtangPlanView[]
  todayKey: string
  /** What is owed right now, so the payment dialog can question an overpayment. */
  balanceCentavos: number
  /** The part of that balance belonging to no plan; convertible when positive. */
  unplannedCentavos: number
  /** Whether a carry-over has already been entered — it may only be set once. */
  hasOpeningBalance: boolean
  /** The record itself, so Edit opens the same form the Book list uses. */
  customer: CustomerWithDiscount
  categories: CategoryCheapest[]
  units: string[]
}) {
  const [open, setOpen] = useState<'payment' | 'plan' | 'convert' | 'opening' | 'edit' | null>(
    null,
  )

  return (
    <>
      <div className="mb-6 flex flex-wrap gap-2">
        <Button variant="success" onClick={() => setOpen('payment')}>
          Record a payment
        </Button>
        <Button variant="secondary" onClick={() => setOpen('plan')}>
          New utang
        </Button>
        {/* Only offered when there is something to schedule. */}
        {unplannedCentavos > 0 && (
          <Button variant="secondary" onClick={() => setOpen('convert')}>
            Put balance on terms
          </Button>
        )}
        {/* Hidden once one exists, because the server allows only one and a
            button whose only outcome is an error is worse than no button.
            It sits last: it is a once-per-customer setup step, not part of
            the daily round. */}
        {!hasOpeningBalance && (
          <Button variant="secondary" onClick={() => setOpen('opening')}>
            Starting utang
          </Button>
        )}
        {/* Reaching a customer's own details used to mean going back to the
            Book, finding the row and pressing Edit there — from the screen
            that is entirely about that customer. */}
        <Button variant="secondary" onClick={() => setOpen('edit')}>
          Edit details
        </Button>
        <Link
          href={customerDiscount(customerId)}
          className="inline-flex h-10 items-center justify-center rounded-control border border-line-strong bg-surface-raised px-4 text-sm font-medium text-ink hover:border-accent hover:bg-accent-soft"
        >
          Discount
        </Link>
        <Link
          href={accountStatement(customerId)}
          className="inline-flex h-10 items-center justify-center rounded-control px-4 text-sm font-medium text-accent hover:bg-accent-soft"
        >
          Statement
        </Link>
      </div>

      {open === 'payment' && (
        <PaymentDialog
          customerId={customerId}
          plans={plans}
          todayKey={todayKey}
          balanceCentavos={balanceCentavos}
          onClose={() => setOpen(null)}
        />
      )}
      {open === 'plan' && (
        <UtangPlanDialog customerId={customerId} onClose={() => setOpen(null)} />
      )}
      {open === 'edit' && (
        <CustomerForm
          categories={categories}
          units={units}
          customer={customer}
          onClose={() => setOpen(null)}
        />
      )}
      {open === 'opening' && (
        <OpeningBalanceDialog
          customerId={customerId}
          customerName={customerName}
          todayKey={todayKey}
          onClose={() => setOpen(null)}
        />
      )}
      {open === 'convert' && (
        <UtangPlanDialog
          customerId={customerId}
          convertCentavos={unplannedCentavos}
          onClose={() => setOpen(null)}
        />
      )}
    </>
  )
}
