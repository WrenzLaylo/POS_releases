import { describe, it, expect, beforeEach, vi } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'
import {
  listCustomers,
  getCustomer,
  createCustomer,
  updateCustomer,
  archiveCustomer,
  setCustomerDueDate,
  listCategoriesWithCheapest,
} from '@/server/customers'

beforeEach(resetDb)

describe('createCustomer', () => {
  it('creates a customer and trims the name', async () => {
    const result = await createCustomer({ name: '  ROMAN  ' })

    expect(result.ok).toBe(true)
    if (!result.ok) return

    const customer = await prisma.customer.findUniqueOrThrow({
      where: { id: result.data.customerId },
    })
    expect(customer.name).toBe('ROMAN')
  })

  it('rejects a blank name', async () => {
    const result = await createCustomer({ name: '   ' })

    expect(result).toEqual({ ok: false, error: 'Name is required.' })
    expect(await prisma.customer.count()).toBe(0)
  })

  it('rejects a duplicate name with a readable message, not a crash', async () => {
    await createCustomer({ name: 'ROMAN' })

    const result = await createCustomer({ name: 'ROMAN' })

    expect(result.ok).toBe(false)
    if (result.ok) return
    expect(result.error).toContain('ROMAN')
    expect(await prisma.customer.count()).toBe(1)
  })
})

describe('listCustomers', () => {
  it('hides archived customers', async () => {
    await createCustomer({ name: 'ROMAN' })
    const gone = await createCustomer({ name: 'BALDO' })
    if (!gone.ok) throw new Error('setup failed')
    await archiveCustomer(gone.data.customerId)

    const names = (await listCustomers()).map((c) => c.name)
    expect(names).toEqual(['ROMAN'])
  })

  it('puts the most recently ordered customer first', async () => {
    const a = await createCustomer({ name: 'ALPHA' })
    const b = await createCustomer({ name: 'ZULU' })
    if (!a.ok || !b.ok) throw new Error('setup failed')

    // ZULU ordered yesterday; ALPHA has never ordered.
    await prisma.sale.create({
      data: {
        totalAmount: 1000,
        customerId: b.data.customerId,
        createdAt: new Date('2026-07-27T09:00:00'),
      },
    })

    const names = (await listCustomers()).map((c) => c.name)
    expect(names).toEqual(['ZULU', 'ALPHA'])
  })

  it('orders customers who have never ordered alphabetically', async () => {
    await createCustomer({ name: 'ZULU' })
    await createCustomer({ name: 'ALPHA' })

    const names = (await listCustomers()).map((c) => c.name)
    expect(names).toEqual(['ALPHA', 'ZULU'])
  })
})

describe('updateCustomer', () => {
  it('changes the phone without touching the name', async () => {
    const created = await createCustomer({ name: 'NENA' })
    if (!created.ok) throw new Error('setup failed')

    const result = await updateCustomer(created.data.customerId, {
      name: 'NENA',
      phone: '0917-000-1234',
    })

    expect(result.ok).toBe(true)
    const after = await getCustomer(created.data.customerId)
    expect(after?.phone).toBe('0917-000-1234')
    expect(after?.name).toBe('NENA')
  })

  it('returns an error instead of throwing when the customer does not exist', async () => {
    const result = await updateCustomer(999, { name: 'GHOST' })

    expect(result).toEqual({ ok: false, error: 'Customer not found.' })
  })
})

describe('archiveCustomer', () => {
  it('archives rather than deletes, so ledger rows still resolve', async () => {
    const created = await createCustomer({ name: 'TASYO' })
    if (!created.ok) throw new Error('setup failed')
    await prisma.ledgerEntry.create({
      data: {
        customerId: created.data.customerId,
        type: 'OPENING',
        amountCentavos: 50000,
        occurredAt: new Date(),
      },
    })

    const result = await archiveCustomer(created.data.customerId)

    expect(result.ok).toBe(true)
    expect(await prisma.customer.count()).toBe(1)
    const after = await getCustomer(created.data.customerId)
    expect(after?.isArchived).toBe(true)
    expect(await prisma.ledgerEntry.count()).toBe(1)
  })

  it('returns an error instead of throwing when the customer does not exist', async () => {
    const result = await archiveCustomer(999)

    expect(result).toEqual({ ok: false, error: 'Customer not found.' })
  })
})

describe('customer discounts', () => {
  async function makeCategory(name: string, sortOrder: number) {
    return prisma.category.create({ data: { name, sortOrder } })
  }

  it('saves a discount and its categories', async () => {
    const sako = await makeCategory('Feeds (Sako)', 1)

    const created = await createCustomer({
      name: 'DENNIS FARM',
      discountCentavos: 5000,
      discountCategoryIds: [sako.id],
    })

    expect(created.ok).toBe(true)
    if (!created.ok) return

    const customer = await getCustomer(created.data.customerId)
    expect(customer?.discountCentavos).toBe(5000)
    expect(customer?.discountCategories.map((c) => c.id)).toEqual([sako.id])
  })

  it('defaults to no discount when none is given', async () => {
    const created = await createCustomer({ name: 'ROMAN' })
    expect(created.ok).toBe(true)
    if (!created.ok) return

    const customer = await getCustomer(created.data.customerId)
    expect(customer?.discountCentavos).toBe(0)
    expect(customer?.discountCategories).toEqual([])
  })

  it('replaces the category set on update rather than adding to it', async () => {
    const sako = await makeCategory('Feeds (Sako)', 1)
    const kilo = await makeCategory('Feeds (Kilo)', 2)
    const created = await createCustomer({
      name: 'ROMAN',
      discountCentavos: 5000,
      discountCategoryIds: [sako.id],
    })
    if (!created.ok) throw new Error('setup failed')

    const updated = await updateCustomer(created.data.customerId, {
      name: 'ROMAN',
      discountCentavos: 7500,
      discountCategoryIds: [kilo.id],
    })
    expect(updated.ok).toBe(true)

    const customer = await getCustomer(created.data.customerId)
    expect(customer?.discountCentavos).toBe(7500)
    expect(customer?.discountCategories.map((c) => c.id)).toEqual([kilo.id])
  })

  // The case the `set`-vs-`connect` choice exists for. Swapping to `connect`
  // still passes the test above (the new id does get attached); only clearing
  // to an empty list distinguishes them, because `connect: []` is a no-op and
  // would leave her granting a discount she watched herself remove.
  it('clears every category when the list is emptied', async () => {
    const sako = await makeCategory('Feeds (Sako)', 1)
    const kilo = await makeCategory('Feeds (Kilo)', 2)
    const created = await createCustomer({
      name: 'ROMAN',
      discountCentavos: 5000,
      discountCategoryIds: [sako.id, kilo.id],
    })
    if (!created.ok) throw new Error('setup failed')

    const updated = await updateCustomer(created.data.customerId, {
      name: 'ROMAN',
      discountCentavos: 5000,
      discountCategoryIds: [],
    })
    expect(updated.ok).toBe(true)

    const customer = await getCustomer(created.data.customerId)
    expect(customer?.discountCategories).toEqual([])
  })

  it('rejects a negative discount', async () => {
    const result = await createCustomer({ name: 'ROMAN', discountCentavos: -100 })
    expect(result.ok).toBe(false)
    expect(await prisma.customer.count()).toBe(0)
  })

  it('reports each category with its cheapest live product', async () => {
    const sako = await makeCategory('Feeds (Sako)', 1)
    await prisma.product.create({
      data: {
        categoryId: sako.id, name: 'ADM Starter (sako)', unit: 'sako', price: 157500,
        costPrice: 145000, stockQty: 5, lowStockThreshold: 2,
      },
    })
    await prisma.product.create({
      data: {
        categoryId: sako.id, name: 'Cheap Sack', unit: 'sako', price: 90000,
        costPrice: 80000, stockQty: 5, lowStockThreshold: 2,
      },
    })
    await prisma.product.create({
      data: {
        categoryId: sako.id, name: 'Archived Cheapest', unit: 'sako', price: 100,
        costPrice: 50, stockQty: 0, lowStockThreshold: 0, isArchived: true,
      },
    })

    const rows = await listCategoriesWithCheapest()
    const row = rows.find((r) => r.id === sako.id)

    expect(row?.cheapestCentavos).toBe(90000)
    expect(row?.cheapestName).toBe('Cheap Sack')
  })

  it('reports null for a category with no live products', async () => {
    const empty = await makeCategory('Equipment', 4)

    const rows = await listCategoriesWithCheapest()
    const row = rows.find((r) => r.id === empty.id)

    expect(row?.cheapestCentavos).toBeNull()
    expect(row?.cheapestName).toBeNull()
  })
})

describe('setCustomerDueDate', () => {
  async function debtor(name = 'ROMAN') {
    const customer = await prisma.customer.create({ data: { name } })
    await prisma.ledgerEntry.create({
      data: {
        customerId: customer.id,
        type: 'CHARGE',
        amountCentavos: 50000,
        occurredAt: new Date(2026, 7, 1),
      },
    })
    return customer
  }

  it('stores a valid local due day for an account that owes', async () => {
    vi.useFakeTimers()
    vi.setSystemTime(new Date(2026, 7, 3, 12))
    try {
      const customer = await debtor()

      const result = await setCustomerDueDate(customer.id, '2026-08-20')

      expect(result.ok).toBe(true)
      const after = await prisma.customer.findUniqueOrThrow({ where: { id: customer.id } })
      expect(after.dueAt).toEqual(new Date(2026, 7, 20))
    } finally {
      vi.useRealTimers()
    }
  })

  it('rejects a past or malformed date without changing the customer', async () => {
    vi.useFakeTimers()
    vi.setSystemTime(new Date(2026, 7, 3, 12))
    try {
      const customer = await debtor()

      expect((await setCustomerDueDate(customer.id, '2026-08-02')).ok).toBe(false)
      expect((await setCustomerDueDate(customer.id, '2026-02-29')).ok).toBe(false)
      expect((await prisma.customer.findUniqueOrThrow({ where: { id: customer.id } })).dueAt).toBeNull()
    } finally {
      vi.useRealTimers()
    }
  })

  it('rejects a settled account and a missing customer', async () => {
    const settled = await prisma.customer.create({ data: { name: 'SETTLED' } })

    expect((await setCustomerDueDate(settled.id, '2099-01-01')).ok).toBe(false)
    expect((await setCustomerDueDate(999999, '2099-01-01')).ok).toBe(false)
  })
})

describe('adding a customer who is already on the list', () => {
  it.each([
    ['the same name', 'MARILOU'],
    ['a different case', 'Marilou'],
    ['lower case', 'marilou'],
    ['trailing spaces', 'MARILOU  '],
  ])('refuses %s, and creates no second account', async (_label, name) => {
    // Worse than the duplicate-product case: two accounts for one person
    // split their utang across both, so neither balance is what they owe and
    // a payment against one leaves the other still showing a debt.
    const first = await createCustomer({ name: 'MARILOU' })
    expect(first.ok).toBe(true)

    const again = await createCustomer({ name })
    expect(again.ok).toBe(false)
    expect(await prisma.customer.count()).toBe(1)
  })

  it('still allows a genuinely different name', async () => {
    await createCustomer({ name: 'MARILOU' })
    expect((await createCustomer({ name: 'MARILOU CRUZ' })).ok).toBe(true)
    expect(await prisma.customer.count()).toBe(2)
  })
})

describe('renaming a customer onto a name already taken', () => {
  it('refuses, whatever the casing', async () => {
    const first = await createCustomer({ name: 'MARILOU' })
    const second = await createCustomer({ name: 'ROMAN' })
    expect(first.ok && second.ok).toBe(true)
    if (!second.ok) return

    const renamed = await updateCustomer(second.data.customerId, { name: 'marilou' })
    expect(renamed.ok).toBe(false)

    const row = await prisma.customer.findUnique({ where: { id: second.data.customerId } })
    expect(row!.name).toBe('ROMAN')
  })

  it('lets a customer be saved without changing her own name', async () => {
    // The check must exclude the row being edited, or editing a phone number
    // would report her as a duplicate of herself.
    const created = await createCustomer({ name: 'MARILOU' })
    expect(created.ok).toBe(true)
    if (!created.ok) return

    const saved = await updateCustomer(created.data.customerId, {
      name: 'MARILOU',
      phone: '0917 000 0000',
    })
    expect(saved.ok).toBe(true)
  })

  it('points at an archived account rather than letting a second one be opened', async () => {
    const created = await createCustomer({ name: 'MARILOU' })
    expect(created.ok).toBe(true)
    if (!created.ok) return
    await archiveCustomer(created.data.customerId)

    const again = await createCustomer({ name: 'marilou' })
    expect(again.ok).toBe(false)
    if (again.ok) return
    expect(again.error).toMatch(/archived/)
    expect(await prisma.customer.count()).toBe(1)
  })
})
