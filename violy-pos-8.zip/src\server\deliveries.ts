'use server'

import type { Prisma } from '@prisma/client'
import { prisma } from '@/lib/db'
import { lineTotal } from '@/lib/money'
import {
  chargeableCentavos,
  deliveryTotal,
  isDeliveryTerms,
  outstandingOf,
  unaccountedQuantity,
  validateDelivery,
  validateReconcile,
  type DeliveryInput,
  type DeliveryTerms,
  type ReconcileLine,
} from '@/lib/delivery'
import { PAGE_SIZE, pageCountOf, clampPage } from '@/lib/pagination'
import type { ActionResult, Paged } from '@/lib/types'
import { ROUTES } from '@/lib/routes'
import { revalidateRoutes } from './revalidate'

/** Thrown inside a transaction to roll it back with a message worth reading. */
class DeliveryError extends Error {}

export type DeliveryRow = {
  id: number
  supplierId: number
  supplierName: string
  terms: DeliveryTerms
  receivedAt: Date
  reference: string
  note: string
  /** The full value of what arrived, whatever the terms. */
  totalCostCentavos: number
  /** What is actually owed right now — see `chargeableQuantity`. */
  chargeableCentavos: number
  amountPaidCentavos: number
  outstandingCentavos: number
  /** Consignment stock still on the shelf: neither sold nor sent back. */
  unaccountedCentavos: number
  isVoided: boolean
  voidReason: string
  lineCount: number
}

export type DeliveryDetail = DeliveryRow & {
  lines: {
    productId: number
    name: string
    unit: string
    quantity: number
    quantitySettled: number
    quantityReturned: number
    unaccountedQuantity: number
    unitCostCentavos: number
    lineCostCentavos: number
    /**
     * How many the counter has sold since this delivery arrived.
     *
     * The figure the settle screen starts from, so a settlement begins at
     * what actually happened rather than at an empty box. An ESTIMATE for the
     * same reason as the To settle tab: stock is fungible and nothing on a
     * `SaleItem` says which delivery its sack came from.
     */
    soldSinceArrival: number
  }[]
}

const WITH_SUPPLIER = { supplier: { select: { id: true, name: true } } }

function toRow(delivery: {
  id: number
  supplierId: number
  supplier: { name: string }
  terms: string
  receivedAt: Date
  reference: string
  note: string
  totalCostCentavos: number
  chargeableCentavos: number
  amountPaidCentavos: number
  isVoided: boolean
  voidReason: string
  _count?: { items: number }
}): DeliveryRow {
  return {
    id: delivery.id,
    supplierId: delivery.supplierId,
    supplierName: delivery.supplier.name,
    // Falls back rather than throwing. SQLite has no enum, so a bad value is
    // reachable in principle, and refusing to show a delivery because one
    // column holds nonsense helps nobody.
    terms: isDeliveryTerms(delivery.terms) ? delivery.terms : 'OUTRIGHT',
    receivedAt: delivery.receivedAt,
    reference: delivery.reference,
    note: delivery.note,
    totalCostCentavos: delivery.totalCostCentavos,
    chargeableCentavos: delivery.chargeableCentavos,
    amountPaidCentavos: delivery.amountPaidCentavos,
    outstandingCentavos: outstandingOf(delivery),
    // What arrived, less what is already owed for and less what went back.
    unaccountedCentavos: delivery.isVoided
      ? 0
      : Math.max(0, delivery.totalCostCentavos - delivery.chargeableCentavos),
    isVoided: delivery.isVoided,
    voidReason: delivery.voidReason,
    lineCount: delivery._count?.items ?? 0,
  }
}

/**
 * Consignments with stock still unaccounted for — the settling to-do list.
 *
 * A consignment is not one event but a relationship: sacks land, some sell,
 * the agent visits and bills for those, the rest sit until next time. The
 * question "what does he settle when he comes on Tuesday" had no screen — it
 * meant reading the whole delivery list and knowing which rows were still
 * open.
 *
 * Unpaged on purpose. A shop has a handful of open consignments at a time, and
 * a to-do list that hides its tail behind a page control is a to-do list that
 * gets half done. Oldest first, because the oldest is the one whose stock has
 * been sitting longest.
 */
export type ConsignmentToSettle = DeliveryRow & {
  lines: {
    productId: number
    name: string
    unit: string
    quantity: number
    quantitySettled: number
    quantityReturned: number
    /** Roughly how many have sold since it arrived. An ESTIMATE — see below. */
    estimatedSoldQuantity: number
    unitCostCentavos: number
  }[]
  /**
   * What those estimated sales are worth: what she will probably owe when the
   * agent next visits. NOT a debt — nothing is owed on a consignment until it
   * is settled, and `outstandingCentavos` remains the figure that is.
   */
  estimatedOwedCentavos: number
}

/**
 * Consignments with stock still unaccounted for, and roughly what has sold.
 *
 * The estimate exists because "Owed to suppliers ₱0.00" is strictly true and
 * badly misleading: nothing is owed until the agent counts the shelf, but by
 * then the shop has been selling his stock for weeks. A zero that means "a
 * bill is building up which you cannot see" is the kind of understated money
 * this app is careful about everywhere else.
 *
 * It is an ESTIMATE and is labelled as one, because stock is FUNGIBLE and this
 * app has no lot tracking. If fifty sacks arrived on consignment and twenty
 * were bought outright, a sale cannot be attributed to either — nothing on a
 * `SaleItem` records which delivery its stock came from. So this counts sales
 * of the product since the consignment landed and calls it approximate, rather
 * than posting a debt to a supplier whose sacks may not have been the ones
 * sold.
 *
 * Voided sales are netted out: `voidSale` writes a positive VOID movement
 * against the negative SALE one, so summing both and negating gives what
 * actually left the shelf. Counting only SALE rows would bill the supplier for
 * a sale that was cancelled.
 *
 * Capped at what is genuinely outstanding on the line. Without the cap, stock
 * of the same product from a LATER outright delivery would keep inflating the
 * estimate past the number of sacks the consignment ever contained.
 */
export async function listConsignmentsToSettle(): Promise<ConsignmentToSettle[]> {
  const rows = await prisma.delivery.findMany({
    where: { terms: 'CONSIGNMENT', isVoided: false },
    include: {
      ...WITH_SUPPLIER,
      _count: { select: { items: true } },
      items: { include: { product: { select: { name: true, unit: true } } } },
    },
    orderBy: [{ receivedAt: 'asc' }, { id: 'asc' }],
  })

  // Filtered here rather than in SQL: "unaccounted" is
  // `totalCost - chargeable`, a comparison between two columns that Prisma
  // cannot express in a `where` without a raw fragment, and there are never
  // enough consignments for it to matter.
  const open = rows.filter((row) => toRow(row).unaccountedCentavos > 0)
  if (open.length === 0) return []

  const productIds = [...new Set(open.flatMap((row) => row.items.map((item) => item.productId)))]
  const earliest = open.reduce(
    (oldest, row) => (row.receivedAt < oldest ? row.receivedAt : oldest),
    open[0].receivedAt,
  )
  const movements = await prisma.stockMovement.findMany({
    where: {
      productId: { in: productIds },
      type: { in: ['SALE', 'VOID'] },
      createdAt: { gte: earliest },
    },
    select: { productId: true, quantity: true, createdAt: true },
  })

  return open.map((row) => {
    const lines = row.items.map((item) => {
      const net = movements
        .filter(
          (movement) =>
            movement.productId === item.productId && movement.createdAt >= row.receivedAt,
        )
        // SALE quantities are negative and VOID positive, so the sum is what
        // the shelf lost and negating it gives what sold.
        .reduce((total, movement) => total - movement.quantity, 0)

      const stillOpen = Math.max(0, item.quantity - item.quantitySettled - item.quantityReturned)
      // Sold and NOT YET SETTLED. `net` counts every sale since the delivery
      // landed, including the ones already accounted for at the last visit —
      // leaving them in would keep billing for sacks that have been paid for
      // once, and would pre-fill the settle screen with them again.
      const outstandingSold = Math.max(0, net - item.quantitySettled)
      return {
        productId: item.productId,
        name: item.product.name,
        unit: item.product.unit,
        quantity: item.quantity,
        quantitySettled: item.quantitySettled,
        quantityReturned: item.quantityReturned,
        estimatedSoldQuantity: Math.min(outstandingSold, stillOpen),
        unitCostCentavos: item.unitCostCentavos,
      }
    })

    return {
      ...toRow(row),
      lines,
      estimatedOwedCentavos: lines.reduce(
        (total, line) => total + lineTotal(line.unitCostCentavos, line.estimatedSoldQuantity),
        0,
      ),
    }
  })
}

export async function listDeliveries(
  filters: { supplierId?: number; unpaidOnly?: boolean } = {},
  page = 1,
): Promise<Paged<DeliveryRow>> {
  const where: Prisma.DeliveryWhereInput = {}
  if (filters.supplierId) where.supplierId = filters.supplierId
  if (filters.unpaidOnly) {
    // A voided consignment owes nothing, so it can never be "unpaid" — the
    // delivery did not happen, and neither did the debt.
    //
    // Compared against CHARGEABLE, not against what arrived. A consignment
    // with nothing sold yet is fully unpaid against its total and owes
    // nothing, and listing it as outstanding would be a debt that does not
    // exist.
    where.isVoided = false
    where.amountPaidCentavos = { lt: prisma.delivery.fields.chargeableCentavos }
  }

  const total = await prisma.delivery.count({ where })
  const pageCount = pageCountOf(total)
  const current = clampPage(page, pageCount)

  const rows = await prisma.delivery.findMany({
    where,
    include: { ...WITH_SUPPLIER, _count: { select: { items: true } } },
    // Newest arrival first, id as the tiebreaker so two consignments received
    // on the same day cannot swap places between pages and duplicate one row
    // while dropping another.
    orderBy: [{ receivedAt: 'desc' }, { id: 'desc' }],
    skip: (current - 1) * PAGE_SIZE,
    take: PAGE_SIZE,
  })

  return { rows: rows.map(toRow), total, page: current, pageCount }
}

/** Net units of a product that left the shelf since a moment, voids removed. */
async function soldSince(productIds: number[], since: Date): Promise<Map<number, number>> {
  const movements = await prisma.stockMovement.findMany({
    where: { productId: { in: productIds }, type: { in: ['SALE', 'VOID'] }, createdAt: { gte: since } },
    select: { productId: true, quantity: true },
  })
  const byProduct = new Map<number, number>()
  for (const movement of movements) {
    // SALE is negative and VOID positive, so negating the sum gives what sold.
    byProduct.set(movement.productId, (byProduct.get(movement.productId) ?? 0) - movement.quantity)
  }
  return byProduct
}

export async function getDelivery(id: number): Promise<DeliveryDetail | null> {
  if (!Number.isInteger(id) || id <= 0) return null

  const delivery = await prisma.delivery.findUnique({
    where: { id },
    include: {
      ...WITH_SUPPLIER,
      _count: { select: { items: true } },
      items: { include: { product: { select: { name: true, unit: true } } } },
    },
  })
  if (!delivery) return null

  const sold = await soldSince(
    delivery.items.map((item) => item.productId),
    delivery.receivedAt,
  )

  return {
    ...toRow(delivery),
    lines: delivery.items.map((item) => ({
      productId: item.productId,
      name: item.product.name,
      unit: item.product.unit,
      quantity: item.quantity,
      quantitySettled: item.quantitySettled,
      quantityReturned: item.quantityReturned,
      unaccountedQuantity: unaccountedQuantity(item),
      unitCostCentavos: item.unitCostCentavos,
      lineCostCentavos: Math.round(item.quantity * item.unitCostCentavos),
      // Sold, LESS what a previous visit already settled, and capped at what
      // is still open on the line. Both subtractions matter: without the
      // first, reopening this screen pre-fills sacks that were settled last
      // time and saving would count them twice; without the second, sales of
      // the same product from another delivery would push it past the number
      // that ever arrived.
      soldSinceArrival: Math.max(
        0,
        Math.min(
          (sold.get(item.productId) ?? 0) - item.quantitySettled,
          unaccountedQuantity(item),
        ),
      ),
    })),
  }
}

/** What the shop owes its suppliers, across every consignment not settled. */
export async function totalPayable(): Promise<number> {
  const unpaid = await prisma.delivery.findMany({
    where: { isVoided: false },
    select: { chargeableCentavos: true, amountPaidCentavos: true, isVoided: true },
  })
  return unpaid.reduce((total, delivery) => total + outstandingOf(delivery), 0)
}

/**
 * Records a consignment: stock up, cost set, payable opened.
 *
 * Everything happens in ONE transaction. A delivery that raised stock but did
 * not record what it cost, or recorded a cost against half its lines, is worse
 * than one that failed outright — the first is invisible and the second is
 * obvious.
 *
 * The total is computed here from the lines, never taken from the browser, for
 * the same reason a sale's total is: the figure that opens a debt to a
 * supplier has to come from the same arithmetic the preview showed, not from
 * whatever arrived in the request.
 */
export async function createDelivery(
  input: DeliveryInput & { clientKey: string },
): Promise<ActionResult<{ id: number }>> {
  const problem = validateDelivery(input)
  if (problem) return { ok: false, error: problem }

  const clientKey = input.clientKey.trim()
  if (clientKey.length < 8 || clientKey.length > 128) {
    return { ok: false, error: 'The save key is invalid. Reopen the form and try again.' }
  }

  // Idempotency, exactly as `createSale` does it. A delivery raises stock and
  // rewrites a cost price; saving it twice inflates inventory silently, which
  // is harder to spot than a duplicate sale and harder to unpick afterwards.
  const already = await prisma.delivery.findUnique({ where: { clientKey }, select: { id: true } })
  if (already) return { ok: true, data: { id: already.id } }

  let deliveryId: number
  try {
    deliveryId = await prisma.$transaction(async (tx) => {
      const supplier = await tx.supplier.findUnique({ where: { id: input.supplierId } })
      if (!supplier) throw new DeliveryError('That supplier no longer exists.')
      if (supplier.isArchived) {
        throw new DeliveryError(`${supplier.name} is archived. Restore it before recording a delivery.`)
      }

      const productIds = input.lines.map((line) => line.productId)
      const products = await tx.product.findMany({ where: { id: { in: productIds } } })
      const byId = new Map(products.map((product) => [product.id, product]))

      for (const line of input.lines) {
        const product = byId.get(line.productId)
        if (!product) throw new DeliveryError('A product on this delivery no longer exists.')
        // Refused rather than silently un-archiving. Receiving stock of
        // something withdrawn from sale is either a mistake or a decision to
        // sell it again, and the second one should be made deliberately on the
        // Stock screen.
        if (product.isArchived) {
          throw new DeliveryError(`${product.name} is archived. Restore it before receiving stock.`)
        }
      }

      const totalCostCentavos = deliveryTotal(input.lines)

      const delivery = await tx.delivery.create({
        data: {
          supplierId: input.supplierId,
          terms: input.terms,
          receivedAt: input.receivedAt,
          reference: input.reference.trim(),
          note: input.note.trim(),
          totalCostCentavos,
          // A consignment owes NOTHING on arrival — the sacks are the
          // supplier's until they sell. An outright purchase owes all of it
          // the same day. This one line is the whole difference between the
          // two, and getting it wrong overstates what the shop owes by the
          // value of every sack still sitting on the shelf.
          chargeableCentavos: input.terms === 'CONSIGNMENT' ? 0 : totalCostCentavos,
          amountPaidCentavos: input.amountPaidCentavos,
          clientKey,
          items: {
            create: input.lines.map((line) => ({
              productId: line.productId,
              quantity: line.quantity,
              unitCostCentavos: line.unitCostCentavos,
            })),
          },
        },
      })

      for (const line of input.lines) {
        await tx.product.update({
          where: { id: line.productId },
          data: {
            stockQty: { increment: line.quantity },
            // The LATEST cost, not a running average. A weighted average is
            // more correct in principle and unexplainable at the counter —
            // she knows what she paid this time, and that is the number she
            // prices against. Every unit cost ever paid is kept on the
            // DeliveryItem rows, so an average remains computable if it is
            // ever actually wanted.
            costPrice: line.unitCostCentavos,
          },
        })
        await tx.stockMovement.create({
          data: {
            productId: line.productId,
            deliveryId: delivery.id,
            type: 'DELIVERY',
            quantity: line.quantity,
            note: `Delivery #${delivery.id}${supplier.name ? ` from ${supplier.name}` : ''}`,
          },
        })
      }

      return delivery.id
    })
  } catch (error) {
    if (error instanceof DeliveryError) return { ok: false, error: error.message }
    return { ok: false, error: 'Could not save that delivery.' }
  }

  // AFTER the try/catch, never inside it. A revalidation throw caught in there
  // would be reported as a failed save, and the retry would raise stock a
  // second time for sacks that arrived once.
  revalidateRoutes([ROUTES.deliveries, ROUTES.stock, ROUTES.counter, ROUTES.dashboard], {
    layout: true,
  })
  return { ok: true, data: { id: deliveryId } }
}

/**
 * Records a payment against a consignment already received.
 *
 * Separate from creating it, because a delivery is usually paid later than it
 * arrives, and the alternative — editing the delivery — would mean reopening a
 * form that also moves stock.
 */
export async function payDelivery(
  id: number,
  amountCentavos: number,
): Promise<ActionResult> {
  if (!Number.isInteger(id) || id <= 0) return { ok: false, error: 'Delivery id is required.' }
  if (!Number.isInteger(amountCentavos) || amountCentavos <= 0) {
    return { ok: false, error: 'Enter an amount greater than zero.' }
  }

  try {
    await prisma.$transaction(async (tx) => {
      const delivery = await tx.delivery.findUnique({ where: { id } })
      if (!delivery) throw new DeliveryError('That delivery no longer exists.')
      if (delivery.isVoided) {
        throw new DeliveryError('This delivery was voided. There is nothing to pay on it.')
      }

      // Against CHARGEABLE. On a consignment with nothing sold yet this is
      // zero, and paying it would be settling a debt that does not exist.
      const outstanding = delivery.chargeableCentavos - delivery.amountPaidCentavos
      if (outstanding <= 0) {
        throw new DeliveryError(
          delivery.chargeableCentavos === 0
            ? 'Nothing is owed on this yet. Settle what has sold first.'
            : 'This delivery is already fully paid.',
        )
      }
      // Read INSIDE the transaction and checked against the live figure, not
      // against whatever the browser was showing when the form opened.
      if (amountCentavos > outstanding) {
        throw new DeliveryError('That is more than is still owed on this delivery.')
      }

      await tx.delivery.update({
        where: { id },
        data: { amountPaidCentavos: { increment: amountCentavos } },
      })
    })
  } catch (error) {
    if (error instanceof DeliveryError) return { ok: false, error: error.message }
    return { ok: false, error: 'Could not record that payment.' }
  }

  revalidateRoutes([ROUTES.deliveries, ROUTES.dashboard])
  return { ok: true, data: undefined }
}

/**
 * Reverses a consignment recorded in error.
 *
 * Voided, never deleted — the same rule sales follow. The row stays, marked,
 * with the reason on it, because "this delivery was entered twice" is itself a
 * fact worth keeping.
 *
 * Stock comes back off, with reversing movements so the stock card explains
 * itself. The cost price is RECOMPUTED rather than rolled back: the delivery
 * being voided may not be the one that set the current cost, and a later
 * consignment must not be undone by voiding an earlier one. When no delivery
 * remains for a product, the cost is left exactly as it is — it may have been
 * typed by hand on the Stock screen, and zeroing it would destroy a figure
 * this delivery never set.
 */
export async function voidDelivery(id: number, reason: string): Promise<ActionResult> {
  if (!Number.isInteger(id) || id <= 0) return { ok: false, error: 'Delivery id is required.' }
  const voidReason = reason.trim()
  if (!voidReason) return { ok: false, error: 'Say why this delivery is being voided.' }

  try {
    await prisma.$transaction(async (tx) => {
      const delivery = await tx.delivery.findUnique({ where: { id }, include: { items: true } })
      if (!delivery) throw new DeliveryError('That delivery no longer exists.')
      if (delivery.isVoided) throw new DeliveryError('This delivery has already been voided.')

      // Chargeable goes to zero with it: a delivery that did not happen owes
      // nothing, and leaving the figure behind would keep it in the payables
      // total for ever.
      await tx.delivery.update({
        where: { id },
        data: { isVoided: true, voidReason, chargeableCentavos: 0 },
      })

      for (const item of delivery.items) {
        // Only what has NOT already gone back. Reversing the full quantity
        // after some was returned would take the same sacks off the shelf
        // twice.
        const stillHere = Math.max(0, item.quantity - item.quantityReturned)
        if (stillHere > 0) {
          await tx.product.update({
            where: { id: item.productId },
            // Allowed to go negative. The sacks may already have been sold, and
            // the counter deliberately permits a negative count rather than
            // blocking a sale of stock the shop physically has — refusing here
            // would leave a known-wrong delivery on file instead.
            data: { stockQty: { decrement: stillHere } },
          })
          await tx.stockMovement.create({
            data: {
              productId: item.productId,
              deliveryId: delivery.id,
              type: 'VOID',
              quantity: -stillHere,
              note: `Voided delivery #${delivery.id}: ${voidReason}`,
            },
          })
        }

        const latest = await tx.deliveryItem.findFirst({
          where: { productId: item.productId, delivery: { isVoided: false } },
          orderBy: [{ delivery: { receivedAt: 'desc' } }, { id: 'desc' }],
          select: { unitCostCentavos: true },
        })
        if (latest) {
          await tx.product.update({
            where: { id: item.productId },
            data: { costPrice: latest.unitCostCentavos },
          })
        }
      }
    })
  } catch (error) {
    if (error instanceof DeliveryError) return { ok: false, error: error.message }
    return { ok: false, error: 'Could not void that delivery.' }
  }

  revalidateRoutes([ROUTES.deliveries, ROUTES.stock, ROUTES.counter, ROUTES.dashboard], {
    layout: true,
  })
  return { ok: true, data: undefined }
}

/**
 * Settles a consignment, or sends stock back.
 *
 * This is the visit: the supplier's agent counts the shelf, bills for what
 * moved, and takes away what did not. Both figures are DELTAS, because one
 * consignment is usually reconciled several times before it is finished.
 *
 * The two halves behave differently on purpose:
 *
 *   · Sold does NOT touch stock. The sack left the shelf when it was rung up
 *     at the counter, and decrementing again here would count it twice. What
 *     settling changes is the LIABILITY — those units stop being the
 *     supplier's and start being owed for.
 *   · Returned DOES touch stock, because the sacks physically leave, and it
 *     reduces what is owed on an outright purchase for the same reason a torn
 *     sack sent back is not paid for.
 */
export async function reconcileDelivery(
  id: number,
  updates: ReconcileLine[],
): Promise<ActionResult> {
  if (!Number.isInteger(id) || id <= 0) return { ok: false, error: 'Delivery id is required.' }

  try {
    await prisma.$transaction(async (tx) => {
      const delivery = await tx.delivery.findUnique({ where: { id }, include: { items: true } })
      if (!delivery) throw new DeliveryError('That delivery no longer exists.')
      if (delivery.isVoided) {
        throw new DeliveryError('This delivery was voided. There is nothing to settle on it.')
      }

      const terms: DeliveryTerms = isDeliveryTerms(delivery.terms) ? delivery.terms : 'OUTRIGHT'

      // Validated against the rows as they stand RIGHT NOW, inside the
      // transaction — not against whatever the browser was showing when the
      // form opened, which may be an hour and two reconciliations old.
      const problem = validateReconcile(terms, delivery.items, updates)
      if (problem) throw new DeliveryError(problem)

      const byId = new Map(updates.map((update) => [update.productId, update]))

      for (const item of delivery.items) {
        const update = byId.get(item.productId)
        if (!update) continue

        await tx.deliveryItem.update({
          where: { id: item.id },
          data: {
            quantitySettled: { increment: update.soldQuantity },
            quantityReturned: { increment: update.returnedQuantity },
          },
        })

        if (update.returnedQuantity > 0) {
          await tx.product.update({
            where: { id: item.productId },
            data: { stockQty: { decrement: update.returnedQuantity } },
          })
          await tx.stockMovement.create({
            data: {
              productId: item.productId,
              deliveryId: delivery.id,
              type: 'RETURN',
              quantity: -update.returnedQuantity,
              note: `Returned to supplier on delivery #${delivery.id}`,
            },
          })
        }
      }

      // Recomputed from the rows as they now stand rather than nudged by a
      // delta. One arithmetic path means the stored figure cannot drift away
      // from the lines it is meant to summarise.
      const after = await tx.deliveryItem.findMany({ where: { deliveryId: id } })
      const chargeable = chargeableCentavos(after, terms)

      if (chargeable < delivery.amountPaidCentavos) {
        throw new DeliveryError(
          'That would leave this delivery owing less than has already been paid. Check the figures.',
        )
      }

      await tx.delivery.update({ where: { id }, data: { chargeableCentavos: chargeable } })
    })
  } catch (error) {
    if (error instanceof DeliveryError) return { ok: false, error: error.message }
    return { ok: false, error: 'Could not record that.' }
  }

  revalidateRoutes([ROUTES.deliveries, ROUTES.stock, ROUTES.counter, ROUTES.dashboard], {
    layout: true,
  })
  return { ok: true, data: undefined }
}
