import Link from 'next/link'
import type { DayOrder } from '@/lib/types'
import { saleStatus } from '@/lib/money-display'
import { Badge } from '@/components/ui/Badge'
import { Card } from '@/components/ui/Card'
import { EmptyState } from '@/components/ui/EmptyState'
import { Money } from '@/components/ui/Money'
import { formatPeso } from '@/lib/money'
import { sale as saleRoute } from '@/lib/routes'

/** Today's orders, read the way her notebook page reads: quantity, item,
 *  then the name. During changeover she checks this against the paper.
 *
 *  Stacked, not a single wrapping line — this sits in a 384px column, and a
 *  name + item list + total + status all fighting for one row wraps into a
 *  ragged mess the moment an order has more than one or two lines. */
export function DayView({ orders }: { orders: DayOrder[] }) {
  return (
    <Card>
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <h2 className="text-base font-semibold">Today's orders</h2>
        {orders.length > 0 && (
          <span className="text-sm text-ink-muted">
            {orders.length} {orders.length === 1 ? 'order' : 'orders'}
          </span>
        )}
      </div>

      {orders.length === 0 && <EmptyState>No orders yet today.</EmptyState>}

      <ul className="divide-y divide-line">
        {orders.map((order) => {
          const utang = Math.max(0, order.totalCentavos - order.cashPaidCentavos)
          const status = saleStatus(order)
          return (
            <li key={order.saleId} className="animate-row-enter first:pt-0 last:pb-0">
              {/* The whole row is the link, not a "Receipt" word at the end of
                  it. The question being asked of this list is "what was that
                  sale", and the answer is the sale — so the target is the
                  sale's own page, which offers the printable as a tab. */}
              <Link
                href={saleRoute(order.saleId)}
                className="-mx-2 block rounded-control px-2 py-3 transition-colors duration-150 hover:bg-surface-sunk focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
              >
              <div className="flex items-baseline justify-between gap-3">
                <span className="truncate text-sm font-semibold text-ink">
                  {order.customerName ?? 'Walk-in'}
                </span>
                <Money
                  centavos={order.totalCentavos}
                  scale="body"
                  className="shrink-0 font-semibold"
                />
              </div>

              <p className="mt-1 text-sm text-ink-muted">
                {order.lines.map((line) => `${line.quantity} ${line.name}`).join(', ')}
              </p>

              <div className="mt-2">
                {/* Shares its derivation with SalesList's "Recent sales" tab
                    via `saleStatus` (src/lib/money-display.ts) so the two
                    adjacent tabs can never show the same sale two different
                    ways — a credit sale is backed by a live charge, while a cash sale
                    actually covered it, and 'charge-voided' is neither: the
                    debt was cancelled, but no cash arrived, so it stays out
                    of the green `paid` tone. */}
                <div className="flex flex-wrap items-center gap-2">
                  {status === 'credit' && <Badge tone="owed">Credit {formatPeso(utang)}</Badge>}
                  {status === 'partial' && <Badge tone="owed">Partial · credit {formatPeso(utang)}</Badge>}
                  {status === 'cash' && <Badge tone="paid">Cash sale</Badge>}
                  {status === 'charge-voided' && <Badge tone="neutral">Charge voided</Badge>}
                  {status === 'voided' && <Badge tone="muted">Sale voided</Badge>}
                </div>
              </div>
              </Link>
            </li>
          )
        })}
      </ul>
    </Card>
  )
}
