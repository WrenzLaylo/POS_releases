// @vitest-environment jsdom

import { render, screen, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { AppRail } from '@/components/AppRail'

const { usePathname } = vi.hoisted(() => ({ usePathname: vi.fn() }))
vi.mock('next/navigation', () => ({ usePathname }))

// Order matters here, not just membership: Dashboard leads the rail.
const destinations = [
  ['Dashboard', '/dashboard'],
  ['Counter', '/counter'],
  ['Book', '/book'],
  ['Stock', '/stock'],
  // Beside Stock, because it is the other half of the same question: Stock
  // says what is on the shelf, Deliveries says how it got there.
  ['Deliveries', '/deliveries'],
  ['History', '/history'],
] as const

beforeEach(() => {
  usePathname.mockReturnValue('/counter')
  window.localStorage.clear()
})

describe('AppRail', () => {
  it('renders the six destinations in order', () => {
    render(<AppRail />)
    const nav = screen.getByRole('navigation', { name: 'Primary navigation' })
    const links = within(nav).getAllByRole('link')
    expect(links.map((link) => [link.textContent, link.getAttribute('href')])).toEqual(
      destinations,
    )
  })

  it.each([
    ['/book', 'Book'],
    ['/book/42', 'Book'],
    ['/counter', 'Counter'],
  ])('marks the route family for %s as current', (pathname, label) => {
    usePathname.mockReturnValue(pathname)
    render(<AppRail />)
    expect(screen.getByRole('link', { name: label })).toHaveAttribute('aria-current', 'page')
    for (const [other] of destinations.filter(([candidate]) => candidate !== label)) {
      expect(screen.getByRole('link', { name: other })).not.toHaveAttribute('aria-current')
    }
  })

  it('keeps the mark at both widths and drops only the name when collapsed', async () => {
    // The mark survives the collapse and the "VS" initials are gone: a 4rem
    // rail is exactly where the brand is hardest to recognise, so it keeps the
    // real mark rather than falling back to two letters.
    const user = userEvent.setup()
    const { container } = render(<AppRail />)

    const mark = () => container.querySelector('img[src="/brand/violy-store-mark.png"]')
    expect(mark()).not.toBeNull()
    expect(screen.getByText('Violy Store')).toBeInTheDocument()
    expect(screen.queryByText('VS')).not.toBeInTheDocument()

    await user.click(screen.getByRole('button', { name: 'Collapse sidebar' }))
    expect(mark()).not.toBeNull()
    expect(screen.queryByText('Violy Store')).not.toBeInTheDocument()
    expect(screen.queryByText('VS')).not.toBeInTheDocument()
  })

  it('gives the mark an empty alt, so it is not read out beside the name', () => {
    // Decorative here: the shop's name is right next to it in text, and a
    // screen reader announcing "Violy Store logo, Violy Store" is noise.
    const { container } = render(<AppRail />)
    expect(
      container.querySelector('img[src="/brand/violy-store-mark.png"]')?.getAttribute('alt'),
    ).toBe('')
  })

  it('persists the collapsed state across mounts', async () => {
    const user = userEvent.setup()
    const view = render(<AppRail />)
    await user.click(screen.getByRole('button', { name: 'Collapse sidebar' }))
    expect(screen.getByRole('button', { name: 'Expand sidebar' })).toBeInTheDocument()

    view.unmount()
    render(<AppRail />)
    expect(screen.getByRole('button', { name: 'Expand sidebar' })).toBeInTheDocument()
  })
})
