'use client'

import { useMemo, useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import type { CustomerWithDiscount, DiscountRuleView, ProductWithCategory } from '@/lib/types'
import { parsePesoInput } from '@/lib/money'
import { bookEntry } from '@/lib/routes'
import { describeRule } from '@/lib/discount-words'
import { addDiscountRule, removeDiscountRule, updateDiscountRule } from '@/server/discount-rules'
import {
  MAX_BPS,
  isDiscountBasis,
  isDiscountKind,
  isDiscountScope,
  type DiscountBasis,
  type DiscountKind,
  type DiscountScope,
} from '@/lib/discount'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { EmptyState } from '@/components/ui/EmptyState'
import { Field } from '@/components/ui/Field'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'
import { SegmentedControl } from '@/components/ui/SegmentedControl'
import { cn } from '@/lib/cn'

const KIND_OPTIONS = [
  { value: 'AMOUNT', label: '₱' },
  { value: 'PERCENT', label: '%' },
] as const

const BASIS_OPTIONS = [
  { value: 'PER_UNIT', label: 'each unit' },
  { value: 'ONCE_PER_ORDER', label: 'once an order' },
  { value: 'ORDER_TOTAL', label: 'the whole order' },
] as const

const SCOPE_OPTIONS = [
  { value: 'ALL', label: 'Everything' },
  { value: 'CATEGORIES', label: 'These brands' },
  { value: 'PRODUCTS', label: 'These products' },
] as const

type Draft = {
  kind: DiscountKind
  basis: DiscountBasis
  scope: DiscountScope
  raw: string
  unit: string
  categoryIds: number[]
  productIds: number[]
}

const BLANK: Draft = {
  kind: 'AMOUNT',
  basis: 'PER_UNIT',
  scope: 'CATEGORIES',
  raw: '',
  unit: '',
  categoryIds: [],
  productIds: [],
}

function draftFrom(rule: DiscountRuleView): Draft {
  return {
    kind: isDiscountKind(rule.kind) ? rule.kind : 'AMOUNT',
    basis: isDiscountBasis(rule.basis) ? rule.basis : 'PER_UNIT',
    scope: isDiscountScope(rule.scope) ? rule.scope : 'CATEGORIES',
    raw:
      rule.kind === 'PERCENT'
        ? rule.bps > 0
          ? String(rule.bps / 100)
          : ''
        : rule.amountCentavos > 0
          ? String(rule.amountCentavos / 100)
          : '',
    unit: rule.unit ?? '',
    categoryIds: rule.categories.map((each) => each.id),
    productIds: rule.products.map((each) => each.id),
  }
}

/**
 * A customer's standing discounts — all of them.
 *
 * A customer used to hold exactly one, so "₱20 off Atlas bags" and "₱300 off a
 * sack of Broodsow" could not both exist; saving the second silently replaced
 * the first. They are separate rules now, and the screen is a list with one
 * form rather than a single form pretending to be the whole story.
 *
 * At most ONE rule applies to any given line — the most specific — and the
 * list says so under the heading, because a shop with three overlapping rules
 * needs to know that without reading the code.
 */
export function DiscountEditor({
  customer,
  products,
  categories,
}: {
  customer: CustomerWithDiscount
  products: ProductWithCategory[]
  categories: { id: number; name: string }[]
}) {
  const router = useRouter()
  const [pending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)

  /** The rule being edited, 'new' while adding, or null when just looking. */
  const [editing, setEditing] = useState<number | 'new' | null>(null)
  const [draft, setDraft] = useState<Draft>(BLANK)
  const [search, setSearch] = useState('')

  const units = useMemo(() => {
    const seen = new Set<string>()
    for (const product of products) {
      const first = product.unit.split(' ')[0].toLowerCase()
      if (first) seen.add(first)
    }
    return [...seen].sort()
  }, [products])

  const trimmed = draft.raw.trim()
  const parsed = trimmed === '' ? 0 : parsePesoInput(trimmed)
  const invalid = trimmed !== '' && parsed === null
  const value = parsed ?? 0

  const chosenProducts = products.filter((each) => draft.productIds.includes(each.id))
  const needle = search.trim().toLowerCase()
  const matches =
    needle === ''
      ? []
      : products
          .filter(
            (each) => !draft.productIds.includes(each.id) && each.name.toLowerCase().includes(needle),
          )
          .slice(0, 8)

  function set(patch: Partial<Draft>) {
    setDraft((current) => ({ ...current, ...patch }))
  }

  function toggle(list: number[], key: 'categoryIds' | 'productIds', id: number) {
    set({ [key]: list.includes(id) ? list.filter((each) => each !== id) : [...list, id] } as Partial<Draft>)
  }

  function startNew() {
    setError(null)
    setDraft(BLANK)
    setSearch('')
    setEditing('new')
  }

  function startEdit(rule: DiscountRuleView) {
    setError(null)
    setDraft(draftFrom(rule))
    setSearch('')
    setEditing(rule.id)
  }

  /** The rule as it stands in the form, shaped for `describeRule`. */
  const preview = {
    kind: draft.kind,
    amountCentavos: draft.kind === 'AMOUNT' ? value : 0,
    bps: draft.kind === 'PERCENT' ? value : 0,
    basis: draft.basis,
    unit: draft.unit,
    scope: draft.scope,
    categories: categories.filter((each) => draft.categoryIds.includes(each.id)),
    products: chosenProducts,
  }

  function save() {
    setError(null)
    if (invalid) {
      setError(draft.kind === 'PERCENT' ? 'Enter a percentage like 5 or 12.5' : 'Enter an amount like 50')
      return
    }
    if (draft.kind === 'PERCENT' && value > MAX_BPS) {
      setError('A discount cannot be more than 100%.')
      return
    }

    const input = {
      kind: draft.kind,
      amountCentavos: draft.kind === 'AMOUNT' ? value : 0,
      bps: draft.kind === 'PERCENT' ? value : 0,
      basis: draft.basis,
      unit: draft.unit,
      scope: draft.scope,
      categoryIds: draft.categoryIds,
      productIds: draft.productIds,
    }

    startTransition(async () => {
      const result =
        editing === 'new'
          ? await addDiscountRule(customer.id, input)
          : await updateDiscountRule(editing as number, input)
      if (!result.ok) {
        setError(result.error)
        return
      }
      setEditing(null)
      router.refresh()
    })
  }

  function remove(ruleId: number) {
    setError(null)
    startTransition(async () => {
      const result = await removeDiscountRule(ruleId)
      if (!result.ok) {
        setError(result.error)
        return
      }
      if (editing === ruleId) setEditing(null)
      router.refresh()
    })
  }

  const scoped = draft.basis !== 'ORDER_TOTAL'

  return (
    <div className="grid gap-4">
      <Card>
        <div className="mb-3 flex flex-wrap items-start justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold">Standing discounts</h2>
            <p className="text-sm text-ink-muted">
              {customer.discountRules.length === 0
                ? 'None yet.'
                : 'Only one applies to any item — the most specific. A rule naming the product beats one naming its brand.'}
            </p>
          </div>
          <Button variant="primary" onClick={startNew} disabled={pending}>
            Add a discount
          </Button>
        </div>

        {customer.discountRules.length === 0 ? (
          <EmptyState>
            No standing discount. Anything you add here applies automatically at the counter.
          </EmptyState>
        ) : (
          <ul className="divide-y divide-line rounded-card border border-line">
            {customer.discountRules.map((rule) => (
              <li key={rule.id} className="flex flex-wrap items-center justify-between gap-3 px-4 py-3">
                <span className="text-sm text-ink">{describeRule(rule)}</span>
                <span className="flex shrink-0 items-center gap-1">
                  <Button variant="ghost" size="sm" disabled={pending} onClick={() => startEdit(rule)}>
                    Edit
                  </Button>
                  <Button variant="danger" size="sm" disabled={pending} onClick={() => remove(rule.id)}>
                    Remove
                  </Button>
                </span>
              </li>
            ))}
          </ul>
        )}

        {error && !editing && <FormError className="mt-3">{error}</FormError>}
      </Card>

      {editing !== null && (
        <Card>
          <h2 className="mb-4 text-base font-semibold">
            {editing === 'new' ? 'New discount' : 'Edit discount'}
          </h2>

          <div className="grid gap-5">
            <div className="flex flex-wrap items-end gap-3">
              <Field label="Take">
                <div className="flex items-center gap-2">
                  <Input
                    inputMode="decimal"
                    value={draft.raw}
                    onChange={(event) => set({ raw: event.target.value })}
                    placeholder="0.00"
                    aria-label={draft.kind === 'PERCENT' ? 'Discount percentage' : 'Discount in pesos'}
                    className={cn('w-32 tabular-nums', invalid && 'border-owed')}
                  />
                  <SegmentedControl
                    ariaLabel="Discount type"
                    options={KIND_OPTIONS}
                    value={draft.kind}
                    onValueChange={(v) => set({ kind: v as DiscountKind })}
                  />
                </div>
              </Field>

              <Field label="Off">
                <SegmentedControl
                  ariaLabel="What the discount comes off"
                  options={BASIS_OPTIONS}
                  value={draft.basis}
                  onValueChange={(v) => set({ basis: v as DiscountBasis })}
                />
              </Field>

              {scoped && units.length > 0 && (
                <Field label="Sold by the">
                  <SegmentedControl
                    ariaLabel="Which unit the discount is per"
                    options={[
                      { value: '', label: 'any unit' },
                      ...units.map((each) => ({ value: each, label: each })),
                    ]}
                    value={draft.unit}
                    onValueChange={(v) => set({ unit: v })}
                  />
                </Field>
              )}
            </div>

            {scoped && (
              <div className="grid gap-3 border-t border-line pt-5">
                <Field label="Which items">
                  <SegmentedControl
                    ariaLabel="What the discount covers"
                    options={SCOPE_OPTIONS}
                    value={draft.scope}
                    onValueChange={(v) => set({ scope: v as DiscountScope })}
                  />
                </Field>

                {draft.scope === 'CATEGORIES' && (
                  <div className="flex flex-wrap gap-2">
                    {categories.map((category) => {
                      const on = draft.categoryIds.includes(category.id)
                      return (
                        <button
                          key={category.id}
                          type="button"
                          aria-pressed={on}
                          onClick={() => toggle(draft.categoryIds, 'categoryIds', category.id)}
                          className={cn(
                            'flex h-9 items-center rounded-control border px-3 text-sm font-medium transition-colors duration-150',
                            on
                              ? 'border-accent bg-accent-soft text-accent'
                              : 'border-line text-ink-muted hover:border-line-strong hover:text-ink',
                          )}
                        >
                          {category.name}
                        </button>
                      )
                    })}
                  </div>
                )}

                {draft.scope === 'PRODUCTS' && (
                  <div className="grid gap-3">
                    {chosenProducts.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {chosenProducts.map((product) => (
                          <button
                            key={product.id}
                            type="button"
                            onClick={() => toggle(draft.productIds, 'productIds', product.id)}
                            aria-label={`Remove ${product.name}`}
                            className="flex h-9 items-center gap-2 rounded-control border border-accent bg-accent-soft px-3 text-sm font-medium text-accent"
                          >
                            {product.name}
                            <span aria-hidden="true" className="text-ink-subtle">
                              ×
                            </span>
                          </button>
                        ))}
                      </div>
                    )}

                    <Field label="Add a product">
                      <Input
                        type="search"
                        value={search}
                        onChange={(event) => setSearch(event.target.value)}
                        placeholder="Start typing a name"
                        className="w-full max-w-md"
                      />
                    </Field>

                    {matches.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {matches.map((product) => (
                          <button
                            key={product.id}
                            type="button"
                            onClick={() => {
                              toggle(draft.productIds, 'productIds', product.id)
                              setSearch('')
                            }}
                            className="flex h-9 items-center rounded-control border border-line px-3 text-sm text-ink-muted hover:border-accent hover:bg-accent-soft hover:text-accent"
                          >
                            {product.name}
                            <span className="ml-2 text-xs text-ink-subtle">{product.unit}</span>
                          </button>
                        ))}
                      </div>
                    )}

                    {needle !== '' && matches.length === 0 && (
                      <p className="text-sm text-ink-subtle">Nothing matches that name.</p>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* The rule read back in plain words, by the same function the
                counter uses. A discount she cannot say out loud is one she
                cannot check, and this catches "₱20 off nothing yet" before it
                is saved and quietly does nothing. */}
            <p className="rounded-control border border-line bg-surface-sunk px-4 py-3 text-sm text-ink">
              {describeRule(preview)}
            </p>

            {error && <FormError>{error}</FormError>}

            <div className="flex items-center gap-2">
              <Button variant="success" onClick={save} disabled={pending}>
                {pending ? 'Saving…' : editing === 'new' ? 'Add discount' : 'Save changes'}
              </Button>
              <Button variant="ghost" onClick={() => setEditing(null)} disabled={pending}>
                Cancel
              </Button>
            </div>
          </div>
        </Card>
      )}

      <div>
        <Button variant="ghost" onClick={() => router.push(bookEntry(customer.id))}>
          Back to {customer.name}
        </Button>
      </div>
    </div>
  )
}
