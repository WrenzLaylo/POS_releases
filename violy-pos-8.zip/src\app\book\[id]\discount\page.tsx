import { notFound } from 'next/navigation'
import Link from 'next/link'
import { getCustomer } from '@/server/customers'
import { listCategories, listProducts } from '@/server/products'
import { bookEntry } from '@/lib/routes'
import { PageHeader } from '@/components/ui/PageHeader'
import { DiscountEditor } from './DiscountEditor'

export const dynamic = 'force-dynamic'

/**
 * A screen for one customer's standing discount.
 *
 * Its own route rather than a taller dialog, because the discount now names
 * individual products and fifty-five checkboxes is not a control. The customer
 * form goes back to being name, phone and notes.
 */
export default async function CustomerDiscountPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const customerId = Number(id)
  if (!Number.isInteger(customerId) || customerId <= 0) notFound()

  const customer = await getCustomer(customerId)
  if (!customer) notFound()

  // Unarchived only, and the whole catalogue: the picker searches it rather
  // than rendering it, so its size costs nothing on screen.
  const [products, categories] = await Promise.all([listProducts(), listCategories()])

  return (
    <PageHeader
      title={`${customer.name} — discount`}
      actions={
        <Link
          href={bookEntry(customerId)}
          className="text-sm font-medium text-ink-muted hover:text-ink"
        >
          ← Back to {customer.name}
        </Link>
      }
    >
      <DiscountEditor customer={customer} products={products} categories={categories} />
    </PageHeader>
  )
}
