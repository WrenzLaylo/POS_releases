#!/usr/bin/env node
/**
 * Packages a release for the shop laptop to download.
 *
 *   npm run release -- "What changed, in one sentence" ["another sentence"]
 *
 * Produces two files in `release-out/`:
 *
 *   violy-pos-<build>.zip   the app, without any of the shop's data
 *   latest.json             build number, notes, download URL, SHA-256
 *
 * Both then go into the PUBLIC releases repository. That repository holds only
 * these two things; the source stays private. The laptop reads `latest.json`
 * over plain HTTPS — no git, no GitHub account, nothing that expires.
 *
 * WHAT IS DELIBERATELY NOT IN THE ZIP, and this is the safety rather than an
 * optimisation: the database, `.env`, `backups/`, `data/uploads`, `exports/`,
 * `node_modules/` and `.git`. The shop's data survives an update because it was
 * never in the delivery — not because the updater remembered to skip it. The
 * seed scripts holding real customer names and supplier prices are excluded for
 * the same reason: the releases repository is public.
 */

import { execSync } from 'node:child_process'
import { createHash, createPrivateKey, sign } from 'node:crypto'
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { mkdir, readFile, rm } from 'node:fs/promises'
import path from 'node:path'

const ROOT = process.cwd()
const OUT = path.join(ROOT, 'release-out')
const NEWLINE = String.fromCharCode(10)

/** Where the laptop will fetch it from. One definition, shared with the app,
 *  the desktop shell and the updater. */
const CHANNEL = JSON.parse(readFileSync(path.join(ROOT, 'release-channel.json'), 'utf8'))
const BASE_URL = CHANNEL.baseUrl

/** Held only on this machine, never committed. See docs/RELEASE-SIGNING.md. */
const KEY_FILE = path.join(ROOT, '.release-signing-key.pem')

/**
 * The canonical form that gets signed.
 *
 * MUST match `canonicalManifest` in `src/lib/update-signature.ts` exactly. It
 * is duplicated rather than imported because this script runs under plain Node
 * before any TypeScript is compiled — so the two are kept honest by
 * `update-signature.test.ts`, which asserts this exact shape rather than
 * trusting that nobody edited one of them.
 *
 * `notes` are excluded on purpose: they are prose for the operator and get
 * reworded, and nothing about them decides what is downloaded or trusted.
 */
function canonicalManifest({ build, version, zipUrl, sha256 }) {
  return [
    `build:${build}`,
    `version:${version}`,
    `zipUrl:${zipUrl}`,
    `sha256:${String(sha256).toLowerCase()}`,
  ].join(NEWLINE)
}

/**
 * Signs the four fields that decide what gets installed.
 *
 * Ed25519 takes a NULL algorithm — the curve carries its own hash, and passing
 * a digest name here throws instead of signing.
 */
function signManifest(fields) {
  if (!existsSync(KEY_FILE)) {
    throw new Error(
      [
        `No signing key at ${KEY_FILE}`,
        '',
        'A release has to be signed, or the shop will refuse to install it.',
        'If this is a new machine, copy the key across from wherever it is kept.',
        'If no key has ever been made, run:  node scripts/generate-signing-key.mjs',
        '  — but note that generating a NEW key orphans every laptop already',
        '    running a build that trusts the old one.',
      ].join(NEWLINE),
    )
  }

  const key = createPrivateKey(readFileSync(KEY_FILE, 'utf8'))
  return sign(null, Buffer.from(canonicalManifest(fields), 'utf8'), key).toString('base64')
}

/**
 * Everything the app needs to RUN, and nothing else.
 *
 * An allow-list, not a list of exclusions. An exclusion list silently ships
 * whatever is added to the project later — including, one day, something
 * holding the shop's data.
 */
const INCLUDE = [
  'src',
  'public',
  'prisma/schema.prisma',
  'prisma/migrations',
  'electron',
  'scripts',
  'package.json',
  'package-lock.json',
  'next.config.ts',
  'tsconfig.json',
  'postcss.config.mjs',
  'vitest.config.ts',
  '.env.example',
  'release-channel.json',
  'install.cmd',
  'run-pos.vbs',
  'start-pos.cmd',
  'INSTALL.md',
]

/**
 * Files matching these never travel, even from inside an included folder.
 *
 * `real-data.ts` and `chicken-feeds.ts` are one-time loaders holding 45 real
 * customer names and real supplier prices. They have already been run; the data
 * lives in the database now. The releases repository is public, so they stay
 * behind.
 */
const EXCLUDE_NAMES = ['real-data.ts', 'chicken-feeds.ts', 'demo.ts', 'demo-clear.ts']

const say = (message) => console.log(message)

/** The build number the shop can actually see, read from the live channel. */
async function publishedBuild() {
  try {
    const response = await fetch(`${BASE_URL}/${CHANNEL.manifestFile}?t=${Date.now()}`, {
      cache: 'no-store',
      signal: AbortSignal.timeout(10_000),
    })
    // A 404 is not a failure: it is what "nothing has ever been published"
    // looks like, and the answer to that is build 1.
    if (response.status === 404) return { reachable: true, build: 0 }
    if (!response.ok) return { reachable: false, build: 0 }
    const value = await response.json()
    return { reachable: true, build: Number.isInteger(value.build) ? value.build : 0 }
  } catch {
    return { reachable: false, build: 0 }
  }
}

/** What the last release from THIS machine was, if there was one. */
function localBuild() {
  const previous = path.join(OUT, 'latest.json')
  if (!existsSync(previous)) return 0
  try {
    const value = JSON.parse(readFileSync(previous, 'utf8'))
    return Number.isInteger(value.build) ? value.build : 0
  } catch {
    return 0
  }
}

/**
 * The next build number, taken from what is PUBLISHED rather than from disk.
 *
 * `release-out/` is gitignored, so a clean checkout — or simply a second
 * machine, or this one after a tidy-up — has no memory of the last release and
 * the old version of this function restarted the count at 1. That is the worst
 * possible failure here and a completely silent one: the laptop compares
 * `latest.build > installed.build`, so a repeated number reads as "you have
 * the newest version" and the shop is told it is up to date forever while
 * every fix sits unshipped. It happened; this is the fix.
 *
 * Refuses to guess when the channel cannot be reached and this machine has no
 * record either. Publishing a colliding build number is worse than not
 * publishing today.
 */
async function nextBuild() {
  const published = await publishedBuild()
  const local = localBuild()

  if (!published.reachable && local === 0) {
    throw new Error(
      [
        'Cannot reach the releases channel and this machine has no record of the last build.',
        '  Numbering from 1 would collide with a build the shop already has, and a repeated',
        '  number reads as "up to date" — the update would never arrive. Check the internet',
        `  connection and try again, or read the build number from ${BASE_URL}/${CHANNEL.manifestFile}.`,
      ].join(NEWLINE),
    )
  }

  const highest = Math.max(published.build, local)
  if (published.reachable && local > published.build) {
    say(`  note: build ${local} was packaged here but never published.`)
  }
  return highest + 1
}

function today() {
  const now = new Date()
  const pad = (n) => String(n).padStart(2, '0')
  return `${now.getFullYear()}.${pad(now.getMonth() + 1)}.${pad(now.getDate())}`
}

async function main() {
  const notes = process.argv.slice(2).filter((note) => note.trim() !== '')
  if (notes.length === 0) {
    console.error('Say what changed:')
    console.error('  npm run release -- "Deliveries can now be recorded on consignment"')
    process.exit(1)
  }

  const build = await nextBuild()
  const version = today()
  const zipName = `violy-pos-${build}.zip`

  say(`\nPackaging build ${build} (${version})…`)

  // Built first, so a release that cannot compile never reaches the shop.
  say('  building…')
  execSync('npm run build', { cwd: ROOT, stdio: 'inherit' })

  const staging = path.join(OUT, 'staging')
  await rm(staging, { recursive: true, force: true })
  await mkdir(staging, { recursive: true })

  for (const entry of INCLUDE) {
    const from = path.join(ROOT, entry)
    if (!existsSync(from)) continue
    const to = path.join(staging, entry)
    await mkdir(path.dirname(to), { recursive: true })
    execSync(
      process.platform === 'win32'
        ? `powershell -NoProfile -Command "Copy-Item -LiteralPath '${from}' -Destination '${to}' -Recurse -Force"`
        : `cp -R "${from}" "${to}"`,
      { stdio: 'ignore' },
    )
  }

  for (const name of EXCLUDE_NAMES) {
    await rm(path.join(staging, 'prisma', name), { force: true })
  }

  // The stamp the laptop compares against. Written into the zip, so an
  // installed copy always knows which build it is.
  writeFileSync(
    path.join(staging, 'release.json'),
    JSON.stringify({ build, version, installedAt: null }, null, 2) + NEWLINE,
    'utf8',
  )

  const zipPath = path.join(OUT, zipName)
  await rm(zipPath, { force: true })
  say('  zipping…')
  execSync(
    process.platform === 'win32'
      ? `powershell -NoProfile -Command "Compress-Archive -Path '${staging}\\*' -DestinationPath '${zipPath}' -Force"`
      : `cd "${staging}" && zip -qr "${zipPath}" .`,
    { stdio: 'ignore' },
  )

  const bytes = await readFile(zipPath)
  const sha256 = createHash('sha256').update(bytes).digest('hex')

  const signed = { build, version, zipUrl: `${BASE_URL}/${zipName}`, sha256 }
  const manifest = {
    ...signed,
    publishedAt: new Date().toISOString(),
    notes,
    // Proves this manifest came from someone holding the private key, which
    // GitHub never does. The sha256 above proves the zip is intact; this
    // proves it is ours. Neither replaces the other.
    signature: signManifest(signed),
  }
  writeFileSync(path.join(OUT, 'latest.json'), JSON.stringify(manifest, null, 2) + NEWLINE, 'utf8')
  await rm(staging, { recursive: true, force: true })

  say(`\n  ${zipName}  ${(bytes.length / 1_000_000).toFixed(1)} MB`)
  say(`  sha256 ${sha256.slice(0, 16)}…`)
  say(`\nWritten to ${OUT}`)
  say('\nTo publish, copy BOTH files into the public releases repository and push:')
  say(`  ${zipName}`)
  say('  latest.json')
  say('\nPush latest.json LAST. A manifest that names a zip nobody has uploaded')
  say('yet sends every laptop to a 404.\n')
}

main().catch((error) => {
  console.error(`\nRelease FAILED: ${error instanceof Error ? error.message : String(error)}\n`)
  process.exit(1)
})
