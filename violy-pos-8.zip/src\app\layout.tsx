import type { Metadata } from 'next'
import { Archivo, Inter, JetBrains_Mono } from 'next/font/google'
import { AppRail } from '@/components/AppRail'
import { AppTopbar } from '@/components/AppTopbar'
import { getNotifications } from '@/server/notifications'
import './globals.css'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
})

// Headings and section labels. The width axis is what makes the UI read as
// an instrument panel rather than a generic dashboard.
const archivo = Archivo({
  subsets: ['latin'],
  variable: '--font-archivo',
  display: 'swap',
  axes: ['wdth'],
})

// Every peso figure and stock count renders in this, via the `Money`
// primitive. Genuinely tabular, so columns of figures align.
const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-jetbrains-mono',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'Violy Store POS',
  description: 'Point of sale for a pig feeds dealer',
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const notifications = await getNotifications()

  return (
    <html
      lang="en"
      className={`${inter.variable} ${archivo.variable} ${jetbrainsMono.variable}`}
    >
      <body className="bg-canvas font-sans text-ink antialiased">
        {/* The three `app-*` class names exist for the print stylesheet, which
            has to undo this shell's `overflow: hidden` and fixed heights.
            Naming the elements beats describing their shape: the previous
            rules matched on `body > div > div`, which stopped being true the
            moment the tree changed and failed silently — the printed page
            simply came out wrong. */}
        <div className="app-shell flex h-screen overflow-hidden">
          <AppRail />
          <div className="app-body flex min-w-0 flex-1 flex-col">
            <AppTopbar notifications={notifications} />
            {/* `relative` is load-bearing, not decoration. Tailwind's `sr-only` is
                `position: absolute`, and an absolutely-positioned element resolves
                against the nearest POSITIONED ancestor — with none, that is the
                document itself, so it escapes this scroll container completely
                and is not clipped by it. A hidden radio inside a
                `SegmentedControl` far down a long page therefore stretched the
                DOCUMENT to reach it, giving the window its own scrollbar beside
                this one: two scrollbars, and a band of blank page below the app.
                Making this element the containing block keeps such things inside
                it. */}
            <main className="app-main relative min-h-0 flex-1 overflow-y-auto">{children}</main>
          </div>
        </div>
      </body>
    </html>
  )
}
