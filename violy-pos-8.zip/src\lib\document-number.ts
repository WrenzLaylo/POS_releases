/**
 * Reference numbers for printed documents.
 *
 * `OR-2026-000042` rather than `#P42`. Three reasons it is worth the extra
 * characters: the prefix says what the document IS without reading it, the
 * year makes a reference unambiguous across the life of the business, and the
 * padding keeps references the same width so a column of them lines up and a
 * missing one is visible.
 *
 * The number itself is the underlying row id, NOT a separate counter. A
 * separate counter would need its own storage and its own contention rules,
 * and could drift out of step with the record it names. The row id is already
 * unique, already permanent, and already the thing anyone would look up.
 *
 * That does mean references are not gapless — deleting is not something this
 * app does, but a failed insert still consumes an id. A gapless series is a
 * stricter requirement than anything asked for here, and faking one on top of
 * autoincrement ids would be worse than not having it.
 */

export type DocumentKind =
  | 'SALES_INVOICE'
  | 'SALES_RECEIPT'
  | 'CREDIT_AGREEMENT'
  | 'PAYMENT_RECEIPT'
  | 'STATEMENT'
  | 'DELIVERY_RECEIPT'

const PREFIXES: Record<DocumentKind, string> = {
  // Charged, not yet paid — an invoice asks for money.
  SALES_INVOICE: 'INV',
  // Paid at the counter — a receipt acknowledges money already handed over.
  SALES_RECEIPT: 'OR',
  // A credit agreement, not a sales invoice: it records terms the
  // customer agreed to, and it is the document the payment receipts
  // below refer back to.
  CREDIT_AGREEMENT: 'CA',
  PAYMENT_RECEIPT: 'PR',
  STATEMENT: 'SOA',
  // The only document here that flows the other way: goods coming IN, and the
  // copy a supplier's driver expects back. "DR" is what the trade calls it.
  DELIVERY_RECEIPT: 'DR',
}

export const DOCUMENT_TITLES: Record<DocumentKind, string> = {
  SALES_INVOICE: 'Sales Invoice',
  SALES_RECEIPT: 'Official Receipt',
  CREDIT_AGREEMENT: 'Credit Agreement and Invoice',
  PAYMENT_RECEIPT: 'Payment Receipt',
  STATEMENT: 'Statement of Account',
  DELIVERY_RECEIPT: 'Delivery Receipt',
}

/**
 * `INV-2026-000042`. The year comes from the document's own date, not from
 * today: reprinting last year's receipt must not renumber it into this year.
 */
export function documentNumber(kind: DocumentKind, id: number, issuedAt: Date): string {
  const year = issuedAt.getFullYear()
  return `${PREFIXES[kind]}-${year}-${String(id).padStart(6, '0')}`
}
