import type { ReactNode } from 'react'
import { cn } from '@/lib/cn'

/** A form-level error message — one treatment used everywhere a save/void/
 *  submit can fail, so "errors fade in rather than appearing abruptly"
 *  holds on every screen instead of half of them. */
export function FormError({ className, children }: { className?: string; children: ReactNode }) {
  return (
    <p className={cn('animate-fade-in text-sm text-owed', className)}>
      {children}
    </p>
  )
}
