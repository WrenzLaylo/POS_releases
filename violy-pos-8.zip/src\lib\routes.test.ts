import { existsSync } from 'node:fs'
import { join } from 'node:path'
import { describe, expect, it } from 'vitest'
import {
  ROUTES,
  accountStatement,
  bookEntry,
  BOOK_BULK,
  NEW_DELIVERY,
  STOCK_COUNT,
  customerDiscount,
  delivery,
  settleDelivery,
  paymentReceipt,
  planInvoice,
  sale,
  saleReceipt,
} from './routes'

describe('ROUTES', () => {
  it('every route is absolute and has no trailing slash', () => {
    for (const route of Object.values(ROUTES)) {
      expect(route.startsWith('/')).toBe(true)
      expect(route.endsWith('/')).toBe(false)
    }
  })

  it('names every destination and nothing else', () => {
    // Settings is a route but not a rail destination — it is a utility,
    // reached from the topbar. The rail carries the six workspaces.
    expect(Object.keys(ROUTES).sort()).toEqual([
      'book',
      'counter',
      'dashboard',
      'deliveries',
      'history',
      'settings',
      'stock',
    ])
  })

  it('builds customer ledger, bulk and receipt paths', () => {
    expect(bookEntry(42)).toBe('/book/42')
    expect(BOOK_BULK).toBe('/book/bulk')
    expect(NEW_DELIVERY).toBe('/deliveries/new')
    expect(STOCK_COUNT).toBe('/stock/count')
    expect(sale(42)).toBe('/history/42')
    expect(saleReceipt(42)).toBe('/history/42/receipt')
  })

  it('nests the three utang documents under the customer they concern', () => {
    expect(planInvoice(42, 7)).toBe('/book/42/plan/7')
    expect(paymentReceipt(42, 9)).toBe('/book/42/payment/9')
    expect(accountStatement(42)).toBe('/book/42/statement')
  })
})

/**
 * `revalidatePath` pointing at a route that does not exist has shipped as a
 * bug in this repo twice (`revalidatePath('/pos')` in both products.ts and
 * sales.ts, after /pos was deleted). `vitest.config.ts` stubs `next/cache`,
 * so revalidation itself is unobservable in tests — but a route constant that
 * resolves to nothing is observable, and that is the actual defect.
 */
describe('ROUTES resolve to real pages', () => {
  it.each(Object.entries(ROUTES))('%s (%s) has a page.tsx', (_name, route) => {
    const dir = join(process.cwd(), 'src', 'app', route.replace(/^\//, ''))
    expect(existsSync(join(dir, 'page.tsx'))).toBe(true)
  })
})


describe('dynamic route builders resolve to real pages', () => {
  it('saleReceipt points at the history receipt page', () => {
    const page = join(process.cwd(), 'src', 'app', 'history', '[id]', 'receipt', 'page.tsx')
    expect(existsSync(page)).toBe(true)
  })

  it.each([
    ['planInvoice', ['book', '[id]', 'plan', '[planId]']],
    ['paymentReceipt', ['book', '[id]', 'payment', '[entryId]']],
    ['accountStatement', ['book', '[id]', 'statement']],
    ['sale', ['history', '[id]']],
    ['bookEntry', ['book', '[id]']],
    ['BOOK_BULK', ['book', 'bulk']],
    ['NEW_DELIVERY', ['deliveries', 'new']],
    ['STOCK_COUNT', ['stock', 'count']],
    // Guarded now because it was NOT: this helper existed for weeks pointing
    // at a page nobody had built, and nothing failed. Every route constant
    // belongs on this list or the check is only as good as who remembers it.
    ['delivery', ['deliveries', '[id]']],
    ['customerDiscount', ['book', '[id]', 'discount']],
    ['settleDelivery', ['deliveries', '[id]', 'settle']],
  ])('%s points at a real page', (_name, segments) => {
    expect(existsSync(join(process.cwd(), 'src', 'app', ...segments, 'page.tsx'))).toBe(true)
  })
})
