'use client'

import { useMemo, useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import type { ProductWithCategory } from '@/lib/types'
import { createDelivery } from '@/server/deliveries'
import {
  deliveryTotal,
  lineCost,
  validateDelivery,
  type DeliveryTerms,
} from '@/lib/delivery'
import { parsePesoInput, toPesos } from '@/lib/money'
import { dayKey, parseDayKey } from '@/lib/dates'
import { ROUTES } from '@/lib/routes'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { DatePicker } from '@/components/ui/DatePicker'
import { Field } from '@/components/ui/Field'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'
import { Money } from '@/components/ui/Money'
import { SegmentedControl } from '@/components/ui/SegmentedControl'
import { Select } from '@/components/ui/Select'
import { Textarea } from '@/components/ui/Textarea'
import type { SupplierOption } from './DeliveriesScreen'

type Row = {
  /** Stable across inserts and removals so React keeps focus in the right box. */
  key: number
  productId: string
  quantity: string
  cost: string
}

let nextKey = 1
function blankRow(): Row {
  nextKey += 1
  return { key: nextKey, productId: '', quantity: '', cost: '' }
}

/**
 * Recording what arrived.
 *
 * A full page rather than a dialog, because the number of lines is unbounded
 * and a dialog is sized for a question. As a dialog the product picker had
 * about six characters of width and every option rendered as "Ch…" — see the
 * note on `deliveries/new/page.tsx`.
 *
 * The preview at the bottom calls the SAME `deliveryTotal` and
 * `validateDelivery` the Server Action calls, so what she reads off the screen
 * before saving is what gets written — the same contract the counter's
 * discount preview holds to. A total computed twice, two ways, eventually
 * disagrees with itself.
 *
 * The cost box is seeded from what the product cost last time. That is the
 * number that is usually still right, and seeing it makes a price increase
 * visible at the moment it matters rather than three weeks later in a margin
 * report.
 */
export function DeliveryForm({
  suppliers,
  products,
}: {
  suppliers: SupplierOption[]
  products: ProductWithCategory[]
}) {
  const router = useRouter()
  const [pending, startTransition] = useTransition()

  const [supplierId, setSupplierId] = useState(String(suppliers[0]?.id ?? ''))
  const [terms, setTerms] = useState<DeliveryTerms>('OUTRIGHT')
  const [receivedAt, setReceivedAt] = useState(dayKey(new Date()))
  const [reference, setReference] = useState('')
  const [note, setNote] = useState('')
  const [amountPaid, setAmountPaid] = useState('')
  const [rows, setRows] = useState<Row[]>([blankRow()])
  const [error, setError] = useState<string | null>(null)

  // Generated once per visit, not per attempt: a retry after a failed save must
  // reuse it, or the retry is what creates the duplicate this key prevents.
  const [clientKey] = useState(
    () => `delivery-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
  )

  const byId = useMemo(() => new Map(products.map((product) => [product.id, product])), [products])

  function setRow(key: number, patch: Partial<Row>) {
    setRows((current) =>
      current.map((row) => {
        if (row.key !== key) return row
        const next = { ...row, ...patch }
        // Seeded, never overwritten: if she has already typed a cost, changing
        // the product must not silently replace what she entered.
        if (patch.productId !== undefined && row.cost.trim() === '') {
          const product = byId.get(Number(patch.productId))
          if (product && product.costPrice > 0) next.cost = String(toPesos(product.costPrice))
        }
        return next
      }),
    )
  }

  const parsedLines = rows
    .filter((row) => row.productId !== '')
    .map((row) => ({
      productId: Number(row.productId),
      quantity: Number(row.quantity),
      unitCostCentavos: parsePesoInput(row.cost) ?? Number.NaN,
    }))

  const usableLines = parsedLines.filter(
    (line) => Number.isFinite(line.quantity) && Number.isFinite(line.unitCostCentavos),
  )
  const total = deliveryTotal(usableLines)
  // Forced to zero on a consignment: nothing is owed on arrival, so anything
  // left in the box from before switching terms must not be sent.
  const paidCentavos =
    terms === 'CONSIGNMENT'
      ? 0
      : amountPaid.trim() === ''
        ? 0
        : (parsePesoInput(amountPaid) ?? Number.NaN)

  const input = {
    supplierId: Number(supplierId),
    terms,
    receivedAt: parseDayKey(receivedAt) ?? new Date(Number.NaN),
    reference,
    note,
    lines: parsedLines,
    amountPaidCentavos: Number.isFinite(paidCentavos) ? paidCentavos : Number.NaN,
  }
  // The same check the server will run, so the button is only enabled when the
  // save would actually succeed.
  const problem = validateDelivery(input)
  const started = rows.some((row) => row.productId !== '')

  function save() {
    setError(null)
    startTransition(async () => {
      const result = await createDelivery({ ...input, clientKey })
      if (!result.ok) {
        setError(result.error)
        return
      }
      router.push(ROUTES.deliveries)
      router.refresh()
    })
  }

  return (
    <div className="grid gap-6">
      <Card>
        <div className="grid gap-5">
          {/* Terms first, because everything below reads differently depending
              on the answer: on a consignment the sacks go on the shelf but
              nothing is owed for them, and "paid now" has nothing to pay
              against. */}
          <div className="grid gap-1.5">
            <span className="text-xs font-semibold uppercase tracking-wide text-ink-subtle">
              Terms
            </span>
            <SegmentedControl
              ariaLabel="Delivery terms"
              options={[
                { value: 'OUTRIGHT', label: 'Bought outright' },
                { value: 'CONSIGNMENT', label: 'Consignment' },
              ]}
              value={terms}
              onValueChange={(value) =>
                setTerms(value === 'CONSIGNMENT' ? 'CONSIGNMENT' : 'OUTRIGHT')
              }
            />
            <p className="text-xs text-ink-subtle">
              {terms === 'CONSIGNMENT'
                ? 'The supplier’s stock on your shelf. You owe nothing until it sells, and whatever does not sell goes back.'
                : 'You bought it. The full amount is owed from today.'}
            </p>
          </div>

          <div className="grid min-w-0 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <Field label="Supplier">
              <Select
                value={supplierId}
                onChange={(event) => setSupplierId(event.target.value)}
                className="w-full"
              >
                {suppliers.map((supplier) => (
                  <option key={supplier.id} value={String(supplier.id)}>
                    {supplier.name}
                  </option>
                ))}
              </Select>
            </Field>

            <Field label="Date received">
              <DatePicker
                value={receivedAt}
                onChange={setReceivedAt}
                aria-label="Date received"
                className="w-full"
              />
            </Field>

            <Field label="Their reference (optional)">
              <Input
                value={reference}
                onChange={(event) => setReference(event.target.value)}
                placeholder="DR number on their paper"
                className="w-full"
              />
            </Field>

            {/* Hidden on a consignment rather than disabled: there is nothing
                to pay against yet, and a greyed-out box invites the question
                of why. */}
            {terms === 'OUTRIGHT' && (
              <Field label="Paid now (optional)">
                <Input
                  inputMode="decimal"
                  value={amountPaid}
                  onChange={(event) => setAmountPaid(event.target.value)}
                  placeholder="0.00"
                  className="w-full tabular-nums"
                />
              </Field>
            )}
          </div>
        </div>
      </Card>

      <Card>
        <h2 className="mb-3 text-base font-semibold">What arrived</h2>

        {/* A table on wide screens and stacked cards on narrow ones. The
            product name is the widest thing here and gets the flexible column;
            everything else is a short number with a fixed width, so the name
            keeps whatever is left rather than being squeezed by them. */}
        <div className="overflow-x-auto">
          <table className="w-full min-w-[44rem] text-sm">
            <thead className="text-left text-xs uppercase tracking-wide text-ink-muted">
              <tr>
                <th className="pb-2 font-medium">Product</th>
                <th className="w-24 pb-2 font-medium">Quantity</th>
                <th className="w-32 pb-2 font-medium">Cost each</th>
                <th className="w-32 pb-2 text-right font-medium">Line total</th>
                <th className="w-12 pb-2" />
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => {
                const line = row.productId
                  ? {
                      productId: Number(row.productId),
                      quantity: Number(row.quantity),
                      unitCostCentavos: parsePesoInput(row.cost) ?? Number.NaN,
                    }
                  : null
                const showable =
                  line && Number.isFinite(line.quantity) && Number.isFinite(line.unitCostCentavos)
                const product = byId.get(Number(row.productId))

                return (
                  <tr key={row.key} className="align-top">
                    <td className="py-1.5 pr-2">
                      <Select
                        aria-label="Product"
                        value={row.productId}
                        onChange={(event) => setRow(row.key, { productId: event.target.value })}
                        className="w-full"
                      >
                        <option value="">Choose a product…</option>
                        {products.map((candidate) => (
                          <option key={candidate.id} value={String(candidate.id)}>
                            {candidate.name}
                          </option>
                        ))}
                      </Select>
                      {product && (
                        <span className="mt-1 block text-xs text-ink-subtle">
                          per {product.unit}
                        </span>
                      )}
                    </td>
                    <td className="py-1.5 pr-2">
                      <Input
                        aria-label="Quantity"
                        inputMode="decimal"
                        value={row.quantity}
                        onChange={(event) => setRow(row.key, { quantity: event.target.value })}
                        placeholder="0"
                        className="w-full tabular-nums"
                      />
                    </td>
                    <td className="py-1.5 pr-2">
                      <Input
                        aria-label="Cost each"
                        inputMode="decimal"
                        value={row.cost}
                        onChange={(event) => setRow(row.key, { cost: event.target.value })}
                        placeholder="0.00"
                        className="w-full tabular-nums"
                      />
                    </td>
                    <td className="py-1.5 pr-2 text-right">
                      <span className="flex h-10 items-center justify-end text-sm tabular-nums">
                        {showable ? <Money centavos={lineCost(line)} scale="body" /> : null}
                      </span>
                    </td>
                    <td className="py-1.5">
                      <span className="flex h-10 items-center">
                        <button
                          type="button"
                          aria-label="Remove this line"
                          onClick={() =>
                            setRows((current) =>
                              // Never below one row: an empty list has nothing
                              // to type into and no obvious way back.
                              current.length === 1
                                ? [blankRow()]
                                : current.filter((candidate) => candidate.key !== row.key),
                            )
                          }
                          className="h-8 w-8 shrink-0 rounded-lg border border-line-strong text-base leading-none text-ink-muted transition-colors duration-150 hover:border-owed hover:text-owed focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                        >
                          ×
                        </button>
                      </span>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>

        <div className="mt-3">
          <Button
            variant="secondary"
            size="sm"
            onClick={() => setRows((current) => [...current, blankRow()])}
          >
            Add another line
          </Button>
        </div>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <Field label="Note (optional)">
            <Textarea
              value={note}
              onChange={(event) => setNote(event.target.value)}
              rows={3}
              placeholder="e.g. Two sacks torn, replacement promised"
              className="w-full"
            />
          </Field>
        </Card>

        <Card>
          <dl className="grid gap-1 text-sm">
            <div className="flex justify-between">
              <dt className="text-ink-muted">Delivery total</dt>
              <dd>
                {/* Neutral. This is money going OUT, and must never be green. */}
                <Money centavos={total} scale="strong" />
              </dd>
            </div>
            <div className="flex justify-between border-t border-line pt-2">
              <dt className="font-semibold text-ink">
                {terms === 'CONSIGNMENT' ? 'Owed on arrival' : 'Still owing after this'}
              </dt>
              <dd>
                <Money
                  centavos={
                    terms === 'CONSIGNMENT'
                      ? 0
                      : Math.max(0, total - (Number.isFinite(paidCentavos) ? paidCentavos : 0))
                  }
                  tone="owed"
                  scale="strong"
                />
              </dd>
            </div>
          </dl>
          {terms === 'CONSIGNMENT' && (
            <p className="mt-2 text-xs text-ink-subtle">
              Nothing is owed yet. Settle this delivery when the supplier counts what sold.
            </p>
          )}
        </Card>
      </div>

      {/* The server's own complaint, shown before she presses anything, so a
          disabled Save button is never a mystery. */}
      {problem && started && <p className="text-sm text-warn">{problem}</p>}
      {error && <FormError>{error}</FormError>}

      <div className="flex flex-wrap justify-end gap-2">
        <Button variant="ghost" onClick={() => router.push(ROUTES.deliveries)} disabled={pending}>
          Cancel
        </Button>
        {/* `success`: terminal and money-committing. */}
        <Button variant="success" onClick={save} disabled={pending || problem !== null}>
          {pending ? 'Saving…' : 'Save delivery'}
        </Button>
      </div>
    </div>
  )
}
