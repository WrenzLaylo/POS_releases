'use client'

import { useRouter } from 'next/navigation'
import { Tabs } from '@/components/ui/Tabs'
import { sale as saleRoute, saleReceipt } from '@/lib/routes'

const SALE_TABS = [
  { value: 'summary', label: 'Summary' },
  { value: 'receipt', label: 'Receipt' },
] as const

/**
 * Switches between the working view of a sale and its printable document.
 *
 * A real navigation rather than local state, matching the Book's tab strip:
 * each half is its own route, so either can be linked to, refreshed, or
 * reached with the back button — and the receipt keeps the URL it already had.
 */
export function SaleTabs({
  saleId,
  active,
}: {
  saleId: number
  active: 'summary' | 'receipt'
}) {
  const router = useRouter()

  return (
    <Tabs
      ariaLabel="Sale view"
      tabs={SALE_TABS}
      value={active}
      onValueChange={(value) =>
        router.push(value === 'receipt' ? saleReceipt(saleId) : saleRoute(saleId))
      }
      className="mb-4"
    />
  )
}
