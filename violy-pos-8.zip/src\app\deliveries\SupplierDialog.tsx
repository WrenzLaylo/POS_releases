'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import {
  archiveSupplier,
  createSupplier,
  restoreSupplier,
  updateSupplier,
} from '@/server/suppliers'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Dialog } from '@/components/ui/Dialog'
import { Field } from '@/components/ui/Field'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'
import type { SupplierOption } from './DeliveriesScreen'

/**
 * Who the shop buys from.
 *
 * One dialog for the whole list rather than a screen of its own: suppliers are
 * a handful of names touched a few times a year, and a fifth item in the rail
 * for that would cost more attention than it returns.
 */
export function SupplierDialog({
  suppliers,
  onClose,
}: {
  suppliers: SupplierOption[]
  onClose: () => void
}) {
  const router = useRouter()
  const [pending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)

  const [name, setName] = useState('')
  const [contactNumber, setContactNumber] = useState('')
  const [editingId, setEditingId] = useState<number | null>(null)

  function reset() {
    setName('')
    setContactNumber('')
    setEditingId(null)
  }

  function save() {
    setError(null)
    startTransition(async () => {
      const result =
        editingId === null
          ? await createSupplier({ name, contactNumber })
          : await updateSupplier(editingId, { name, contactNumber })
      if (!result.ok) {
        setError(result.error)
        return
      }
      reset()
      router.refresh()
    })
  }

  function run(action: () => Promise<{ ok: boolean; error?: string }>) {
    setError(null)
    startTransition(async () => {
      const result = await action()
      if (!result.ok) {
        setError(result.error ?? 'That did not work.')
        return
      }
      router.refresh()
    })
  }

  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title="Suppliers"
      description="Who the shop buys from. Deliveries are recorded against these names."
      footer={
        <div className="flex justify-end">
          <Button variant="secondary" onClick={onClose}>
            Done
          </Button>
        </div>
      }
    >
      <div className="grid gap-4">
        <div className="flex flex-wrap items-end gap-2">
          <Field label={editingId === null ? 'New supplier' : 'Rename supplier'}>
            <Input
              value={name}
              onChange={(event) => setName(event.target.value)}
              placeholder="e.g. Bataan Farmers Center"
              className="w-56"
            />
          </Field>
          <Field label="Contact (optional)">
            <Input
              value={contactNumber}
              onChange={(event) => setContactNumber(event.target.value)}
              placeholder="09XX XXX XXXX"
              className="w-40"
            />
          </Field>
          <Button variant="primary" onClick={save} disabled={pending || name.trim() === ''}>
            {editingId === null ? 'Add' : 'Save'}
          </Button>
          {editingId !== null && (
            <Button variant="ghost" onClick={reset} disabled={pending}>
              Cancel
            </Button>
          )}
        </div>

        {error && <FormError>{error}</FormError>}

        {suppliers.length === 0 ? (
          <p className="rounded-control bg-surface-sunk px-3 py-4 text-sm text-ink-muted">
            No suppliers yet.
          </p>
        ) : (
          <ul className="divide-y divide-line rounded-control border border-line">
            {suppliers.map((supplier) => (
              <li key={supplier.id} className="flex items-center justify-between gap-3 px-3 py-2">
                <span className="min-w-0">
                  <span className="block truncate text-sm font-medium text-ink">
                    {supplier.name}
                    {supplier.isArchived && (
                      <span className="ml-2 align-middle">
                        <Badge tone="muted">Archived</Badge>
                      </span>
                    )}
                  </span>
                  {supplier.contactNumber && (
                    <span className="block text-xs text-ink-subtle">{supplier.contactNumber}</span>
                  )}
                </span>

                <span className="flex shrink-0 items-center gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    disabled={pending}
                    onClick={() => {
                      setEditingId(supplier.id)
                      setName(supplier.name)
                      setContactNumber(supplier.contactNumber)
                    }}
                  >
                    Edit
                  </Button>
                  {supplier.isArchived ? (
                    <Button
                      variant="ghost"
                      size="sm"
                      disabled={pending}
                      onClick={() => run(() => restoreSupplier(supplier.id))}
                    >
                      Restore
                    </Button>
                  ) : (
                    // Refused by the server while anything is still owed, so
                    // a debt cannot vanish because somebody tidied up.
                    <Button
                      variant="danger"
                      size="sm"
                      disabled={pending}
                      onClick={() => run(() => archiveSupplier(supplier.id))}
                    >
                      Archive
                    </Button>
                  )}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </Dialog>
  )
}
