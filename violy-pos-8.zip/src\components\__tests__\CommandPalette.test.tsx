// @vitest-environment jsdom

import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { CommandPalette } from '@/components/CommandPalette'
import type { SearchResult } from '@/server/search'

const { searchEverything } = vi.hoisted(() => ({ searchEverything: vi.fn() }))
vi.mock('@/server/search', () => ({ searchEverything }))

beforeEach(() => {
  searchEverything.mockReset()
  searchEverything.mockResolvedValue([])
})

afterEach(() => {
  document.body.style.overflow = ''
})

describe('CommandPalette', () => {
  it('is closed until the shortcut is pressed', () => {
    render(<CommandPalette />)
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
  })

  it('opens on Ctrl+K', async () => {
    const user = userEvent.setup()
    render(<CommandPalette />)

    await user.keyboard('{Control>}k{/Control}')

    expect(screen.getByRole('dialog', { name: 'Search' })).toBeInTheDocument()
  })

  it('opens on Cmd+K (metaKey, the Mac shortcut)', async () => {
    const user = userEvent.setup()
    render(<CommandPalette />)

    await user.keyboard('{Meta>}k{/Meta}')

    expect(screen.getByRole('dialog', { name: 'Search' })).toBeInTheDocument()
  })

  it('closes on Escape', async () => {
    const user = userEvent.setup()
    render(<CommandPalette />)
    await user.keyboard('{Control>}k{/Control}')
    expect(screen.getByRole('dialog')).toBeInTheDocument()

    await user.keyboard('{Escape}')

    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
  })

  it('removes its keydown listener on unmount', async () => {
    const user = userEvent.setup()
    const view = render(<CommandPalette />)
    view.unmount()

    await user.keyboard('{Control>}k{/Control}')

    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
  })

  it('debounces the query and renders results as navigation links', async () => {
    searchEverything.mockResolvedValue([
      { kind: 'customer', id: '7', label: 'Maria Santos', hint: 'Customer', href: '/book/7' },
      { kind: 'workspace', id: 'stock', label: 'Stock', href: '/stock' },
    ])
    const user = userEvent.setup()
    render(<CommandPalette />)
    await user.keyboard('{Control>}k{/Control}')

    await user.type(screen.getByRole('textbox', { name: /search/i }), 'maria')

    const link = await screen.findByRole('link', { name: /maria santos/i })
    expect(link).toHaveAttribute('href', '/book/7')
    expect(screen.getByRole('link', { name: /stock/i })).toHaveAttribute('href', '/stock')
    expect(searchEverything).toHaveBeenCalledWith('maria')
    // A fast typist should not fire a query per keystroke.
    expect(searchEverything.mock.calls.length).toBeLessThan(5)
  })

  it('offers navigation only, never a money-committing action, in the empty state', async () => {
    const user = userEvent.setup()
    render(<CommandPalette />)
    await user.keyboard('{Control>}k{/Control}')
    for (const label of [/save order/i, /save payment/i, /record payment/i, /void/i]) {
      expect(screen.queryByRole('button', { name: label })).not.toBeInTheDocument()
    }
  })

  // The load-bearing guardrail: the check above runs against an almost-empty
  // dialog (just the search input), so it would not catch a quick-action
  // button that only appears once results are populated. This one types a
  // query, waits for real result links to land on screen, and only then
  // asserts no money-committing button exists alongside them.
  it('offers navigation only, never a money-committing action, once results are rendered', async () => {
    searchEverything.mockResolvedValue([
      { kind: 'customer', id: '7', label: 'Maria Santos', hint: 'Customer', href: '/book/7' },
      { kind: 'workspace', id: 'stock', label: 'Stock', href: '/stock' },
    ])
    const user = userEvent.setup()
    render(<CommandPalette />)
    await user.keyboard('{Control>}k{/Control}')

    await user.type(screen.getByRole('textbox', { name: /search/i }), 'maria')

    // Confirm results are actually on screen — otherwise the assertions
    // below would pass vacuously against an empty list.
    expect(await screen.findByRole('link', { name: /maria santos/i })).toBeInTheDocument()
    expect(screen.getByRole('link', { name: /stock/i })).toBeInTheDocument()

    for (const label of [/save order/i, /save payment/i, /record payment/i, /void/i]) {
      expect(screen.queryByRole('button', { name: label })).not.toBeInTheDocument()
    }
  })

  // The debounce clears pending *timers* on cleanup, but a timer that has
  // already fired has a request in flight that clearTimeout cannot touch. If
  // an earlier, slower request resolves after a later, faster one, it must
  // not be allowed to overwrite the newer query's results on screen.
  it('does not let a stale in-flight response overwrite a newer query\'s results', async () => {
    let resolveSlow: (results: SearchResult[]) => void = () => {}
    const slow = new Promise<SearchResult[]>((resolve) => {
      resolveSlow = resolve
    })

    searchEverything.mockImplementation((q: string) =>
      q === 'slow'
        ? slow
        : Promise.resolve([{ kind: 'workspace', id: 'stock', label: 'Stock', href: '/stock' }]),
    )

    const user = userEvent.setup()
    render(<CommandPalette />)
    await user.keyboard('{Control>}k{/Control}')

    const input = screen.getByRole('textbox', { name: /search/i })
    await user.type(input, 'slow')

    // Wait for the "slow" request to actually be dispatched — it stays
    // pending, which is what makes it "in flight" rather than just debounced
    // away.
    await waitFor(() => expect(searchEverything).toHaveBeenCalledWith('slow'))

    await user.clear(input)
    await user.type(input, 'fast')

    // The newer, faster query's result lands.
    expect(await screen.findByRole('link', { name: /stock/i })).toBeInTheDocument()

    // Now let the stale "slow" response resolve. Without the cancellation
    // flag, this would overwrite the screen with results for a query that no
    // longer matches what is in the box.
    resolveSlow([
      { kind: 'customer', id: '7', label: 'Maria Santos', hint: 'Customer', href: '/book/7' },
    ])
    await new Promise((resolve) => setTimeout(resolve, 50))

    expect(screen.getByRole('link', { name: /stock/i })).toBeInTheDocument()
    expect(screen.queryByRole('link', { name: /maria santos/i })).not.toBeInTheDocument()
  })
})
