import { formatPeso } from './money'
import type { DiscountRuleView } from './types'

/**
 * A standing discount rule, in the words a shopkeeper would use.
 *
 * One implementation, used by the discount editor as she builds a rule and by
 * the counter as she reads one back. Two would drift, and the whole point of
 * the sentence is that the rule she saved and the rule the till applies are
 * visibly the same thing.
 *
 * Deliberately not in `discount.ts`: that file is the arithmetic, and it has
 * no business knowing how to phrase anything.
 */
export function describeRule(
  rule: Pick<DiscountRuleView, 'kind' | 'amountCentavos' | 'bps' | 'basis' | 'unit' | 'scope'> & {
    categories: readonly { name: string }[]
    products: readonly { name: string }[]
  },
): string {
  const isPercent = rule.kind === 'PERCENT'
  const value = isPercent
    ? rule.bps > 0
      ? `${rule.bps / 100}%`
      : ''
    : rule.amountCentavos > 0
      ? formatPeso(rule.amountCentavos)
      : ''
  if (value === '') return 'No amount set yet.'

  if (rule.basis === 'ORDER_TOTAL') return `${value} off the whole order.`

  const per =
    rule.basis === 'ONCE_PER_ORDER'
      ? 'off the order, once'
      : `off each ${rule.unit === '' ? 'unit' : rule.unit}`

  const named =
    rule.scope === 'PRODUCTS'
      ? rule.products.map((product) => product.name)
      : rule.scope === 'CATEGORIES'
        ? rule.categories.map((category) => category.name)
        : []

  const what =
    rule.scope === 'ALL'
      ? 'anything'
      : named.length === 0
        ? rule.scope === 'PRODUCTS'
          ? 'nothing yet — choose a product'
          : 'nothing yet — tick a brand'
        : // Two names then a count. A 300px rail cannot carry nine.
          named.length <= 2
          ? named.join(' and ')
          : `${named.slice(0, 2).join(', ')} and ${named.length - 2} more`

  return `${value} ${per} of ${what}.`
}
