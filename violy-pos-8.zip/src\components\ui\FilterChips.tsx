'use client'

import { cn } from '@/lib/cn'

export type FilterChipOption = {
  value: string
  label: string
  /** Shown as a badge on the chip. Omit where a count is not knowable cheaply. */
  count?: number
}

/**
 * One row of single-choice filter chips, with its own label.
 *
 * Chips rather than a `<select>` for the filters an operator changes
 * constantly: every option is visible and one tap away, and she can see what
 * is currently applied without opening anything. A select is still the right
 * control where the list is long or rarely touched — which is why
 * `HistoryFilters` keeps selects for the customer and the date range and this
 * is not used there.
 *
 * `h-9` is the sanctioned bespoke chip size, and this component is now the one
 * place it is written for table filters. That is the point of moving it here:
 * it used to be hand-rolled inside `InventoryFilters`, so every screen that
 * wanted the same row copied the class list and they drifted.
 * `CatalogColumn`'s strip keeps its own — it is a denser, `rounded-control`
 * variant in a much narrower column, not the same control.
 */
export function FilterChips({
  label,
  options,
  value,
  onChange,
  ariaLabel,
  className,
}: {
  /** Rendered above the row. Omit for a row whose meaning is self-evident. */
  label?: string
  options: readonly FilterChipOption[]
  /** The selected value. `''` is the conventional "no filter" option. */
  value: string
  onChange: (value: string) => void
  ariaLabel: string
  className?: string
}) {
  return (
    <div className={className}>
      {label && (
        <div className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-ink-subtle">
          {label}
        </div>
      )}
      <div role="group" aria-label={ariaLabel} className="flex flex-wrap gap-2">
        {options.map((option) => {
          const active = option.value === value
          return (
            <button
              key={option.value}
              type="button"
              onClick={() => onChange(option.value)}
              aria-pressed={active}
              className={cn(
                'flex h-9 items-center gap-2 rounded-full px-4 text-sm font-medium transition-colors duration-150',
                'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2',
                active
                  ? 'bg-accent-soft text-accent'
                  : 'border border-line-strong bg-surface text-ink-muted hover:bg-surface-sunk hover:text-ink',
              )}
            >
              <span>{option.label}</span>
              {option.count !== undefined && (
                <span
                  className={cn(
                    'inline-flex h-5 min-w-5 items-center justify-center rounded-full px-1.5 text-xs font-semibold tabular-nums',
                    active ? 'bg-accent text-canvas' : 'bg-surface-sunk text-ink-muted',
                  )}
                >
                  {option.count}
                </span>
              )}
            </button>
          )
        })}
      </div>
    </div>
  )
}
