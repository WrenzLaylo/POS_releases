import { notFound } from 'next/navigation'
import { getCustomer, listCategoriesWithCheapest } from '@/server/customers'
import { listProductUnits } from '@/server/products'
import { dayKey, startOfDay } from '@/lib/dates'
import { getBalance, getLedger } from '@/server/ledger'
import { getUnplannedBalance, listPlans } from '@/server/utang'
import { LedgerView } from './LedgerView'
import { PlanList } from './PlanList'
import { CustomerActions } from './CustomerActions'
import { DueDateControl } from './DueDateControl'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card } from '@/components/ui/Card'
import { Money } from '@/components/ui/Money'

export const dynamic = 'force-dynamic'

export default async function CustomerPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const customerId = Number(id)
  if (!Number.isInteger(customerId)) notFound()

  const customer = await getCustomer(customerId)
  if (!customer) notFound()

  const [lines, balanceCentavos, plans, unplannedCentavos, categories, units] = await Promise.all([
    getLedger(customerId),
    getBalance(customerId),
    listPlans(customerId),
    getUnplannedBalance(customerId),
    // The edit form needs both; fetched here so the button opens instantly
    // rather than showing an empty dialog while it loads.
    listCategoriesWithCheapest(),
    listProductUnits(),
  ])
  const overdue =
    customer.dueAt !== null && balanceCentavos > 0 && customer.dueAt < startOfDay(new Date())

  // Computed here, on the server, and passed down. A client component
  // deriving "today" itself would disagree with this render across a midnight
  // crossing or a timezone difference, and hydrate with a warning.
  const todayKey = dayKey(new Date())
  const livePlans = plans.filter((plan) => !plan.isVoided)
  // A voided one does not count: voiding is the only undo this app has, so
  // she has to be able to set the figure again after getting it wrong.
  const hasOpeningBalance = lines.some((line) => line.type === 'OPENING' && !line.isVoided)

  return (
    <PageHeader
      title={customer.name}
      actions={
        <span className="flex items-baseline gap-4">
          {customer.phone && <span className="text-sm text-ink-muted">{customer.phone}</span>}
          <span className="text-sm text-ink-muted">
            Balance: <Money centavos={balanceCentavos} tone="balance" scale="strong" />
          </span>
          {balanceCentavos > 0 && customer.dueAt && (
            <span className={overdue ? 'text-sm font-semibold text-owed' : 'text-sm text-ink-muted'}>
              {overdue ? 'Overdue' : 'Due'}{' '}
              {customer.dueAt.toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' })}
            </span>
          )}
        </span>
      }
    >
      {balanceCentavos < 0 && (
        <Card className="mb-4">
          {/* Not `tone="balance"`: the figure below is `-balanceCentavos`,
              deliberately sign-flipped so "Overpaid by ₱X" reads as a
              positive amount. Feeding that flipped value through
              `balanceTone` would invert it back to red. `tone="in"` matches
              what `balanceTone` would have returned on the original
              (unflipped) negative balance — this *is* the credit case. */}
          <p className="text-sm font-semibold text-ink">
            Overpaid by <Money centavos={-balanceCentavos} tone="in" />.
          </p>
        </Card>
      )}

      {overdue && (
        <Card variant="danger" className="mb-4">
          <p className="text-sm font-semibold text-owed">
            This balance is past due. Record a payment or extend the due date below.
          </p>
        </Card>
      )}

      {balanceCentavos > 0 && customer.dueAt && (
        <DueDateControl customerId={customerId} dueAt={customer.dueAt} />
      )}

      <CustomerActions
        customerId={customerId}
        customerName={customer.name}
        plans={livePlans}
        todayKey={todayKey}
        balanceCentavos={balanceCentavos}
        unplannedCentavos={unplannedCentavos}
        hasOpeningBalance={hasOpeningBalance}
        customer={customer}
        categories={categories}
        units={units}
      />
      <PlanList plans={plans} todayKey={todayKey} unplannedCentavos={unplannedCentavos} />
      <LedgerView lines={lines} customerId={customerId} />
    </PageHeader>
  )
}
