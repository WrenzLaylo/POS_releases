import { describe, expect, it } from 'vitest'
import { isDocumentPath } from './document-paths'
import { accountStatement, delivery, paymentReceipt, planInvoice, saleReceipt } from './routes'

describe('what /pdf will render', () => {
  it('accepts every document this app actually builds a path for', () => {
    // Built through `routes.ts` rather than typed out, so a rename there fails
    // here instead of quietly leaving the allow-list pointing at the old shape.
    expect(isDocumentPath(saleReceipt(4959))).toBe(true)
    expect(isDocumentPath(accountStatement(142))).toBe(true)
    expect(isDocumentPath(paymentReceipt(142, 73))).toBe(true)
    expect(isDocumentPath(planInvoice(142, 3))).toBe(true)
    expect(isDocumentPath(delivery(2))).toBe(true)
  })

  it('refuses the app pages that are not documents', () => {
    // `/pdf` spawns a browser engine. Everything it will point at should be a
    // deliberate decision, not "whatever happens to render".
    for (const path of ['/counter', '/book', '/stock', '/settings', '/deliveries', '/history']) {
      expect(isDocumentPath(path)).toBe(false)
    }
  })

  it('refuses anything that could leave this machine', () => {
    // The failure this list exists to prevent. `//host/x` is protocol-relative
    // — a naive "starts with a slash" check waves it through and `new URL()`
    // then resolves it to another host entirely.
    for (const path of [
      '//evil.test/x',
      'https://evil.test/x',
      'http://localhost:3000/history/1/receipt',
      'file:///C:/Windows/win.ini',
      '/history/1/receipt/../../../etc/passwd',
      '\\\\server\\share',
    ]) {
      expect(isDocumentPath(path)).toBe(false)
    }
  })

  it('refuses a document path carrying a query or a fragment', () => {
    // Otherwise the renderer can be pointed at the same page with different
    // parameters than the ones the page was checked for.
    expect(isDocumentPath('/history/1/receipt?x=1')).toBe(false)
    expect(isDocumentPath('/history/1/receipt#x')).toBe(false)
  })

  it('refuses a malformed or empty path', () => {
    for (const path of ['', ' ', '/', 'history/1/receipt', '/history//receipt', '/history/x/receipt']) {
      expect(isDocumentPath(path)).toBe(false)
    }
  })

  it('refuses a document id that is not a number', () => {
    expect(isDocumentPath('/deliveries/2')).toBe(true)
    expect(isDocumentPath('/deliveries/2a')).toBe(false)
    expect(isDocumentPath('/deliveries/-2')).toBe(false)
  })
})
