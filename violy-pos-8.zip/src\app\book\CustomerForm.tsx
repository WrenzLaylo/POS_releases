'use client'

import Link from 'next/link'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createCustomer, updateCustomer } from '@/server/customers'
import { parsePesoInput, formatPeso } from '@/lib/money'
import {
  isDiscountBasis,
  isDiscountKind,
  MAX_BPS,
  type DiscountBasis,
  type DiscountKind,
} from '@/lib/discount'
import type { CategoryCheapest, CustomerWithDiscount } from '@/lib/types'
import { Button } from '@/components/ui/Button'
import { Dialog } from '@/components/ui/Dialog'
import { Field } from '@/components/ui/Field'
import { FormError } from '@/components/ui/FormError'
import { Input } from '@/components/ui/Input'
import { SegmentedControl } from '@/components/ui/SegmentedControl'
import { Textarea } from '@/components/ui/Textarea'
import { customerDiscount } from '@/lib/routes'

const DISCOUNT_KIND_OPTIONS = [
  { value: 'AMOUNT', label: '₱' },
  { value: 'PERCENT', label: '%' },
] as const

const DISCOUNT_BASIS_OPTIONS = [
  { value: 'PER_UNIT', label: 'Per unit' },
  { value: 'ONCE_PER_ORDER', label: 'Once an order' },
  { value: 'ORDER_TOTAL', label: 'Whole order' },
] as const

/** The two bases that cover particular categories rather than the whole
 *  order — they share every scope control below. */
function isScoped(basis: DiscountBasis): boolean {
  return basis === 'PER_UNIT' || basis === 'ONCE_PER_ORDER'
}

/** Kept identical to `Field`'s own label, which these sit alongside. */
const FIELD_LABEL = 'text-xs font-medium uppercase tracking-[0.08em] text-ink-muted'

type Props = {
  categories: CategoryCheapest[]
  /** Unit kinds the catalog sells in — "bag", "kilo" — for scoping a per-unit
   *  discount. Empty when nothing is in the catalog yet, which hides the
   *  chooser rather than offering an empty one. */
  units: string[]
  customer: CustomerWithDiscount | null
  onClose: () => void
}

/**
 * The caller (`CustomerList`) only mounts this component while it should be
 * open, so `Dialog`'s own `open` is always `true` here — closing means the
 * parent stops rendering this component, not `open` flipping to `false` on
 * a persistent instance. That is deliberate: a fresh mount means every field
 * below re-initialises from the current `customer` prop instead of carrying
 * over whatever was typed the previous time the form was open.
 *
 * All Escape-to-close, focus-trapping, body-scroll-locking, and
 * focus-restoration behaviour comes from `Dialog`/`Overlay` — this component
 * adds none of its own, and must not.
 */
export function CustomerForm({ categories, units, customer, onClose }: Props) {
  const router = useRouter()
  const [name, setName] = useState(customer?.name ?? '')
  const [phone, setPhone] = useState(customer?.phone ?? '')
  const [notes, setNotes] = useState(customer?.notes ?? '')
  const [discountKind, setDiscountKind] = useState<DiscountKind>(
    customer && isDiscountKind(customer.discountKind) ? customer.discountKind : 'AMOUNT',
  )
  const [discountBasis, setDiscountBasis] = useState<DiscountBasis>(
    customer && isDiscountBasis(customer.discountBasis) ? customer.discountBasis : 'PER_UNIT',
  )
  // One field for both kinds — the toggle decides whether what she types is
  // pesos or percent. Seeded from whichever column the saved kind uses; both
  // are stored to two decimal places, so the /100 is the same either way.
  const [discountRaw, setDiscountRaw] = useState(() => {
    if (!customer) return ''
    if (isDiscountKind(customer.discountKind) && customer.discountKind === 'PERCENT') {
      return customer.discountBps > 0 ? String(customer.discountBps / 100) : ''
    }
    return customer.discountCentavos > 0 ? String(customer.discountCentavos / 100) : ''
  })
  const [categoryIds, setCategoryIds] = useState<number[]>(
    customer?.discountCategories.map((c) => c.id) ?? [],
  )
  // '' means every unit — the behaviour every customer had before discounts
  // could name one.
  const [discountUnit, setDiscountUnit] = useState<string>(customer?.discountUnit ?? '')
  /** The saved rule in a few words, so the card says what is already in force
   *  rather than sending her to another screen to find out. */
  const discountSummary = (() => {
    if (!customer) return 'Set one up after saving.'
    const value =
      customer.discountKind === 'PERCENT'
        ? customer.discountBps > 0
          ? `${customer.discountBps / 100}%`
          : ''
        : customer.discountCentavos > 0
          ? formatPeso(customer.discountCentavos)
          : ''
    if (value === '') return 'None yet.'
    const what =
      customer.discountBasis === 'ORDER_TOTAL'
        ? 'off the whole order'
        : customer.discountScope === 'PRODUCTS'
          ? `off ${customer.discountProducts.length} product${customer.discountProducts.length === 1 ? '' : 's'}`
          : customer.discountScope === 'ALL'
            ? 'off everything'
            : `off ${customer.discountCategories.length} brand${customer.discountCategories.length === 1 ? '' : 's'}`
    return `${value} ${what}.`
  })()

  const [error, setError] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)

  function toggleCategory(id: number) {
    setCategoryIds((prev) =>
      prev.includes(id) ? prev.filter((existing) => existing !== id) : [...prev, id],
    )
  }

  // Blank means no discount. A non-empty value that fails to parse is a
  // validation error, never a silent zero — see parsePesoInput's contract.
  const discountTrimmed = discountRaw.trim()
  const parsedDiscount = discountTrimmed === '' ? 0 : parsePesoInput(discountTrimmed)
  const discountInvalid = discountTrimmed !== '' && parsedDiscount === null

  // The "this would make those lines free" warning is only meaningful for a
  // peso amount taken per unit. A percentage cannot exceed the price it is a
  // percentage OF unless it is 100%, and an order-total discount has no
  // per-line cheapest to compare against — so rather than compute something
  // misleading for those, the warning stands down.
  const warnable = discountKind === 'AMOUNT' && discountBasis === 'PER_UNIT'

  const warnings =
    discountInvalid || !warnable
      ? []
      : categories
          .filter(
            (category) =>
              categoryIds.includes(category.id) &&
              category.cheapestCentavos !== null &&
              parsedDiscount !== null &&
              category.cheapestCentavos <= parsedDiscount,
          )
          .map((category) => ({
            id: category.id,
            message: `${formatPeso(parsedDiscount as number)} is more than ${category.cheapestName} costs (${formatPeso(category.cheapestCentavos as number)}). Those lines will be free.`,
          }))

  async function handleSubmit() {
    setError(null)

    if (discountInvalid) {
      setError(
        discountKind === 'PERCENT'
          ? 'Enter a percentage like 5 or 12.5'
          : 'Enter an amount like 50 or 1,000',
      )
      return
    }
    if (discountKind === 'PERCENT' && (parsedDiscount ?? 0) > MAX_BPS) {
      setError('A discount cannot be more than 100%.')
      return
    }

    setSaving(true)
    const input = {
      name,
      phone,
      notes,
      // The unused column is written as zero rather than left alone. Switching
      // a customer from "₱50 off" to "5%" must not leave the old ₱50 sitting
      // in discountCentavos, where flipping the kind back would silently
      // resurrect it.
      discountCentavos: discountKind === 'AMOUNT' ? (parsedDiscount ?? 0) : 0,
      discountBps: discountKind === 'PERCENT' ? (parsedDiscount ?? 0) : 0,
      discountKind,
      discountBasis,
      // Same reasoning as the ticks below: a whole-order discount has no
      // per-line scope, so a unit saved against one would sit inert and then
      // surprise somebody who later switched the basis back.
      discountUnit: isScoped(discountBasis) ? discountUnit : '',
      // A whole-order discount has no category scope, so the ticks are
      // discarded rather than saved to sit inert against a basis that never
      // reads them.
      discountCategoryIds: isScoped(discountBasis) ? categoryIds : [],
    }

    const result = customer
      ? await updateCustomer(customer.id, input)
      : await createCustomer(input)

    setSaving(false)
    if (!result.ok) {
      setError(result.error)
      return
    }
    router.refresh()
    onClose()
  }

  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title={customer ? 'Edit customer' : 'New customer'}
      footer={
        <div className="flex justify-end gap-2">
          <Button type="button" variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" form="customer-form" variant="primary" disabled={saving}>
            {saving ? 'Saving…' : 'Save'}
          </Button>
        </div>
      }
    >
      <form
        id="customer-form"
        onSubmit={(e) => {
          e.preventDefault()
          handleSubmit()
        }}
        className="grid gap-4"
      >
        <Field label="Name">
          <Input
            name="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            className="w-full"
            placeholder="Juan Dela Cruz"
          />
        </Field>

        <Field label="Phone">
          <Input
            name="phone"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="w-full"
            placeholder="09XX XXX XXXX"
          />
        </Field>

        <Field label="Notes">
          <Textarea
            name="notes"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={2}
            className="w-full"
          />
        </Field>

        {/* Not a `Field`: that renders a <label> wrapping its children, and a
            radiogroup nested inside a label is the wrong element for the job.
            The label styling is copied from `Field` so the form still reads as
            one set of controls. */}
        {/* The discount used to live here — four stacked controls and a
            checkbox per brand, at the bottom of the tallest dialog in the
            app. It now names individual products too, and fifty-five
            checkboxes is not a control, so it moved to a screen of its own.
            A customer record is a name, a number and a note again. */}
        {customer && (
          <div className="rounded-control border border-line bg-surface-sunk px-4 py-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <span className="text-sm text-ink">
                Discount
                <span className="block text-xs text-ink-subtle">{discountSummary}</span>
              </span>
              <Link
                href={customerDiscount(customer.id)}
                className="inline-flex h-8 items-center justify-center rounded-control border border-line-strong bg-surface-raised px-3 text-sm font-medium text-ink hover:border-accent hover:bg-accent-soft"
              >
                Set up
              </Link>
            </div>
          </div>
        )}

        {warnings.map((warning) => (
          <p key={warning.id} className="animate-fade-in text-sm text-warn">
            {warning.message}
          </p>
        ))}

        {error && <FormError>{error}</FormError>}
      </form>
    </Dialog>
  )
}
