import { describe, expect, it } from 'vitest'
import type { NotificationSummary } from './types'
import { notificationSignature } from './notification-seen'

function summary(overrides: Partial<NotificationSummary> = {}): NotificationSummary {
  return {
    overdueAccounts: [],
    overdueInstallments: [],
    dueToday: [],
    lowStock: [],
    updatesAvailable: 0,
    total: 0,
    ...overrides,
  }
}

const account = (customerId: number, balanceCentavos = 100_00) => ({
  customerId,
  name: `Customer ${customerId}`,
  balanceCentavos,
  dueAt: new Date('2026-08-01T00:00:00.000Z'),
})

const stock = (id: number, stockQty = 1) => ({
  id,
  name: `Product ${id}`,
  unit: 'bag',
  stockQty,
  lowStockThreshold: 3,
})

describe('notificationSignature', () => {
  it('is stable for the same set of notifications', () => {
    const one = summary({ overdueAccounts: [account(7)], lowStock: [stock(11)], total: 2 })
    const two = summary({ overdueAccounts: [account(7)], lowStock: [stock(11)], total: 2 })
    expect(notificationSignature(one)).toBe(notificationSignature(two))
  })

  it('does not depend on the order the server returned them in', () => {
    const ascending = summary({ overdueAccounts: [account(3), account(9)] })
    const descending = summary({ overdueAccounts: [account(9), account(3)] })
    expect(notificationSignature(ascending)).toBe(notificationSignature(descending))
  })

  it('changes when a different account becomes overdue, even at the same total', () => {
    // The reason this is not just a count. One account settling on the same
    // morning another falls due leaves the total unmoved while the list is
    // materially different, and a count-based badge would stay silent about
    // somebody she has never been told about.
    const before = summary({ overdueAccounts: [account(3)], total: 1 })
    const after = summary({ overdueAccounts: [account(9)], total: 1 })
    expect(notificationSignature(after)).not.toBe(notificationSignature(before))
  })

  it('ignores a balance creeping up on an account already flagged', () => {
    // That the account is overdue is the news. Re-badging every time the
    // figure moves teaches her to ignore the badge.
    const before = summary({ overdueAccounts: [account(3, 500_00)], total: 1 })
    const after = summary({ overdueAccounts: [account(3, 900_00)], total: 1 })
    expect(notificationSignature(after)).toBe(notificationSignature(before))
  })

  it('ignores stock falling further on a product already flagged', () => {
    const before = summary({ lowStock: [stock(11, 2)], total: 1 })
    const after = summary({ lowStock: [stock(11, 1)], total: 1 })
    expect(notificationSignature(after)).toBe(notificationSignature(before))
  })

  it('changes when a customer falls another month behind', () => {
    // Two months behind and three months behind are different conversations,
    // not the same one louder.
    const installment = (count: number) => ({
      customerId: 7,
      name: 'Maria',
      planId: 3,
      count,
      oldestDueAt: new Date('2026-06-15T00:00:00.000Z'),
      amountCentavos: 230_000,
    })
    const before = summary({ overdueInstallments: [installment(2)], total: 1 })
    const after = summary({ overdueInstallments: [installment(3)], total: 1 })
    expect(notificationSignature(after)).not.toBe(notificationSignature(before))
  })

  it('changes when an update arrives', () => {
    expect(notificationSignature(summary({ updatesAvailable: 1 }))).not.toBe(
      notificationSignature(summary({ updatesAvailable: 0 })),
    )
  })

  it('changes when a new low-stock product appears alongside the old one', () => {
    const before = summary({ lowStock: [stock(11)], total: 1 })
    const after = summary({ lowStock: [stock(11), stock(12)], total: 2 })
    expect(notificationSignature(after)).not.toBe(notificationSignature(before))
  })

  it('never collides across the different kinds', () => {
    // Ids are only unique within their own table, so a customer 7 and a
    // product 7 must not produce the same signature.
    const customer = summary({ overdueAccounts: [account(7)], total: 1 })
    const product = summary({ lowStock: [stock(7)], total: 1 })
    expect(notificationSignature(customer)).not.toBe(notificationSignature(product))
  })

  it('gives an empty summary a signature that nothing else shares', () => {
    const empty = notificationSignature(summary())
    expect(notificationSignature(summary({ lowStock: [stock(1)] }))).not.toBe(empty)
    expect(notificationSignature(summary())).toBe(empty)
  })
})
