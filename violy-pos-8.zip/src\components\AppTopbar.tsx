'use client'

import { useState } from 'react'
import Link from 'next/link'
import { CommandPalette } from '@/components/CommandPalette'
import { NotificationBell } from '@/components/NotificationBell'
import { Button } from '@/components/ui/Button'
import { Icon } from '@/components/ui/Icon'
import { ROUTES } from '@/lib/routes'
import type { NotificationSummary } from '@/lib/types'

/**
 * Slim utility bar above `<main>`. Carries no primary navigation — that
 * lives entirely in `AppRail` now. The left slot holds the command-palette
 * (⌘K) trigger; the palette itself also answers the shortcut directly, so
 * this button and a bare keypress open the exact same dialog instance.
 */
export function AppTopbar({ notifications }: { notifications: NotificationSummary }) {
  const [paletteOpen, setPaletteOpen] = useState(false)

  return (
    <header
      data-print="hide"
      className="flex h-16 shrink-0 items-center justify-between border-b border-line bg-surface px-4"
    >
      <div>
        <Button variant="secondary" onClick={() => setPaletteOpen(true)}>
          <Icon name="search" className="h-4 w-4" />
          Search ⌘K
        </Button>
        <CommandPalette open={paletteOpen} onOpenChange={setPaletteOpen} />
      </div>

      <div
        role="region"
        aria-label="Header utilities"
        className="flex shrink-0 items-center"
      >
        <NotificationBell notifications={notifications} />
        {/* Settings lives here rather than in the rail: the rail is the five
            workspaces she moves between all day, and store details are a
            utility touched once. This bar is where the utilities live. */}
        <Link
          href={ROUTES.settings}
          aria-label="Settings"
          title="Settings"
          className="flex h-10 w-10 items-center justify-center rounded-control text-ink-muted transition-colors duration-150 hover:bg-surface-sunk hover:text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-surface"
        >
          <Icon name="settings" className="h-4 w-4 shrink-0" />
        </Link>
      </div>
    </header>
  )
}
