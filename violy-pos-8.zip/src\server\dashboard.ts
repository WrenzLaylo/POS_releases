import { prisma } from '@/lib/db'
import { lineTotal } from '@/lib/money'
import { startOfDay, startOfWeek, startOfMonth, addDays, dayKey } from '@/lib/dates'
import { listCustomerBalances, getTotalUtang } from '@/server/ledger'
import { listLowStockProducts } from '@/server/products'
import type { DashboardData, TrendPoint, TopProduct, CustomerBalance } from '@/lib/types'

const TREND_DAYS = 30
const TOP_PRODUCT_LIMIT = 5
const TOP_BALANCE_LIMIT = 5

/**
 * Aggregation runs in JavaScript rather than SQL: Prisma cannot group by a
 * truncated date on SQLite, and one store's 60 days of sales is a trivial
 * amount of data to bucket in memory.
 *
 * `now` is injectable so tests can pin the clock.
 */
export async function getDashboard(now: Date = new Date()): Promise<DashboardData> {
  const todayStart = startOfDay(now)
  const weekStart = startOfWeek(now)
  const monthStart = startOfMonth(now)
  const trendStart = addDays(todayStart, -(TREND_DAYS - 1))

  const earliest = [todayStart, weekStart, monthStart, trendStart].reduce((a, b) =>
    a < b ? a : b,
  )

  const sales = await prisma.sale.findMany({
    where: { createdAt: { gte: earliest }, isVoided: false },
    include: {
      items: { include: { product: { select: { id: true, name: true, unit: true } } } },
    },
  })

  let todayCentavos = 0
  let weekCentavos = 0
  let monthCentavos = 0
  let monthProfitCentavos = 0
  let todayCashCentavos = 0
  let weekCashCentavos = 0
  let monthCashCentavos = 0

  const buckets = new Map<string, number>()
  for (let i = 0; i < TREND_DAYS; i++) {
    buckets.set(dayKey(addDays(trendStart, i)), 0)
  }

  const totals = new Map<number, TopProduct>()

  for (const sale of sales) {
    if (sale.createdAt >= todayStart) todayCentavos += sale.totalAmount
    if (sale.createdAt >= weekStart) weekCentavos += sale.totalAmount

    if (sale.createdAt >= todayStart) todayCashCentavos += sale.cashPaidCentavos
    if (sale.createdAt >= weekStart) weekCashCentavos += sale.cashPaidCentavos
    if (sale.createdAt >= monthStart) monthCashCentavos += sale.cashPaidCentavos

    const key = dayKey(sale.createdAt)
    if (buckets.has(key)) buckets.set(key, buckets.get(key)! + sale.totalAmount)

    if (sale.createdAt >= monthStart) {
      monthCentavos += sale.totalAmount

      for (const item of sale.items) {
        // `priceAtSale` is the LIST price; what the customer was actually
        // billed is `priceAtSale - discountAtSale`. Profit and top-product
        // revenue must both be computed on the net price: `sale.totalAmount`
        // above is already discounted, so using the list price here would
        // put benta and profit on inconsistent bases and inflate margin from
        // both ends — and would rank top products by money never charged.
        const netPrice = item.priceAtSale - item.discountAtSale

        monthProfitCentavos += lineTotal(netPrice - item.costAtSale, item.quantity)

        const existing = totals.get(item.productId)
        const revenue = lineTotal(netPrice, item.quantity)
        if (existing) {
          existing.quantitySold += item.quantity
          existing.revenueCentavos += revenue
        } else {
          totals.set(item.productId, {
            productId: item.productId,
            name: item.product.name,
            unit: item.product.unit,
            quantitySold: item.quantity,
            revenueCentavos: revenue,
          })
        }
      }
    }
  }

  const trend: TrendPoint[] = [...buckets.entries()].map(([day, totalCentavos]) => ({
    day,
    totalCentavos,
  }))

  const topProducts = [...totals.values()]
    .sort((a, b) => b.revenueCentavos - a.revenueCentavos)
    .slice(0, TOP_PRODUCT_LIMIT)

  const lowStock = await listLowStockProducts()

  // Payments are keyed on occurredAt — when the money changed hands, not
  // when it was typed.
  const payments = await prisma.ledgerEntry.findMany({
    where: { type: 'PAYMENT', isVoided: false, occurredAt: { gte: earliest } },
    select: { amountCentavos: true, occurredAt: true },
  })

  for (const payment of payments) {
    if (payment.occurredAt >= todayStart) todayCashCentavos += payment.amountCentavos
    if (payment.occurredAt >= weekStart) weekCashCentavos += payment.amountCentavos
    if (payment.occurredAt >= monthStart) monthCashCentavos += payment.amountCentavos
  }

  // Sourced from ledger.ts rather than summed independently here, so the
  // dashboard, the customers list, and getTotalUtang can never disagree.
  const balances = await listCustomerBalances()
  const totalUtangCentavos = await getTotalUtang()
  const topBalances: CustomerBalance[] = balances
    .filter((row) => row.balanceCentavos > 0)
    .slice(0, TOP_BALANCE_LIMIT)
    .map((row) => ({
      customerId: row.customerId,
      name: row.name,
      balanceCentavos: row.balanceCentavos,
    }))

  return {
    todayCentavos,
    weekCentavos,
    monthCentavos,
    monthProfitCentavos,
    todayCashCentavos,
    weekCashCentavos,
    monthCashCentavos,
    totalUtangCentavos,
    topBalances,
    trend,
    topProducts,
    lowStock,
  }
}
