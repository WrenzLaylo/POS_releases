/**
 * Which paths `/pdf` is allowed to render, and nothing else.
 *
 * This is a security boundary, not a convenience. `/pdf` spawns a browser
 * engine against whatever path it is handed; without this list it would render
 * any URL a caller named — another site, the shop's router, `file:///` — and
 * hand the result back as a download. The list is what keeps it a document
 * printer rather than a fetch service.
 *
 * An ALLOW-list of exact shapes, not a "reject anything suspicious" filter.
 * Blocklists are wrong by default: they protect against the cases somebody
 * thought of, and a new document route added later would silently be allowed.
 * Here a new document has to be added on purpose, and `document-paths.test.ts`
 * is what notices if the shapes stop matching `routes.ts`.
 *
 * Kept in `lib/` rather than beside the route so it can be tested without
 * standing a server up, and so `routes.ts` stays the only place that BUILDS a
 * path while this stays the only place that VALIDATES one.
 */

/** Every printable document, as the shape its URL takes. */
const DOCUMENT_PATTERNS: readonly RegExp[] = [
  // A sale's receipt or invoice.
  /^\/history\/\d+\/receipt$/,
  // A customer's statement of account.
  /^\/book\/\d+\/statement$/,
  // One payment's receipt.
  /^\/book\/\d+\/payment\/\d+$/,
  // A credit agreement.
  /^\/book\/\d+\/plan\/\d+$/,
  // What a supplier delivered.
  /^\/deliveries\/\d+$/,
]

/**
 * Whether this is one of this app's own document pages.
 *
 * Rejects anything carrying a query string, a fragment, a host, or a protocol
 * — `//evil.test/x` is a protocol-relative URL that a naive "starts with /"
 * check would wave through, and `new URL()` would then resolve it off-machine.
 */
export function isDocumentPath(value: string): boolean {
  if (typeof value !== 'string' || value === '') return false
  if (!value.startsWith('/')) return false
  // A second leading slash makes it protocol-relative, i.e. another host.
  if (value.startsWith('//')) return false
  if (value.includes('?') || value.includes('#')) return false
  if (value.includes('\\') || value.includes('..')) return false
  return DOCUMENT_PATTERNS.some((pattern) => pattern.test(value))
}
