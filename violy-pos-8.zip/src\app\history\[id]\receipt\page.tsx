import { notFound } from 'next/navigation'
import { getSaleReceipt } from '@/server/sales'
import { lineTotal } from '@/lib/money'
import Link from 'next/link'
import { documentNumber, DOCUMENT_TITLES } from '@/lib/document-number'
import { ROUTES } from '@/lib/routes'
import { PageHeader } from '@/components/ui/PageHeader'
import { getStoreProfile } from '@/server/store-profile'
import { Money } from '@/components/ui/Money'
import { cn } from '@/lib/cn'
import { DocumentShell } from '@/components/DocumentShell'
import {
  DocumentFacts,
  DocumentFooter,
  DocumentHeading,
} from '@/components/DocumentHeading'
import { SaleTabs } from '../SaleTabs'
import { ReceiptActions } from './ReceiptActions'

export const dynamic = 'force-dynamic'

export default async function ReceiptPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const saleId = Number(id)
  if (!Number.isInteger(saleId) || saleId <= 0) notFound()

  const sale = await getSaleReceipt(saleId)
  if (!sale) notFound()

  const profile = await getStoreProfile()

  const subtotalCentavos = sale.items.reduce(
    (total, item) => total + lineTotal(item.priceAtSale, item.quantity),
    0,
  )
  // Split, not summed. These used to be one "Customer discount" line, on the
  // grounds that a receipt has no reason to distinguish where the money came
  // off. That stopped being true once the counter could discount a single
  // tallied line: `discountAtSale` now holds either the customer's standing
  // per-unit rate OR a figure haggled at the till, so calling the total
  // "Customer discount" would print a haggle as though it were their standing
  // rate. Nothing on the row records which it was, and nothing needs to — the
  // honest label is what came off items, whoever decided it.
  const lineDiscountCentavos = sale.items.reduce(
    (total, item) => total + lineTotal(item.discountAtSale, item.quantity),
    0,
  )
  // Only ever the customer's own: a whole-order or once-an-order standing
  // discount, which the counter cannot type.
  const standingDiscountCentavos = sale.customerDiscountCentavos
  const discountCentavos = subtotalCentavos - sale.totalAmount

  // "10% off", not merely the ₱145 it worked out to. bps are hundredths of a
  // percent, so 1000 reads as 10 and 1050 as 10.5.
  const orderDiscountLabel =
    sale.orderDiscountKind === 'PERCENT' && sale.orderDiscountBps > 0
      ? `Order discount (${sale.orderDiscountBps / 100}% off)`
      : 'Order discount'

  // An invoice asks for money; a receipt acknowledges money already handed
  // over. A sale that went on credit is the former, a cash sale the latter,
  // and they carry different reference prefixes for the same reason.
  const liveCharge = sale.ledgerEntry && !sale.ledgerEntry.isVoided
  const kind = liveCharge ? 'SALES_INVOICE' : 'SALES_RECEIPT'
  const reference = documentNumber(kind, sale.id, sale.createdAt)
  const tendered = sale.cashTenderedCentavos ?? sale.cashPaidCentavos

  return (
    // The same `PageHeader` shell the Summary tab uses. Without it the tabs
    // sat in the document's own centred column while Summary put them flush
    // left under a title, so switching tabs made them jump across the screen
    // and the title disappear. Both halves of one page have to be framed the
    // same way. `data-print="hide"` keeps the whole frame off the paper.
    <PageHeader
      title={`Sale ${documentNumber(kind, sale.id, sale.createdAt)}`}
      hideOnPrint
      actions={
        <Link
          href={ROUTES.history}
          className="text-sm font-medium text-ink-muted hover:text-ink"
        >
          ← Back to history
        </Link>
      }
    >
      <div data-print="hide">
        <SaleTabs saleId={sale.id} active="receipt" />
      </div>

    <DocumentShell
      fileName={reference}
      actions={<ReceiptActions saleId={sale.id} isVoided={sale.isVoided} />}
    >
      <DocumentHeading
        profile={profile}
        title={DOCUMENT_TITLES[kind]}
        reference={reference}
        issuedAt={sale.createdAt}
      />

      <DocumentFacts
        items={[
          {
            label: 'Customer',
            value: (
              <>
                {sale.customer?.name ?? 'Walk-in customer'}
                {sale.customer?.phone && (
                  <div className="font-normal text-ink-muted">{sale.customer.phone}</div>
                )}
              </>
            ),
          },
          {
            label: 'Payment type',
            value: sale.isVoided
              ? 'Voided sale'
              : liveCharge
                ? sale.cashPaidCentavos > 0
                  ? 'Partial cash + credit'
                  : 'Full credit'
                : 'Cash sale',
            align: 'end',
          },
        ]}
      />

      {/* `doc-table` plus a `data-label` per cell is what lets this become a
          stacked list on the 80mm roll instead of a table too wide to fit.
          No `min-w`: on paper there is no scrollbar, so a minimum width just
          amputates the right-hand columns. */}
      <div className="overflow-x-auto">
        <table className="doc-table w-full text-sm">
          <thead className="border-b border-line text-left text-xs uppercase tracking-wide text-ink-muted">
            <tr>
              <th className="py-3 pr-3">Item</th>
              <th className="px-3 py-3 text-right">Qty</th>
              <th className="px-3 py-3 text-right">Unit price</th>
              <th className="px-3 py-3 text-right">Discount</th>
              <th className="py-3 pl-3 text-right">Amount</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {sale.items.map((item) => {
              const netPrice = item.priceAtSale - item.discountAtSale
              return (
                <tr key={item.id}>
                  <td className="py-3 pr-3">
                    <div className="font-medium text-ink">{item.product.name}</div>
                    <div className="text-xs text-ink-muted">{item.product.unit}</div>
                  </td>
                  <td data-label="Qty" className="px-3 py-3 text-right font-mono">
                    {item.quantity}
                  </td>
                  <td data-label="Unit price" className="px-3 py-3 text-right">
                    <Money centavos={item.priceAtSale} />
                  </td>
                  {/* `doc-roll-hide` when there is nothing to show: on the
                      roll this whole line disappears rather than printing
                      "DISCOUNT —" down a 72mm column. A4 keeps the dash, so
                      the column still lines up. */}
                  <td
                    data-label="Discount"
                    className={cn(
                      'px-3 py-3 text-right',
                      item.discountAtSale === 0 && 'doc-roll-hide',
                    )}
                  >
                    {item.discountAtSale > 0 ? <Money centavos={item.discountAtSale} /> : '—'}
                  </td>
                  <td data-label="Amount" className="py-3 pl-3 text-right">
                    <Money
                      centavos={lineTotal(netPrice, item.quantity)}
                      className="font-semibold"
                    />
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      <section className="doc-keep-together ml-auto mt-6 w-full max-w-sm space-y-2 border-t border-line pt-5">
        {discountCentavos > 0 && (
          <>
            <div className="flex justify-between text-sm text-ink-muted">
              <span>Subtotal</span>
              <Money centavos={subtotalCentavos} />
            </div>
            {lineDiscountCentavos > 0 && (
              <div className="flex justify-between text-sm text-ink-muted">
                <span>Discount on items</span>
                <span>
                  −<Money centavos={lineDiscountCentavos} />
                </span>
              </div>
            )}
            {standingDiscountCentavos > 0 && (
              <div className="flex justify-between text-sm text-ink-muted">
                <span>Customer discount</span>
                <span>
                  −<Money centavos={standingDiscountCentavos} />
                </span>
              </div>
            )}
            {sale.orderDiscountCentavos > 0 && (
              <div className="flex justify-between text-sm text-ink-muted">
                <span>{orderDiscountLabel}</span>
                <span>
                  −<Money centavos={sale.orderDiscountCentavos} />
                </span>
              </div>
            )}
          </>
        )}
        <div className="flex items-baseline justify-between border-t border-line pt-3">
          <span className="font-semibold text-ink">Total</span>
          <Money centavos={sale.totalAmount} scale="strong" />
        </div>
        <div className="flex justify-between text-sm text-ink-muted">
          <span>Cash tendered</span>
          <Money centavos={tendered} />
        </div>
        <div className="flex justify-between text-sm text-ink-muted">
          <span>Cash kept</span>
          <Money centavos={sale.cashPaidCentavos} tone="in" />
        </div>
        {liveCharge && (
          <div className="flex justify-between text-sm text-ink-muted">
            <span>Added to credit</span>
            <Money centavos={sale.ledgerEntry!.amountCentavos} tone="owed" />
          </div>
        )}
        <div className="flex justify-between text-sm text-ink-muted">
          <span>Change</span>
          <Money centavos={sale.changeCentavos} />
        </div>
        {sale.customerBalanceAfterCentavos !== null && (
          <div className="flex items-baseline justify-between border-t border-line pt-3">
            <span className="font-medium text-ink">
              {sale.isVoided ? 'Account balance after original sale' : 'Account balance after sale'}
            </span>
            <Money centavos={sale.customerBalanceAfterCentavos} tone="balance" scale="strong" />
          </div>
        )}
      </section>

      {sale.isVoided && (
        <section className="mt-6 rounded-control border border-owed/40 bg-owed/10 p-4 text-sm text-owed">
          <div className="font-semibold">This sale was voided.</div>
          {sale.voidReason && <div className="mt-1">Reason: {sale.voidReason}</div>}
          {sale.voidedAt && (
            <div className="mt-1">Voided: {sale.voidedAt.toLocaleString('en-PH')}</div>
          )}
        </section>
      )}


      <DocumentFooter>
        This document forms part of the official records of {profile.name}. Please retain it
        for your reference.
      </DocumentFooter>
    </DocumentShell>
    </PageHeader>
  )
}
