'use server'

import { prisma } from '@/lib/db'
import { ROUTES } from '@/lib/routes'
import { prismaErrorCode } from '@/lib/prisma-errors'
import { sumBalance } from '@/lib/ledger-balance'
import { reconcileCustomerDueAt } from '@/server/account-due'
import {
  applyPayments,
  buildSchedule,
  describeTerms,
  isInterestMethod,
  nextDue,
  overdueInstallments,
  validateTerms,
  type InterestMethod,
  type ScheduledInstallment,
} from '@/lib/utang'
import type { ActionResult, PlanInput, UtangPlanView } from '@/lib/types'
import { revalidateRoutes } from './revalidate'

function revalidateUtang(): void {
  // The notification bell lives in the root layout, so the shell is
  // invalidated alongside the pages whose own data changed.
  revalidateRoutes([ROUTES.book, ROUTES.dashboard, ROUTES.history], { layout: true })
}

/** Everything needed to turn stored rows into a `UtangPlanView`. */
type PlanRow = {
  id: number
  customerId: number
  principalCentavos: number
  interestMethod: string
  interestRateBps: number
  termMonths: number
  interestCentavos: number
  totalCentavos: number
  startedAt: Date
  note: string
  isVoided: boolean
  installments: {
    sequence: number
    dueAt: Date
    amountCentavos: number
    principalCentavos: number
    interestCentavos: number
  }[]
  entries: { type: string; amountCentavos: number; isVoided: boolean }[]
}

/**
 * Projects a stored plan into the shape screens read.
 *
 * The schedule comes from the STORED instalment rows, never from re-running
 * `buildSchedule` — a plan already agreed to must not shift under a later
 * change to the arithmetic. `buildSchedule` runs exactly once, at creation.
 *
 * `asOf` is passed in rather than read from the clock here so a server render
 * and its client hydration cannot disagree about what "today" is.
 */
function toView(plan: PlanRow, asOf: Date): UtangPlanView {
  const installments: ScheduledInstallment[] = [...plan.installments]
    .sort((a, b) => a.sequence - b.sequence)
    .map((installment) => ({
      sequence: installment.sequence,
      dueAt: installment.dueAt,
      amountCentavos: installment.amountCentavos,
      principalCentavos: installment.principalCentavos,
      interestCentavos: installment.interestCentavos,
    }))

  const paidCentavos = plan.entries
    .filter((entry) => entry.type === 'PAYMENT' && !entry.isVoided)
    .reduce((total, entry) => total + entry.amountCentavos, 0)

  const statuses = applyPayments(installments, paidCentavos)
  const method: InterestMethod = isInterestMethod(plan.interestMethod)
    ? plan.interestMethod
    : 'FLAT_MONTHLY'

  return {
    id: plan.id,
    customerId: plan.customerId,
    principalCentavos: plan.principalCentavos,
    interestMethod: method,
    interestRateBps: plan.interestRateBps,
    termMonths: plan.termMonths,
    interestCentavos: plan.interestCentavos,
    totalCentavos: plan.totalCentavos,
    startedAt: plan.startedAt,
    note: plan.note,
    isVoided: plan.isVoided,
    termsLabel: describeTerms({
      interestMethod: method,
      interestRateBps: plan.interestRateBps,
      termMonths: plan.termMonths,
    }),
    paidCentavos,
    outstandingCentavos: Math.max(0, plan.totalCentavos - paidCentavos),
    installments: statuses,
    nextDue: nextDue(statuses),
    // A voided plan is off the books entirely; nothing on it can be overdue.
    overdue: plan.isVoided ? [] : overdueInstallments(statuses, asOf),
  }
}

const PLAN_INCLUDE = {
  installments: true,
  entries: { select: { type: true, amountCentavos: true, isVoided: true } },
} as const

/** One customer's plans, newest borrowing first. */
export async function listPlans(customerId: number): Promise<UtangPlanView[]> {
  const plans = await prisma.utangPlan.findMany({
    where: { customerId },
    include: PLAN_INCLUDE,
    orderBy: [{ startedAt: 'desc' }, { id: 'desc' }],
  })
  const asOf = new Date()
  return plans.map((plan) => toView(plan, asOf))
}

export async function getPlan(planId: number): Promise<UtangPlanView | null> {
  if (!Number.isInteger(planId) || planId <= 0) return null
  const plan = await prisma.utangPlan.findUnique({
    where: { id: planId },
    include: PLAN_INCLUDE,
  })
  return plan ? toView(plan, new Date()) : null
}

/**
 * Records a borrowing on terms.
 *
 * Principal AND all interest post immediately, as one ledger entry dated
 * `startedAt`. The instalment schedule is a payment plan layered over a debt
 * that already exists in full — which is what keeps "total utang" on the Book
 * equal to everything outstanding, with no future obligation hiding off-book.
 *
 * The entry's type is OPENING when this is the customer's first ledger row and
 * CHARGE otherwise, so a notebook carry-over still reads as an opening balance
 * on the tape.
 */
export async function createPlan(
  input: PlanInput,
): Promise<ActionResult<{ planId: number }>> {
  if (!isInterestMethod(input.interestMethod)) {
    return { ok: false, error: 'Unrecognised interest method.' }
  }

  const terms = {
    principalCentavos: input.principalCentavos,
    interestMethod: input.interestMethod,
    interestRateBps: input.interestRateBps,
    termMonths: input.termMonths,
    startedAt: input.startedAt,
  }
  const invalid = validateTerms(terms)
  if (invalid) return { ok: false, error: invalid }

  const customer = await prisma.customer.findUnique({ where: { id: input.customerId } })
  if (!customer) return { ok: false, error: 'That customer no longer exists.' }

  const schedule = buildSchedule(terms)
  const note = (input.note ?? '').trim()

  let planId: number
  try {
    planId = await prisma.$transaction(async (tx) => {
      const liveEntries = await tx.ledgerEntry.count({
        where: { customerId: input.customerId, isVoided: false },
      })

      const plan = await tx.utangPlan.create({
        data: {
          customerId: input.customerId,
          principalCentavos: schedule.principalCentavos,
          interestMethod: terms.interestMethod,
          interestRateBps: terms.interestRateBps,
          termMonths: terms.termMonths,
          interestCentavos: schedule.interestCentavos,
          totalCentavos: schedule.totalCentavos,
          startedAt: terms.startedAt,
          note,
          installments: {
            create: schedule.installments.map((installment) => ({
              sequence: installment.sequence,
              dueAt: installment.dueAt,
              amountCentavos: installment.amountCentavos,
              principalCentavos: installment.principalCentavos,
              interestCentavos: installment.interestCentavos,
            })),
          },
        },
      })

      await tx.ledgerEntry.create({
        data: {
          customerId: input.customerId,
          type: liveEntries === 0 ? 'OPENING' : 'CHARGE',
          amountCentavos: schedule.totalCentavos,
          occurredAt: terms.startedAt,
          note,
          planId: plan.id,
        },
      })

      await reconcileCustomerDueAt(tx, input.customerId, terms.startedAt)
      return plan.id
    })
  } catch (error) {
    if (
      prismaErrorCode(error) === 'P2003' ||
      (error instanceof Error && error.message === 'CUSTOMER_VANISHED')
    ) {
      return { ok: false, error: 'That customer no longer exists.' }
    }
    return { ok: false, error: 'Could not save this utang.' }
  }

  revalidateUtang()
  return { ok: true, data: { planId } }
}

/**
 * What a customer owes that belongs to no plan.
 *
 * The balance minus everything outstanding on live plans. This is the figure
 * the statement shows as "other charges and payments", and it is what
 * `convertBalanceToPlan` can put on terms — an opening balance carried over
 * from the notebook, or a sale that went on credit at the counter.
 *
 * Can be negative when an account is in credit, which is not convertible;
 * callers check for a positive figure.
 */
export async function getUnplannedBalance(customerId: number): Promise<number> {
  const [entries, plans] = await Promise.all([
    prisma.ledgerEntry.findMany({
      where: { customerId, isVoided: false },
      select: { id: true, type: true, amountCentavos: true, isVoided: true },
    }),
    prisma.utangPlan.findMany({
      where: { customerId, isVoided: false },
      select: {
        totalCentavos: true,
        entries: {
          where: { type: 'PAYMENT', isVoided: false },
          select: { amountCentavos: true },
        },
      },
    }),
  ])

  const onPlans = plans.reduce((total, plan) => {
    const paid = plan.entries.reduce((sum, entry) => sum + entry.amountCentavos, 0)
    return total + Math.max(0, plan.totalCentavos - paid)
  }, 0)

  return sumBalance(entries) - onPlans
}

/**
 * Puts an existing balance onto terms.
 *
 * This is for debt that predates the plans feature, or that arrived as a plain
 * credit sale: the money is already owed and already on the ledger, so the
 * conversion must NOT charge it again. It writes a plan whose principal is
 * that balance, and — when no interest is added — no ledger entry at all,
 * because the charge is already there.
 *
 * Adding interest is the one case that moves money: the difference between the
 * new total and the balance already on the books is posted as its own CHARGE,
 * so the ledger says where the increase came from instead of a balance
 * silently growing.
 */
export async function convertBalanceToPlan(
  input: Omit<PlanInput, 'principalCentavos'>,
): Promise<ActionResult<{ planId: number }>> {
  if (!isInterestMethod(input.interestMethod)) {
    return { ok: false, error: 'Unrecognised interest method.' }
  }

  const customer = await prisma.customer.findUnique({ where: { id: input.customerId } })
  if (!customer) return { ok: false, error: 'That customer no longer exists.' }

  const principalCentavos = await getUnplannedBalance(input.customerId)
  if (principalCentavos <= 0) {
    return {
      ok: false,
      error: 'There is no unscheduled balance on this account to put on terms.',
    }
  }

  const terms = {
    principalCentavos,
    interestMethod: input.interestMethod,
    interestRateBps: input.interestRateBps,
    termMonths: input.termMonths,
    startedAt: input.startedAt,
  }
  const invalid = validateTerms(terms)
  if (invalid) return { ok: false, error: invalid }

  const schedule = buildSchedule(terms)
  const note = (input.note ?? '').trim()

  let planId: number
  try {
    planId = await prisma.$transaction(async (tx) => {
      // Re-read inside the transaction. The balance was computed before it
      // opened, and a concurrent payment would otherwise let this schedule a
      // principal the customer no longer owes.
      const live = await tx.ledgerEntry.findMany({
        where: { customerId: input.customerId, isVoided: false },
        select: { id: true, type: true, amountCentavos: true, isVoided: true },
      })
      const livePlans = await tx.utangPlan.findMany({
        where: { customerId: input.customerId, isVoided: false },
        select: {
          totalCentavos: true,
          entries: {
            where: { type: 'PAYMENT', isVoided: false },
            select: { amountCentavos: true },
          },
        },
      })
      const onPlans = livePlans.reduce((total, plan) => {
        const paid = plan.entries.reduce((sum, entry) => sum + entry.amountCentavos, 0)
        return total + Math.max(0, plan.totalCentavos - paid)
      }, 0)
      if (sumBalance(live) - onPlans !== principalCentavos) {
        throw new Error('BALANCE_MOVED')
      }

      const plan = await tx.utangPlan.create({
        data: {
          customerId: input.customerId,
          principalCentavos: schedule.principalCentavos,
          interestMethod: terms.interestMethod,
          interestRateBps: terms.interestRateBps,
          termMonths: terms.termMonths,
          interestCentavos: schedule.interestCentavos,
          totalCentavos: schedule.totalCentavos,
          startedAt: terms.startedAt,
          note,
          installments: {
            create: schedule.installments.map((installment) => ({
              sequence: installment.sequence,
              dueAt: installment.dueAt,
              amountCentavos: installment.amountCentavos,
              principalCentavos: installment.principalCentavos,
              interestCentavos: installment.interestCentavos,
            })),
          },
        },
      })

      // Only the interest is new money. The principal is already on the
      // ledger — charging it again would double what the customer owes, which
      // is the one mistake this whole function has to avoid.
      if (schedule.interestCentavos > 0) {
        await tx.ledgerEntry.create({
          data: {
            customerId: input.customerId,
            type: 'CHARGE',
            amountCentavos: schedule.interestCentavos,
            occurredAt: terms.startedAt,
            note: note || 'Interest on scheduled balance',
            planId: plan.id,
          },
        })
      }

      await reconcileCustomerDueAt(tx, input.customerId, terms.startedAt)
      return plan.id
    })
  } catch (error) {
    if (error instanceof Error && error.message === 'BALANCE_MOVED') {
      return {
        ok: false,
        error: 'The balance changed while this was open. Close and try again.',
      }
    }
    if (
      prismaErrorCode(error) === 'P2003' ||
      (error instanceof Error && error.message === 'CUSTOMER_VANISHED')
    ) {
      return { ok: false, error: 'That customer no longer exists.' }
    }
    return { ok: false, error: 'Could not put this balance on terms.' }
  }

  revalidateUtang()
  return { ok: true, data: { planId } }
}

/**
 * Takes a plan off the books: the plan and its originating charge are both
 * voided.
 *
 * Payments already allocated to it are NOT voided — they revert to
 * account-level by having their `planId` cleared. The customer really did hand
 * that money over, and voiding it would be the ledger making a false statement
 * about cash received. Voiding a plan cancels what was owed, not what was
 * paid.
 */
export async function voidPlan(planId: number): Promise<ActionResult> {
  if (!Number.isInteger(planId) || planId <= 0) {
    return { ok: false, error: 'Plan id is required.' }
  }

  const existing = await prisma.utangPlan.findUnique({ where: { id: planId } })
  if (!existing) return { ok: false, error: 'That utang no longer exists.' }
  if (existing.isVoided) return { ok: true, data: undefined }

  try {
    await prisma.$transaction(async (tx) => {
      const charges = await tx.ledgerEntry.findMany({
        where: { planId, type: { not: 'PAYMENT' } },
      })

      for (const charge of charges) {
        // Same append-only snapshot the ledger's own void takes, so the
        // history of this row survives the void.
        await tx.ledgerEntryRevision.create({
          data: {
            ledgerEntryId: charge.id,
            type: charge.type,
            amountCentavos: charge.amountCentavos,
            occurredAt: charge.occurredAt,
            note: charge.note,
            isVoided: charge.isVoided,
          },
        })
        await tx.ledgerEntry.update({ where: { id: charge.id }, data: { isVoided: true } })
      }

      await tx.ledgerEntry.updateMany({
        where: { planId, type: 'PAYMENT' },
        data: { planId: null },
      })

      await tx.utangPlan.update({ where: { id: planId }, data: { isVoided: true } })
      await reconcileCustomerDueAt(tx, existing.customerId, new Date())
    })
  } catch (error) {
    if (prismaErrorCode(error) === 'P2025') {
      return { ok: false, error: 'That utang no longer exists.' }
    }
    return { ok: false, error: 'Could not void this utang.' }
  }

  revalidateUtang()
  return { ok: true, data: undefined }
}
