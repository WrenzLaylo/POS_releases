import { listProducts } from '@/server/products'
import { listCustomers } from '@/server/customers'
import { listCustomerBalances } from '@/server/ledger'
import { OrderScreen } from './OrderScreen'
import { PageHeader } from '@/components/ui/PageHeader'

export const dynamic = 'force-dynamic'

export default async function CounterPage() {
  const [products, customers, balances] = await Promise.all([
    listProducts(),
    listCustomers(),
    listCustomerBalances(),
  ])

  // Only what the counter needs: who is in credit, and how much. A
  // negative balance is money the shop is holding for somebody.
  const creditByCustomer = Object.fromEntries(
    balances
      .filter((row) => row.balanceCentavos < 0)
      .map((row) => [row.customerId, -row.balanceCentavos]),
  )

  return (
    // `dense`: the counter is the one screen she works in continuously, and a
    // visible "Counter" title only repeats what the rail already highlights.
    <PageHeader title="Counter" dense fill>
      <OrderScreen
        products={products}
        customers={customers}
        creditByCustomer={creditByCustomer}
      />
    </PageHeader>
  )
}
