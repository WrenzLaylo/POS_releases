import { beforeEach, describe, expect, it } from 'vitest'
import { prisma } from '@/lib/db'
import { resetDb } from '@/test/reset-db'
import {
  createCategory,
  deleteCategory,
  listCategoriesWithCounts,
  renameCategory,
} from '@/server/categories'

beforeEach(resetDb)

async function productIn(categoryId: number, name = 'Hog Grower') {
  return prisma.product.create({
    data: {
      categoryId,
      name,
      unit: 'bag (50kg)',
      price: 200_000,
      costPrice: 0,
      stockQty: 0,
      lowStockThreshold: 0,
    },
  })
}

async function make(name: string) {
  const result = await createCategory(name)
  if (!result.ok) throw new Error(result.error)
  return result.data.id
}

describe('creating a category', () => {
  it('adds one and counts what is in it', async () => {
    const id = await make('Gamefowl')
    expect((await listCategoriesWithCounts()).map((c) => [c.name, c.productCount])).toEqual([
      ['Gamefowl', 0],
    ])

    await productIn(id)
    expect((await listCategoriesWithCounts())[0].productCount).toBe(1)
  })

  it('puts new categories at the END of the strip', async () => {
    // `sortOrder` drives the chip strip on the counter. Quietly reordering a
    // strip she has learned the shape of is worse than a new chip appearing
    // predictably at the far right.
    await make('Atlas')
    await make('Pigrolac')
    await make('Gamefowl')

    expect((await listCategoriesWithCounts()).map((c) => c.name)).toEqual([
      'Atlas',
      'Pigrolac',
      'Gamefowl',
    ])
  })

  it.each(['Atlas', 'atlas', '  ATLAS  '])('refuses the duplicate %s', async (name) => {
    // Two categories differing only in case would split one brand's products
    // across two chips on the counter.
    await make('Atlas')
    const again = await createCategory(name)
    expect(again.ok).toBe(false)
    expect(await prisma.category.count()).toBe(1)
  })

  it.each(['', '   '])('refuses a blank name (%s)', async (name) => {
    expect((await createCategory(name)).ok).toBe(false)
    expect(await prisma.category.count()).toBe(0)
  })

  it('trims what it stores', async () => {
    await make('  Gamefowl  ')
    expect((await listCategoriesWithCounts())[0].name).toBe('Gamefowl')
  })
})

describe('renaming a category', () => {
  it('carries every product with it', async () => {
    // The whole reason renaming is safe where deleting is not: the products
    // keep pointing at the same row.
    const id = await make('Chicken')
    await productIn(id)

    expect((await renameCategory(id, 'Gamefowl')).ok).toBe(true)

    const rows = await listCategoriesWithCounts()
    expect(rows).toHaveLength(1)
    expect(rows[0].name).toBe('Gamefowl')
    expect(rows[0].productCount).toBe(1)
  })

  it('refuses renaming onto another category, whatever the casing', async () => {
    await make('Atlas')
    const second = await make('Pigrolac')

    expect((await renameCategory(second, 'atlas')).ok).toBe(false)
    expect((await prisma.category.findUnique({ where: { id: second } }))!.name).toBe('Pigrolac')
  })

  it('allows saving a category under its own name', async () => {
    // The check must exclude the row being edited, or fixing capitalisation
    // would report it as a duplicate of itself.
    const id = await make('Atlas')
    expect((await renameCategory(id, 'Atlas')).ok).toBe(true)
    expect((await renameCategory(id, 'ATLAS')).ok).toBe(true)
    expect((await prisma.category.findUnique({ where: { id } }))!.name).toBe('ATLAS')
  })

  it('refuses one that does not exist', async () => {
    expect((await renameCategory(9_999, 'Anything')).ok).toBe(false)
  })
})

describe('removing a category', () => {
  it('removes an empty one', async () => {
    const id = await make('Mistake')
    expect((await deleteCategory(id)).ok).toBe(true)
    expect(await prisma.category.count()).toBe(0)
  })

  it('refuses one that still holds products, and says how many', async () => {
    // `Product.categoryId` is required, so deleting would either orphan those
    // rows or take the catalogue with them. Which category a sack belongs to
    // is the shop's decision, not a delete button's.
    const id = await make('Atlas')
    await productIn(id, 'Atlas Grower')
    await productIn(id, 'Atlas Starter')

    const result = await deleteCategory(id)
    expect(result.ok).toBe(false)
    if (result.ok) return
    expect(result.error).toMatch(/2 products/)
    expect(await prisma.category.count()).toBe(1)
  })

  it('removes one a customer had scoped a discount to', async () => {
    // A discount scoped to an empty category is inert, but the relation still
    // exists and would fail the delete if nobody disconnected it first.
    const id = await make('Atlas')
    await prisma.customer.create({
      data: { name: 'MARILOU', discountCategories: { connect: [{ id }] } },
    })

    expect((await deleteCategory(id)).ok).toBe(true)
    expect(await prisma.category.count()).toBe(0)
    // The customer survives; only the scope went with the category.
    expect(await prisma.customer.count()).toBe(1)
  })

  it('refuses one that does not exist', async () => {
    expect((await deleteCategory(9_999)).ok).toBe(false)
  })
})

describe('removing a category that still holds products', () => {
  it('moves them to the named destination instead of deleting them', async () => {
    // The whole point of the option: the shop stops stocking a brand, and the
    // sacks still on the floor have to keep existing somewhere.
    const atlas = await make('Atlas')
    const other = await make('Other')
    await productIn(atlas, 'Atlas Grower')
    await productIn(atlas, 'Atlas Starter')

    expect((await deleteCategory(atlas, other)).ok).toBe(true)

    const rows = await listCategoriesWithCounts()
    expect(rows.map((c) => [c.name, c.productCount])).toEqual([['Other', 2]])
    expect(await prisma.product.count()).toBe(2)
  })

  it('refuses moving a category into itself', async () => {
    // The products would be pointed at the row about to be deleted, taking the
    // catalogue with it.
    const id = await make('Atlas')
    await productIn(id)

    expect((await deleteCategory(id, id)).ok).toBe(false)
    expect(await prisma.product.count()).toBe(1)
    expect(await prisma.category.count()).toBe(1)
  })

  it('refuses a destination that is not there', async () => {
    const id = await make('Atlas')
    await productIn(id)

    expect((await deleteCategory(id, 9_999)).ok).toBe(false)
    expect(await prisma.category.count()).toBe(1)
  })

  it('leaves the category standing when the move cannot go through', async () => {
    // Move and delete share one transaction, so a failure leaves the products
    // where they were — the category is never half-emptied.
    const id = await make('Atlas')
    await productIn(id, 'Atlas Grower')

    await deleteCategory(id, 0)

    const rows = await listCategoriesWithCounts()
    expect(rows.map((c) => [c.name, c.productCount])).toEqual([['Atlas', 1]])
  })

  it('accepts a destination for an empty category without complaining', async () => {
    // The dialog offers Remove for every category now, so an empty one can
    // still arrive with a destination attached.
    const empty = await make('Mistake')
    const other = await make('Other')

    expect((await deleteCategory(empty, other)).ok).toBe(true)
    expect((await listCategoriesWithCounts()).map((c) => c.name)).toEqual(['Other'])
  })
})
