'use client'

import { useState } from 'react'
import type { DayOrder, Paged, SaleWithItems } from '@/lib/types'
import { Card } from '@/components/ui/Card'
import { Tabs } from '@/components/ui/Tabs'
import { Pagination } from '@/components/Pagination'
import { DayView } from './DayView'
import { SalesList } from './SalesList'
import { HistoryFilters } from './HistoryFilters'

const HISTORY_TABS = [
  { value: 'today', label: 'Today' },
  { value: 'recent', label: 'Recent' },
] as const

export function HistoryScreen({
  todayOrders,
  sales,
  customers,
  categories,
  filters,
}: {
  todayOrders: DayOrder[]
  sales: Paged<SaleWithItems>
  customers: { id: number; name: string; isArchived: boolean }[]
  categories: { id: number; name: string }[]
  filters: { from?: string; to?: string; customer?: string; status?: string; category?: string }
}) {
  // Starts on "Recent" instead of "Today" whenever the URL already carries a
  // filter or a page beyond the first — otherwise submitting `HistoryFilters`
  // (a plain GET form, so it reloads the page) would land back on "Today"
  // and hide the very results the operator just asked for.
  const hasHistoryQuery =
    Boolean(filters.from || filters.to || filters.customer || filters.status || filters.category) ||
    sales.page > 1
  const [tab, setTab] = useState<'today' | 'recent'>(hasHistoryQuery ? 'recent' : 'today')

  return (
    <div className="flex flex-col gap-4">
      <Tabs
        ariaLabel="Order history"
        tabs={HISTORY_TABS}
        value={tab}
        onValueChange={(value) => setTab(value as 'today' | 'recent')}
      />

      {tab === 'today' ? (
        <DayView orders={todayOrders} />
      ) : (
        <div className="flex flex-col gap-4">
          <Card>
            <HistoryFilters
              customers={customers}
              categories={categories}
              from={filters.from}
              to={filters.to}
              customer={filters.customer}
              status={filters.status}
              category={filters.category}
            />
          </Card>

          <SalesList sales={sales.rows} />

          <Pagination
            page={sales.page}
            pageCount={sales.pageCount}
            params={{
              from: filters.from,
              to: filters.to,
              customer: filters.customer,
              status: filters.status,
              category: filters.category,
            }}
          />
        </div>
      )}
    </div>
  )
}
