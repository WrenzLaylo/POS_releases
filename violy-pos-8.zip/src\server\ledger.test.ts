import { describe, it, expect, beforeEach, vi } from 'vitest'
import { prisma } from '@/lib/db'
import { occurredAtForDay } from '@/lib/dates'
import { resetDb } from '@/test/reset-db'
import {
  getBalance,
  listCustomerBalances,
  getTotalUtang,
  getLedger,
  recordPayment,
  setOpeningBalance,
  updateEntry,
  voidEntry,
  createEntry,
  recordPaymentBatch,
} from '@/server/ledger'
import type { LedgerEntryType } from '@/lib/types'

beforeEach(resetDb)

async function makeCustomer(name = 'ROMAN') {
  return prisma.customer.create({ data: { name } })
}

async function addEntry(
  customerId: number,
  type: 'OPENING' | 'CHARGE' | 'PAYMENT',
  amountCentavos: number,
  occurredAt = new Date('2026-07-28T00:00:00'),
) {
  return prisma.ledgerEntry.create({
    data: { customerId, type, amountCentavos, occurredAt },
  })
}

describe('getBalance', () => {
  it('is zero for a customer with no entries', async () => {
    const customer = await makeCustomer()
    expect(await getBalance(customer.id)).toBe(0)
  })

  it('adds opening and charges, subtracts payments', async () => {
    const customer = await makeCustomer()
    await addEntry(customer.id, 'OPENING', 315000)
    await addEntry(customer.id, 'CHARGE', 157500)
    await addEntry(customer.id, 'PAYMENT', 100000)

    expect(await getBalance(customer.id)).toBe(372500)
  })

  it('excludes voided entries', async () => {
    const customer = await makeCustomer()
    await addEntry(customer.id, 'CHARGE', 157500)
    const wrong = await addEntry(customer.id, 'CHARGE', 999999)

    await voidEntry(wrong.id)

    expect(await getBalance(customer.id)).toBe(157500)
  })

  it('is unaffected by the order entries were written in', async () => {
    const customer = await makeCustomer()
    // A payment typed today, dated last week, before the charge it settles.
    await addEntry(customer.id, 'PAYMENT', 50000, new Date('2026-07-20T00:00:00'))
    await addEntry(customer.id, 'CHARGE', 157500, new Date('2026-07-25T00:00:00'))

    expect(await getBalance(customer.id)).toBe(107500)
  })

  it('goes negative when a customer overpays', async () => {
    const customer = await makeCustomer()
    await addEntry(customer.id, 'CHARGE', 100000)
    await addEntry(customer.id, 'PAYMENT', 120000)

    expect(await getBalance(customer.id)).toBe(-20000)
  })

  it('ignores another customer’s entries', async () => {
    const mine = await makeCustomer('ROMAN')
    const theirs = await makeCustomer('BALDO')
    await addEntry(mine.id, 'CHARGE', 100000)
    await addEntry(theirs.id, 'CHARGE', 999999)

    expect(await getBalance(mine.id)).toBe(100000)
  })
})

describe('listCustomerBalances', () => {
  it('sorts largest balance first and zero balances last', async () => {
    const small = await makeCustomer('SMALL')
    const big = await makeCustomer('BIG')
    await makeCustomer('NONE')
    await addEntry(small.id, 'CHARGE', 50000)
    await addEntry(big.id, 'CHARGE', 780000)

    const rows = await listCustomerBalances()

    expect(rows.map((r) => r.name)).toEqual(['BIG', 'SMALL', 'NONE'])
    expect(rows.map((r) => r.balanceCentavos)).toEqual([780000, 50000, 0])
  })

  it('agrees with getBalance for every customer', async () => {
    const a = await makeCustomer('A')
    const b = await makeCustomer('B')
    await addEntry(a.id, 'OPENING', 315000)
    await addEntry(a.id, 'PAYMENT', 15000)
    await addEntry(b.id, 'CHARGE', 42000)

    for (const row of await listCustomerBalances()) {
      expect(row.balanceCentavos).toBe(await getBalance(row.customerId))
    }
  })

  it('includes archived customers who still owe', async () => {
    const gone = await makeCustomer('GONE')
    await addEntry(gone.id, 'CHARGE', 42000)
    await prisma.customer.update({ where: { id: gone.id }, data: { isArchived: true } })

    const rows = await listCustomerBalances()
    expect(rows.map((r) => r.name)).toContain('GONE')
  })

  it('reports the newer date when a customer has two payments', async () => {
    const customer = await makeCustomer('ROMAN')
    await addEntry(customer.id, 'CHARGE', 500000, new Date('2026-07-01T00:00:00'))
    // The newer payment is inserted first, so array/insertion order and
    // chronological order diverge. `entries` has no `orderBy`, so nothing
    // guarantees Prisma returns rows oldest-first; a max-finding
    // implementation that (wrongly) just kept the last PAYMENT seen while
    // iterating, rather than actually comparing occurredAt, would pass with
    // dates in creation order but must fail here.
    await addEntry(customer.id, 'PAYMENT', 50000, new Date('2026-07-20T00:00:00'))
    await addEntry(customer.id, 'PAYMENT', 50000, new Date('2026-07-05T00:00:00'))

    const rows = await listCustomerBalances()

    const row = rows.find((r) => r.customerId === customer.id)
    expect(row?.lastPaymentAt).toEqual(new Date('2026-07-20T00:00:00'))
  })

  it('reports null when a customer’s only payment was voided', async () => {
    const customer = await makeCustomer('BALDO')
    await addEntry(customer.id, 'CHARGE', 100000, new Date('2026-07-01T00:00:00'))
    const payment = await addEntry(customer.id, 'PAYMENT', 100000, new Date('2026-07-10T00:00:00'))
    await voidEntry(payment.id)

    const rows = await listCustomerBalances()

    const row = rows.find((r) => r.customerId === customer.id)
    expect(row?.lastPaymentAt).toBeNull()
  })

  it('reports null for a customer with charges but no payments', async () => {
    const customer = await makeCustomer('NENA')
    await addEntry(customer.id, 'CHARGE', 100000, new Date('2026-07-01T00:00:00'))

    const rows = await listCustomerBalances()

    const row = rows.find((r) => r.customerId === customer.id)
    expect(row?.lastPaymentAt).toBeNull()
  })
})

describe('getTotalUtang', () => {
  it('sums every customer’s balance', async () => {
    const a = await makeCustomer('A')
    const b = await makeCustomer('B')
    await addEntry(a.id, 'CHARGE', 100000)
    await addEntry(b.id, 'OPENING', 50000)
    await addEntry(b.id, 'PAYMENT', 20000)

    expect(await getTotalUtang()).toBe(130000)
  })

  it('does not let one customer’s credit offset another’s debt', async () => {
    const debtor = await makeCustomer('DEBTOR')
    const overpaid = await makeCustomer('OVERPAID')
    await addEntry(debtor.id, 'CHARGE', 100000)
    await addEntry(overpaid.id, 'CHARGE', 30000)
    await addEntry(overpaid.id, 'PAYMENT', 80000) // -50000 balance

    expect(await getTotalUtang()).toBe(100000)
  })

  it('excludes a voided entry from the store-wide total', async () => {
    const a = await makeCustomer('A')
    await addEntry(a.id, 'CHARGE', 100000)
    const wrong = await addEntry(a.id, 'CHARGE', 999999)
    await voidEntry(wrong.id)

    expect(await getTotalUtang()).toBe(100000)
  })
})

describe('getLedger', () => {
  it('returns entries oldest first with a running balance', async () => {
    const customer = await makeCustomer()
    await addEntry(customer.id, 'CHARGE', 157500, new Date('2026-07-25T00:00:00'))
    await addEntry(customer.id, 'OPENING', 315000, new Date('2026-07-20T00:00:00'))
    await addEntry(customer.id, 'PAYMENT', 100000, new Date('2026-07-27T00:00:00'))

    const lines = await getLedger(customer.id)

    expect(lines.map((l) => l.type)).toEqual(['OPENING', 'CHARGE', 'PAYMENT'])
    expect(lines.map((l) => l.runningBalanceCentavos)).toEqual([315000, 472500, 372500])
  })

  it('shows voided entries without letting them move the running balance', async () => {
    const customer = await makeCustomer()
    await addEntry(customer.id, 'CHARGE', 100000, new Date('2026-07-20T00:00:00'))
    const wrong = await addEntry(customer.id, 'CHARGE', 999999, new Date('2026-07-21T00:00:00'))
    await addEntry(customer.id, 'PAYMENT', 40000, new Date('2026-07-22T00:00:00'))
    await voidEntry(wrong.id)

    const lines = await getLedger(customer.id)

    expect(lines).toHaveLength(3)
    expect(lines[1].isVoided).toBe(true)
    expect(lines.map((l) => l.runningBalanceCentavos)).toEqual([100000, 100000, 60000])
    // The ledger footer and the customers-list balance must be the same
    // number. If getLedger's running total and getBalance ever diverge
    // (e.g. someone changes the void rule in one but not the other), this
    // is where it would show up.
    expect(lines[lines.length - 1].runningBalanceCentavos).toBe(await getBalance(customer.id))
  })
})

describe('recordPayment', () => {
  it('writes one PAYMENT entry and lowers the balance', async () => {
    const customer = await makeCustomer()
    await addEntry(customer.id, 'CHARGE', 157500)

    const result = await recordPayment({
      customerId: customer.id,
      amountCentavos: 57500,
      occurredAt: new Date('2026-07-28T00:00:00'),
      note: 'partial',
    })

    expect(result.ok).toBe(true)
    expect(await getBalance(customer.id)).toBe(100000)
    const entries = await prisma.ledgerEntry.findMany({ where: { type: 'PAYMENT' } })
    expect(entries).toHaveLength(1)
    expect(entries[0].note).toBe('partial')
  })

  it('allows paying more than is owed', async () => {
    const customer = await makeCustomer()
    await addEntry(customer.id, 'CHARGE', 100000)

    const result = await recordPayment({
      customerId: customer.id,
      amountCentavos: 150000,
      occurredAt: new Date(),
    })

    expect(result.ok).toBe(true)
    expect(await getBalance(customer.id)).toBe(-50000)
  })

  it('rejects zero, negative, and non-integer amounts', async () => {
    const customer = await makeCustomer()

    for (const amountCentavos of [0, -100, 57500.5]) {
      const result = await recordPayment({
        customerId: customer.id,
        amountCentavos,
        occurredAt: new Date(),
      })
      expect(result.ok).toBe(false)
    }
    expect(await prisma.ledgerEntry.count()).toBe(0)
  })
})

describe('setOpeningBalance', () => {
  it('writes one OPENING entry', async () => {
    const customer = await makeCustomer()

    const result = await setOpeningBalance({
      customerId: customer.id,
      amountCentavos: 315000,
      occurredAt: new Date('2026-07-28T00:00:00'),
    })

    expect(result.ok).toBe(true)
    expect(await getBalance(customer.id)).toBe(315000)
  })

  it('refuses a second opening balance while the first is still live', async () => {
    const customer = await makeCustomer()
    await setOpeningBalance({
      customerId: customer.id,
      amountCentavos: 315000,
      occurredAt: new Date(),
    })

    const result = await setOpeningBalance({
      customerId: customer.id,
      amountCentavos: 999999,
      occurredAt: new Date(),
    })

    expect(result.ok).toBe(false)
    expect(await getBalance(customer.id)).toBe(315000)
  })

  it('allows setting it again after the first was voided (the only undo available)', async () => {
    const customer = await makeCustomer()
    const first = await setOpeningBalance({
      customerId: customer.id,
      amountCentavos: 315000,
      occurredAt: new Date('2026-07-20T00:00:00'),
    })
    expect(first.ok).toBe(true)
    if (first.ok) await voidEntry(first.data.entryId)

    const second = await setOpeningBalance({
      customerId: customer.id,
      amountCentavos: 351000,
      occurredAt: new Date('2026-07-28T00:00:00'),
    })

    expect(second.ok).toBe(true)
    expect(await getBalance(customer.id)).toBe(351000)
  })

  it('allows entering a forgotten carry-over after the customer already has a charge', async () => {
    const customer = await makeCustomer()
    await addEntry(customer.id, 'CHARGE', 42000, new Date('2026-07-25T00:00:00'))

    const result = await setOpeningBalance({
      customerId: customer.id,
      amountCentavos: 315000,
      occurredAt: new Date('2026-07-01T00:00:00'),
    })

    expect(result.ok).toBe(true)
    expect(await getBalance(customer.id)).toBe(357000)
  })
})

describe('updateEntry', () => {
  it('changes the entry and snapshots what it was', async () => {
    const customer = await makeCustomer()
    const entry = await addEntry(
      customer.id,
      'PAYMENT',
      50000,
      new Date('2026-07-20T00:00:00'),
    )

    const result = await updateEntry(entry.id, {
      amountCentavos: 60000,
      occurredAt: new Date('2026-07-21T00:00:00'),
      note: 'corrected',
    })

    expect(result.ok).toBe(true)

    const after = await prisma.ledgerEntry.findUniqueOrThrow({ where: { id: entry.id } })
    expect(after.amountCentavos).toBe(60000)
    expect(after.note).toBe('corrected')

    const revisions = await prisma.ledgerEntryRevision.findMany({
      where: { ledgerEntryId: entry.id },
    })
    expect(revisions).toHaveLength(1)
    expect(revisions[0].amountCentavos).toBe(50000)
    expect(revisions[0].occurredAt).toEqual(new Date('2026-07-20T00:00:00'))
  })

  it('writes one revision per edit', async () => {
    const customer = await makeCustomer()
    const entry = await addEntry(customer.id, 'PAYMENT', 10000)

    await updateEntry(entry.id, { amountCentavos: 20000, occurredAt: entry.occurredAt })
    await updateEntry(entry.id, { amountCentavos: 30000, occurredAt: entry.occurredAt })

    const revisions = await prisma.ledgerEntryRevision.findMany({
      where: { ledgerEntryId: entry.id },
      orderBy: { id: 'asc' },
    })
    expect(revisions.map((r) => r.amountCentavos)).toEqual([10000, 20000])
  })

  it('rejects a non-positive or non-integer amount and leaves the entry untouched', async () => {
    const customer = await makeCustomer()
    const entry = await addEntry(customer.id, 'PAYMENT', 10000)

    for (const amountCentavos of [0, -100, 57500.5]) {
      const result = await updateEntry(entry.id, { amountCentavos, occurredAt: new Date() })
      expect(result.ok).toBe(false)
    }

    const after = await prisma.ledgerEntry.findUniqueOrThrow({ where: { id: entry.id } })
    expect(after.amountCentavos).toBe(10000)
    expect(await prisma.ledgerEntryRevision.count()).toBe(0)
  })

  it('rejects updating an entry that does not exist', async () => {
    const result = await updateEntry(999999, { amountCentavos: 10000, occurredAt: new Date() })
    expect(result.ok).toBe(false)
  })
})

describe('voidEntry', () => {
  it('marks the entry voided and snapshots it, without deleting', async () => {
    const customer = await makeCustomer()
    const entry = await addEntry(customer.id, 'CHARGE', 157500)

    const result = await voidEntry(entry.id)

    expect(result.ok).toBe(true)
    const after = await prisma.ledgerEntry.findUniqueOrThrow({ where: { id: entry.id } })
    expect(after.isVoided).toBe(true)
    expect(await prisma.ledgerEntry.count()).toBe(1)

    const revisions = await prisma.ledgerEntryRevision.findMany({
      where: { ledgerEntryId: entry.id },
    })
    expect(revisions).toHaveLength(1)
    expect(revisions[0].isVoided).toBe(false)
  })

  it('rejects voiding an entry that does not exist', async () => {
    const result = await voidEntry(999999)
    expect(result.ok).toBe(false)
  })

  it('voiding an already-voided entry is a no-op success, not a second revision', async () => {
    const customer = await makeCustomer()
    const entry = await addEntry(customer.id, 'CHARGE', 157500)
    await voidEntry(entry.id)

    const result = await voidEntry(entry.id)

    expect(result.ok).toBe(true)
    const revisions = await prisma.ledgerEntryRevision.findMany({
      where: { ledgerEntryId: entry.id },
    })
    expect(revisions).toHaveLength(1)
  })
})

describe('recordPaymentBatch', () => {
  it('records every valid row', async () => {
    const a = await makeCustomer('ROMAN')
    const b = await makeCustomer('NENA')
    await addEntry(a.id, 'CHARGE', 100000)
    await addEntry(b.id, 'CHARGE', 50000)

    const result = await recordPaymentBatch([
      { customerId: a.id, amountCentavos: 40000, occurredAt: new Date('2026-07-28T00:00:00') },
      { customerId: b.id, amountCentavos: 25000, occurredAt: new Date('2026-07-28T00:00:00') },
    ])

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.recorded).toBe(2)
    expect(result.data.failures).toEqual([])
    expect(await getBalance(a.id)).toBe(60000)
    expect(await getBalance(b.id)).toBe(25000)
  })

  it('records the good rows and reports the bad one by index', async () => {
    const a = await makeCustomer('ROMAN')
    const b = await makeCustomer('NENA')

    const result = await recordPaymentBatch([
      { customerId: a.id, amountCentavos: 40000, occurredAt: new Date() },
      { customerId: b.id, amountCentavos: 0, occurredAt: new Date() },
      { customerId: b.id, amountCentavos: 25000, occurredAt: new Date() },
    ])

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.recorded).toBe(2)
    expect(result.data.failures).toHaveLength(1)
    expect(result.data.failures[0].index).toBe(1)
    expect(result.data.failures[0].error).toMatch(/more than zero/i)

    // The failing row wrote nothing.
    expect(await prisma.ledgerEntry.count({ where: { customerId: b.id } })).toBe(1)
  })

  it('reports a row naming a customer that does not exist', async () => {
    const result = await recordPaymentBatch([
      { customerId: 999999, amountCentavos: 40000, occurredAt: new Date() },
    ])

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.data.recorded).toBe(0)
    expect(result.data.failures[0].index).toBe(0)
    expect(await prisma.ledgerEntry.count()).toBe(0)
  })

  it('rejects an empty batch', async () => {
    const result = await recordPaymentBatch([])
    expect(result.ok).toBe(false)
  })

  it('keeps each row an independent entry', async () => {
    const a = await makeCustomer('ROMAN')

    await recordPaymentBatch([
      { customerId: a.id, amountCentavos: 10000, occurredAt: new Date(), note: 'first' },
      { customerId: a.id, amountCentavos: 20000, occurredAt: new Date(), note: 'second' },
    ])

    const entries = await prisma.ledgerEntry.findMany({ where: { customerId: a.id } })
    expect(entries).toHaveLength(2)
    expect(entries.map((e) => e.note).sort()).toEqual(['first', 'second'])
  })
})

describe('an unrecognised ledger entry type', () => {
  // SQLite has no enum, so LedgerEntryType is a TypeScript-only guarantee.
  // These pin the two boundaries that keep a corrupt `type` from doing
  // damage: writes are refused outright, reads degrade to zero instead of
  // throwing out of a Server Action or inflating a balance.

  it('is refused at the write boundary and persists nothing', async () => {
    const customer = await makeCustomer()

    const result = await createEntry('BOGUS' as unknown as LedgerEntryType, {
      customerId: customer.id,
      amountCentavos: 100000,
      occurredAt: new Date(),
    })

    expect(result.ok).toBe(false)
    expect(await prisma.ledgerEntry.count()).toBe(0)
  })

  it('is excluded from getBalance without throwing, and the corruption is logged', async () => {
    const customer = await makeCustomer()
    await addEntry(customer.id, 'CHARGE', 100000)
    // Simulate a corrupt row — e.g. a raw-SQL fix or a migration bug — by
    // writing directly with Prisma, bypassing the app's own write boundary.
    await prisma.ledgerEntry.create({
      data: { customerId: customer.id, type: 'BOGUS', amountCentavos: 999999, occurredAt: new Date() },
    })
    const errorSpy = vi.spyOn(console, 'error').mockImplementation(() => {})

    await expect(getBalance(customer.id)).resolves.toBe(100000)
    expect(errorSpy).toHaveBeenCalledOnce()

    errorSpy.mockRestore()
  })

  it('is excluded from getLedger’s running balance without throwing', async () => {
    const customer = await makeCustomer()
    await addEntry(customer.id, 'CHARGE', 100000, new Date('2026-07-20T00:00:00'))
    await prisma.ledgerEntry.create({
      data: {
        customerId: customer.id,
        type: 'BOGUS',
        amountCentavos: 999999,
        occurredAt: new Date('2026-07-21T00:00:00'),
      },
    })
    const errorSpy = vi.spyOn(console, 'error').mockImplementation(() => {})

    const lines = await getLedger(customer.id)

    expect(lines).toHaveLength(2)
    expect(lines.map((l) => l.runningBalanceCentavos)).toEqual([100000, 100000])
    expect(await getBalance(customer.id)).toBe(100000)

    errorSpy.mockRestore()
  })
})

describe('ledger due-date integration', () => {
  it('assigns the default deadline when an opening balance creates debt', async () => {
    const customer = await makeCustomer()

    const result = await setOpeningBalance({
      customerId: customer.id,
      amountCentavos: 50000,
      occurredAt: new Date(2026, 7, 3, 14),
    })

    expect(result.ok).toBe(true)
    const after = await prisma.customer.findUniqueOrThrow({ where: { id: customer.id } })
    expect(after.dueAt).toEqual(new Date(2026, 8, 2))
  })

  it('clears the deadline when a payment settles the account', async () => {
    const customer = await prisma.customer.create({
      data: { name: 'NENA', dueAt: new Date(2026, 7, 20) },
    })
    await addEntry(customer.id, 'CHARGE', 50000)

    await recordPayment({
      customerId: customer.id,
      amountCentavos: 50000,
      occurredAt: new Date(2026, 7, 5),
    })

    const after = await prisma.customer.findUniqueOrThrow({ where: { id: customer.id } })
    expect(after.dueAt).toBeNull()
  })

  it('reopens a deadline when editing a payment makes the balance positive', async () => {
    const customer = await makeCustomer('BALDO')
    await addEntry(customer.id, 'CHARGE', 50000)
    const payment = await addEntry(customer.id, 'PAYMENT', 50000)

    await updateEntry(payment.id, {
      amountCentavos: 40000,
      occurredAt: new Date(2026, 7, 10),
    })

    const after = await prisma.customer.findUniqueOrThrow({ where: { id: customer.id } })
    expect(after.dueAt).toEqual(new Date(2026, 8, 9))
  })

  it('reopens a deadline when voiding the payment exposes debt', async () => {
    const customer = await makeCustomer('TASYO')
    await addEntry(customer.id, 'CHARGE', 50000)
    const payment = await addEntry(customer.id, 'PAYMENT', 50000, new Date(2026, 7, 6))

    await voidEntry(payment.id)

    const after = await prisma.customer.findUniqueOrThrow({ where: { id: customer.id } })
    expect(after.dueAt).not.toBeNull()
  })
})

describe('sale-linked ledger protection', () => {
  it('refuses generic edit and void operations for a charge created by a sale', async () => {
    const customer = await makeCustomer('SALE LOCK')
    const sale = await prisma.sale.create({
      data: { totalAmount: 100000, customerId: customer.id },
    })
    const entry = await prisma.ledgerEntry.create({
      data: {
        customerId: customer.id,
        type: 'CHARGE',
        amountCentavos: 100000,
        occurredAt: new Date(),
        saleId: sale.id,
      },
    })

    const edited = await updateEntry(entry.id, {
      amountCentavos: 50000,
      occurredAt: new Date(),
      note: 'wrong path',
    })
    const voided = await voidEntry(entry.id)

    expect(edited).toEqual({
      ok: false,
      error: 'Sale-linked charges must be corrected from the sale record.',
    })
    expect(voided).toEqual({
      ok: false,
      error: 'Sale-linked charges must be corrected from the sale record.',
    })
    expect((await prisma.ledgerEntry.findUniqueOrThrow({ where: { id: entry.id } })).isVoided).toBe(false)
  })
})

describe('a payment recorded today, against a charge made earlier today', () => {
  it('never shows the running balance going negative', async () => {
    // The bug this exists for. A date picker gives a day, and stamping it
    // midnight put every payment BEFORE every sale made the same day — so a
    // customer who owed ₱14,450 and paid it in four instalments showed a
    // running balance of -₱14,450 partway down her own ledger, as though the
    // shop owed her the money.
    const customerId = (await makeCustomer()).id

    // Charged at 7am, as a sale would be.
    await addEntry(customerId, 'CHARGE', 1_198_000, new Date(2026, 7, 18, 7, 9))
    await addEntry(customerId, 'CHARGE', 247_000, new Date(2026, 7, 18, 7, 10))

    // Paid across the day, each recorded through the date picker as "today".
    const now = new Date(2026, 7, 18, 14, 32)
    for (const amount of [500_000, 600_000, 300_000, 45_000]) {
      const at = occurredAtForDay('2026-08-18', now)
      expect(at).not.toBeNull()
      const result = await recordPayment({ customerId, amountCentavos: amount, occurredAt: at! })
      expect(result.ok).toBe(true)
    }

    const lines = await getLedger(customerId)
    expect(lines).toHaveLength(6)

    // Charges first, then the payments — and no line in between claims the
    // shop owed her anything.
    let running = 0
    const balances: number[] = []
    for (const line of lines) {
      running += line.type === 'PAYMENT' ? -line.amountCentavos : line.amountCentavos
      balances.push(running)
    }

    expect(Math.min(...balances)).toBeGreaterThanOrEqual(0)
    expect(balances[balances.length - 1]).toBe(0)
    expect(await getBalance(customerId)).toBe(0)
  })

  it('still puts a genuinely earlier payment first', async () => {
    // The fix must not overcorrect: a payment recorded for YESTERDAY belongs
    // before today's charge, and a negative running balance there is the truth.
    const customerId = (await makeCustomer()).id
    const now = new Date(2026, 7, 18, 14, 32)

    await recordPayment({
      customerId,
      amountCentavos: 100_000,
      occurredAt: occurredAtForDay('2026-08-17', now)!,
    })
    await addEntry(customerId, 'CHARGE', 100_000, new Date(2026, 7, 18, 7, 9))

    const lines = await getLedger(customerId)
    expect(lines.map((line) => line.type)).toEqual(['PAYMENT', 'CHARGE'])
  })
})
