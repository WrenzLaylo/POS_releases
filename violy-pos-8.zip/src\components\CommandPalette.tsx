'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { Dialog } from '@/components/ui/Dialog'
import { searchEverything, type SearchResult } from '@/server/search'

const DEBOUNCE_MS = 150

const KIND_LABEL: Record<SearchResult['kind'], string> = {
  workspace: 'Workspace',
  customer: 'Customer',
  product: 'Product',
}

type CommandPaletteProps = {
  /**
   * Both omitted (the default) lets the palette manage its own open state —
   * all it needs to answer ⌘K/Ctrl+K on its own, which is how the palette
   * test renders it. AppTopbar's visible "Search ⌘K" button passes both so
   * a click opens this same instance instead of a second one.
   */
  open?: boolean
  onOpenChange?: (open: boolean) => void
}

/**
 * Navigation only. Every result below is a `next/link` that changes the
 * route — nothing here calls a Server Action, submits a form, or reaches an
 * order/payment screen's commit button. Saving an order or recording a
 * payment must stay a deliberate click on its own screen, never something a
 * search box or a stray Enter keypress can trigger.
 */
export function CommandPalette({ open: openProp, onOpenChange: onOpenChangeProp }: CommandPaletteProps = {}) {
  const [internalOpen, setInternalOpen] = useState(false)
  const open = openProp ?? internalOpen
  const setOpen = onOpenChangeProp ?? setInternalOpen

  const [query, setQuery] = useState('')
  const [results, setResults] = useState<SearchResult[]>([])

  // Dialog already provides Escape-to-close, the focus trap, body-scroll
  // lock, and focus restoration — none of that is reimplemented here, and
  // this listener never touches Escape, so there is only ever one handler
  // for it (Dialog's own).
  useEffect(() => {
    function onKeyDown(event: KeyboardEvent) {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault()
        setOpen(true)
      }
    }
    document.addEventListener('keydown', onKeyDown)
    return () => document.removeEventListener('keydown', onKeyDown)
  }, [setOpen])

  // Debounced search: a fast typist should not fire a query per keystroke.
  // `cancelled` guards against the race clearTimeout alone cannot stop: once
  // the timer has fired and the request is in flight, a later query's effect
  // can still run and resolve before this one does. Without this flag, that
  // stale response would land last and overwrite the newer query's results —
  // or repopulate the list after the palette has already closed.
  useEffect(() => {
    if (!open || !query.trim()) {
      setResults([])
      return
    }

    let cancelled = false
    const handle = setTimeout(() => {
      searchEverything(query).then((next) => {
        if (!cancelled) setResults(next)
      })
    }, DEBOUNCE_MS)

    return () => {
      cancelled = true
      clearTimeout(handle)
    }
  }, [open, query])

  function close() {
    setOpen(false)
    setQuery('')
    setResults([])
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => (next ? setOpen(true) : close())}
      title="Search"
      description="Jump to a workspace, customer, or product."
    >
      <div className="flex flex-col gap-3">
        <input
          type="text"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search workspaces, customers, products…"
          aria-label="Search"
          className="h-10 w-full rounded-control border border-line bg-surface px-3 text-sm text-ink placeholder:text-ink-subtle focus:outline-none focus:ring-2 focus:ring-accent"
        />

        {results.length > 0 ? (
          <ul className="flex flex-col gap-1">
            {results.map((result) => (
              <li key={`${result.kind}-${result.id}`}>
                <Link
                  href={result.href}
                  onClick={close}
                  className="flex items-center justify-between gap-3 rounded-control px-3 py-2 text-sm text-ink hover:bg-surface-sunk focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                >
                  <span className="truncate">{result.label}</span>
                  <span className="shrink-0 text-xs text-ink-subtle">
                    {result.hint ?? KIND_LABEL[result.kind]}
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        ) : query.trim() ? (
          <p className="px-3 py-2 text-sm text-ink-muted">No matches.</p>
        ) : null}
      </div>
    </Dialog>
  )
}
