import type { NotificationSummary } from './types'

/** Where the last-seen signature lives. Per browser, per laptop. */
export const NOTIFICATIONS_SEEN_KEY = 'violy.notifications-seen'

/**
 * A short string identifying WHICH notifications are showing, not how many.
 *
 * The badge has to disappear once she has read the panel and come back the
 * moment something new arrives, so "have I seen this?" needs to compare
 * contents rather than a count. A count cannot do it: one overdue account
 * settling on the same morning another falls due leaves the total at nine
 * while the list is materially different, and the badge would stay silent
 * about a customer she has never been told about.
 *
 * What each entry is keyed on is a judgement about what counts as news:
 *
 *   · Accounts and products are keyed by id ALONE. That an account is overdue
 *     is the news; the balance creeping up on an account she has already seen
 *     flagged is not, and re-badging on it would train her to ignore the
 *     badge.
 *   · Missed instalments carry their count, because going from two months
 *     behind to three is a different conversation, not the same one louder.
 *   · Updates carry their number, since a second update really is new.
 *
 * Sorted, so the same set of notifications arriving in a different order from
 * the server is still the same set.
 */
export function notificationSignature(notifications: NotificationSummary): string {
  const parts = [
    `u:${notifications.updatesAvailable}`,
    ...notifications.dueToday.map((row) => `d:${row.customerId}`),
    ...notifications.overdueAccounts.map((row) => `o:${row.customerId}`),
    ...notifications.overdueInstallments.map((row) => `i:${row.planId}:${row.count}`),
    ...notifications.lowStock.map((row) => `s:${row.id}`),
  ]
  return parts.sort().join('|')
}
