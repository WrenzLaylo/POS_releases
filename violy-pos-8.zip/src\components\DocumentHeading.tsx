import type { ReactNode } from 'react'
import { storeProfileLines, type StoreIdentity } from '@/lib/store-profile'

/**
 * The masthead every printable document opens with. Server-rendered — it holds
 * no state and belongs inside `DocumentShell`'s sheet.
 *
 * Kept in one place so the documents cannot drift into looking like they came
 * from different shops, and so the store's registered identity is printed
 * from a single source rather than retyped per document.
 */
export function DocumentHeading({
  profile,
  title,
  reference,
  issuedAt,
  subtitle,
}: {
  /** The shop's identity, loaded once by the page and passed in. */
  profile: StoreIdentity
  /** e.g. "Official Receipt", "Statement of Account". */
  title: string
  /** The document's own reference, e.g. `OR-2026-000042`. */
  reference: string
  issuedAt: Date
  /** An optional line under the title. */
  subtitle?: string
}) {
  // Anything not yet filled in on the Settings screen is absent from this
  // list, so an unfinished profile prints a plain heading rather than an empty
  // "TIN:" where a number belongs.
  const identity = storeProfileLines(profile)

  return (
    <header className="doc-masthead flex flex-wrap items-start justify-between gap-6 border-b border-line-strong pb-6">
      <div className="flex min-w-0 items-start gap-3">
        {/* Printed as well as shown. A receipt that carries the shop's mark is
            the difference between a document and a slip of paper, and this is
            the masthead every printable document shares — so it appears once
            here rather than being added per document and drifting. */}
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/brand/violy-store-mark.png"
          alt=""
          width={56}
          height={56}
          className="h-14 w-14 shrink-0"
        />
        <div className="min-w-0">
        <div className="text-xl font-semibold text-ink">{profile.name}</div>
        {profile.tagline.trim() !== '' && (
          <div className="mt-1 text-sm text-ink-muted">{profile.tagline}</div>
        )}
        {identity.length > 0 && (
          <address className="mt-2 not-italic text-xs leading-relaxed text-ink-muted">
            {identity.map((line) => (
              <div key={`${line.label ?? ''}-${line.value}`}>
                {line.label && <span className="font-medium">{line.label}: </span>}
                {line.value}
              </div>
            ))}
          </address>
        )}
        </div>
      </div>
      <div className="text-right">
        <h1 className="text-xl font-semibold uppercase tracking-wide text-ink">{title}</h1>
        <div className="mt-1 font-mono text-sm font-medium text-ink">{reference}</div>
        <div className="mt-1 text-sm text-ink-muted">
          {issuedAt.toLocaleString('en-PH', { dateStyle: 'long', timeStyle: 'short' })}
        </div>
        {subtitle && <div className="mt-1 text-sm text-ink-muted">{subtitle}</div>}
      </div>
    </header>
  )
}

/** A labelled block of facts, e.g. the customer panel. */
export function DocumentFacts({
  items,
}: {
  items: readonly { label: string; value: ReactNode; align?: 'start' | 'end' }[]
}) {
  return (
    <section className="doc-facts grid gap-4 border-b border-line py-5 sm:grid-cols-2">
      {items.map((item) => (
        <div key={item.label} className={item.align === 'end' ? 'sm:text-right' : undefined}>
          <div className="text-xs font-semibold uppercase tracking-wide text-ink-muted">
            {item.label}
          </div>
          <div className="mt-1 text-sm font-medium text-ink">{item.value}</div>
        </div>
      ))}
    </section>
  )
}

/** Standing legal text at the foot of a document. */
export function DocumentTerms({ title, items }: { title: string; items: readonly string[] }) {
  return (
    <section className="doc-keep-together mt-8 border-t border-line pt-5">
      <h2 className="text-xs font-semibold uppercase tracking-wide text-ink">{title}</h2>
      <ol className="mt-2 list-decimal space-y-1 pl-4 text-xs leading-relaxed text-ink-muted">
        {items.map((item) => (
          <li key={item}>{item}</li>
        ))}
      </ol>
    </section>
  )
}

export function DocumentFooter({ children }: { children?: ReactNode }) {
  return (
    <footer className="mt-8 border-t border-line pt-5 text-center text-xs text-ink-muted">
      {children ?? 'Thank you. Keep this document for your records.'}
    </footer>
  )
}
