'use server'

import { prisma } from '@/lib/db'
import { csvToCentavos, parseCsv, rowsToRecords } from '@/lib/csv'
import { isDiscountBasis, isDiscountKind, MAX_BPS } from '@/lib/discount'
import type { ActionResult } from '@/lib/types'

export type ImportTable = 'products' | 'customers' | 'categories' | 'suppliers'

/** What one CSV row would do, or why it cannot. */
export type ImportRow = {
  /** 1-based row number as it appears in the spreadsheet, header included. */
  line: number
  name: string
  action: 'create' | 'update' | 'skip'
  /** Human summary of what changes, e.g. "price 1450.00 -> 1500.00". */
  changes: string[]
  error?: string
}

export type ImportPreview = {
  table: ImportTable
  rows: ImportRow[]
  createCount: number
  updateCount: number
  errorCount: number
}

/**
 * Imports are ALWAYS previewed before they are applied.
 *
 * A spreadsheet is edited by hand, so a column can be shifted, a price can be
 * a word, a name can be a typo that creates a duplicate product rather than
 * updating the one that exists. Writing straight from a file means finding
 * that out afterwards, in the data.
 *
 * `dryRun` walks exactly the same code as the real thing and reports what each
 * row would do. Applying re-derives the rows rather than trusting a preview
 * the browser sends back, because the database can move between the two.
 */
async function planProducts(records: Record<string, string>[]): Promise<ImportRow[]> {
  const [existing, categories] = await Promise.all([
    prisma.product.findMany({ select: { id: true, name: true, price: true, costPrice: true, stockQty: true } }),
    prisma.category.findMany({ select: { id: true, name: true } }),
  ])
  // Matched case-insensitively: "adm broodsow (sako)" out of a spreadsheet is
  // the same product as "ADM Broodsow (sako)", and treating it as new would
  // silently duplicate the catalog.
  const byName = new Map(existing.map((product) => [product.name.trim().toLowerCase(), product]))
  const categoryByName = new Map(categories.map((c) => [c.name.trim().toLowerCase(), c]))

  return records.map((record, index) => {
    const line = index + 2
    const name = record.name ?? ''
    const row: ImportRow = { line, name, action: 'skip', changes: [] }

    if (name === '') return { ...row, error: 'No name in this row.' }

    const price = csvToCentavos(record.price ?? '')
    const cost = csvToCentavos(record.cost ?? '')
    const stock = record.stock === '' || record.stock === undefined ? null : Number(record.stock)
    const threshold =
      record.low_stock_at === '' || record.low_stock_at === undefined
        ? null
        : Number(record.low_stock_at)

    if (price === null) return { ...row, error: 'Price is not a number.' }
    if (cost === null) return { ...row, error: 'Cost is not a number.' }
    if (stock === null || !Number.isFinite(stock)) return { ...row, error: 'Stock is not a number.' }
    if (threshold !== null && !Number.isFinite(threshold)) {
      return { ...row, error: 'Low stock alert is not a number.' }
    }

    const categoryName = (record.category ?? '').trim()
    if (categoryName === '') return { ...row, error: 'No category in this row.' }
    if (!categoryByName.has(categoryName.toLowerCase())) {
      // Deliberately refused rather than created. A typo in a category column
      // would otherwise quietly add "Feeds (Sakoo)" and split the catalog.
      return { ...row, error: `No category called "${categoryName}".` }
    }

    const current = byName.get(name.trim().toLowerCase())
    if (!current) {
      return { ...row, action: 'create', changes: ['new product'] }
    }

    const changes: string[] = []
    if (current.price !== price) changes.push(`price ${current.price / 100} → ${price / 100}`)
    if (current.costPrice !== cost) changes.push(`cost ${current.costPrice / 100} → ${cost / 100}`)
    if (current.stockQty !== stock) changes.push(`stock ${current.stockQty} → ${stock}`)

    return changes.length === 0
      ? { ...row, action: 'skip', changes: ['no change'] }
      : { ...row, action: 'update', changes }
  })
}

async function planCustomers(records: Record<string, string>[]): Promise<ImportRow[]> {
  const existing = await prisma.customer.findMany({
    select: {
      id: true,
      name: true,
      phone: true,
      notes: true,
      // Fetched so the discount can be COMPARED rather than assumed changed.
      discountKind: true,
      discountBasis: true,
      discountCentavos: true,
      discountBps: true,
    },
  })
  const byName = new Map(existing.map((customer) => [customer.name.trim().toLowerCase(), customer]))

  return records.map((record, index) => {
    const line = index + 2
    const name = record.name ?? ''
    const row: ImportRow = { line, name, action: 'skip', changes: [] }

    if (name === '') return { ...row, error: 'No name in this row.' }

    const kind = (record.discount_kind || 'AMOUNT').toUpperCase()
    const basis = (record.discount_basis || 'PER_UNIT').toUpperCase()
    if (!isDiscountKind(kind)) return { ...row, error: `Unknown discount kind "${kind}".` }
    if (!isDiscountBasis(basis)) return { ...row, error: `Unknown discount basis "${basis}".` }

    const rawValue = record.discount_value ?? ''
    const value = rawValue === '' ? 0 : csvToCentavos(rawValue)
    if (value === null) return { ...row, error: 'Discount value is not a number.' }
    if (kind === 'PERCENT' && value > MAX_BPS) {
      return { ...row, error: 'Discount percentage is above 100%.' }
    }

    const current = byName.get(name.trim().toLowerCase())
    if (!current) return { ...row, action: 'create', changes: ['new customer'] }

    const changes: string[] = []
    const phone = record.phone ?? ''
    const notes = record.notes ?? ''
    if ((current.phone ?? '') !== phone) changes.push('phone')
    if (current.notes !== notes) changes.push('notes')

    // Compared against what is stored, not merely "the file has a value".
    // Reporting an unchanged discount as a change made the preview describe an
    // untouched file as forty-six updates — and a preview that cries wolf is
    // one she stops reading, which defeats the only safeguard an import has.
    //
    // The value lands in the column its KIND uses: centavos for AMOUNT, basis
    // points for PERCENT, matching what the exporter wrote and what the apply
    // branch below stores.
    const storedValue = kind === 'PERCENT' ? current.discountBps : current.discountCentavos
    if (kind !== current.discountKind) changes.push(`discount type ${current.discountKind} -> ${kind}`)
    else if (basis !== current.discountBasis) changes.push(`discount basis ${current.discountBasis} -> ${basis}`)
    else if (value !== storedValue) changes.push('discount')

    return changes.length === 0
      ? { ...row, action: 'skip', changes: ['no change'] }
      : { ...row, action: 'update', changes }
  })
}

/**
 * Categories, matched by name.
 *
 * This one has to exist for the others to be worth anything: `planProducts`
 * REFUSES a row whose category is not already on file rather than inventing
 * one, so a fresh laptop cannot take a products file until its categories are
 * there. Importing products first and wondering why every row failed is the
 * shape that bug takes.
 *
 * Case-insensitively matched, like every other name in this app — SQLite
 * compares TEXT case-sensitively, so "Atlas" and "atlas" would otherwise
 * become two chips holding half a brand each.
 */
async function planCategories(records: Record<string, string>[]): Promise<ImportRow[]> {
  const existing = await prisma.category.findMany({ select: { id: true, name: true } })
  const byName = new Map(existing.map((row) => [row.name.trim().toLowerCase(), row]))

  return records.map((record, index) => {
    const line = index + 2
    const name = (record.name ?? '').trim()
    const row: ImportRow = { line, name, action: 'skip', changes: [] }

    if (name === '') return { ...row, error: 'No name in this row.' }
    if (name.length > 60) return { ...row, error: 'That name is too long.' }

    const match = byName.get(name.toLowerCase())
    if (!match) return { ...row, action: 'create', changes: ['new category'] }
    // Nothing but the name identifies a category, so a match is a no-op. Said
    // plainly rather than reported as an update that changes nothing.
    return { ...row, action: 'skip', changes: ['already there'] }
  })
}

/** Suppliers, matched by name, same rules as customers. */
async function planSuppliers(records: Record<string, string>[]): Promise<ImportRow[]> {
  const existing = await prisma.supplier.findMany({
    select: { id: true, name: true, contactNumber: true, notes: true },
  })
  const byName = new Map(existing.map((row) => [row.name.trim().toLowerCase(), row]))

  return records.map((record, index) => {
    const line = index + 2
    const name = (record.name ?? '').trim()
    const row: ImportRow = { line, name, action: 'skip', changes: [] }

    if (name === '') return { ...row, error: 'No name in this row.' }

    const contact = (record.contact_number ?? '').trim()
    const notes = (record.notes ?? '').trim()
    const match = byName.get(name.toLowerCase())
    if (!match) return { ...row, action: 'create', changes: ['new supplier'] }

    const changes: string[] = []
    if (contact !== match.contactNumber) changes.push(`contact ${match.contactNumber || '—'} -> ${contact || '—'}`)
    if (notes !== match.notes) changes.push('notes')
    return changes.length === 0
      ? { ...row, action: 'skip', changes: ['no change'] }
      : { ...row, action: 'update', changes }
  })
}

function summarise(table: ImportTable, rows: ImportRow[]): ImportPreview {
  return {
    table,
    rows,
    createCount: rows.filter((row) => !row.error && row.action === 'create').length,
    updateCount: rows.filter((row) => !row.error && row.action === 'update').length,
    errorCount: rows.filter((row) => row.error).length,
  }
}

/** One place the table picks its planner, so preview and apply cannot drift. */
async function plan(
  table: ImportTable,
  records: Record<string, string>[],
): Promise<ImportRow[]> {
  switch (table) {
    case 'products':
      return planProducts(records)
    case 'customers':
      return planCustomers(records)
    case 'categories':
      return planCategories(records)
    case 'suppliers':
      return planSuppliers(records)
  }
}

export async function previewImport(
  table: ImportTable,
  csvText: string,
): Promise<ActionResult<ImportPreview>> {
  const records = rowsToRecords(parseCsv(csvText))
  if (records.length === 0) {
    return { ok: false, error: 'That file has no rows under its header.' }
  }
  if (!('name' in records[0])) {
    return { ok: false, error: 'That file has no "name" column.' }
  }

  const rows = await plan(table, records)
  return { ok: true, data: summarise(table, rows) }
}

/**
 * Applies an import, skipping rows that cannot be read.
 *
 * Deliberately NOT one transaction, for the same reason `recordPaymentBatch`
 * is not: a hundred rows deep, one bad cell discarding the lot is how a person
 * stops using a tool. Each row either lands or is reported, and there is no
 * half-written state to recover from because a row is one record.
 */
export async function applyImport(
  table: ImportTable,
  csvText: string,
): Promise<ActionResult<{ created: number; updated: number; failed: number }>> {
  const records = rowsToRecords(parseCsv(csvText))
  if (records.length === 0) return { ok: false, error: 'That file has no rows under its header.' }

  // Re-derived here rather than taken from the preview the browser holds: the
  // database can change between looking and applying.
  const planned = await plan(table, records)

  let created = 0
  let updated = 0
  let failed = 0

  for (const [index, row] of planned.entries()) {
    if (row.error || row.action === 'skip') {
      if (row.error) failed += 1
      continue
    }
    const record = records[index]

    try {
      if (table === 'products') {
        const category = await prisma.category.findFirst({
          where: { name: record.category.trim() },
        })
        if (!category) {
          failed += 1
          continue
        }
        const data = {
          name: record.name.trim(),
          categoryId: category.id,
          unit: (record.unit ?? '').trim() || 'piraso',
          price: csvToCentavos(record.price)!,
          costPrice: csvToCentavos(record.cost)!,
          stockQty: Number(record.stock),
          lowStockThreshold:
            record.low_stock_at === '' || record.low_stock_at === undefined
              ? 0
              : Number(record.low_stock_at),
        }
        const existing = await prisma.product.findFirst({ where: { name: data.name } })
        if (existing) {
          await prisma.product.update({ where: { id: existing.id }, data })
          updated += 1
        } else {
          await prisma.product.create({ data })
          created += 1
        }
      } else if (table === 'categories') {
        const name = record.name.trim()
        // Sorted to the END when the file does not say, matching
        // `createCategory`: a chip strip she has learned the shape of should
        // not reorder itself because a file was imported.
        const last = await prisma.category.findFirst({
          orderBy: { sortOrder: 'desc' },
          select: { sortOrder: true },
        })
        const sortOrder =
          record.sort_order === undefined || record.sort_order.trim() === ''
            ? (last?.sortOrder ?? 0) + 1
            : Number(record.sort_order)
        await prisma.category.create({
          data: { name, sortOrder: Number.isFinite(sortOrder) ? sortOrder : (last?.sortOrder ?? 0) + 1 },
        })
        created += 1
      } else if (table === 'suppliers') {
        const data = {
          name: record.name.trim(),
          contactNumber: (record.contact_number ?? '').trim(),
          notes: (record.notes ?? '').trim(),
        }
        const existing = await prisma.supplier.findFirst({ where: { name: data.name } })
        if (existing) {
          await prisma.supplier.update({ where: { id: existing.id }, data })
          updated += 1
        } else {
          await prisma.supplier.create({ data })
          created += 1
        }
      } else {
        const kind = (record.discount_kind || 'AMOUNT').toUpperCase()
        const rawValue = record.discount_value ?? ''
        const value = rawValue === '' ? 0 : (csvToCentavos(rawValue) ?? 0)
        const data = {
          name: record.name.trim(),
          phone: (record.phone ?? '').trim() || null,
          notes: (record.notes ?? '').trim(),
          discountKind: kind,
          discountBasis: (record.discount_basis || 'PER_UNIT').toUpperCase(),
          discountCentavos: kind === 'AMOUNT' ? value : 0,
          discountBps: kind === 'PERCENT' ? value : 0,
        }
        const existing = await prisma.customer.findFirst({ where: { name: data.name } })
        if (existing) {
          await prisma.customer.update({ where: { id: existing.id }, data })
          updated += 1
        } else {
          await prisma.customer.create({ data })
          created += 1
        }
      }
    } catch {
      failed += 1
    }
  }

  return { ok: true, data: { created, updated, failed } }
}
