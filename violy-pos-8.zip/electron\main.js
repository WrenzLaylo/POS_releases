/**
 * The desktop shell for Violy Store POS.
 *
 * A WINDOW around the local server, deliberately not a bundle of the app.
 * The Next application stays ordinary files on disk, so the updater in
 * `scripts/update.mjs` keeps working exactly as it does without Electron —
 * download, unpack, rebuild, restart. Packaging the app inside the executable
 * would have meant shipping two update mechanisms instead of one.
 *
 * What this owns:
 *   · starting and stopping the Next server
 *   · a branded splash while it boots, so a slow start is not a blank screen
 *   · checking for updates before the shop opens, and telling her three ways
 *   · start-when-the-computer-turns-on
 *   · taking backups on a schedule, because nobody remembers to
 *   · putting one back, which needed a terminal until now
 *   · copying the backups onto a stick, which the app kept telling her to do
 *   · noticing the server has died, and starting it again
 */

const {
  app,
  BrowserWindow,
  Menu,
  Notification,
  dialog,
  ipcMain,
  powerSaveBlocker,
  shell,
} = require('electron')
const { spawn, execFile } = require('node:child_process')
const { copyFileSync, mkdirSync, readFileSync, readdirSync, statSync, writeFileSync } = require('node:fs')
const path = require('node:path')
const net = require('node:net')

const PORT = Number(process.env.POS_PORT ?? 3000)
const URL = `http://localhost:${PORT}`
const ROOT = path.join(__dirname, '..')
/** A literal newline, kept out of string escapes so a patch cannot break it. */
const NEWLINE = String.fromCharCode(10)

/** The server this shell started, if it started one. */
let serverProcess = null
let mainWindow = null
let splashWindow = null

// ── server ────────────────────────────────────────────────────────────────

/** Whether something is already answering on the port. */
function portInUse() {
  return new Promise((resolve) => {
    const socket = net.connect({ port: PORT, host: '127.0.0.1' })
    socket.setTimeout(600)
    socket.on('connect', () => {
      socket.destroy()
      resolve(true)
    })
    socket.on('error', () => resolve(false))
    socket.on('timeout', () => {
      socket.destroy()
      resolve(false)
    })
  })
}

async function waitForServer(timeoutMs = 90_000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    if (await portInUse()) return true
    await new Promise((resolve) => setTimeout(resolve, 400))
  }
  return false
}

/**
 * Starts the Next server, unless one is already running.
 *
 * The already-running check matters: opening the app twice must not start a
 * second server that fails on a taken port and leaves the second window
 * blank. It simply attaches to the one that is there.
 */
async function startServer() {
  if (await portInUse()) return 'already-running'

  serverProcess = spawn(
    process.execPath,
    [path.join(ROOT, 'node_modules', 'next', 'dist', 'bin', 'next'), 'start', '-p', String(PORT)],
    {
      cwd: ROOT,
      // ELECTRON_RUN_AS_NODE makes Electron's bundled binary behave as plain
      // Node for this child, so the server runs without Node needing to be
      // installed separately on her laptop.
      env: { ...process.env, ELECTRON_RUN_AS_NODE: '1', NODE_ENV: 'production' },
      stdio: 'ignore',
      windowsHide: true,
    },
  )
  serverProcess.on('error', () => {
    serverProcess = null
  })
  return 'started'
}

function stopServer() {
  if (!serverProcess) return
  try {
    // `/T` kills the tree: `next start` spawns workers, and killing only the
    // parent leaves them holding the port so the next launch cannot bind.
    if (process.platform === 'win32') {
      execFile('taskkill', ['/PID', String(serverProcess.pid), '/F', '/T'], () => {})
    } else {
      serverProcess.kill('SIGTERM')
    }
  } catch {
    // Already gone.
  }
  serverProcess = null
}

// ── backups ───────────────────────────────────────────────────────────────

/**
 * How often to ASK for a backup — not how often one is taken.
 *
 * The schedule itself lives in `src/lib/backup-policy.ts`, and the script
 * answers "there is already a recent one" when it is too soon. Asking every
 * hour and being refused costs a few hundred milliseconds and means this file
 * holds no second copy of the interval that could drift away from the sentence
 * in Settings telling her how often backups happen.
 */
const BACKUP_TICK_MS = 60 * 60 * 1000

/** How often to check the server is still answering. Often enough that a
 *  blip is over before a customer notices, cheap enough to ignore. */
const WATCH_TICK_MS = 15 * 1000

/**
 * Runs one of the project's tsx scripts and collects what it said.
 *
 * `stdout` and `stderr` are kept APART. They used to be concatenated, which is
 * fine for a human reading a backup's output and useless for `--inspect`,
 * whose stdout is JSON that has to parse — `node:sqlite` prints an
 * ExperimentalWarning to stderr on every run and would land in the middle of
 * it.
 */
function runTsx(script, args = []) {
  return new Promise((resolve) => {
    const child = spawn(
      process.execPath,
      [path.join(ROOT, 'node_modules', 'tsx', 'dist', 'cli.mjs'), path.join(ROOT, 'scripts', script), ...args],
      {
        cwd: ROOT,
        // ELECTRON_RUN_AS_NODE so this works whether or not Node is on the
        // PATH — the same reason the server is started that way.
        env: { ...process.env, ELECTRON_RUN_AS_NODE: '1' },
        stdio: ['ignore', 'pipe', 'pipe'],
        windowsHide: true,
      },
    )

    let out = ''
    let err = ''
    child.stdout.on('data', (chunk) => {
      out += chunk
    })
    child.stderr.on('data', (chunk) => {
      err += chunk
    })
    child.on('error', () => resolve({ ok: false, out: '', err: 'Could not start it.' }))
    child.on('close', (code) => resolve({ ok: code === 0, out: out.trim(), err: err.trim() }))
  })
}

async function runBackup({ auto }) {
  const result = await runTsx('backup-db.ts', auto ? ['--auto'] : [])
  return { ok: result.ok, output: [result.out, result.err].filter(Boolean).join(NEWLINE) }
}

/**
 * The menu's "Back up now", which always takes one.
 *
 * It reports either way. A backup button that says nothing is the same as no
 * backup button — the answer she needs is not "it probably worked".
 */
async function backupNowFromMenu() {
  const result = await runBackup({ auto: false })
  await dialog.showMessageBox({
    type: result.ok ? 'info' : 'error',
    title: 'Violy Store',
    message: result.ok ? 'Your data has been backed up.' : 'Could not save a backup.',
    detail: result.ok
      ? 'A full copy is in the backups folder. Copy that folder to a USB stick now and then — a backup on this laptop does not survive losing the laptop.'
      : 'Check there is space on the computer, then try again. Nothing has been changed.',
    buttons: ['OK'],
  })
}

// ── restoring a backup ────────────────────────────────────────────────────

/**
 * The backups folder, newest first.
 *
 * Only files this app wrote. A folder somebody has also been copying things
 * into should not offer those things as restore candidates.
 */
function listBackups() {
  const folder = path.join(ROOT, 'backups')
  try {
    return readdirSync(folder)
      .filter((name) => name.startsWith('violy-pos-') && name.endsWith('.db'))
      .sort()
      .reverse()
      .map((name) => {
        const full = path.join(folder, name)
        const info = statSync(full)
        return { name, path: full, bytes: info.size, takenAt: info.mtime }
      })
  } catch {
    return []
  }
}

function whenTaken(date) {
  return new Intl.DateTimeFormat('en-PH', {
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(date)
}

/**
 * Putting a backup back, from the menu.
 *
 * This existed only as `npm run restore -- <file>` — a terminal command, on a
 * shop laptop, for the one operation you reach for on the worst day. Backups
 * that cannot be restored without someone else's help are not backups.
 *
 * The server is STOPPED before the file is replaced and started again after.
 * That is not tidiness: `next start` holds the SQLite file open, and Windows
 * either refuses the overwrite or leaves a half-written database — turning a
 * recoverable problem into the total loss the backup existed to prevent.
 *
 * The heavy lifting stays in `scripts/restore-db.ts`, which validates the
 * candidate and saves the current database first. This is a way to reach it,
 * not a second copy of it.
 */
async function restoreFromMenu() {
  const backups = listBackups()
  if (backups.length === 0) {
    await dialog.showMessageBox({
      type: 'info',
      title: 'Violy Store',
      message: 'There are no backups yet.',
      detail: 'Use "Back up now" first. Backups are also taken automatically while the app is open.',
      buttons: ['OK'],
    })
    return
  }

  const newest = backups[0]
  const { response: pick } = await dialog.showMessageBox({
    type: 'question',
    title: 'Violy Store',
    message: 'Go back to a saved copy of your data?',
    detail: [
      `The newest copy was saved ${whenTaken(newest.takenAt)}.`,
      '',
      'Anything recorded since then will be gone. Your data as it is right now is saved first, so this can be undone.',
    ].join(NEWLINE),
    buttons: ['Use the newest copy', 'Choose a different one…', 'Cancel'],
    defaultId: 2,
    cancelId: 2,
  })
  if (pick === 2) return

  let chosen = newest.path
  if (pick === 1) {
    const picked = await dialog.showOpenDialog({
      title: 'Choose a backup',
      defaultPath: path.join(ROOT, 'backups'),
      // A backup on a USB stick is the case that matters most here: it is how
      // the shop's data survives losing the laptop entirely.
      filters: [{ name: 'Violy Store backup', extensions: ['db'] }],
      properties: ['openFile'],
    })
    if (picked.canceled || picked.filePaths.length === 0) return
    chosen = picked.filePaths[0]
  }

  // Read and checked BEFORE anything is replaced. A truncated copy or a file
  // that is not one of ours is refused here rather than after the live
  // database is already gone.
  const look = await runTsx('restore-db.ts', ['--inspect', chosen])
  if (!look.ok) {
    await dialog.showMessageBox({
      type: 'error',
      title: 'Violy Store',
      message: 'That file cannot be used.',
      detail: `${look.err || 'It is not a backup of this app.'}${NEWLINE}${NEWLINE}Nothing has been changed.`,
      buttons: ['OK'],
    })
    return
  }

  let summary = null
  try {
    summary = JSON.parse(look.out)
  } catch {
    summary = null
  }

  const { response: confirm } = await dialog.showMessageBox({
    type: 'warning',
    title: 'Violy Store',
    message: 'Replace your data with this copy?',
    detail: [
      path.basename(chosen),
      '',
      summary
        ? `It holds ${summary.products} products, ${summary.customers} customers, ${summary.sales} sales and ${summary.entries} ledger entries.`
        : 'It looks like a valid backup.',
      '',
      'The app will close and open again by itself.',
    ].join(NEWLINE),
    buttons: ['Replace my data', 'Cancel'],
    defaultId: 1,
    cancelId: 1,
  })
  if (confirm !== 0) return

  // Held open by the server until this moment. Everything below runs with the
  // database closed.
  stopServer()
  await new Promise((resolve) => setTimeout(resolve, 1500))

  const result = await runTsx('restore-db.ts', [chosen])

  await startServer()
  const up = await waitForServer(60_000)
  if (up && mainWindow && !mainWindow.isDestroyed()) mainWindow.reload()

  await dialog.showMessageBox({
    type: result.ok ? 'info' : 'error',
    title: 'Violy Store',
    message: result.ok ? 'Your data has been restored.' : 'Could not restore that copy.',
    detail: result.ok
      ? 'The copy you chose is now in place. Your previous data was saved into the backups folder first, in case this was not what you wanted.'
      : `${result.err || 'Nothing was replaced.'}${NEWLINE}${NEWLINE}Your data has not been changed.`,
    buttons: ['OK'],
  })
}

// ── copying the backups somewhere else ────────────────────────────────────

/**
 * Copies the whole backups folder onto a stick.
 *
 * The app has been telling her to do this since the day backups shipped — "a
 * backup on this laptop does not survive losing the laptop" — and giving her
 * no way to. Advice with no button is not advice.
 *
 * A folder picker rather than a drive list: enumerating removable drives on
 * Windows needs WMI or a native module, and gets it wrong for phones, SD card
 * readers and network shares. The picker already knows about all of them, and
 * she recognises her own USB stick in it.
 */
async function copyBackupsToStick() {
  const source = path.join(ROOT, 'backups')
  const backups = listBackups()
  if (backups.length === 0) {
    await dialog.showMessageBox({
      type: 'info',
      title: 'Violy Store',
      message: 'There are no backups to copy yet.',
      buttons: ['OK'],
    })
    return
  }

  const picked = await dialog.showOpenDialog({
    title: 'Where should the copies go?',
    message: 'Choose your USB stick',
    properties: ['openDirectory', 'createDirectory'],
    buttonLabel: 'Copy here',
  })
  if (picked.canceled || picked.filePaths.length === 0) return

  // Into a folder of its own, dated. Emptying a stick into its root leaves a
  // hundred loose files nobody can tell apart, and the second copy overwrites
  // the first with no record that it did.
  const stamp = new Date().toISOString().slice(0, 10)
  const target = path.join(picked.filePaths[0], `violy-backups-${stamp}`)

  try {
    mkdirSync(target, { recursive: true })
    for (const backup of backups) {
      copyFileSync(backup.path, path.join(target, backup.name))
    }
  } catch (error) {
    await dialog.showMessageBox({
      type: 'error',
      title: 'Violy Store',
      message: 'Could not copy the backups.',
      detail: [
        error && error.message ? error.message : 'The stick may be full or write-protected.',
        '',
        'Nothing on this computer has been changed.',
      ].join(NEWLINE),
      buttons: ['OK'],
    })
    return
  }

  const { response } = await dialog.showMessageBox({
    type: 'info',
    title: 'Violy Store',
    message: `${backups.length} backup${backups.length === 1 ? '' : 's'} copied.`,
    detail: [
      target,
      '',
      'Keep the stick somewhere other than beside the laptop. A copy that burns with the shop is not a copy.',
    ].join(NEWLINE),
    buttons: ['Show me', 'OK'],
    defaultId: 1,
    cancelId: 1,
  })
  if (response === 0) shell.openPath(target)
}

// ── staying awake, and staying up ─────────────────────────────────────────

/** Held for the life of the app; released only when it quits. */
let awakeBlockerId = null

/**
 * Stops Windows sleeping while the till is open.
 *
 * A laptop that sleeps mid-sale wakes to a page rendered before the sleep, and
 * the operator carries on typing into a screen that no longer matches the
 * server. `prevent-app-suspension` is the weaker of the two blockers on
 * purpose: it lets the SCREEN switch off, which saves the panel and the power
 * bill, while keeping the machine and its server running.
 */
function stayAwake() {
  try {
    if (awakeBlockerId === null) {
      awakeBlockerId = powerSaveBlocker.start('prevent-app-suspension')
    }
  } catch {
    // Not fatal. A sleeping laptop is an annoyance; failing to open is not.
  }
}

/**
 * Notices when the server has died, and starts it again.
 *
 * Without this the window simply goes blank — `next start` is a child process
 * and it can be killed by an update, an out-of-memory moment, or somebody
 * closing the wrong console window. From the counter that is indistinguishable
 * from the app being broken, and there is nothing on screen to do about it.
 *
 * Deliberately quiet. A restart that works needs no announcement, and one
 * dialog per blip would teach her to click past dialogs. It only speaks up
 * when it has tried and failed.
 */
function watchServer() {
  let restarting = false

  setInterval(async () => {
    if (restarting) return
    if (await portInUse()) return

    restarting = true
    try {
      await startServer()
      const up = await waitForServer(60_000)
      if (up) {
        if (mainWindow && !mainWindow.isDestroyed()) mainWindow.reload()
      } else {
        await dialog.showMessageBox({
          type: 'error',
          title: 'Violy Store',
          message: 'The app stopped and could not start again.',
          detail:
            'Please close it and open it again. If it still does not work, turn the computer off and on. Your data is safe — nothing is lost by restarting.',
          buttons: ['OK'],
        })
      }
    } finally {
      restarting = false
    }
  }, WATCH_TICK_MS)
}

// ── saving a document as a PDF ─────────────────────────────────────────────

/** A4 and the 80mm receipt roll, in inches — what `printToPDF` measures in. */
const A4 = { width: 8.27, height: 11.69 }
const ROLL_WIDTH = 80 / 25.4

/**
 * How long one 80mm page is.
 *
 * There is no "as long as it needs to be" here. `printToPDF` wants a fixed
 * height, Chromium does not resolve `@page { size: 80mm auto }` to the content
 * height, and measuring the page on screen does not answer it either — the
 * print stylesheet reflows the whole document (the item table becomes a
 * stacked list on the roll), so the on-screen height is not the printed one.
 * Measured, that guess was short and spilled onto a second page.
 *
 * A fixed 12in page is the honest answer instead. On a thermal roll a page
 * break is just where the paper is cut, which is what a long receipt does
 * anyway; and a receipt that fits — nearly all of them — comes out as one
 * sheet with the tail trimmed by the printer's own auto-cut.
 */
const ROLL_PAGE_HEIGHT = 12

/**
 * Strips anything Windows will not accept in a file name.
 *
 * The name arrives from the page, which builds it from a document reference
 * like `SR-2026-0042`. Sanitised here anyway rather than trusted: this is the
 * side of the bridge that touches the disk, and a name is the only thing it
 * takes from the other side.
 */
function safeFileName(raw) {
  const cleaned = String(raw ?? '')
    .replace(/[<>:"/\\|?*\x00-\x1f]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 80)
  return cleaned === '' ? 'document' : cleaned
}

/**
 * Renders whatever the window is showing to a PDF in the Downloads folder.
 *
 * `printToPDF` runs the page through the same print pipeline `Ctrl+P` does, so
 * every `data-print="hide"` rule already written for paper applies here too and
 * the app's own chrome stays off the document. That is the whole reason this is
 * a shell feature rather than a PDF library: there is no second layout to build
 * and none to drift.
 *
 * Downloads, not a save dialog. A file picker is a place to get lost, and
 * Downloads is both where Windows suggests and where Messenger's attach button
 * opens — which is what a receipt is usually for.
 *
 * The roll is printed as ONE long page rather than a stack of 80mm sheets: a
 * receipt cut across three pages is not a receipt. Its height comes from the
 * page, which is the only side that can measure the rendered document.
 */
async function savePdf(webContents, options) {
  const paper = options?.paper === 'roll' ? 'roll' : 'a4'
  const fileName = `${safeFileName(options?.fileName)}.pdf`
  const target = path.join(app.getPath('downloads'), fileName)

  try {
    const pdf = await webContents.printToPDF({
      pageSize: paper === 'roll' ? { width: ROLL_WIDTH, height: ROLL_PAGE_HEIGHT } : A4,
      margins: paper === 'roll' ? { top: 0.16, bottom: 0.16, left: 0.16, right: 0.16 } : undefined,
      printBackground: true,
    })
    writeFileSync(target, pdf)
    return { ok: true, path: target }
  } catch {
    return { ok: false, error: 'Could not save the PDF.' }
  }
}

ipcMain.handle('violy:save-pdf', async (event, options) => {
  const result = await savePdf(event.sender, options)
  if (!result.ok) return result

  const { response } = await dialog.showMessageBox({
    type: 'info',
    title: 'Violy Store',
    message: 'Saved to your Downloads folder.',
    detail: path.basename(result.path),
    buttons: ['Open it', 'Show the folder', 'OK'],
    defaultId: 2,
    cancelId: 2,
  })

  if (response === 0) shell.openPath(result.path)
  if (response === 1) shell.showItemInFolder(result.path)
  return result
})

/**
 * Printing straight to the receipt printer, with no dialog.
 *
 * The dialog is four decisions — destination, paper, margins, Print — taken
 * afresh for every single receipt, and three of the four have the same answer
 * every time. `silent: true` with a remembered device name takes them once.
 *
 * `printBackground` is on so the document looks like the PDF and the screen;
 * off, the shaded totals block prints as bare text and the two copies of the
 * same receipt no longer match.
 *
 * A failure here is reported rather than swallowed. A till that says nothing
 * when the paper does not come out teaches the operator to press Print twice,
 * and then to distrust it when two receipts appear.
 */
ipcMain.handle('violy:print', async (event, options) => {
  const deviceName = typeof options?.deviceName === 'string' ? options.deviceName : ''
  const roll = options?.paper === 'roll'

  return new Promise((resolve) => {
    event.sender.print(
      {
        silent: true,
        printBackground: true,
        // Empty means the system default, which is what `print` already does
        // with the key absent — passing '' explicitly is the same thing said
        // out loud.
        ...(deviceName ? { deviceName } : {}),
        // The roll's margins live in the page CSS; asking for none here stops
        // the driver adding its own on top and pushing the total off the edge.
        margins: roll ? { marginType: 'none' } : { marginType: 'default' },
      },
      (ok, reason) => {
        if (ok) resolve({ ok: true })
        else resolve({ ok: false, error: reason || 'The printer did not accept it.' })
      },
    )
  })
})

/** What Windows says is available, newest API first. */
ipcMain.handle('violy:list-printers', async (event) => {
  try {
    const printers = await event.sender.getPrintersAsync()
    return printers.map((printer) => ({
      name: printer.name,
      displayName: printer.displayName || printer.name,
      isDefault: !!printer.isDefault,
    }))
  } catch {
    return []
  }
})

// ── updates ───────────────────────────────────────────────────────────────

/** Where the shop laptop looks for new builds. Public, and read-only.
 *  One definition, shared with the app and the updater — see
 *  `release-channel.json`. */
const CHANNEL = require('../release-channel.json')
const MANIFEST_URL = `${CHANNEL.baseUrl}/${CHANNEL.manifestFile}`

/**
 * Which build this copy is. Absent means it was installed from source.
 */
function installedBuild() {
  try {
    const raw = readFileSync(path.join(ROOT, 'release.json'), 'utf8')
    const value = JSON.parse(raw)
    return Number.isInteger(value.build) ? value : null
  } catch {
    return null
  }
}

/**
 * Asks the public releases channel whether there is a newer build.
 *
 * No git. It used to run `git fetch` and compare commits, which meant this
 * laptop needed git installed AND signed in to GitHub, because the source
 * repository is private — two things to set up and a credential that expires
 * quietly. Now it is one small JSON file over plain HTTPS.
 *
 * Times out deliberately short: the shop's connection is not guaranteed, and a
 * check that hangs must never be the reason the till is slow to open.
 */
async function checkForUpdates() {
  const installed = installedBuild()
  if (!installed) return { available: false, reachable: true, fromSource: true, notes: [] }

  try {
    // `?t=` busts the CDN cache — raw.githubusercontent.com holds a manifest
    // for five minutes, and `no-store` only governs this machine's own cache.
    const response = await fetch(`${MANIFEST_URL}?t=${Date.now()}`, {
      cache: 'no-store',
      signal: AbortSignal.timeout(8000),
    })
    if (!response.ok) return { available: false, reachable: false, notes: [] }

    const value = await response.json()
    if (!Number.isInteger(value.build)) return { available: false, reachable: false, notes: [] }

    return {
      available: value.build > installed.build,
      reachable: true,
      version: String(value.version ?? value.build),
      notes: Array.isArray(value.notes) ? value.notes.filter((n) => typeof n === 'string') : [],
    }
  } catch {
    return { available: false, reachable: false, notes: [] }
  }
}

function notifyUpdate(version) {
  if (!Notification.isSupported()) return
  new Notification({
    title: 'Violy Store — update ready',
    body: `Version ${version} is ready to install.`,
  }).show()
}

/**
 * Hands over to the updater and closes.
 *
 * The updater has to stop this server and replace files the app holds open,
 * which cannot happen from inside the process doing the holding — Windows
 * refuses, as `prisma generate` in this project has already demonstrated with
 * EPERM. So it runs in its own console window and this shell gets out of the
 * way.
 */
function runUpdater() {
  spawn('cmd.exe', ['/c', 'start', '"Violy Store update"', 'cmd', '/k', 'node', 'scripts/update.mjs'], {
    cwd: ROOT,
    detached: true,
    stdio: 'ignore',
  }).unref()

  stopServer()
  app.exit(0)
}

async function offerUpdate({ silentWhenNone } = { silentWhenNone: true }) {
  const status = await checkForUpdates()

  if (!status.available) {
    if (!silentWhenNone) {
      await dialog.showMessageBox({
        type: 'info',
        title: 'Violy Store',
        message: status.fromSource
          ? 'This copy was installed from source, so it updates by rebuilding rather than downloading.'
          : status.reachable
            ? 'You have the latest version.'
            : 'Could not check for updates. Check the internet connection.',
        buttons: ['OK'],
      })
    }
    return
  }

  notifyUpdate(status.version)

  const { response } = await dialog.showMessageBox({
    type: 'question',
    title: 'Violy Store — update ready',
    message: `Version ${status.version} is ready to install.`,
    // Plain sentences, capped: a wall of twenty release notes is not a choice
    // anybody can make.
    detail: `${status.notes.slice(0, 6).join('\n')}${
      status.notes.length > 6 ? `\n…and ${status.notes.length - 6} more.` : ''
    }\n\nThe app will close while it installs, then open again by itself. Your data is backed up first.`,
    buttons: ['Install now', 'Later'],
    defaultId: 1,
    cancelId: 1,
  })

  if (response === 0) runUpdater()
}

// ── start on boot ─────────────────────────────────────────────────────────

function startsOnLogin() {
  return app.getLoginItemSettings().openAtLogin
}

function setStartsOnLogin(enabled) {
  // `args: [ROOT]` is not optional. This app is not a packaged executable —
  // `process.execPath` is Electron's own binary, and launching that alone
  // opens Electron's default window, not the till. It needs the app directory
  // as its argument, exactly as `electron .` passes it.
  app.setLoginItemSettings({
    openAtLogin: enabled,
    path: process.execPath,
    args: [ROOT],
  })
  buildMenu()
}

// ── windows ───────────────────────────────────────────────────────────────

function createSplash() {
  splashWindow = new BrowserWindow({
    width: 420,
    height: 300,
    frame: false,
    resizable: false,
    center: true,
    show: true,
    backgroundColor: '#f4f0e6',
  })
  splashWindow.loadFile(path.join(__dirname, 'splash.html'))
}

function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    show: false,
    backgroundColor: '#f4f0e6',
    title: 'Violy Store',
    icon: path.join(__dirname, 'icon.png'),
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      preload: path.join(__dirname, 'preload.js'),
    },
  })

  mainWindow.loadURL(URL)

  mainWindow.once('ready-to-show', () => {
    if (splashWindow && !splashWindow.isDestroyed()) splashWindow.destroy()
    splashWindow = null
    mainWindow.maximize()
    mainWindow.show()
  })

  // Anything that is not this app opens in the real browser rather than
  // replacing the till with a web page she cannot navigate back from.
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (!url.startsWith(URL)) shell.openExternal(url)
    return { action: 'deny' }
  })

  mainWindow.on('closed', () => {
    mainWindow = null
  })
}

function buildMenu() {
  const template = [
    {
      label: 'Violy Store',
      submenu: [
        { label: 'Reload', accelerator: 'F5', click: () => mainWindow?.reload() },
        { type: 'separator' },
        { label: 'Check for updates…', click: () => offerUpdate({ silentWhenNone: false }) },
        {
          label: 'Start when the computer turns on',
          type: 'checkbox',
          checked: startsOnLogin(),
          click: (item) => setStartsOnLogin(item.checked),
        },
        { type: 'separator' },
        { label: 'Back up now', click: () => backupNowFromMenu() },
        { label: 'Go back to a saved copy…', click: () => restoreFromMenu() },
        { label: 'Copy backups to a USB stick…', click: () => copyBackupsToStick() },
        { label: 'Open backups folder', click: () => shell.openPath(path.join(ROOT, 'backups')) },
        { type: 'separator' },
        { label: 'Quit', accelerator: 'Alt+F4', role: 'quit' },
      ],
    },
    {
      label: 'Edit',
      submenu: [
        { role: 'undo' },
        { role: 'redo' },
        { type: 'separator' },
        { role: 'cut' },
        { role: 'copy' },
        { role: 'paste' },
        { role: 'selectAll' },
      ],
    },
    {
      label: 'Help',
      submenu: [
        {
          label: 'About',
          click: () =>
            dialog.showMessageBox({
              type: 'info',
              title: 'Violy Store',
              message: 'Violy Store — Point of Sale',
              detail: 'Made by Wrenz.',
              buttons: ['OK'],
            }),
        },
      ],
    },
  ]
  Menu.setApplicationMenu(Menu.buildFromTemplate(template))
}

// ── lifecycle ─────────────────────────────────────────────────────────────

// One instance only. A second launch focuses the window that exists instead
// of starting a rival server against the same database.
if (!app.requestSingleInstanceLock()) {
  app.exit(0)
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore()
      mainWindow.focus()
    }
  })

  app.whenReady().then(async () => {
    buildMenu()
    createSplash()

    await startServer()
    const up = await waitForServer()

    if (!up) {
      if (splashWindow && !splashWindow.isDestroyed()) splashWindow.destroy()
      await dialog.showMessageBox({
        type: 'error',
        title: 'Violy Store',
        message: 'The app could not start.',
        detail:
          'Try turning the computer off and on again. If it still does not open, tell whoever looks after this app.',
        buttons: ['Close'],
      })
      app.exit(1)
      return
    }

    createMainWindow()

    // A backup at launch, and one every so often after that. Silent on
    // purpose: this is the one that has to happen on the mornings she is busy,
    // and anything she has to acknowledge is something she will eventually
    // click past. It runs BEFORE the update prompt, so the copy exists whether
    // or not she chooses to install anything.
    void runBackup({ auto: true })
    setInterval(() => void runBackup({ auto: true }), BACKUP_TICK_MS)

    // After the window exists, so neither can delay the till opening.
    stayAwake()
    watchServer()

    // Checked AFTER the POS is up, never before: an update prompt must not
    // stand between her and a customer waiting at the counter.
    setTimeout(() => offerUpdate({ silentWhenNone: true }), 4_000)
  })

  app.on('window-all-closed', () => {
    stopServer()
    app.quit()
  })

  // The server is this shell's child; leaving it running after the window
  // closes would hold the port and the database file.
  app.on('before-quit', stopServer)
  process.on('exit', stopServer)
}
