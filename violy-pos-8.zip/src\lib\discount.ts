/**
 * Every discount this app grants, resolved in one place.
 *
 * Two kinds of discount exist and they compose:
 *
 * - A customer's **standing** discount, configured once on their record. It is
 *   either a peso amount or a percentage, and it applies on one of three
 *   bases: per unit (scoped to chosen categories), once per order against
 *   those same categories, or against the whole order.
 * - An **ad-hoc** discount typed at the counter for one order, which either
 *   stacks on top of the standing one or replaces it.
 * - A **line** discount typed at the counter against one tallied product,
 *   which replaces whatever that line would otherwise have been given.
 *
 * `computeOrderTotals` is used by BOTH the order screen's live preview and the
 * server action that commits the sale. That sharing is the point: a preview
 * and a commit that each do their own arithmetic will eventually disagree, and
 * the disagreement is money — the figure she read out loud to the customer
 * against the figure that hit the books.
 */

import { lineTotal } from './money'

import { ANY_UNIT, unitMatches } from './unit'

export type DiscountKind = 'AMOUNT' | 'PERCENT'
export type DiscountBasis = 'PER_UNIT' | 'ORDER_TOTAL' | 'ONCE_PER_ORDER'
export type OrderDiscountMode = 'STACK' | 'REPLACE'

/**
 * What a standing discount covers.
 *
 * Three answers, and they are exclusive rather than additive: a rule names
 * everything, or a set of brands, or a set of products. Making them additive
 * would allow one rule to cover a brand AND a product inside it, and then
 * something has to decide which figure wins on the overlap — a decision with
 * no good answer that a shop can explain to a customer.
 *
 * When several RULES per customer arrive, the settled precedence is
 * most-specific-first: a rule naming the product beats one naming its brand,
 * which beats one covering everything. One discount per line, always
 * traceable to one rule.
 */
export type DiscountScope = 'ALL' | 'CATEGORIES' | 'PRODUCTS'

export function isDiscountScope(value: string): value is DiscountScope {
  return value === 'ALL' || value === 'CATEGORIES' || value === 'PRODUCTS'
}

/** 100.00%. Nothing may discount more than the thing costs. */
export const MAX_BPS = 10_000

export function isDiscountKind(value: string): value is DiscountKind {
  return value === 'AMOUNT' || value === 'PERCENT'
}

export function isDiscountBasis(value: string): value is DiscountBasis {
  return value === 'PER_UNIT' || value === 'ORDER_TOTAL' || value === 'ONCE_PER_ORDER'
}

export function isOrderDiscountMode(value: string): value is OrderDiscountMode {
  return value === 'STACK' || value === 'REPLACE'
}

export type CustomerDiscount = {
  kind: DiscountKind
  /** Centavos off. Per unit when basis is PER_UNIT, off the order otherwise. */
  amountCentavos: number
  /** Basis points off — 500 is 5.00%. Read only when kind is PERCENT. */
  bps: number
  basis: DiscountBasis
  /**
   * What the rule covers. Read when basis is PER_UNIT or ONCE_PER_ORDER —
   * both are scoped, and differ only in whether the amount comes off every
   * matching unit or just once. An ORDER_TOTAL discount is against the order
   * as a whole and has no per-line scope to check.
   */
  scope: DiscountScope
  /**
   * Categories the discount covers when `scope` is CATEGORIES. Empty means it
   * applies to nothing, which is inert rather than an error — a stored amount
   * with no scope.
   */
  categoryIds: ReadonlySet<number>
  /**
   * Individual products it covers when `scope` is PRODUCTS.
   *
   * Named products beat brands as an ARRANGEMENT, not as arithmetic: "₱20 off
   * Atlas Grower" is a real thing a shop agrees to, and scoping it to the
   * whole Atlas brand would give away the other nine products in it.
   */
  productIds: ReadonlySet<number>
  /**
   * Which unit the discount is per — "bag", "kilo". Empty means every unit.
   *
   * A second scope on top of the categories, not a replacement for one. A
   * category can hold both sizes: Pigrolac sells sacks and a 1kg Booster, so
   * "₱20 off Pigrolac per unit" would otherwise take ₱20 off a ₱110 kilo pack
   * as readily as off a ₱2,050 sack.
   */
  unit: string
}

export type OrderDiscount = {
  kind: DiscountKind
  amountCentavos: number
  bps: number
  mode: OrderDiscountMode
}

export const NO_ORDER_DISCOUNT: OrderDiscount = {
  kind: 'AMOUNT',
  amountCentavos: 0,
  bps: 0,
  mode: 'STACK',
}

/**
 * Reads a customer row's four discount columns into the shape the pipeline
 * wants. Structurally typed rather than importing Prisma's `Customer`, so the
 * client-side preview can call it with the same object the server does.
 *
 * An unrecognised string falls back to the historical behaviour rather than
 * throwing. SQLite has no enums, so a bad value is reachable in principle —
 * and refusing to price an order because a discount column holds nonsense
 * would stop a sale over something the operator cannot see or fix from the
 * counter.
 */
/**
 * Every standing rule a customer holds, newest last.
 *
 * A customer may hold several: "P20 off Atlas bags" and "P300 off a sack of
 * Broodsow" are two arrangements, not one that overwrites the other.
 */
export function customerDiscountsOf(customer: {
  discountRules?: readonly {
    kind: string
    amountCentavos: number
    bps: number
    basis: string
    unit: string
    scope: string
    categories: readonly { id: number }[]
    products: readonly { id: number }[]
  }[]
}): CustomerDiscount[] {
  return (customer.discountRules ?? []).map((rule) => ({
    kind: isDiscountKind(rule.kind) ? rule.kind : 'AMOUNT',
    amountCentavos: rule.amountCentavos,
    bps: rule.bps,
    basis: isDiscountBasis(rule.basis) ? rule.basis : 'PER_UNIT',
    unit: rule.unit ?? ANY_UNIT,
    scope: isDiscountScope(rule.scope) ? rule.scope : 'CATEGORIES',
    categoryIds: new Set(rule.categories.map((category) => category.id)),
    productIds: new Set(rule.products.map((product) => product.id)),
  }))
}

export function customerDiscountOf(customer: {
  discountKind: string
  discountCentavos: number
  discountBps: number
  discountBasis: string
  discountUnit?: string
  discountScope?: string
  discountCategories: readonly { id: number }[]
  discountProducts?: readonly { id: number }[]
}): CustomerDiscount {
  return {
    kind: isDiscountKind(customer.discountKind) ? customer.discountKind : 'AMOUNT',
    amountCentavos: customer.discountCentavos,
    bps: customer.discountBps,
    basis: isDiscountBasis(customer.discountBasis) ? customer.discountBasis : 'PER_UNIT',
    // Optional, and defaulting to "every unit": a customer row written before
    // this column existed has no value for it, and must keep pricing exactly
    // as it did.
    unit: customer.discountUnit ?? ANY_UNIT,
    // Optional and defaulting to CATEGORIES, like `unit` above: a row written
    // before the column existed must keep scoping exactly as it did.
    scope:
      customer.discountScope !== undefined && isDiscountScope(customer.discountScope)
        ? customer.discountScope
        : 'CATEGORIES',
    categoryIds: new Set(customer.discountCategories.map((category) => category.id)),
    productIds: new Set((customer.discountProducts ?? []).map((product) => product.id)),
  }
}

/** The ad-hoc discount as it arrives from the browser, before validation. */
export type OrderDiscountInput = {
  kind: string
  amountCentavos: number
  bps: number
  mode: string
}

/**
 * The write boundary for an ad-hoc discount. Both `kind` and `mode` are
 * validated at runtime rather than trusted from the type, for the same reason
 * `isLedgerEntryType` exists: these cross a Server Action boundary, so the
 * compiler's word for what the client sent is not evidence.
 *
 * A missing discount is not an error — it is the ordinary case.
 */
export function validateOrderDiscount(
  input: OrderDiscountInput | null | undefined,
): { ok: true; value: OrderDiscount } | { ok: false; error: string } {
  if (!input) return { ok: true, value: NO_ORDER_DISCOUNT }

  if (!isDiscountKind(input.kind)) {
    return { ok: false, error: 'Unrecognised discount type.' }
  }
  if (!isOrderDiscountMode(input.mode)) {
    return { ok: false, error: 'Unrecognised discount mode.' }
  }
  if (!Number.isInteger(input.amountCentavos) || input.amountCentavos < 0) {
    return { ok: false, error: 'The discount must be a whole, non-negative amount.' }
  }
  if (!Number.isInteger(input.bps) || input.bps < 0 || input.bps > MAX_BPS) {
    return { ok: false, error: 'The discount percentage must be between 0 and 100.' }
  }

  return {
    ok: true,
    value: {
      kind: input.kind,
      amountCentavos: input.amountCentavos,
      bps: input.bps,
      mode: input.mode,
    },
  }
}

/**
 * The write boundary for a discount typed against one line.
 *
 * Checked here rather than trusted, for the same reason `validateOrderDiscount`
 * exists: this crosses a Server Action boundary, so the compiler's word for
 * what the client sent is not evidence. Absent is the ordinary case, not an
 * error.
 *
 * Returns an error message, or null when the value is acceptable.
 */
export function validateLineDiscount(value: number | undefined): string | null {
  if (value === undefined) return null
  if (!Number.isInteger(value) || value < 0) {
    return 'A line discount must be a whole, non-negative amount.'
  }
  return null
}

/**
 * Combines the line discounts of two rows for the same product.
 *
 * The counter cannot produce a duplicate — quantities are held in a Map keyed
 * by product id — so this only fires for a caller assembling the payload
 * itself. The larger of the two wins: deterministic, and it errs toward the
 * customer rather than quietly discarding a figure somebody typed.
 */
export function mergeLineDiscounts(a: number | undefined, b: number | undefined): number {
  return Math.max(a ?? 0, b ?? 0)
}

export type DiscountLineInput = {
  productId: number
  quantity: number
  priceCentavos: number
  categoryId: number
  /** The product's unit, so a discount scoped to bags skips the kilo lines. */
  unit: string
  /**
   * A discount typed at the counter against THIS line, per unit, in centavos.
   * Absent or zero on an ordinary line.
   *
   * Whether it comes on top of the customer's standing discounts or instead
   * of them is `order.mode`, the single "on top of theirs / instead of theirs"
   * choice that governs every ad-hoc discount on the sale.
   *
   * It used to be a second, separate control that governed only the per-unit
   * overlap on this one line. That was defensible in theory and a lie in
   * practice: a customer whose standing rule was ORDER-LEVEL kept it in full
   * while the control said "instead of theirs", so ₱800 typed here plus their
   * ₱500 came off together and choosing either setting changed nothing.
   *
   * Either way it touches only this LINE. A standing whole-order or
   * once-an-order discount is not per-line and is untouched by it.
   */
  manualDiscountPerUnitCentavos?: number
  /**
   * Whether that figure is per unit or for the line as a whole.
   *
   * EACH is the default and the historical behaviour. ONCE means "₱500 off
   * this line", however many sacks are on it — which is how a shopkeeper
   * usually says it, and was previously only expressible by dividing in her
   * head.
   *
   * ONCE comes off the LINE, not the units, and is stored in its own column.
   * It used to be divided into a per-unit figure, which meant ₱500 across
   * three sacks became ₱166.66 each and took ₱499.98 — a figure nobody typed
   * and nobody could explain to a customer. The amount she says is now the
   * amount that comes off, exactly.
   */
  manualDiscountMode?: LineDiscountMode
}

/** Whether a typed line discount is per unit or for the whole line. */
export type LineDiscountMode = 'EACH' | 'ONCE'

export function isLineDiscountMode(value: string): value is LineDiscountMode {
  return value === 'EACH' || value === 'ONCE'
}

/** The typed figure, when it is meant PER UNIT. Zero when it is a once. */
export function manualPerUnitOf(line: {
  manualDiscountPerUnitCentavos?: number
  manualDiscountMode?: LineDiscountMode
}): number {
  const typed = line.manualDiscountPerUnitCentavos ?? 0
  if (typed <= 0) return 0
  return line.manualDiscountMode === 'ONCE' ? 0 : typed
}

/** The typed figure, when it is meant for the WHOLE line. Zero otherwise. */
export function manualPerLineOf(line: {
  manualDiscountPerUnitCentavos?: number
  manualDiscountMode?: LineDiscountMode
}): number {
  const typed = line.manualDiscountPerUnitCentavos ?? 0
  if (typed <= 0) return 0
  return line.manualDiscountMode === 'ONCE' ? typed : 0
}

export type DiscountedLine = DiscountLineInput & {
  /** The per-unit discount actually granted; stored as `discountAtSale`. */
  discountPerUnitCentavos: number
  /** A discount against the whole line; stored as `lineDiscountAtSale`. Never
   *  divided, so "₱500 off this line" is exactly ₱500. */
  lineDiscountCentavos: number
  lineTotalCentavos: number
}

export type OrderTotals = {
  lines: DiscountedLine[]
  /** List price × quantity, summed, before any discount at all. */
  subtotalCentavos: number
  /** Everything taken off per unit, summed across lines — a standing per-unit
   *  discount, a figure typed against one line, or a mix of both. */
  lineDiscountCentavos: number
  /** The order-level slice of the customer's standing discount. */
  customerDiscountCentavos: number
  /** The ad-hoc discount typed at the counter. */
  orderDiscountCentavos: number
  /** Every discount added together — what a receipt prints on one line. */
  totalDiscountCentavos: number
  /** What is actually owed. Never negative. */
  totalCentavos: number
}

/** Rounds half away from zero, like every other money conversion here. */
export function percentOf(centavos: number, bps: number): number {
  return Math.round((centavos * bps) / MAX_BPS)
}

/** Whether a discount would actually take anything off. */
export function hasOrderDiscount(discount: OrderDiscount | null): boolean {
  if (!discount) return false
  return discount.kind === 'PERCENT' ? discount.bps > 0 : discount.amountCentavos > 0
}

/**
 * Whether a line falls inside a scoped discount — both categories and unit.
 *
 * Shared by PER_UNIT and ONCE_PER_ORDER on purpose. The two bases differ only
 * in how often the amount comes off, never in what they cover, and writing the
 * scope test twice is how they would eventually stop agreeing.
 */
function lineInScope(line: DiscountLineInput, customer: CustomerDiscount): boolean {
  if (!unitMatches(line.unit, customer.unit)) return false

  switch (customer.scope) {
    case 'ALL':
      return true
    case 'PRODUCTS':
      return customer.productIds.has(line.productId)
    case 'CATEGORIES':
    default:
      return customer.categoryIds.has(line.categoryId)
  }
}

/** The customer's standing per-unit rate for this line, before anything typed. */
function standingPerUnitFor(
  line: DiscountLineInput,
  rules: readonly CustomerDiscount[],
): number {
  const rule = ruleFor(line, rules, 'PER_UNIT')
  if (!rule) return 0

  const raw =
    rule.kind === 'PERCENT' ? percentOf(line.priceCentavos, rule.bps) : rule.amountCentavos

  return Math.max(0, raw)
}

/**
 * How specific a rule is about a line. Higher wins.
 *
 * A rule naming the product beats one naming its brand, which beats one
 * covering everything. Naming the UNIT is a further narrowing on top of any of
 * them, so it adds a point rather than forming a tier of its own.
 */
function specificityFor(line: DiscountLineInput, rule: CustomerDiscount): number {
  const base = rule.scope === 'PRODUCTS' ? 4 : rule.scope === 'CATEGORIES' ? 2 : 1
  return base + (rule.unit === ANY_UNIT ? 0 : 1)
}

/**
 * The one rule that applies to a line, or null.
 *
 * ONE, not the sum. Adding overlapping rules together is how a line reaches
 * free without anybody intending it, and how a figure on a receipt stops being
 * traceable to a thing the shop agreed. Most specific wins; ties break on the
 * larger discount, and then on the older rule, so the answer never depends on
 * the order rows came back in.
 */
function ruleFor(
  line: DiscountLineInput,
  rules: readonly CustomerDiscount[],
  basis: DiscountBasis,
): CustomerDiscount | null {
  let best: CustomerDiscount | null = null
  let bestScore = -1
  let bestValue = -1

  for (const rule of rules) {
    if (rule.basis !== basis) continue
    if (basis !== 'ORDER_TOTAL' && !lineInScope(line, rule)) continue

    const score = basis === 'ORDER_TOTAL' ? 1 : specificityFor(line, rule)
    const value =
      rule.kind === 'PERCENT' ? percentOf(line.priceCentavos, rule.bps) : rule.amountCentavos

    if (score > bestScore || (score === bestScore && value > bestValue)) {
      best = rule
      bestScore = score
      bestValue = value
    }
  }

  return best
}

function perUnitDiscountFor(
  line: DiscountLineInput,
  rules: readonly CustomerDiscount[],
  mode: OrderDiscountMode,
): number {
  const standing = standingPerUnitFor(line, rules)
  const manual = manualPerUnitOf(line)

  // Both present is the only case the mode decides. STACK adds them; REPLACE
  // takes the typed figure alone, which is the default and what "instead of
  // theirs" means at the line she typed it against.
  const raw = manual > 0 ? (mode === 'STACK' ? manual + standing : manual) : standing

  // Floored at the price. A discount bigger than the item makes it free; it
  // never makes the line negative, which would have the store paying someone
  // to take the sack away.
  return Math.min(raw, line.priceCentavos)
}

/**
 * The standing discount's single order-level deduction.
 *
 * Both ORDER_TOTAL and ONCE_PER_ORDER land here rather than on a line, because
 * neither is attributable to one: they come off the order as a whole, and
 * `SaleItem.discountAtSale` stays zero for every line. That is also what a
 * receipt needs — one "Customer discount" figure, not an amount smeared across
 * lines it was never computed from.
 *
 * The difference between them is only what the amount is measured against:
 *
 * - ORDER_TOTAL takes it off everything on the order.
 * - ONCE_PER_ORDER takes it off ONCE if the order contains anything inside the
 *   scope, and nothing at all if it does not. This is the "₱20 off Atlas, but
 *   only once, however many sacks she buys" case — five sacks is ₱20 off, not
 *   ₱100.
 *
 * A PERCENT under ONCE_PER_ORDER is measured against the matching lines only,
 * which makes it arithmetically identical to the same percentage taken per
 * unit. That is not a bug in the basis: a percentage does not care how it is
 * sliced. The bases genuinely differ only for a peso amount, and the form says
 * so rather than pretending otherwise.
 */
function standingOrderDiscount(
  rules: readonly CustomerDiscount[],
  lines: readonly DiscountedLine[],
  afterLines: number,
): number {
  // Each order-level rule is taken ONCE and they are summed, unlike the
  // per-line rules where one wins. They cannot overlap the way per-line rules
  // do: "P50 off the order" and "P20 off once if there is Atlas on it" are two
  // separate arrangements, not two answers to the same question, and a shop
  // that agreed both means both. Still clamped to the order total, so they
  // cannot together take off more than the order is worth.
  let total = 0

  for (const rule of rules) {
    if (rule.basis === 'ORDER_TOTAL') {
      total +=
        rule.kind === 'PERCENT' ? percentOf(afterLines, rule.bps) : rule.amountCentavos
      continue
    }

    if (rule.basis === 'ONCE_PER_ORDER') {
      const inScope = lines.filter((line) => lineInScope(line, rule))
      if (inScope.length === 0) continue
      const scopedTotal = inScope.reduce((sum, line) => sum + line.lineTotalCentavos, 0)
      total += rule.kind === 'PERCENT' ? percentOf(scopedTotal, rule.bps) : rule.amountCentavos
    }
  }

  return clamp(total, afterLines)
}

/**
 * The whole discount pipeline, in the order the design fixed:
 *
 *   1. per-unit customer discount off each line
 *   2. order-level customer discount off that subtotal
 *   3. ad-hoc counter discount off what remains
 *
 * A percentage at step 3 is therefore taken against the already-discounted
 * figure, not the list subtotal. That ordering is arbitrary in principle but
 * has to be fixed in practice, or "10% off" means two different pesos
 * depending on which code path computed it.
 */
export function computeOrderTotals(input: {
  lines: readonly DiscountLineInput[]
  /** Every standing rule the customer holds. One rule wins per line; see
   *  `ruleFor`. A single rule may still be passed as a one-item list. */
  customer?: CustomerDiscount | readonly CustomerDiscount[] | null
  order?: OrderDiscount | null
}): OrderTotals {
  const order = input.order ?? null

  // REPLACE only bites when an ad-hoc discount was actually entered. Leaving
  // the mode on "instead of" with an empty amount field must not silently
  // strip a customer of the discount they are owed.
  // Anything she typed at the counter, on a line or against the order.
  const typedAnything =
    hasOrderDiscount(order) ||
    input.lines.some((line) => (line.manualDiscountPerUnitCentavos ?? 0) > 0)

  // ONE mode for every ad-hoc discount on the sale. "Instead of theirs" means
  // the customer's standing rules do not apply at all — not "do not apply to
  // the per-unit part of one line", which is what it used to mean and which
  // left an order-level rule running underneath it.
  //
  // It only bites when something was actually typed: leaving the toggle on
  // "instead of" with every box empty must not strip a customer of the
  // discount they are owed.
  const mode: OrderDiscountMode = order?.mode ?? 'STACK'
  const replacing = mode === 'REPLACE' && typedAnything
  // Normalised to a list once, here, so every caller may pass either and
  // nothing below has to ask which it got.
  const given = input.customer ?? null
  const rules: readonly CustomerDiscount[] = replacing
    ? []
    : given === null
      ? []
      : Array.isArray(given)
        ? given
        : [given as CustomerDiscount]


  const lines: DiscountedLine[] = input.lines.map((line) => {
    const discountPerUnitCentavos = perUnitDiscountFor(line, rules, mode)
    const afterUnits = lineTotal(line.priceCentavos - discountPerUnitCentavos, line.quantity)
    // Floored at what the line is worth: a whole-line discount can make it
    // free, never negative, the same rule every other discount here follows.
    const lineDiscountCentavos = Math.min(manualPerLineOf(line), afterUnits)
    return {
      ...line,
      discountPerUnitCentavos,
      lineDiscountCentavos,
      lineTotalCentavos: afterUnits - lineDiscountCentavos,
    }
  })

  const subtotalCentavos = input.lines.reduce(
    (total, line) => total + lineTotal(line.priceCentavos, line.quantity),
    0,
  )
  const afterLines = lines.reduce((total, line) => total + line.lineTotalCentavos, 0)
  const lineDiscountCentavos = subtotalCentavos - afterLines

  const customerDiscountCentavos = standingOrderDiscount(rules, lines, afterLines)

  const afterCustomer = afterLines - customerDiscountCentavos

  const orderDiscountCentavos =
    order && hasOrderDiscount(order)
      ? clamp(
          order.kind === 'PERCENT'
            ? percentOf(afterCustomer, order.bps)
            : order.amountCentavos,
          afterCustomer,
        )
      : 0

  return {
    lines,
    subtotalCentavos,
    lineDiscountCentavos,
    customerDiscountCentavos,
    orderDiscountCentavos,
    totalDiscountCentavos:
      lineDiscountCentavos + customerDiscountCentavos + orderDiscountCentavos,
    totalCentavos: afterCustomer - orderDiscountCentavos,
  }
}

/** Keeps a discount inside [0, ceiling]. Nothing takes off more than is there. */
function clamp(value: number, ceiling: number): number {
  return Math.min(Math.max(0, value), Math.max(0, ceiling))
}
