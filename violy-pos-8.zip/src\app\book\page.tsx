import { listCustomerBalances, getTotalUtang } from '@/server/ledger'
import { listCategoriesWithCheapest, listCustomers } from '@/server/customers'
import { listProductUnits } from '@/server/products'
import { dayKey } from '@/lib/dates'
import { CustomerList } from './CustomerList'

export const dynamic = 'force-dynamic'

type Props = {
  // `tab` drives the Customers/Bulk-payments switch — see CustomerList.
  // Read server-side (not via useSearchParams) so the initial render already
  // matches the URL, the same pattern HistoryFilters/InventoryFilters use.
  searchParams: Promise<{ tab?: string }>
}

export default async function CustomersPage({ searchParams }: Props) {
  const params = await searchParams

  // Both tabs' data are fetched together rather than branching on which is
  // active — the same choice OrderScreen makes for its Today/Recent tabs.
  // This is a low-traffic local POS; one extra query per view is cheaper
  // than the branching it would take to avoid it.
  const [rows, totalCentavos, categories, customers, units] = await Promise.all([
    listCustomerBalances(),
    getTotalUtang(),
    listCategoriesWithCheapest(),
    listCustomers(),
    listProductUnits(),
  ])

  return (
    <CustomerList
      rows={rows}
      totalCentavos={totalCentavos}
      categories={categories}
      customers={customers}
      units={units}
      todayKey={dayKey(new Date())}
      tab={params.tab === 'bulk' ? 'bulk' : 'list'}
    />
  )
}
